from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from cassandra.cluster import BatchStatement
import requests;
import sys

print(sys.argv[1])

auth_provider = PlainTextAuthProvider(
        username='tejbrdusr', password='tejbrdusr')

cluster = Cluster(contact_points=['cassandra-dbserver.sit-jiocloud.com'],port=9042,auth_provider=auth_provider);
#user_id = input('plesse enter user_id')
user_id = sys.argv[1]
print (user_id)
user_id = "'" + user_id + "'"
session = cluster.connect('boards');
sqlStr = 'SELECT board_key FROM user_board_mapping where user_id =  %s and member_type= %s allow filtering' %(user_id,'\'O\'')
print (sqlStr)
rows = session.execute(sqlStr);

for row in rows:
    batch = BatchStatement()
    print (row.board_key)
    board_key = "'" + row.board_key + "'"
    batch.add('delete from board_comment where board_key = %s' %board_key)
    batch.add('delete from board_object_comment where board_key = %s' %board_key)
    batch.add('delete from board_user_mapping where board_key = %s' %board_key)
    batch.add('delete from board_user_mapping where board_key = %s' % board_key)
    batch.add('delete from user_board_mapping where board_key = %s and user_id = %s' %(board_key,user_id))
    batch.add('delete from board_object_mapping where board_key = %s' %board_key)
    batch.add('delete from board_object_trash where board_key = %s' %board_key)
    print("Trash cleared")
    batch.add('delete from board where board_key = %s' %board_key)
    rows = session.execute(batch)

