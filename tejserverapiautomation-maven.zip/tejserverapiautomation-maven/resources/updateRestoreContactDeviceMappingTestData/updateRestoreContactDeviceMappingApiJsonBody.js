{
"snapshotId": "XXXX",
"devices": ["YYYYY"]
}
