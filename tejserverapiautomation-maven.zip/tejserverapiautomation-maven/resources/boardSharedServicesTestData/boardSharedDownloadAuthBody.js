
{
    "shareId":"b492be98e30e460495c6a2",
    "boardKey":"0f8e80c0-3f8f-11e7-b92b-89fc0e6ad4da",
    "objectKey":"b81cea058a074dd6b99160283377130e",
    "fileType":0
}
