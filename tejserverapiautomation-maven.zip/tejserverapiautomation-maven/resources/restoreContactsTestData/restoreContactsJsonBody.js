{
"snapshotId":"1",
"devices":["{deviceId}"]
}
