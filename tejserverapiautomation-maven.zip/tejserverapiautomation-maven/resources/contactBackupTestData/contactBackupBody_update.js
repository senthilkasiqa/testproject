{ 
"actTranId": "119062242372301", "hasMore": true, "isFirstTime": true, "totalRecords": 3746, "contacts":[ 
{ 
"serGuid": "120000108015", "operation":"delete", "conSrcType":"ntive", "conSrcName":"tictickAmkocontact", "vcard":
"[\"vcard\",[[\"version\",{},\"text\",\"4.0\"],[\"n\",{},\"text\",[\"testContactLN_1_160927023935\",\"testContactFN_FromJava_1_160927023935\",\"testContactAditionalN_1_160927023935\",\"\",\"Cons\"]],[\"fn\",{},\"text\",\"dude\"],[\"tel\", {\"type\":[\"work\", \"voice\"]}, \"uri\", \"tel:+16-092-702-3936\"],[\"email\",{\"type\":[\"home\"],\"pref\":\"0\"},\"text\",\"testContactEmail_1_160927023935@test.com\"]]]"
}
,{ 
"serGuid": "120000108016", "operation":"delete", "conSrcType":"ntive", "conSrcName":"tictickAmkocontact", "vcard":
"[\"vcard\",[[\"version\",{},\"text\",\"4.0\"],[\"n\",{},\"text\",[\"testContactLN_2_160927023935\",\"testContactFN_FromJava_2_160927023935\",\"testContactAditionalN_2_160927023935\",\"\",\"Cons\"]],[\"fn\",{},\"text\",\"dude\"],[\"tel\", {\"type\":[\"work\", \"voice\"]}, \"uri\", \"tel:+16-092-702-3936\"],[\"email\",{\"type\":[\"home\"],\"pref\":\"0\"},\"text\",\"testContactEmail_1_160927023935@test.com\"]]]"
}
,{ 
"serGuid": "120000108017", "operation":"delete", "conSrcType":"ntive", "conSrcName":"tictickAmkocontact", "vcard":
"[\"vcard\",[[\"version\",{},\"text\",\"4.0\"],[\"n\",{},\"text\",[\"testContactLN_3_160927023935\",\"testContactFN_FromJava_3_160927023935\",\"testContactAditionalN_3_160927023935\",\"\",\"Cons\"]],[\"fn\",{},\"text\",\"dude\"],[\"tel\", {\"type\":[\"work\", \"voice\"]}, \"uri\", \"tel:+16-092-702-3936\"],[\"email\",{\"type\":[\"home\"],\"pref\":\"0\"},\"text\",\"testContactEmail_1_160927023935@test.com\"]]]"
}
,{ 
"serGuid": "120000108006", "operation":"delete", "conSrcType":"ntive", "conSrcName":"tictickAmkocontact", "vcard":
"[\"vcard\",[[\"version\",{},\"text\",\"4.0\"],[\"n\",{},\"text\",[\"LN__NameTestcontact_20160714_10020001MergeSuggestionsCompleteDuplicateContacts_160927021842\",\"FN__NameTestcontact_20160714_10020001MergeSuggestionsCompleteDuplicateContacts_160927021842\",\"ADN_NameTestcontact_20160714_10020001MergeSuggestionsCompleteDuplicateContacts_160927021842\",\"\",\"Cons\"]],[\"fn\",{},\"text\",\"dude\"],[\"tel\", {\"type\":[\"work\", \"voice\"]}, \"uri\", \"tel:+16-092-702-1843\"],[\"email\",{\"type\":[\"home\"],\"pref\":\"0\"},\"text\",\"testContactEmail__20160714_10020001MergeSuggestionsCompleteDuplicateContacts_160927021842@test.com\"]]]"
}
,{ 
"serGuid": "120000108007", "operation":"delete", "conSrcType":"ntive", "conSrcName":"tictickAmkocontact", "vcard":
"[\"vcard\",[[\"version\",{},\"text\",\"4.0\"],[\"n\",{},\"text\",[\"LN__NameTestcontact_20160714_10020001MergeSuggestionsCompleteDuplicateContacts_160927021842\",\"FN__NameTestcontact_20160714_10020001MergeSuggestionsCompleteDuplicateContacts_160927021842\",\"ADN_NameTestcontact_20160714_10020001MergeSuggestionsCompleteDuplicateContacts_160927021842\",\"\",\"Cons\"]],[\"fn\",{},\"text\",\"dude\"],[\"tel\", {\"type\":[\"work\", \"voice\"]}, \"uri\", \"tel:+16-092-702-1843\"],[\"email\",{\"type\":[\"home\"],\"pref\":\"0\"},\"text\",\"testContactEmail__20160714_10020001MergeSuggestionsCompleteDuplicateContacts_160927021842@test.com\"]]]"
}
,{ 
"serGuid": "120000108008", "operation":"delete", "conSrcType":"ntive", "conSrcName":"tictickAmkocontact", "vcard":
"[\"vcard\",[[\"version\",{},\"text\",\"4.0\"],[\"n\",{},\"text\",[\"LN__NameTestcontact_20160714_10020001MergeSuggestionsCompleteDuplicateContacts_160927021842\",\"FN__NameTestcontact_20160714_10020001MergeSuggestionsCompleteDuplicateContacts_160927021842\",\"ADN_NameTestcontact_20160714_10020001MergeSuggestionsCompleteDuplicateContacts_160927021842\",\"\",\"Cons\"]],[\"fn\",{},\"text\",\"dude\"],[\"tel\", {\"type\":[\"work\", \"voice\"]}, \"uri\", \"tel:+16-092-702-1843\"],[\"email\",{\"type\":[\"home\"],\"pref\":\"0\"},\"text\",\"testContactEmail__20160714_10020001MergeSuggestionsCompleteDuplicateContacts_160927021842@test.com\"]]]"
}
]
}	
