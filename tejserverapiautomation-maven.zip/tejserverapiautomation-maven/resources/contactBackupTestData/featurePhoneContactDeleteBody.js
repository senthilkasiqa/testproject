{
"actTranId":"<active_transaction_id>",
"hasMore" : true,
"totalRecords":"100",
"contacts":                             

[
  { 
    "fpvcard":     
              [
                {
                	"id":"3eb0cde8d7344a84aa241ffb0cfdc94a",
                  "bday": "2015-07-10T00:00:00.000Z",
                  "anniversary": "2017-07-01T00:00:00.000Z",
                  "adr": [
                {
                    "countryName": "india",
                    "locality": "ggn",
                    "postalCode": "223125",
                    "streetAddress": "am",
                    "type": [
                        "home"
                    ]
                }
            ]
,
            "email": [
                {
                    "type": [
                        "personal"
                    ],
                    "value": "sachin@gmail.com"
                }
            ]
,
            "tel": [
                {
                    "type": [
                        "mobile"
                    ],
                    "value": "9599360496"
                }           
 ],

            "name": [
                "Sachin Senger"
            ]
,
            "givenName": [
                "Sachin"
            ]
,
            "familyName": [
                "Senger"
            ]
,
            "category": [
                ""
            ]
,
            "org": [
                "globallogic"
            ]
,
            "note": [
                "my note1"]
        }
    ] 
,
  "serGuid":"1234567",
  "versionNo":1,
  "operation":"delete",
  "conSrcType":"ntive",
  "conSrcName":"self"
                 }
]
}
