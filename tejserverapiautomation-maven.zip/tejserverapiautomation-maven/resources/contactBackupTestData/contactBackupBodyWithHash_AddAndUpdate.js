{ 
"actTranId": "119062242372302", "hasMore": false, "totalRecords": 3746, 
"contacts":[ 
	{ "dguid":"10000200001", "operation":"add", "conSrcType":"ntive", "conSrcName":"tictickAmkocontact", "fldHash":"d193c292-5f04-5510-a84c-ab6eb52fe5f1", "vcHash":"f193c292-5f04-5510-a84c-ab6eb52fe5f2", 
	"vcard":	"[\"vcard\",[[\"version\",{},\"text\",\"4.0\"],[\"n\",{},\"text\",[\"LN__NameTestcontact_20160714_10020003Contacts_Tej_11312\",\"FN__NameTestcontact_20160714_10020003Contacts_Tej_11312.\",\"ADN_NameTestcontact_20160714_10020003Contacts_Tej_11312\",\"\",\"Cons\"]],[\"fn\",{},\"text\",\"API_Automation_Testing\"],[\"tel\", {\"type\":[\"work\", \"voice\"]}, \"uri\", \"tel:+91-702-111-2725\"],[\"email\",{\"type\":[\"home\"],\"pref\":\"0\"},\"text\",\"c.singh2@globallogic.com\"]]]" 
	},
	{ "serGuid":"120000108015", "operation":"update", "conSrcType":"ntive", "conSrcName":"tictickAmkocontact", "fldHash":"d193c292-5f04-5510-a84c-ab6eb52fe5f1", "vcHash":"f193c292-5f04-5510-a84c-ab6eb52fe5f2", 
	"vcard":	"[\"vcard\",[[\"version\",{},\"text\",\"4.0\"],[\"n\",{},\"text\",[\"LN__NameTestcontact_20160714_10020003Contacts_Tej_11312\",\"FN__NameTestcontact_20160714_10020003Contacts_Tej_11312.\",\"ADN_NameTestcontact_20160714_10020003Contacts_Tej_11312\",\"\",\"Cons\"]],[\"fn\",{},\"text\",\"API_Automation_Testing\"],[\"tel\", {\"type\":[\"work\", \"voice\"]}, \"uri\", \"tel:+91-702-111-2725\"],[\"email\",{\"type\":[\"home\"],\"pref\":\"0\"},\"text\",\"c.singh2@globallogic.com\"]]]" 
	}
	]
}
