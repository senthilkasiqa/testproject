{ 
"totalRecords":10, 
"contacts":[ 
{ 
"dguid":"234535233", 
"serGuid": "100002673376",
"versionNo": 1,
"imgHash": "d8ce6ad65ea66e16a2ebd7dbd53c5b01",
"imgbinary":"<base64_encoded_photo>"
 }
]
}                
