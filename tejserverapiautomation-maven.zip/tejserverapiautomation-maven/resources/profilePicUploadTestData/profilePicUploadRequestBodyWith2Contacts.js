{ 
"totalRecords":2, 
"contacts":[ 
{ 
"dguid":"2588443523444444", 
"serGuid": "100002673376",
"versionNo": 1,
"imgbinary":"<base64_encoded_photo>"
 },
 { 
"dguid":"2588443523444444", 
"serGuid": "100002673376",
"versionNo": 1,
"imgbinary":"<base64_encoded_photo>"
 }
]
}                
