
{
	"boardName": "Sample Suggested Board",
	"boardKey": "632fc2a0-61ec-11e7-a6eb-bd0b5f5a3de9",
	"files": [
	               {
	                   "objectKey": "95eb629120c1455c88cd6d12b9667063",
	                   "sizeInBytes": 305905
	               },
	               {
	                   "objectKey": "17e711d2fcc7497a9a55a66db7c5b08e",
	                   "sizeInBytes": 308970
	               },
	               {
	                   "objectKey": "93708d9896ad4c1f90c1695adcf26419",
	                   "sizeInBytes": 304591
	               },
	               {
	                   "objectKey": "bdc0996be494452bb9fea95f213a2b89",
	                   "sizeInBytes": 294683
	               },
	               {
	                   "objectKey": "bdc0996be494452bb9fea95f213a2b89",
	                   "sizeInBytes": 294683
	               },
	               {
	                   "objectKey": "bdc0996be494452bb9fea95f213a2b89",
	                   "sizeInBytes": 294683
	               }
	         ]
 }