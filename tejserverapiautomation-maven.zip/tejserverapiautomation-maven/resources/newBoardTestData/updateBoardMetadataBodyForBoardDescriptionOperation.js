{"operations": [{"operation": "{operation}","object": {"boardKey": "{boardKey}","boardDescription":"{boardDescription}"},"correlationId" : "a8c1ee0-39fa-11e7-922c-1172"}]}
