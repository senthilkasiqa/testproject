{"objects" : [{"status": "A", "objectKey": "05d8a7360af14f638b38eb0e3759481c"}]}
