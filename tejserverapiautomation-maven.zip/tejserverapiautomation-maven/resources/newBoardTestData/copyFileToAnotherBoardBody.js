{
"copyFileList" : [{"sourceBoardKey" : "eeb60120-0884-11e7-b7cd-174eb9d01f7e", "sourceObjectKey" : "f48ebd30-0884-11e7-b7cd-174eb9d01f7e"}]
}
