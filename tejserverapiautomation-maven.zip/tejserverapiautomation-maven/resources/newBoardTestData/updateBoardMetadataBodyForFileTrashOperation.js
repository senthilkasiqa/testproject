{"operations": [{"operation": "{operation}","object": {"boardKey": "{boardKey}","objectKey": "{objectKey}"},"correlationId" : "a8c1ee0-39fa-11e7-922c-1172"}]}
