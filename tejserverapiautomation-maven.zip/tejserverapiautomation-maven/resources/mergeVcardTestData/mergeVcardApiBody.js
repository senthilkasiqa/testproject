{ 
	"masterId": "123456",
	"dupContIds": [$dupContactIds]
}       
