{"backupPhotos":"true","backupVideos":"true","backupAudios":"true","backupDocuments":"true","backupContacts":"true","backupMessages":"true","backupCallLogs":"true","internetMode":"W"}
