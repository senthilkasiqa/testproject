{"revokeAll":"N","forceLogout":"Y","devices":[{"deviceKey":"11111111-1Z1Z-1111-ZZZZ-ZZZZZZ111Z22"}]}


