{"revokeAll":"N","devices":[
{"deviceKey":"089B1EE6-6E2B-4501-B705-28393F0C9BF5"}
,{"deviceKey":"B32B3438-8CF9-46AF-AA49-8E24963076B8"}
]}