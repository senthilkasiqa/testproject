{ 
"totalRecords":10, 
"contacts":[ 
{ 
"dguid":"234535233", 
"serGuid": "100002673376",
"versionNo": 1
}
]}                
