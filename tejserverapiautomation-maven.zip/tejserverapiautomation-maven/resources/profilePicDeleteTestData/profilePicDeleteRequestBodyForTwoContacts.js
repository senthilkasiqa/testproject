{ 
"totalRecords":2, 
"contacts":[ 
{ 
"dguid":"234535233", 
"serGuid": "100002673376",
"versionNo": 1
},
{ 
"dguid":"234535233", 
"serGuid": "100002673376",
"versionNo": 1
}
]}                
