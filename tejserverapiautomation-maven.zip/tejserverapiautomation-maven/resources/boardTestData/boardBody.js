{"boardName":"${boardName}","boardType":"4","boardPermission":"P","availableoffline":"true"}

