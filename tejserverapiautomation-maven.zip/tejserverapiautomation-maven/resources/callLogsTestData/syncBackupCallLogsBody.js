{
  "calllogs": [
    {
      "dvcCallLogId": "string",
      "duration": 0,
      "name": "string",
      "phoneNo": "string",
      "dateTime": 0,
      "type": "incoming"
    }
  ]
}