{
  "calllogs": [
    {
      "dvcCallLogId": "1",
      "duration": 123455678,
      "name": "TestName",
      "phoneNo": "TestPhoneNumber",
      "dateTime": 134567895,
      "type": "incoming/outgoing/missed"
    }
  ]
}



