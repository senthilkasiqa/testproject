{"parentObjectKey":"${parentObjectKey}","objectName":"${objectName}","sourceName":"DRIVE","parentObjectType":"FU"}
