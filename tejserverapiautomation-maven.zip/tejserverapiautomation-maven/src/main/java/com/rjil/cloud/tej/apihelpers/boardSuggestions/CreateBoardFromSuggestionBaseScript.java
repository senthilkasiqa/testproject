package com.rjil.cloud.tej.apihelpers.boardSuggestions;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class CreateBoardFromSuggestionBaseScript extends BaseTestScript{

	protected static final String apiName = "CreateBoardFromSuggestionApi";
	protected static String createBoardFromSuggestionsJsonBody;
	public static String boardKey;
	
	protected String getCreateBoardFromSuggestionsURL() {
		
		FrameworkLogger.logStep("getCreateBoardFromSuggestionsURL: Start");
		
		String url = apiUrls.get("boardUrl") + serverConfig.get("getCreateBoardFromSuggestionsUrl");
		
		FrameworkLogger.logStep("getCreateBoardFromSuggestionsURL: End");
		return url;
	}
	
	
	protected String getCreateBoardFromSuggestionsURL(String urlValue) {
		
		FrameworkLogger.logStep("getCreateBoardFromSuggestionsURL: Start");
		
		String url = apiUrls.get("boardUrl") + urlValue;
		
		FrameworkLogger.logStep("getCreateBoardFromSuggestionsURL: End");
		return url;
	}
	

	protected String setCreateBoardFromSuggestionsJsonBody() throws IOException{
		
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/createBoardfromSuggestionsBody.js";
		File file = new File(path);
		createBoardFromSuggestionsJsonBody = JsonPath.parse(file).jsonString();
		return createBoardFromSuggestionsJsonBody;
	}

	
	
	protected ValidatableResponse triggerPostApiCreateBoardFromSuggestions() throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreateBoardFromSuggestions: Start");

		String strApiUrl=getCreateBoardFromSuggestionsURL();

		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, createBoardFromSuggestionsJsonBody);

		String boardKey = response.extract().path("boardKey");
		repositoryMap.put(RepositoryParameterEnum.BOARDKEY.getValue(), boardKey);

		FrameworkLogger.logStep("triggerPostApiCreateBoardFromSuggestions: BoardKey== :-> "+ boardKey);

		return response;
	}
	
	protected ValidatableResponse triggerPostApiCreateBoardFromSuggestions( Map<String, String> headerMap) throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreateBoardFromSuggestions: Start");

		
		// get url for create metadata for folder API
		String strApiUrl=getCreateBoardFromSuggestionsURL();

		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, createHeader(headerMap), createBoardFromSuggestionsJsonBody);

		String boardKey = response.extract().path("boardKey");
		repositoryMap.put(RepositoryParameterEnum.BOARDKEY.getValue(), boardKey);

		FrameworkLogger.logStep("triggerPostApiCreateBoardFromSuggestions: BoardKey== :-> "+ boardKey);

		return response;
	}
	

	protected ValidatableResponse triggerPostApiCreateBoardFromSuggestions(String urlValue) throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreateBoardFromSuggestions: Start");

		// get url for create metadata for folder API
		String strApiUrl=getCreateBoardFromSuggestionsURL(urlValue);

		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, createBoardFromSuggestionsJsonBody);

		FrameworkLogger.logStep("triggerPostApiCreateBoardFromSuggestions: BoardKey== :-> "+ boardKey);

		return response;
	}
	

	public static ValidatableResponse createBoardServiceMethod(String boardName) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("createBoardServiceMethod: Start");
		
		CreateBoardFromSuggestionBaseScript suggestedBoardBaseScript = new CreateBoardFromSuggestionBaseScript();
		suggestedBoardBaseScript.createHeader();
		createBoardFromSuggestionsJsonBody = suggestedBoardBaseScript.getCreateBoardFromSuggestionsURL();
		createBoardFromSuggestionsJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, createBoardFromSuggestionsJsonBody);
		ValidatableResponse response = suggestedBoardBaseScript.triggerPostApiCreateBoardFromSuggestions();
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Create Board Status");
		FrameworkLogger.logStep("createBoardServiceMethod: End");
		return response;
	}
	
	
	
	public static ValidatableResponse createBoardServiceMethod(Map<String, String> headerMap1,String boardName) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("createBoardServiceMethod: Start");
		CreateBoardFromSuggestionBaseScript suggestedBoardBaseScript = new CreateBoardFromSuggestionBaseScript();
		createBoardFromSuggestionsJsonBody = suggestedBoardBaseScript.getCreateBoardFromSuggestionsURL();
		createBoardFromSuggestionsJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, createBoardFromSuggestionsJsonBody);
		ValidatableResponse response = suggestedBoardBaseScript.triggerPostApiCreateBoardFromSuggestions(headerMap1);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Create Board Status");
		FrameworkLogger.logStep("createBoardServiceMethod: End");
		return response;
	}
}
