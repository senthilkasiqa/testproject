package com.rjil.cloud.tej.apihelpers.boards;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

public class MarkBoardAsFavouriteBaseScript extends BaseTestScript{
protected static final String apiName = "MarkBoardAsFavouriteApi";
	
	protected String markBoardAsFavouriteURL(String boardKey) {
		FrameworkLogger.logStep("markBoardAsFavouriteURL: Start");
		return apiUrls.get("boardUrl") + serverConfig.get("MarkBoardAsFavouriteUrl").replace("{boardKey}", boardKey);
	}
	
	
	protected String markBoardAsFavouriteURL(String urlValue, String boardKey) {
		FrameworkLogger.logStep("markBoardAsFavouriteURL: Start");
		return (apiUrls.get("boardUrl") + urlValue);
	}
  
    
    protected ValidatableResponse triggerPutApiMarkBoardAsFavourite(String boarKey) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiMarkBoardAsFavourite: Start");
 
		String strApiUrl=markBoardAsFavouriteURL(boarKey);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiMarkBoardAsFavourite: End");

    	return response;
    }
    
    protected ValidatableResponse triggerPutApiMarkBoardAsFavourite(String boarKey, Map<String, String>headerMap1) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiMarkBoardAsFavourite: Start");
 
		String strApiUrl=markBoardAsFavouriteURL(boarKey);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap1);
		FrameworkLogger.logStep("triggerPutApiMarkBoardAsFavourite: End");

    	return response;
    }
    
    protected ValidatableResponse triggerPutApiMarkBoardAsFavourite(String urlValue, String boardKey) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiMarkBoardAsFavourite: Start");
 
		String strApiUrl=markBoardAsFavouriteURL(urlValue, boardKey);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiMarkBoardAsFavourite: End");

    	return response;
    }
    
    
    public static ValidatableResponse markBoardAsFavouriteService(String boardKey) throws IOException
    {
    	MarkBoardAsFavouriteBaseScript markFavourite = new MarkBoardAsFavouriteBaseScript();
    	markFavourite.createHeader();
    	ValidatableResponse response = markFavourite.triggerPutApiMarkBoardAsFavourite(boardKey);
    	return response;
    	
    }
	
}
