/**
 * 
 */
package com.rjil.cloud.tej.apihelpers;

import java.io.IOException;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.fileupload.UploadBaseScript;
import com.rjil.cloud.tej.apihelpers.nms.CreateFolderBaseScript;
import com.rjil.cloud.tej.apihelpers.nms.DeleteMetadataBaseScript;
import com.rjil.cloud.tej.apihelpers.nms.EmptyAllTrashBaseScript;
import com.rjil.cloud.tej.apihelpers.nms.TrashMetadataBaseScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

/**
 * @author Prateek
 *
 */
public class ApiIntegrationBaseScript extends BaseTestScript {

	protected static final String apiName = "AddFileToFolder";

	/**
	 * 
	 * Service method for Adding file to folder
	 * 
	 * @throws IOException
	 * @throws VerificationFailException
	 * @throws InterruptedException 
	 */

	public static void addFileToFolderServiceMethod(String fileName) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("addFileToFolderServiceMethod:-> Start"
				+ "Going to create folder...");

		CreateFolderBaseScript.createFolderServiceMethod();
		
		FrameworkLogger.logStep("Going to upload file under folder...");

		UploadBaseScript.getUploadFileServiceMethod(fileName);

		FrameworkLogger.logStep("addFileToFolderServiceMethod:-> End");
	}

	/**
	 * Service method for creating folder and trash a file
	 * 
	 * @throws IOException
	 * @throws VerificationFailException
	 * @throws InterruptedException 
	 */
	public static void createFolderAndTrashFile() throws IOException, VerificationFailException {
		CreateFolderBaseScript.createFolderServiceMethod();
		TrashMetadataBaseScript.trashMetadataServiceMethod();
	}
	
	public static void addFileToFolderAndTrashFileServiceMethod(String fileName) throws IOException, VerificationFailException, InterruptedException{
		CreateFolderBaseScript.createFolderServiceMethod();
		UploadBaseScript.getUploadFileServiceMethod(fileName);
		TrashMetadataBaseScript.trashMetadataServiceMethod();
	}
	

	/*public static ValidatableResponse addFileToFolderServiceMethod1(String fileName) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("addFileToFolderServiceMethod:-> Start"
				+ "Going to create folder...");

		CreateFolderBaseScript.createFolderServiceMethod();
		
		FrameworkLogger.logStep("Going to upload file under folder...");

		ValidatableResponse response=UploadBaseScript.getUploadFileServiceMethod1(fileName);

		FrameworkLogger.logStep("addFileToFolderServiceMethod:-> End");
		
		return response;
	}*/

}
