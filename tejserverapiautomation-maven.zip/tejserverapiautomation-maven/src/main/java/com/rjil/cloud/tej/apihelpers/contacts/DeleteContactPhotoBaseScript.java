package com.rjil.cloud.tej.apihelpers.contacts;

import com.rjil.cloud.tej.apihelpers.BaseTestScript;

public class DeleteContactPhotoBaseScript extends BaseTestScript{

}
