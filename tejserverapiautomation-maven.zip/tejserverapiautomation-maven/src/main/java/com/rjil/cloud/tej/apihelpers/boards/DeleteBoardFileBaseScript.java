package com.rjil.cloud.tej.apihelpers.boards;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class DeleteBoardFileBaseScript extends BaseTestScript{
	
	protected static final String apiName = "DeleteBoardFile";
	protected static String deleteBoardFileJsonBody;
	public static String boardKey;
	
	protected String getDeleteBoardFileURL() {
		FrameworkLogger.logStep("getDeleteBoardFileURL: Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get("deleteBoardFileUrl");
		FrameworkLogger.logStep("getDeleteBoardFileURL: End");
		return url;
	}
	
	
	protected String setDeleteBoardFileJsonBody() throws IOException{
		
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/deleteBoardFileJsonBody.js";
		File file = new File(path);
		deleteBoardFileJsonBody = JsonPath.parse(file).jsonString();
		return deleteBoardFileJsonBody;
	}

protected String setDeleteBoardFileJsonBodyForSingleFile() throws IOException{
		
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/deleteBoardFileJsonBodyForSingleFile.js";
		File file = new File(path);
		deleteBoardFileJsonBody = JsonPath.parse(file).jsonString();
		return deleteBoardFileJsonBody;
	}
	protected ValidatableResponse triggerPostApiDeleteBoardFile() throws IOException {

		FrameworkLogger.logStep("triggerPostApiDeleteBoardFile: Start");

		String strApiUrl=getDeleteBoardFileURL();
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, deleteBoardFileJsonBody);
		FrameworkLogger.logStep("triggerPostApiDeleteBoardFile: BoardKey== :-> "+ boardKey);
		return response;
	}
	
	protected ValidatableResponse triggerPostApiDeleteBoardFile( Map<String, String> headerMap) throws IOException {

		FrameworkLogger.logStep("triggerPostApiDeleteBoardFile: Start");
		String strApiUrl=getDeleteBoardFileURL();

		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, createHeader(headerMap), deleteBoardFileJsonBody);
		FrameworkLogger.logStep("triggerPostApiDeleteBoardFile: BoardKey== :-> "+ boardKey);

		return response;
	}
	

	public static ValidatableResponse getDeleteBoardFileURLServiceMethod(String boardKey, String objectKey) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("getDeleteBoardFileURLServiceMethod: Start");
		
		DeleteBoardFileBaseScript delete = new DeleteBoardFileBaseScript();
		delete.createHeader();
		deleteBoardFileJsonBody = delete.setDeleteBoardFileJsonBodyForSingleFile();
		deleteBoardFileJsonBody  = delete.setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = delete.setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKey, deleteBoardFileJsonBody);
		ValidatableResponse response = delete.triggerPostApiDeleteBoardFile();
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("getDeleteBoardFileURLServiceMethod: End");
		return response;
	}
	
	public static ValidatableResponse getDeleteBoardFileURLServiceMethod(Map<String, String> headerMap1,String boardKey, String objectKey) throws IOException, VerificationFailException {
	
		FrameworkLogger.logStep("createBoardServiceMethod: Start");
		DeleteBoardFileBaseScript delete = new DeleteBoardFileBaseScript();
		delete.createHeader(headerMap1);
		deleteBoardFileJsonBody = delete.setDeleteBoardFileJsonBodyForSingleFile();
		deleteBoardFileJsonBody  = delete.setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = delete.setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKey, deleteBoardFileJsonBody);
		ValidatableResponse response = delete.triggerPostApiDeleteBoardFile(headerMap1);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("createBoardServiceMethod: End");
		return response;
	}
	
}
