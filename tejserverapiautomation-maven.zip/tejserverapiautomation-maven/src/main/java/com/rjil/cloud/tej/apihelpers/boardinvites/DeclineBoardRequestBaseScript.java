package com.rjil.cloud.tej.apihelpers.boardinvites;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class DeclineBoardRequestBaseScript extends BaseTestScript{
protected static final String apiName = "DeclineBoardRequestAPI";

	protected String declineBoardRequestURL(String invitationCode) {
		FrameworkLogger.logStep("declineBoardRequestURL: Start");
		return apiUrls.get("boardInviteUrl") + serverConfig.get("declineBoardRequestUrl").replace("{invitationCode}", invitationCode);
	}
	
	
	protected String declineBoardRequestURL(String urlValue, String invitationCode) {
		FrameworkLogger.logStep("declineBoardRequestURL: Start");
		return (apiUrls.get("boardInviteUrl") + urlValue);
	}
  
    
    protected ValidatableResponse triggerPutApiDeclineBoardRequest(String invitationCode) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiDeclineBoardRequest: Start");
 
		String strApiUrl=declineBoardRequestURL(invitationCode);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiDeclineBoardRequest: End");
    	return response;
    	
    }
    
    protected ValidatableResponse triggerPutApiDeclineBoardRequest(String urlValue, String invitationCode) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiDeclineBoardRequest: Start");
 
		String strApiUrl=declineBoardRequestURL(urlValue, invitationCode);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiDeclineBoardRequest: End");

    	return response;
    	
    }
    
    //overloading method for second user login
    protected ValidatableResponse triggerPutApiDeclineBoardRequest(String urlValue, String invitationCode,Map<String,String>headerMap1) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiDeclineBoardRequest: Start");
 
		String strApiUrl=declineBoardRequestURL(urlValue, invitationCode);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap1);
		FrameworkLogger.logStep("triggerPutApiDeclineBoardRequest: End");

    	return response;
    	
    }
    
    protected ValidatableResponse triggerPutApiDeclineBoardRequest(String invitationCode, Map<String,String>headerMap1) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiDeclineBoardRequest: Start");
 
		String strApiUrl=declineBoardRequestURL(invitationCode);
		Map<String,String>headerMap = createHeader(headerMap1);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiDeclineBoardRequest: End");
    	return response;
    	
    }

    //Overloading method make desired changes in Header
    protected ValidatableResponse triggerPutApiDeclineBoardRequest(String invitationCode, Map<String,String>headerMap1, String headerKey, String headerNewValue) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiDeclineBoardRequest: Start");
 
		String strApiUrl=declineBoardRequestURL(invitationCode);
		Map<String,String>headerMap = createHeader(headerMap1);
		headerMap.put(headerKey, headerNewValue);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiDeclineBoardRequest: End");
    	return response;
    	
    }

    //Overloading method remove desired header from headerMap
    protected ValidatableResponse triggerPutApiDeclineBoardRequestWithRemovedHeader(String invitationCode, Map<String,String>headerMap1, String headerKey) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiDeclineBoardRequest: Start");
 
		String strApiUrl=declineBoardRequestURL(invitationCode);
		Map<String,String>headerMap = createHeader(headerMap1);
		headerMap.remove(headerKey);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiDeclineBoardRequest: End");
    	return response;
    	
    }

    public static ValidatableResponse declineInvitationService(String invitationCode) throws IOException
    {
    	DeclineBoardRequestBaseScript decline = new DeclineBoardRequestBaseScript();
    	decline.createHeader();
    	ValidatableResponse response = decline.triggerPutApiDeclineBoardRequest(invitationCode);
    	return response;
    	
    }
    
    public static ValidatableResponse declineInvitationService(String invitationCode,Map<String, String> headerMap) throws IOException
    {
    	DeclineBoardRequestBaseScript decline = new DeclineBoardRequestBaseScript();
    	decline.createHeader(headerMap);
    	ValidatableResponse response = decline.triggerPutApiDeclineBoardRequest(invitationCode);
    	return response;
    	
    }
    

	
}
