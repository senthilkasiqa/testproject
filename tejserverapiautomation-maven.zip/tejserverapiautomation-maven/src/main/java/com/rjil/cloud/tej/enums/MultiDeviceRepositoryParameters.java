package com.rjil.cloud.tej.enums;

/**
 * @author: Chandra
 * 
 * MultiDeviceCredentialRepository Parameter Enum
 * .
 */

public enum MultiDeviceRepositoryParameters {
	
	USERID("userId"),
    DEVICEKEY("deviceKey"),
    AUTHTOKEN("authtoken"),
	REFRESHTOKEN("refreshtoken"),
	FIRSTNAME("firstName"),
	LASTNAME("lastName"),
	EMAILID("emailId");

    public String value;

    MultiDeviceRepositoryParameters(String value) {
        this.value = value;

    }

    public String getValue() {
        return value;
    }
}

