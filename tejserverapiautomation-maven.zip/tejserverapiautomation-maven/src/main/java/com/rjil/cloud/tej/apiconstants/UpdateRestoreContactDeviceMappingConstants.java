package com.rjil.cloud.tej.apiconstants;

/**
 * UpdateRestoreContactDeviceMapping API, JSON path Constants
 * 
 */

public class UpdateRestoreContactDeviceMappingConstants {

    public static String getSnapshotIdJsonPath() {
        return "$.snapshotId";
    }

    public static String getDevicesIdFirstLocationJsonPath() {
        return "$.devices[0]";
    }
}
