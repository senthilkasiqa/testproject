package com.rjil.cloud.tej.apihelpers.boards;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class IndividualBoardDeltaSyncBaseScript extends BaseTestScript {
	protected static final String apiName = "GetBoardCategories";
	
	protected String individualBoardDeltaSyncURL(String boardKey) {
	FrameworkLogger.logStep(" individualBoardDeltaSyncURL:-> Start");
	return apiUrls.get("boardUrl") + serverConfig.get("individualBoardDeltaSyncUrl").replace("{boardKey}", boardKey);
}
	
protected String individualBoardDeltaSyncURL(String boardKey, String url,String page,String limit) {
		FrameworkLogger.logStep(" individualBoardDeltaSyncURL:-> Start");
		String replaceUrl= apiUrls.get("boardUrl") + serverConfig.get(url).replace("{boardKey}", boardKey);
		String individualBoardDeltaSyncUrl=replaceUrl.replace("{page}", page).replace("{limit}", limit);
		return individualBoardDeltaSyncUrl;
		//return apiUrls.get("boardUrl") + serverConfig.get(url);
	}

protected Map<String, String> createHeader(String ifModifiedSince) {
	FrameworkLogger.logStep("createHeader -> Start");
	headerMap = initializeHeader();
	headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), ifModifiedSince);
	FrameworkLogger.logStep("createHeader -> End");
	return headerMap;
}

//Overload the method.
	protected Map<String, String> createHeader(Map<String, String> device1Info, String ifModifiedSince) {
		FrameworkLogger.logStep("createHeader -> Start");
		headerMap = initializeHeader(device1Info);
		headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), ifModifiedSince);
		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

protected ValidatableResponse triggerGetIndividualBoardDeltaSync(String boardKey) throws IOException {
	FrameworkLogger.logStep("triggerGetIndividualBoardDeltaSync:-> Start");
	String strApiUrl = individualBoardDeltaSyncURL(boardKey);
	ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
	FrameworkLogger.logStep("triggerGetIndividualBoardDeltaSync:-> End");
	return response;
}

protected ValidatableResponse triggerGetIndividualBoardDeltaSync(String boardKey, Map<String, String> device1Info, String ifModifiedSince) throws IOException {
	FrameworkLogger.logStep("triggerGetIndividualBoardDeltaSync:-> Start");
	headerMap = createHeader(device1Info, ifModifiedSince);
	String strApiUrl = individualBoardDeltaSyncURL(boardKey);
	ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
	FrameworkLogger.logStep("triggerGetIndividualBoardDeltaSync:-> End");
	return response;
}


protected ValidatableResponse triggerGetIndividualBoardDeltaSync(String boardKey, String url,String page,String limit) throws IOException {
	FrameworkLogger.logStep("triggerGetIndividualBoardDeltaSync:-> Start");
	String strApiUrl = individualBoardDeltaSyncURL(boardKey,url,page,limit);
	ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
	FrameworkLogger.logStep("triggerGetIndividualBoardDeltaSync:-> End");
	return response;
}

public static ValidatableResponse individualBoardDeltaSyncService(String boardKey, String ifModifiedSince) throws VerificationFailException
{
	FrameworkLogger.logStep("individualBoardDeltaSyncService:-> Start");
	IndividualBoardDeltaSyncBaseScript individualDelta = new IndividualBoardDeltaSyncBaseScript();
	individualDelta.createHeader(ifModifiedSince);
	String strApiUrl = individualDelta.individualBoardDeltaSyncURL(boardKey);
	ValidatableResponse response =individualDelta.triggerGetApi(strApiUrl, individualDelta.headerMap);
	int statusCode = response.extract().statusCode();
	Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Individual Board Delta Sync Status");

	FrameworkLogger.logStep("individualBoardDeltaSyncService:-> End");
	return response;
}

public static ValidatableResponse individualBoardDeltaSyncService(Map<String, String> deviceInfoMap, String boardKey, String ifModifiedSince) throws VerificationFailException
{
	FrameworkLogger.logStep("individualBoardDeltaSyncService:-> Start");
	IndividualBoardDeltaSyncBaseScript individualDelta = new IndividualBoardDeltaSyncBaseScript();
	individualDelta.createHeader(deviceInfoMap, ifModifiedSince);
	String strApiUrl = individualDelta.individualBoardDeltaSyncURL(boardKey);
	ValidatableResponse response =individualDelta.triggerGetApi(strApiUrl, individualDelta.headerMap);
	int statusCode = response.extract().statusCode();
	Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Individual Board Delta Sync Status");
	FrameworkLogger.logStep("individualBoardDeltaSyncService:-> Start");
	return response;
}

public static ValidatableResponse triggetGetNextLink(String nextLink,String ifModifiedSince){
	FrameworkLogger.logStep("triggetGetNextLink:-> Start");
	IndividualBoardDeltaSyncBaseScript boardDeltaSyncBaseScript = new IndividualBoardDeltaSyncBaseScript();
	boardDeltaSyncBaseScript.createHeader(ifModifiedSince);
	String strApiUrl= apiUrls.get("baseURL") + nextLink;
	//String strApiUrl = boardDeltaSyncBaseScript.individualBoardDeltaSyncURL(nextLink);
	ValidatableResponse response =triggerGetApi(strApiUrl, headerMap);
	FrameworkLogger.logStep("triggetGetNextLink:-> End");
	return response;
}


}
