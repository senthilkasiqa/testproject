package com.rjil.cloud.tej.apihelpers.gatewayservices;

import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.enums.BoardParameters;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.util.HashMap;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;

/**
 * Created by bharat on 30/08/16.
 */
public class GetOneTimeAccessTokenBaseScript extends BaseTestScript{

//    protected static Map<String,String> headerMap = null;

    /**In order to construct the header parameters for each test, we would call a createHeader method.
     * This method would initialize a hashmap that would contain a key-value pair ( header parameters and its corresponding value)
     *
     * UserId
     * Devicekey
     * Authorization
     *
     * The method would then put header parameters needed for each test case.
     * Once the header parameters are available, we would call the getOneTimeAccessTokenResponse() method to get response.
     * The idea behing using a hashmap is that we would need only 3 methods in the middle layer base script to run
     * all our test cases namely*/

/*    protected void createHeader(){
        headerMap = new HashMap<>();
        headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
        headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
        headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);

        //Add 'X-Api-Key' in header for the API.
        addXapiHeaderKey(headerMap);

    }
*/


    protected String getOneTimeAccessTokenURL(){

        /** Construct the final getonetimeaccestokenapi request. */

        return apiUrls.get("baseURL") + serverConfig.get("getOneTimeAccessTokenURL");

    }


    //Overloading the method with apiurl passed the invalid url based tests

    protected String getOneTimeAccessTokenURL(String apiurl){

        /** Construct the final getonetimeaccestokenapi request. */
        return apiUrls.get("baseURL") + serverConfig.get(apiurl);
    }

    public ValidatableResponse getOneTimeAccessTokenResponse() {

        /** Pass only the user id, authorization and device key in the header and fire the request and return the response back
         * to the called tests
         * Here, the common parameters used in most requests are picked up from the HeaderParameters Enum class */
        String apiurl = getOneTimeAccessTokenURL();
        ValidatableResponse response = triggerGetApiGetOneTimeAccessToken(apiurl);
        /***
         * Add the request fired to the logger file for reference purpose
         */
//        Utils.addRequestResponseToLogger();
        /**
         * Return back the response to the test method
         */
        return response;

    }

    //Overloading the method with apiurl passed the invalid url based tests
    public ValidatableResponse getOneTimeAccessTokenResponse(String apiUrlKey) {

        /** Pass only the user id, authorization and device key in the header and fire the request and return the response back
         * to the called tests
         * Here, the common parameters used in most requests are picked up from the HeaderParameters Enum class */
        String apiurl = getOneTimeAccessTokenURL(apiUrlKey);
        ValidatableResponse response = triggerGetApiGetOneTimeAccessToken(apiurl);
        /***
         * Add the request fired to the logger file for reference purpose
         */
//        Utils.addRequestResponseToLogger();
        /**
         * Return back the response to the test method
         */
        return response;

    }



    // This method is basically used by the getOneTimeAccessTokenResponse() for method overloading with new values
    public ValidatableResponse triggerGetApiGetOneTimeAccessToken(String apiurl) {
/*        ValidatableResponse response = given()
                .headers(headerMap).log().all()
                .when()
                .get(apiurl)
                .then();
*/
    	ValidatableResponse response = triggerGetApi(apiurl, headerMap);
    	return response;

    }




}



