package com.rjil.cloud.tej.apiconstants;

/**
 * @author Sanjeevanee.Kanase
 *Shared Services Constants
 */
public class SharedServicesConstants {
	
	public static String getShareType() {
		  return "$.shareType";
		 }
	public static String getObjects() {
		  return "$.objects";
		 }
	
	public static String getObjectKey() {
		  return "$.objects[0].objectKey";
		 }
	
	public static String getObjectKey(int index) {
		return "$.objects["+index+"].objectKey";
	}
	
	public static String getShareURL() {
		  return "$.shareURL";
		 }
	
	public static String getShareKey() {
		  return "$.shareKey";
		 }
	
	public static String getRecipients(){
		return "$.recipients";
	}
	
	public static String getComments(){
		return "$.comments";
	}
	public static String getRecipientEmailId(){
		return "$.recipients[0].emailId";
	}
	
	public static String getShareKey(int position){
		return "$.shares[" + position+ "].shareKey";
	}
	
	public static String getBoardKey(){
		return "$.boardKey";
	}
	
	public static String getShareId(){
		return "$.shareId";
	}
	
	public static String getFileType(){
		return "$.fileType";
	}
	
	public static String getObjectKeyBoardShare(){
		return "$.objectKey";
	}
	

}
