package com.rjil.cloud.tej.apihelpers.notifications;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.nms.CreateFolderBaseScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class UnsubscribeBaseScript extends BaseTestScript{


	protected static final String apiName = "UnSubscribed API";
	
    
//protected static Map<String, String> headerMap = null;
	
	// created a Hashmap to save all the headers.
/*	protected void createHeader() {
		headerMap=new HashMap<>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");

		// add x-api header key
		addXapiHeaderKey(headerMap);
	}
*/
    
	protected Map<String, String> createHeader() {
		headerMap = initializeHeader();
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		//headerMap.remove(HeaderParameters.XAPIKEY.getValue());

		return headerMap;
	}
	protected String unSubscribedUrl() {
		FrameworkLogger.logStep("unSubsribedUrl: Start");
	return apiUrls.get("baseURL") + serverConfig.get("unSubscribedURL");
	}
	
	
	protected ValidatableResponse triggerPutApiUnsubsribed() throws IOException {
		FrameworkLogger.logStep("triggerPutApiUpdateMetadata: Start");	
		String strApiUrl=unSubscribedUrl();
		
		//Call method to trigger GET API.
	
		ValidatableResponse response = triggerPutApi(strApiUrl);
		FrameworkLogger.logStep("triggerPutApiUpdateMetadata: End");
		return response;
	}
	
}
