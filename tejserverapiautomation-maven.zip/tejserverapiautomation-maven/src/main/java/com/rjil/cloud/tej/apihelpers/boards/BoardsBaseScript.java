package com.rjil.cloud.tej.apihelpers.boards;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.BoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.enums.BoardParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;

/**
 * @author Sanjeevanee.Kanase
 *
 */
public class BoardsBaseScript extends BaseTestScript {
//    protected static String boardJSONBody;
//    protected static String addFileToBoardJSONBody;
//    protected static String boardName = "QA_";
//    public static int max = 9999;
//    public static int min = 100;
//    protected static Map headerMap = null;

    protected String boardJSONBody;
    protected String addFileToBoardJSONBody;
    protected String boardName = "QA_";
    private int max = 9999;
    private int min = 100;

    
    protected String getBoardURL() {
        return apiUrls.get("baseURL") + serverConfig.get("boardsURL");
    }
    
    /**get a complete url for 'add File to Board API'
     * @return
     */
    protected String getAddFileToBoardURL() {
        return apiUrls.get("baseURL") + serverConfig.get("addFileToBoardURL").replace("{boardKey}", repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue()) );
    }
    
    /**get a complete url for 'create a Like API'
     * @return
     */
    protected String getCreateALikeURL() {
        return apiUrls.get("baseURL") + serverConfig.get("createALikeURL").replace("{boardKey}", repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue())).replace("{objectKey}", repositoryMap.get(RepositoryParameterEnum.BOARDFILEASSOCIATIONKEY.getValue()));
    }
    
    /**get a complete url for 'unlike a File API'
     * @return
     */
    protected String getUnlikeAFileURL() {
        return apiUrls.get("baseURL") + serverConfig.get("unlikeAFileURL").replace("{boardKey}", repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue()) ).replace("{objectKey}", repositoryMap.get(RepositoryParameterEnum.BOARDFILEASSOCIATIONKEY.getValue()));
    }

    protected void setBoardJsonBody() throws IOException {
        //load json file
    	boardName=boardName+Utils.setRandomValue(max, min);
    	System.out.println("New Board Name: "+ boardName);
        String path = System.getProperty("user.dir") + "/resources/boardTestData/boardBody.js";
        File file = new File(path);
        boardJSONBody = JsonPath.parse(file).jsonString();
        boardJSONBody = setJsonData(BoardConstants.getBoardName(), boardName, boardJSONBody);
    }
    
    
    /**
     * method to set Request Body for calling add File to Board API.
     * @throws IOException
     */
    protected void setAddFiletoBoardJsonBody() throws IOException {
    	 
        String path = System.getProperty("user.dir") + "/resources/boardTestData/addFileToBoardBody.js";
        File file = new File(path);
        addFileToBoardJSONBody = JsonPath.parse(file).jsonString();
        addFileToBoardJSONBody = setJsonData(BoardConstants.getObjectKey(), repositoryMap.get("objectKey"), addFileToBoardJSONBody);
    }
    

    /**
     * Method to get Board Response
     *
     * @return board validatable response
     */
    public static ValidatableResponse getCreateBoardAPIResponse() throws IOException {
    	BoardsBaseScript apiObj=new BoardsBaseScript();
    	
        apiObj.setBoardJsonBody();
        apiObj.createHeader();
/*        ValidatableResponse response = given().body(apiObj.boardJSONBody)
                .headers(apiObj.headerMap).log().all()
                .when()
                .post(apiObj.getBoardURL())
                .then();
        response.log().all();
        Utils.addRequestResponseToLogger();
*/        
        ValidatableResponse response = apiObj.triggerPostApi(apiObj.getBoardURL(), apiObj.headerMap, apiObj.boardJSONBody);
        
        System.out.println("Setting Boardkey...");
		String strBoardKey = response.extract().path(
				"boardKey");
		repositoryMap.put(RepositoryParameterEnum.BOARDKEY.getValue(),
				strBoardKey);

        return response;
    }


    /**
     * Method to create header parameters
     */

/*    protected static void createHeader()
    {
        headerMap = new HashMap<>();
        headerMap.put("Content-Type", "application/json");
        headerMap.put(BoardParameters.XUSERID.getValue(), userId);
        headerMap.put(BoardParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
        headerMap.put(BoardParameters.AUTHORIZATION.getValue(), accessToken);
        headerMap.put(BoardParameters.ACCEPTLANGUAGE.getValue(), "en");

        //add x-api header key
        addXapiHeaderKey(headerMap);
    }
*/

    /**
     * Method to get Add File to Board API response
     * @return ValidatableResponse
     * @throws IOException
     */
    protected ValidatableResponse getAddFileToBoardAPIResponse() throws IOException {
    	
    	setAddFiletoBoardJsonBody();
//        ValidatableResponse response = given().body(addFileToBoardJSONBody)
/*                .header("Content-Type", "application/json")
                .header(BoardParameters.XUSERID.getValue(), userId)
                .header(BoardParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"))
                .header(BoardParameters.AUTHORIZATION.getValue(), accessToken)
                .header(BoardParameters.ACCEPTLANGUAGE.getValue(), "en")
*/
/*                .headers(headerMap)
                .log().all()
                .when()
                .post(getAddFileToBoardURL())
                .then();
        response.log().all();
        Utils.addRequestResponseToLogger();
*/        
    	ValidatableResponse response = triggerPostApi(getAddFileToBoardURL(), headerMap, addFileToBoardJSONBody);

        System.out.println("Setting BoardFileAssociationKey...");
		String strAssociationKey = response.extract().path(
				"fileDetails[0].clonedObject.objectKey");
        System.out.println("Setting BoardFileAssociationKey..."+ strAssociationKey);
		repositoryMap.put(RepositoryParameterEnum.BOARDFILEASSOCIATIONKEY.getValue(),
				strAssociationKey);


        return response;
    }
    
    /**
     * Method to get create a Like API response
     * @return ValidatableResponse
     * @throws IOException
     */
   protected ValidatableResponse createALikeAPIResponse() throws IOException {
//        ValidatableResponse response = given()
/*                .header("Content-Type", "application/json")
                .header(BoardParameters.XUSERID.getValue(), userId)
                .header(BoardParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"))
                .header(BoardParameters.AUTHORIZATION.getValue(), accessToken)
                .header(BoardParameters.ACCEPTLANGUAGE.getValue(), "en")
*/
//        		.headers(headerMap)
//        		.log().all()
//                .when()
//                .put(getCreateALikeURL())
//                .then();
//        response.log().all();
//        Utils.addRequestResponseToLogger();
//        
	   ValidatableResponse response =triggerPutApi(getCreateALikeURL(), headerMap, "CreateALike");
         return response;
    }
   
   /**
    * Method to get API response
    * @return ValidatableResponse
    * @throws IOException
    */
   protected ValidatableResponse unlikeAFileAPIResponse() throws IOException {
//       ValidatableResponse response = given()
/*               .header("Content-Type", "application/json")
               .header(BoardParameters.XUSERID.getValue(), userId)
               .header(BoardParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"))
               .header(BoardParameters.AUTHORIZATION.getValue(), accessToken)
               .header(BoardParameters.ACCEPTLANGUAGE.getValue(), "en")
*/
/*    		   .headers(headerMap)
    		   .log().all()
               .when()
               .put(getUnlikeAFileURL())
               .then();
       response.log().all();
       Utils.addRequestResponseToLogger();
*/
       ValidatableResponse response =triggerPutApi(getCreateALikeURL(), headerMap, "UnlikeAFile");
       return response;  
   }
    
}
