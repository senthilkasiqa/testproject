package com.rjil.cloud.mailchamp.common.helper;

import com.jayway.restassured.response.ValidatableResponse;

public class GetSubScriptionListBaseClass extends MailChampBaseTestScript {

/*	protected Map<String, String> createHeaderMap() {
		System.out.println("create Header from GetSubScriptionListBaseClass");

		Map<String, String> headerMap = initializeHeaderMap(getValueFromEnvConfig("userEmail"));
		return headerMap;

	}
*/	
	protected String getBaseURL() {
		String baseUrl = getValueFromEnvConfig("baseURL");
		String subUrl = getValueFromProjectConfig("subScrpListURL");	
		return baseUrl + subUrl;
		}
	
	protected String getSubscriptionUrlForNew() {
		String baseUrl = getValueFromEnvConfig("baseURL");
		String subUrl = getValueFromProjectConfig("getSubscriptionUrl").replace("{toReplace}", "New");	
		return baseUrl + subUrl;
		}
	
	protected String getSubscriptionUrlForInbox() {
		String baseUrl = getValueFromEnvConfig("baseURL");
		String subUrl = getValueFromProjectConfig("getSubscriptionUrl").replace("{toReplace}", "Inbox");	
		return baseUrl + subUrl;
		}
	
	protected String getSubscriptionUrlForRollUp() {
		String baseUrl = getValueFromEnvConfig("baseURL");
		String subUrl = getValueFromProjectConfig("getSubscriptionUrl").replace("{toReplace}", "GroupIt");	
		return baseUrl + subUrl;
		}
	
	protected String getSubscriptionUrlForUnsubscribe() {
		String baseUrl = getValueFromEnvConfig("baseURL");
		String subUrl = getValueFromProjectConfig("getSubscriptionUrl").replace("{toReplace}", "Unsubscribe");	
		return baseUrl + subUrl;
		}

	//This is a service method which will be used for other APIs.
	public static ValidatableResponse triggerGetSubscriptionListApi(){
		GetSubScriptionListBaseClass obj=new GetSubScriptionListBaseClass();
		
		GetSubScriptionListBaseClass getSubScriptionListBaseClass = new GetSubScriptionListBaseClass();
		String getSubScpNewUrl = getSubScriptionListBaseClass.getSubscriptionUrlForNew();
		ValidatableResponse response = obj.triggerGetApi(getSubScpNewUrl, obj.createHeaderMap());
		return response;
	}
	public static ValidatableResponse triggerGetSubscriptionListApi(String subscriptionType){
		GetSubScriptionListBaseClass obj=new GetSubScriptionListBaseClass();
		String getSubScpUrl = null;

		if(subscriptionType.equalsIgnoreCase("New")){
			getSubScpUrl=obj.getSubscriptionUrlForNew();
		} else if(subscriptionType.equalsIgnoreCase("inbox")){
			getSubScpUrl=obj.getSubscriptionUrlForInbox();
		}
			else if(subscriptionType.equalsIgnoreCase("GroupIt")){
				getSubScpUrl=obj.getSubscriptionUrlForRollUp();
		}
			else if(subscriptionType.equalsIgnoreCase("unsubscribe")){
				getSubScpUrl=obj.getSubscriptionUrlForUnsubscribe();
			}				
		ValidatableResponse response = obj.triggerGetApi(getSubScpUrl, obj.createHeaderMap());
		return response;
	}
}