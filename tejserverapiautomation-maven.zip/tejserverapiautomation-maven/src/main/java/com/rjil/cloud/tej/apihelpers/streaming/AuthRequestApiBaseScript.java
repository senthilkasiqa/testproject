/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.streaming;

import static com.jayway.restassured.RestAssured.given;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jayway.restassured.matcher.ResponseAwareMatcher;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.fileupload.UploadBaseScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 *
 *Base Class for auth request api
 */
public class AuthRequestApiBaseScript extends BaseTestScript {

	protected static final String apiName= "AuthRequest";

	//protected static String streamingUrl = null;
	public static String masterUrl = null;
//	protected  Map<String, String> headerMap = null;

	public AuthRequestApiBaseScript(){
		globalApiName=apiName;
	}
	/**
	 * In order to construct the header parameters for each test, we would call
	 * a createHeader method. This method would initialize a hashmap that would
	 * contain a key-value pair ( header parameters and its corresponding value)
	 *
	 * UserId Authorization
	 *
	 * The method would then put header parameters needed for each test case.
	 * Once the header parameters are available, we would call the API method to
	 * get response. The idea behing using a hashmap is that we would need only
	 * 3 methods in the middle layer base script to run all our test cases
	 * namely
	 */

/*	protected  void createHeader() {
		headerMap = new HashMap<>();
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		addXapiHeaderKey(headerMap);
	}
*/

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

	    	//Remove device key from header for this API.
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		if(serverConfig.get("deviceType").equalsIgnoreCase("W")){
			headerMap.put("X-Device-Type", serverConfig.get("deviceType"));
		}

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * 
	 * Construct the final Streaming Auth Request. String that needs to be
	 * appended to the base url is passed directly from the test itself
	 * 
	 */

	protected String getStreamingAuthRequestUrl(String objectKey) {

		String url = apiUrls.get("baseURL") + serverConfig.get("authRequestUrl").replace("{objectKey}", objectKey);
		FrameworkLogger.logStep("getStreamingAuthRequestUrl=========>"+url);
		return url;

	}

	/**
	 * Method to get Streaming Auth Response
	 * @throws InterruptedException 
	 */
	protected  ValidatableResponse getAuthRequestApiResponse(String objectKey) throws InterruptedException {

/*		ValidatableResponse response = given().headers(headerMap).when().get(getStreamingAuthRequestUrl(objectKey))
				.then();
		response.log().all();
*/
		/***
		 * Add the request fired to the logger file for reference purpose
		 */
//		Utils.addRequestResponseToLogger();

		String strApiUrl=getStreamingAuthRequestUrl(objectKey);
		//Call method to trigger GET API.
		ValidatableResponse response1 = triggerGetApi(strApiUrl,headerMap);
Thread.sleep(60000);
ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
		String strStreamingUrl = response.extract().asString();
		
		//Read token  from response cookie header
		if(serverConfig.get("deviceType").equalsIgnoreCase("W")){
			String readToken=response.extract().header("Set-Cookie");
			FrameworkLogger.logStep("TOKEN:"+readToken);
			//String value=readToken.split(";")[0];
			try{
			String value=readToken.substring(readToken.indexOf("t=")+2, readToken.indexOf(";"));
			String strStreamingUrl1=strStreamingUrl+"&token="+value;
			FrameworkLogger.logStep("VALUE:"+value);
			repositoryMap.put(RepositoryParameterEnum.STREAMINGURL.getValue(),
					strStreamingUrl1);
			}catch(Exception e){
				FrameworkLogger.logStep("Null pointer exception");
			}
			
	
		}else{
			repositoryMap.put(RepositoryParameterEnum.STREAMINGURL.getValue(),
					strStreamingUrl);
		}

		/**
		 * Return back the response to the test method
		 */
		return response;

	}
	/**
	 * 
	 * Auth Api Response Service method for utilization in other test cases
	 * 
	 * @param fileName
	 * @throws VerificationFailException
	 * @throws IOException
	 * @throws InterruptedException 
	 */

	public static void getAuthApiResponseServiceMethod(String fileName) throws VerificationFailException, IOException, InterruptedException {
		//if (!repositoryMap.containsKey(RepositoryParameterEnum.OBJECTKEY.getValue())) {

			UploadBaseScript.getUploadFileServiceMethod(fileName);
			
		//}
			// Fecth Object Key from Upload file response
			String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

			AuthRequestApiBaseScript authRequestApiBaseScript= new AuthRequestApiBaseScript();
			// Create header for passing in request
			authRequestApiBaseScript.createHeader();

			ValidatableResponse response = authRequestApiBaseScript.getAuthRequestApiResponse(objectKey);

			FrameworkLogger.logStep(response.toString());
			
		}

	}


