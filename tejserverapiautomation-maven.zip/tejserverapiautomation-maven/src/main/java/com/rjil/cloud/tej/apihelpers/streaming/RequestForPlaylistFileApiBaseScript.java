/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.streaming;

import static com.jayway.restassured.RestAssured.given;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jayway.restassured.matcher.ResponseAwareMatcher;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 * 
 * Base class for request for playlist file api
 *
 */
public class RequestForPlaylistFileApiBaseScript extends BaseTestScript {

	protected static final String apiNameForRequestForPlaylistFileApi = "RequestForPlaylistFile";
	public static String masterUrl = null;
//	protected  Map<String, String> headerMap = null;
	//public static String mPlaylistUrl = null;
	
	public RequestForPlaylistFileApiBaseScript(){
		globalApiName=apiNameForRequestForPlaylistFileApi;
	}

	/**
	 * In order to construct the header parameters for each test, we would call
	 * a createHeader method. This method would initialize a hashmap that would
	 * contain a key-value pair ( header parameters and its corresponding value)
	 *
	 * UserId Authorization
	 *
	 * The method would then put header parameters needed for each test case.
	 * Once the header parameters are available, we would call the API method to
	 * get response. The idea behing using a hashmap is that we would need only
	 * 3 methods in the middle layer base script to run all our test cases
	 * namely
	 */

/*	protected  void createHeader() {
		headerMap = new HashMap<>();
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		
	}
*/	

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		//Remove from header for this API.
	    headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
	//    headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());
	    headerMap.remove(HeaderParameters.XAPIKEY.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * Method to get Request For Playlist File Api Response
	 * 
	 * @throws IOException
	 * @throws VerificationFailException
	 * @throws InterruptedException 
	 */
	public  ValidatableResponse getRequestForPlaylistFileApiResponse(String fileName)
			throws VerificationFailException, IOException, InterruptedException {

		AuthRequestApiBaseScript.getAuthApiResponseServiceMethod(fileName);
		
		createHeader();

/*		ValidatableResponse response = given().headers(headerMap).when().get(repositoryMap.get(RepositoryParameterEnum.STREAMINGURL.getValue()))
				.then();
		response.log().all();

		*//***
		 * Add the request fired to the logger file for reference purpose
		 *//*
		Utils.addRequestResponseToLogger();

*/		

		String strApiUrl=repositoryMap.get(RepositoryParameterEnum.STREAMINGURL.getValue());
		

		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);

		/**
		 * Return back the response to the test method
		 */
		return response;

	}
	
	/**
	 * Method to get Request For Playlist File Api Response
	 * 
	 * @throws IOException
	 * @throws VerificationFailException
	 * @throws InterruptedException 
	 */
	public  ValidatableResponse getRequestForPlaylistFileApiResponseForNegativeTest(String strApiUrl)
			throws VerificationFailException, IOException, InterruptedException {

		//AuthRequestApiBaseScript.getAuthApiResponseServiceMethod(fileName);
		
		createHeader();

/*		ValidatableResponse response = given().headers(headerMap).when().get(repositoryMap.get(RepositoryParameterEnum.STREAMINGURL.getValue()))
				.then();
		response.log().all();

		*//***
		 * Add the request fired to the logger file for reference purpose
		 *//*
		Utils.addRequestResponseToLogger();

*/		

		String apiUrl=apiUrls.get("streamingRequestForPlaylistFileUrl")+strApiUrl;
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(apiUrl,headerMap);

		/**
		 * Return back the response to the test method
		 */
		return response;

	}
	
	/**
	 * Service method for getting master play list url so that it can be used in other test classes
	 * 
	 * @param fileName
	 * @throws VerificationFailException
	 * @throws IOException
	 * @throws InterruptedException 
	 */

	public static void getMPlaylistUrlServiceMethod(String fileName) throws VerificationFailException, IOException, InterruptedException{
		
		RequestForPlaylistFileApiBaseScript requestForPlaylistFileApiBaseScript = new RequestForPlaylistFileApiBaseScript();
		ValidatableResponse response= requestForPlaylistFileApiBaseScript.getRequestForPlaylistFileApiResponse(fileName);
		
		String masterPlaylistUrl = response.extract().asString();

		System.out.println("MasterPlaylist:" + masterPlaylistUrl);

		// Fetch Url from request for playlist file api response
		Pattern pattern = Pattern.compile("[/media].*");
		
		Matcher matcher = pattern.matcher(masterPlaylistUrl);
		if (matcher.find()) {

			masterUrl = matcher.group(0);
			System.out.println("URLS:" + matcher.group(0));
			String mPlaylistUrl = apiUrls.get("streamingIp") + masterUrl;
			FrameworkLogger.logStep("mPlaylistUrl:"+mPlaylistUrl);
			//Adding Url in respository map 
			repositoryMap.put(RepositoryParameterEnum.MPLAYlISTURL.getValue(), mPlaylistUrl);
		}
	}
}
