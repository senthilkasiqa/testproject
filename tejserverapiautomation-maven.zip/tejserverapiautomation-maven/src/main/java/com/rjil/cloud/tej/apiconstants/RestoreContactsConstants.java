package com.rjil.cloud.tej.apiconstants;

/**
 * Restore Contacts API, JSON path Constants
 * 
 */

public class RestoreContactsConstants {

    public static String getSnapshotIdJsonPath() {
        return "$.snapshotId";
    }

}
