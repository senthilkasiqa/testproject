package com.rjil.cloud.tej.enums;

/**
 * @author: Chandra
 * 
 * Repository Parameter Enum
 * This is for all Repository Parameters to be added into map key.
 */

public enum RepositoryParameterEnum {
	
	OBJECTKEY("objectKey"),
	BOARDFILEASSOCIATIONKEY("boardFileAssociationKey"),
	BOARDKEY("boardKey"),
    ONETIMEACCESSTOKENKEY("Authorization"),
	NOTIFICATIONID("notificationId"),
	ROOTFOLDEROBJECTKEY("rootFolderObjectKey"),
	STREAMINGURL("streamingUrl"),
	MPLAYlISTURL("mPlaylistUrl"),
	SHAREKEY("shareKey"),
	SHAREURL("shareUrl"),
	SHARDKEY("shardKey"),
	FOLDEROBJECTKEY("folderObjectKey"),
	PARENTOBJECTKEY("parentObjectKey"),
	LASTUPDATEDTIME("lastUpdatedTime"),
	TOTALUNSEEN("totalUnseen"),
	REFRESHTOKEN("refreshToken"),
	AUTHPROVIDERTOKEN("authProviderToken"),
	TRANSACTIONID("transactionId"),
	DOCUMENTURL("documentUrl"),
	USEDSPACE("usedSpave"),
	ZIPURL("zipurl"),
	HYPERLINKOBJECTKEY("hyperlinkObjectKey"),
	OBJECTKEYOFFFILEUPLOADEDTOBOARDFROMROOT("objectKeyOfFileUploadedToBoardFromRoot"),
	COMMENTKEY("commentKey");
	
    public String value;

    RepositoryParameterEnum(String value) {
        this.value = value;

    }

    public String getValue() {
        return value;
    }
}

