/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.download;

import static com.jayway.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 * 
 *         Base class for Shared file download api
 *
 */
public class SharedFileDownloadBaseScript extends BaseTestScript {

	protected static final String apiName = "SharedFileDownload";
	
	public SharedFileDownloadBaseScript(){
		globalApiName=apiName;
	}

//	protected Map<String, String> headerMap = null;

	/**
	 * In order to construct the header parameters for each test, we would call
	 * a createHeader method. This method would initialize a hashmap that would
	 * contain a key-value pair ( header parameters and its corresponding value)
	 *
	 * UserId Authorization
	 *
	 * The method would then put header parameters needed for each test case.
	 * Once the header parameters are available, we would call the API method to
	 * get response. The idea behing using a hashmap is that we would need only
	 * 3 methods in the middle layer base script to run all our test cases
	 * namely
	 */

/*	protected void createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");
		headerMap = new HashMap<>();
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		addXapiHeaderKey(headerMap);
		FrameworkLogger.logStep("createHeader -> End");
	}
*/

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Remove from header for this API.
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}
    
    /**
	 * 
	 * Construct the Shared File Download request. Need to add object key in the
	 * url by fetching object key from the Upload Response
	 * 
	 */

	protected String getSharedFileDownloadUrl(String url,String objectKey,String shareKey,String shardKey) {

		FrameworkLogger.logStep("getSharedFileDownloadUrl: Start");
		String aplUrl1 = apiUrls.get("downloadPublicIp")
				+ serverConfig.get(url).replace("{objectKey}", objectKey);
		String apiUrl2 = aplUrl1.replace("{shareKey}", shareKey);
		String sharedFileDownloadUrl = apiUrl2.replace("{shardKey}", shardKey);
		FrameworkLogger.logStep("sharedFileDownloadUrl=======>" + sharedFileDownloadUrl);
		FrameworkLogger.logStep("getSharedFileDownloadUrl: End");
		return sharedFileDownloadUrl;
	}

	/**
	 * Method to get Shared File Download Response
	 */
	protected ValidatableResponse getSharedFileDownloadResponse(String url,String objectKey, String shareKey,String shardKey) {

		FrameworkLogger.logStep("getSharedFileDownloadResponse-> Start");
//		ValidatableResponse response = given().headers(headerMap).when().get(getSharedFileDownloadUrl(objectKey))
//				.then();
//		response.log().all();

		ValidatableResponse response =triggerGetApi(getSharedFileDownloadUrl(url,objectKey,shareKey,shardKey), headerMap) ;
				/***
		 * Add the request fired to the logger file for reference purpose
		 */
//		Utils.addRequestResponseToLogger();

		FrameworkLogger.logStep("getSharedFileDownloadResponse-> End");
		/**
		 * Return back the response to the test method
		 */

		return response;

	}
}
