/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.usermanagement;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 *
 *Base class for Testing get user quota base script
 */
public class GetUserQuotaBaseScript extends BaseTestScript{

protected static final String apiName = "GetUserQuotaApi";
	
	public GetUserQuotaBaseScript(){
		globalApiName=apiName;
	}

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Remove device key from header for this API.
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	protected String getUserQuotaUrl() {
		FrameworkLogger.logStep("getUserQuotaUrl: Start");
		String getUserProfileUrl = apiUrls.get("baseURL") + serverConfig.get("getUserQuotaUrl");
		FrameworkLogger.logStep("getUserQuotaUrl: End");
		return getUserProfileUrl;

	}
	/**
	 * 
	 * Method to get user profile pic url
	 * 
	 * URL=http://{envUrl}/security/users
	 * 
	 */
	protected String getUserQuotaUrl(String url) {
		FrameworkLogger.logStep("getUserQuotaUrl: Start");
		String getUserProfileUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		FrameworkLogger.logStep("getUserQuotaUrl:" + url);
		FrameworkLogger.logStep("getUserQuotaUrl: End");
		return getUserProfileUrl;

	}
	
	protected ValidatableResponse triggerGetApiGetUserQuota() throws IOException {

		FrameworkLogger.logStep("triggerGetApiGetUserQuota: Start");

		String strApiUrl = getUserQuotaUrl();
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		
		Integer usedSpace= response.extract().path("usedSpace");
		repositoryMap.put(RepositoryParameterEnum.USEDSPACE.getValue(),usedSpace.toString());

		FrameworkLogger.logStep("triggerGetApiGetUserQuota: End");

		return response;
	}

	protected ValidatableResponse triggerGetApiGetUserQuota(String url) throws IOException {

		FrameworkLogger.logStep("triggerGetApiGetUserQuota: Start");

		String strApiUrl = getUserQuotaUrl(url);
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		
		Integer usedSpace= response.extract().path("usedSpace");
		try{
		repositoryMap.put(RepositoryParameterEnum.USEDSPACE.getValue(),usedSpace.toString());}
		catch(Exception e)
		{System.out.println("");}

		FrameworkLogger.logStep("triggerGetApiGetUserQuota: End");

		return response;
	}
	
	public static void getApiUserQuotaServiceMethod() throws IOException{
		GetUserQuotaBaseScript getUserQuotaBaseScript= new GetUserQuotaBaseScript();
		getUserQuotaBaseScript.createHeader();
		getUserQuotaBaseScript.triggerGetApiGetUserQuota();
	}
}
