/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.download;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;

/**
 * @author Prateek
 *
 */
public class GetSharedBulkDownloadBaseScript extends BaseTestScript {

	protected static final String apiName = "GetSharedBulkDownload";

	// protected Map<String, String> headerMap = null;

	public GetSharedBulkDownloadBaseScript() {
		globalApiName = apiName;
	}

	protected ValidatableResponse triggerGetApiGetSharedBulkDownload(String url, boolean value) {

		ValidatableResponse response = triggerGetApi(url, headerMap, value);

		return response;
	}
}
