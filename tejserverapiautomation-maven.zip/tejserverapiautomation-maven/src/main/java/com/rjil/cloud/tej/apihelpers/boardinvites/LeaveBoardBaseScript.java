package com.rjil.cloud.tej.apihelpers.boardinvites;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

public class LeaveBoardBaseScript extends BaseTestScript{

	protected static final String apiName = "LeaveBoardAPI";
	
	protected String leaveBoardURL(String boardKey) {
		FrameworkLogger.logStep("acceptInvitationURL: Start");
		return apiUrls.get("boardInviteUrl") + serverConfig.get("leaveBoardUrl").replace("{boardKey}", boardKey);
	}
	
	
	protected String leaveBoardURL(String urlValue, String boardKey) {
		FrameworkLogger.logStep("leaveBoardURL: Start");
		return apiUrls.get("boardInviteUrl") + serverConfig.get("leaveBoardUrl").replace("{boardKey}", boardKey);
	}
  
    
    protected ValidatableResponse triggerPutApiLeaveBoard(String boardKey, Map<String, String>headerMap1) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiLeaveBoard: Start");
 
		String strApiUrl=leaveBoardURL(boardKey);
		Map<String,String> headerMap = createHeader(headerMap1);
	
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiLeaveBoard: End");

    	return response;
    	
    }
    
    protected ValidatableResponse triggerPutApiLeaveBoard(String boardKey) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiLeaveBoard: Start");
 
		String strApiUrl=leaveBoardURL("leaveBoardUrl", boardKey);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiLeaveBoard: End");

    	return response;
    	
    }
    
    public static ValidatableResponse leaveBoardService(String boardKey) throws IOException
    {
    	FrameworkLogger.logStep("leaveBoardService: Start");
    	FrameworkLogger.logStep("BOARDKEY"+boardKey);
    	LeaveBoardBaseScript leave = new LeaveBoardBaseScript();
    	leave.createHeader();
    	ValidatableResponse response = leave.triggerPutApiLeaveBoard(boardKey);
    	FrameworkLogger.logStep("leaveBoardService: End");
    	return response;
    }
    
    public static ValidatableResponse leaveBoardService(String urlValue,String boardKey) throws IOException
    {
    	FrameworkLogger.logStep("leaveBoardService: Start");
    	FrameworkLogger.logStep("BOARDKEY"+boardKey);
    	LeaveBoardBaseScript leave = new LeaveBoardBaseScript();
    	leave.createHeader();
    	ValidatableResponse response = leave.triggerPutApiLeaveBoard(boardKey);
    	FrameworkLogger.logStep("leaveBoardService: End");
    	return response;
    }
    
    public static ValidatableResponse leaveBoardService(String boardKey, Map<String, String> headeMap1) throws IOException
    {
    	FrameworkLogger.logStep("leaveBoardService: Start");
    	LeaveBoardBaseScript leaveBoard = new LeaveBoardBaseScript();
    	leaveBoard.createHeader(headeMap1);
    	ValidatableResponse response = leaveBoard.triggerPutApiLeaveBoard(boardKey);
    	FrameworkLogger.logStep("leaveBoardService: Start");
    	return response;
    }
    
	
}
