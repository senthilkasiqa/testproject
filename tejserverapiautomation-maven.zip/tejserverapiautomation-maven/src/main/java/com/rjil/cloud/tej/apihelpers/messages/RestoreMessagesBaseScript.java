package com.rjil.cloud.tej.apihelpers.messages;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class RestoreMessagesBaseScript extends BaseTestScript{
	protected static final String apiName = "RestoreMessagess";
	protected String jsonBody;
	

	public RestoreMessagesBaseScript(){
		globalApiName=apiName;
	}

	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader:-> Start");

		headerMap = initializeHeader();
 	//	headerMap.remove(HeaderParameters.XAPPSECRET.getValue(), getAppSecretValue());
	//	headerMap.remove(HeaderParameters.XAPIKEY.getValue());
		// size is 100 byte
		headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "100"); // Chunk

		FrameworkLogger.logStep("createHeader:-> End");
		return headerMap;
	}

	protected Map<String, String> createHeader(String strChunkSize) {
		FrameworkLogger.logStep("createHeader:-> Start");

    	headerMap=initializeHeader();

		// size is 100 byte
		headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), strChunkSize); // Chunk

		FrameworkLogger.logStep("createHeader:-> End");
		return headerMap;
	}

	protected Map<String, String> createHeader(Map<String, String> deviceInfoMap) {
		FrameworkLogger.logStep("createHeader:-> Start");

		headerMap = initializeHeader();
 		//headerMap.remove(HeaderParameters.XAPPSECRET.getValue(), getAppSecretValue());
		headerMap.remove(HeaderParameters.XAPIKEY.getValue());
		// size is 100 byte
		headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "100"); // Chunk

		FrameworkLogger.logStep("createHeader:-> End");
		return headerMap;
	}

	/**
	 * @author Sanjeevanee Kanase
	 *         <p>
	 *         It creates the url for API
	 */
	protected String getRestoreMessagesApiUrl(String urlKey) {
		FrameworkLogger.logStep("getRestoreMessagesApiUrl:-> Start");
		String url= apiUrls.get("baseMessagesURL") + serverConfig.get(urlKey);
	//	String url= getRestoreContactsApiUrlWithUrlKey("restoreMessagesApiUrl").replace(
	//					"{page}", page);
		FrameworkLogger.logStep("getRestoreContactsApiUrl:-> End");
		return url;
	}
	
	/**
	 * @author Sanjeevanee Kanase
	 * It gets the url with provided Url Key for API
	 */
	protected String getRestoreContactsApiUrlWithUrlKey(String urlKey) {
		FrameworkLogger.logStep("getRestoreContactsApiUrlWithUrlKey:-> Start");
		String url= apiUrls.get("baseMessagesURL") + serverConfig.get(urlKey);
		FrameworkLogger.logStep("getRestoreContactsApiUrlWithUrlKey:-> End");
		return url;
	}
	
	  protected ValidatableResponse triggerGetApiMessageRestore() {
			FrameworkLogger.logStep("triggerGetApiMessageRestore:-> Start");
			String url= apiUrls.get("baseMessagesURL") + serverConfig.get("restoreMessagesApiUrl");
	    	ValidatableResponse response=triggerGetApi(url, headerMap);
	    	FrameworkLogger.logStep("triggerGetApiMessageRestore:-> End");
	        return response;
	    }
	  
	  protected ValidatableResponse triggerGetApiMessageRestore(String url) {
			FrameworkLogger.logStep("triggerGetApiMessageRestore:-> Start");
			String apiurl= apiUrls.get("baseMessagesURL") +url;
	    	ValidatableResponse response=triggerGetApi(apiurl, headerMap);
	    	FrameworkLogger.logStep("triggerGetApiMessageRestore:-> End");
	        return response;
	    }
	  
	  protected ValidatableResponse triggerGetApiMessageRestore(String urlKey, int deletedFlagValue) {
			FrameworkLogger.logStep("triggerGetApiMessageRestore:-> Start");
			String url= apiUrls.get("baseMessagesURL") + serverConfig.get(urlKey)+deletedFlagValue;
			FrameworkLogger.logStep("URL FOR FLAG ON="+url);
	    	ValidatableResponse response=triggerGetApi(url, headerMap);
	    	FrameworkLogger.logStep("triggerGetApiMessageRestore:-> End");
	        return response;
	    }
	
	  protected ValidatableResponse triggerGetApiMessageRestoreWithDeviceKeys(String urlKey, String deviceKeys) {
			FrameworkLogger.logStep("triggerGetApiMessageRestore:-> Start");
			String url= apiUrls.get("baseMessagesURL") + serverConfig.get(urlKey)+deviceKeys;
	    	ValidatableResponse response=triggerGetApi(url, headerMap);
	    	FrameworkLogger.logStep("triggerGetApiMessageRestore:-> End");
	        return response;
	    }
	
	  protected ValidatableResponse triggerGetApiMessageRestoreWithDeviceKeysAndDeletedFlag(String urlKey, String deviceKeys, String isDeleted) {
			FrameworkLogger.logStep("triggerGetApiMessageRestore:-> Start");
			String url= apiUrls.get("baseMessagesURL") + serverConfig.get(urlKey).replace("{deviceKey}", deviceKeys).replace("{includeDeleted}", isDeleted);
	    	ValidatableResponse response=triggerGetApi(url, headerMap);
	    	FrameworkLogger.logStep("triggerGetApiMessageRestore URL="+url);
	        return response;
	    }
	
	public static int getIndexIfMessagePresentInResponse(ValidatableResponse response, String dvcMsgId)
				throws IOException {
			FrameworkLogger
					.logStep("getIndexIfMessagePresentInResponse:-> start; dvcMsgIdValue:-> " + dvcMsgId);
			int isdvcMsgIdMatchingIndex = -1;
	
		try
		{
			List<String> objList = response.extract().jsonPath().get("messages.dvcMsgId");
			
		//	List<String> objList = Newresponse.extract().path("messages.dvcMsgId");
			for (String actualdvcMsgIdValue : objList) {
				FrameworkLogger.logStep("Comparing strObjectKeyValue:-> " + dvcMsgId
						+ " With actualObjectKeyValue:-> " + actualdvcMsgIdValue);
				if (actualdvcMsgIdValue.equalsIgnoreCase(dvcMsgId))
					{
					System.out.println("actualdvcMsgIdValue:-> start; actualdvcMsgIdValue:-> " + actualdvcMsgIdValue);
					System.out.println("dvcMsgId:-> start; dvcMsgId:-> " + dvcMsgId);
					FrameworkLogger.logStep("actualdvcMsgIdValue:-> start; actualdvcMsgIdValue:-> " + actualdvcMsgIdValue);
					FrameworkLogger.logStep("dvcMsgId:-> start; dvcMsgId:-> " + dvcMsgId);
					isdvcMsgIdMatchingIndex = objList.indexOf(actualdvcMsgIdValue);
					break;
				}
			}
		}
		catch(Exception e)
		{
			System.out.println("url is null");
		}
	 
						FrameworkLogger.logStep("getIndexIfMessagePresentInResponse:-> end");
			FrameworkLogger.logStep("index of backup message in response=" + isdvcMsgIdMatchingIndex);
			return isdvcMsgIdMatchingIndex;
		}
	  
	  
	  public static boolean isMessagePresentInResponse(ValidatableResponse response, String dvcMsgId)
				throws IOException {
			FrameworkLogger
					.logStep("getIndexIfMessagePresentInResponse:-> start; dvcMsgIdValue:-> " + dvcMsgId);
			boolean isdvcMsgIdMatchingIndex = false;
			List<String> objList = response.extract().jsonPath().get("messages.dvcMsgId");
			for (String actualdvcMsgIdValue : objList) {
				FrameworkLogger.logStep("Comparing strObjectKeyValue:-> " + dvcMsgId
						+ " With actualObjectKeyValue:-> " + actualdvcMsgIdValue);
				if (actualdvcMsgIdValue.equalsIgnoreCase(dvcMsgId)) {
					isdvcMsgIdMatchingIndex = true;
					break;
				}
			}
			FrameworkLogger.logStep("getIndexIfMessagePresentInResponse:-> end");
			FrameworkLogger.logStep("index of backup message in response=" + isdvcMsgIdMatchingIndex);
			return isdvcMsgIdMatchingIndex;
		}
	  
	  protected ValidatableResponse triggerRestoreMessagesForNextPage(String nextPageUrl) throws IOException {
		  ValidatableResponse response=null;
			FrameworkLogger.logStep("triggerRestoreMessagesForNextPage:-> Start");
		//	String strApiUrl = nextPageUrl;
			// http://apis.jiocloud.com/jcm/messages/all?page=2
			if(!(nextPageUrl==""))
			{
				//http://apis.jiocloud.com/jcm/messages/all?page=2
			//	 String endurl = nextPageUrl.split("com")[1];
				 String endurl = nextPageUrl.split("=")[1];
				 
				 String url= apiUrls.get("baseMessagesURL")+"/messages_all/1.0?page="+endurl;
				 http://35.154.17.113/apiman-gateway/jiocloud/messages_all/1.0?page=2
				 FrameworkLogger.logStep("URL FOR HITTING NEXT API ********************"+url);
			     response = triggerGetApi(url, headerMap);
			 }
			
			FrameworkLogger.logStep("triggerRestoreMessagesForNextPage:-> End");
			return response;
			
		}
		
	  protected ValidatableResponse triggerRestoreMessagesForNextPage(String nextPageUrl, int includeDeleted) throws IOException {
		  ValidatableResponse response=null;
			FrameworkLogger.logStep("triggerRestoreMessagesForNextPage:-> Start");
		//	String strApiUrl = nextPageUrl;
			// http://apis.jiocloud.com/jcm/messages/all?page=2
			if(!(nextPageUrl==""))
			{
				//http://apis.jiocloud.com/jcm/messages/all?page=2
			//	 String endurl = nextPageUrl.split("com")[1];
				 String endurl = nextPageUrl.split("=")[1];
				 
				 String url= apiUrls.get("baseMessagesURL")+"/messages_all/1.0?page="+endurl+"&includeDeleted="+includeDeleted;
			//	 apiUrls.get("baseMessagesURL") + serverConfig.get(urlKey)+deletedFlagValue
		//		 http://35.154.17.113/apiman-gateway/jiocloud/messages_all/1.0?page=2
				 FrameworkLogger.logStep("URL FOR HITTING NEXT API ********************"+url);
			     response = triggerGetApi(url, headerMap);
			 }
			
			FrameworkLogger.logStep("triggerRestoreMessagesForNextPage:-> End");
			return response;
			
		}
	  
	  public boolean readAllPagesForDesiredDvcMsg(ValidatableResponse response, String dvcMsgId) throws IOException
	  {
		  boolean isMessageInResponse = false;
		  String nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
		  
			FrameworkLogger.logStep("next link url: " + nextLinkURL);
			while (nextLinkURL != null && isMessageInResponse==false) {
				response = triggerRestoreMessagesForNextPage(nextLinkURL);
				isMessageInResponse = RestoreMessagesBaseScript.isMessagePresentInResponse(response, dvcMsgId);
				nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
				FrameworkLogger.logStep("next link url: " + nextLinkURL);
			}
			return isMessageInResponse;
		  
	  }
		
	  
	  public int readAllPagesForIndexOfDvcMsg(ValidatableResponse response, String dvcMsgId) throws IOException
	  {
		  FrameworkLogger.logStep("DEVICEMSGID TO BE SEARCHED=" + dvcMsgId);
		  int messageIndex = -1;
		  int finalmessageIndex=-1;
		  String nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
		  
			FrameworkLogger.logStep("Initial next link url: " + nextLinkURL);
			while (nextLinkURL != null && messageIndex==-1) {
				FrameworkLogger.logStep("next link url to be searched: " + nextLinkURL);
				response = triggerRestoreMessagesForNextPage(nextLinkURL);
				messageIndex = RestoreMessagesBaseScript.getIndexIfMessagePresentInResponse(response, dvcMsgId);
				nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
			//	if(!(nextLinkURL==null))
			//	{
			//	String page = nextLinkURL.split("=")[1];
		//	finalmessageIndex = (((Integer.parseInt(page))-1)*100)+messageIndex+1;
		//	}
			}
			FrameworkLogger.logStep("INDEX BELOW WHILE LOOP=" + messageIndex);
			String dvcMsgIdFromResponse=response.extract().path("messages["+messageIndex+"].dvcMsgId");
			FrameworkLogger.logStep("DEVICEMSGID=" + dvcMsgIdFromResponse);
			return messageIndex;
	  }
	  
	  public Object getValueofKeyForDesiredMessage(ValidatableResponse response, String dvcMsgId, String key) throws IOException
	  {
		  FrameworkLogger.logStep("DEVICEMSGID TO BE SEARCHED=" + dvcMsgId);
		  int messageIndex = -1;
		  int finalmessageIndex=-1;
		  String nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
		  
			FrameworkLogger.logStep("Initial next link url: " + nextLinkURL);
			while (nextLinkURL != null && messageIndex==-1) {
				FrameworkLogger.logStep("next link url to be searched: " + nextLinkURL);
				
				response = triggerRestoreMessagesForNextPage(nextLinkURL);
				messageIndex = RestoreMessagesBaseScript.getIndexIfMessagePresentInResponse(response, dvcMsgId);
				nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
				if(nextLinkURL=="")
					messageIndex = RestoreMessagesBaseScript.getIndexIfMessagePresentInResponse(response, dvcMsgId);
			//	if(!(nextLinkURL==null))
			//	{
			//	String page = nextLinkURL.split("=")[1];
		//	finalmessageIndex = (((Integer.parseInt(page))-1)*100)+messageIndex+1;
		//	}
			}
			Object value=response.extract().path("messages["+messageIndex+"]."+key);
			
			return value;
	  }
	  
	  public Object getValueofKeyForDesiredMessage(ValidatableResponse response, String dvcMsgId, String key,int includeDeleted) throws IOException
	  {
		  FrameworkLogger.logStep("DEVICEMSGID TO BE SEARCHED=" + dvcMsgId);
		  int messageIndex = -1;
		  int finalmessageIndex=-1;
		  String nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
		  
			FrameworkLogger.logStep("Initial next link url: " + nextLinkURL);
			while (nextLinkURL != null && messageIndex==-1) 
				{
				FrameworkLogger.logStep("next link url to be searched: " + nextLinkURL);
				
				response = triggerRestoreMessagesForNextPage(nextLinkURL, includeDeleted );
				messageIndex = RestoreMessagesBaseScript.getIndexIfMessagePresentInResponse(response, dvcMsgId);
				FrameworkLogger.logStep("MessageIndex******************" + messageIndex);
				nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
				if(nextLinkURL=="")
				{
					messageIndex = RestoreMessagesBaseScript.getIndexIfMessagePresentInResponse(response, dvcMsgId);
					
				}
				FrameworkLogger.logStep("MessageIndex" + messageIndex);
			//	if(!(nextLinkURL==null))
			//	{
			//	String page = nextLinkURL.split("=")[1];
		//	finalmessageIndex = (((Integer.parseInt(page))-1)*100)+messageIndex+1;
		//	}
			}
			
			Object value=response.extract().path("messages["+messageIndex+"]."+key);
			
			return value;
	  }
	  
	  
	  protected ValidatableResponse triggerRestoreMessagesForNextPage(String nextPageUrl, String deviceKeys) throws IOException {
		  ValidatableResponse response=null;
			FrameworkLogger.logStep("triggerRestoreMessagesForNextPage:-> Start");
		//	String strApiUrl = nextPageUrl;
			// http://apis.jiocloud.com/jcm/messages/all?page=2
			if(!(nextPageUrl==""))
			{
				//http://apis.jiocloud.com/jcm/messages/all?page=2
			//	 String endurl = nextPageUrl.split("com")[1];
				 String endurl = nextPageUrl.split("=")[1];
				 
				 String url= apiUrls.get("baseMessagesURL")+"/messages_all/1.0?page="+endurl+"&deviceKeys="+deviceKeys;
			//	 apiUrls.get("baseMessagesURL") + serverConfig.get(urlKey)+deletedFlagValue
		//		 http://35.154.17.113/apiman-gateway/jiocloud/messages_all/1.0?page=2
				 FrameworkLogger.logStep("URL FOR HITTING NEXT API ********************"+url);
			     response = triggerGetApi(url, headerMap);
			 }
			
			FrameworkLogger.logStep("triggerRestoreMessagesForNextPage:-> End");
			return response;
			
		}
	  public Object getValueofKeyForDesiredMessage(ValidatableResponse response, String dvcMsgId, String key, String devicekeys) throws IOException
	  {
		  FrameworkLogger.logStep("DEVICEMSGID TO BE SEARCHED=" + dvcMsgId);
		  int messageIndex = -1;
		  int finalmessageIndex=-1;
		  String nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
		  
			FrameworkLogger.logStep("Initial next link url: " + nextLinkURL);
			while (nextLinkURL != null && messageIndex==-1) 
				{
				FrameworkLogger.logStep("next link url to be searched: " + nextLinkURL);
				
				response = triggerRestoreMessagesForNextPage(nextLinkURL, devicekeys );
				messageIndex = RestoreMessagesBaseScript.getIndexIfMessagePresentInResponse(response, dvcMsgId);
				
				nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
				if(nextLinkURL=="")
				{
					messageIndex = RestoreMessagesBaseScript.getIndexIfMessagePresentInResponse(response, dvcMsgId);
					;}
				FrameworkLogger.logStep("MessageIndex" + messageIndex);
			//	if(!(nextLinkURL==null))
			//	{
			//	String page = nextLinkURL.split("=")[1];
		//	finalmessageIndex = (((Integer.parseInt(page))-1)*100)+messageIndex+1;
		//	}
			}
			
			Object value=response.extract().path("messages["+messageIndex+"]."+key);
			
			return value;
			
	  }
	  
	  public Object getValueofKeyForDesiredMessage(ValidatableResponse response, String dvcMsgId, String key,int includeDeleted, String devicekeys) throws IOException
	  {
		  FrameworkLogger.logStep("DEVICEMSGID TO BE SEARCHED=" + dvcMsgId);
		  int messageIndex = -1;
		  int finalmessageIndex=-1;
		  Object value = null;
		  try{
		  String nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
		  
			FrameworkLogger.logStep("Initial next link url: " + nextLinkURL);
			while (nextLinkURL != null && messageIndex==-1) 
				{
				FrameworkLogger.logStep("next link url to be searched: " + nextLinkURL);
				
				response = triggerRestoreMessagesForNextPage(nextLinkURL, includeDeleted, devicekeys);
				messageIndex = RestoreMessagesBaseScript.getIndexIfMessagePresentInResponse(response, dvcMsgId);
				try{
				nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
				}
				catch(Exception e)
				{
					System.out.println("next page url not found");
				}
				if(nextLinkURL.equalsIgnoreCase(""))
				{
					//messageIndex = RestoreMessagesBaseScript.getIndexIfMessagePresentInResponse(response, dvcMsgId);
					break;
				}
				FrameworkLogger.logStep("MessageIndex" + messageIndex);
			//	if(!(nextLinkURL==null))
			//	{
			//	String page = nextLinkURL.split("=")[1];
		//	finalmessageIndex = (((Integer.parseInt(page))-1)*100)+messageIndex+1;
		//	}
			}
			
			value=response.extract().path("messages["+messageIndex+"]."+key);
		
		  }
		  
		  catch(Exception e)
		  {
			  System.out.println("");
		  }
		  
		  return value;
			
	  }
	  
	  
	  
	/*  public Object getValueofKeyForDesiredMessage(ValidatableResponse response, String dvcMsgId, String key,int includeDeleted, String devicekeys) throws IOException
	  {
		  FrameworkLogger.logStep("DEVICEMSGID TO BE SEARCHED=" + dvcMsgId);
		  int messageIndex = -1;
		  int finalmessageIndex=-1;
		  Object value = null;
		  try{
		  String nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
		  
			FrameworkLogger.logStep("Initial next link url: " + nextLinkURL);
			while (messageIndex==-1) 
				{
				FrameworkLogger.logStep("next link url to be searched: " + nextLinkURL);
				
				response = triggerRestoreMessagesForNextPage(nextLinkURL, includeDeleted, devicekeys);
				messageIndex = RestoreMessagesBaseScript.getIndexIfMessagePresentInResponse(response, dvcMsgId);
				try{
				nextLinkURL = response.extract().jsonPath().get("nextPageUrl");
				}
				catch(Exception e)
				{
					System.out.println("next page url not found");
				}
				if(nextLinkURL.equalsIgnoreCase(""))
				{
					//messageIndex = RestoreMessagesBaseScript.getIndexIfMessagePresentInResponse(response, dvcMsgId);
					break;
				}
				FrameworkLogger.logStep("MessageIndex" + messageIndex);
			//	if(!(nextLinkURL==null))
			//	{
			//	String page = nextLinkURL.split("=")[1];
		//	finalmessageIndex = (((Integer.parseInt(page))-1)*100)+messageIndex+1;
		//	}
			}
			
			value=response.extract().path("messages["+messageIndex+"]."+key);
		
		  }
		  
		  catch(Exception e)
		  {
			  System.out.println("");
		  }
		  
		  return value;
			
	  }
	  */
	  protected ValidatableResponse triggerRestoreMessagesForNextPage(String nextPageUrl, int includeDeleted, String deviceKeys) throws IOException {
		  ValidatableResponse response=null;
			FrameworkLogger.logStep("triggerRestoreMessagesForNextPage:-> Start");
		//	String strApiUrl = nextPageUrl;
			// http://apis.jiocloud.com/jcm/messages/all?page=2
			if(!(nextPageUrl==""))
			{
				//http://apis.jiocloud.com/jcm/messages/all?page=2
			//	 String endurl = nextPageUrl.split("com")[1];
				 String endurl = nextPageUrl.split("=")[1];
				 
				 String url= apiUrls.get("baseMessagesURL")+"/messages_all/1.0?page="+endurl+"&deviceKeys="+deviceKeys+"&includeDeleted="+includeDeleted;
			//	 apiUrls.get("baseMessagesURL") + serverConfig.get(urlKey)+deletedFlagValue
		//		 http://35.154.17.113/apiman-gateway/jiocloud/messages_all/1.0?page=2
				 FrameworkLogger.logStep("URL FOR HITTING NEXT API ********************"+url);
			     response = triggerGetApi(url, headerMap);
			 }
			
			FrameworkLogger.logStep("triggerRestoreMessagesForNextPage:-> End");
			return response;
			
		}
}
