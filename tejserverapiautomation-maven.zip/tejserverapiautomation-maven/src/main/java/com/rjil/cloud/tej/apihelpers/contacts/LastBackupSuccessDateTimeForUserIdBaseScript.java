package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;

/**
 * @author Chandrashekhar Singh.
 * To get date time of last successful backup executed for User Id from any device. 
 * */

public class LastBackupSuccessDateTimeForUserIdBaseScript extends BaseTestScript {
    protected static final String moduleName="Contacts";
    protected static final String apiName="LastBackupSuccessDateTimeForUserId";
    
    public LastBackupSuccessDateTimeForUserIdBaseScript(){
  		globalApiName=apiName;
  	}

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It creates the url for API
     */
    private String getLastBackupSuccessDateTimeForUserIdUrl() {
        return apiUrls.get("baseContactURL") + serverConfig.get("lastBackupSuccessDateTimeForUserIdUrl");
    }

    /**
     * @return validatable response for the API
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    protected ValidatableResponse triggerGetApiLastBackupSuccessDateTimeForUserId() {
		FrameworkLogger.logStep("triggerGetApiLastBackupSuccessDateTimeForUserId:-> Start");
        // setContactBackupJsonBody();
		
		String strApiUrl=getLastBackupSuccessDateTimeForUserIdUrl();
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);

		FrameworkLogger.logStep("triggerGetApiLastBackupSuccessDateTimeForUserId:-> End");
		return response;
    }

    /**
     * @return validatable response for the API
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
	public static String getLastBackupSuccessDateTimeForUserId() throws org.json.simple.parser.ParseException, VerificationFailException, ParseException, IOException, InterruptedException {
		FrameworkLogger.logStep("getLastBackupSuccessDateTimeForUserId:-> Start");
		
		LastBackupSuccessDateTimeForUserIdBaseScript apiObj=new LastBackupSuccessDateTimeForUserIdBaseScript();
		//Create header for the API.
		apiObj.createHeader();

//      Call the API to call LastBackupSuccessDateTime API.
        ValidatableResponse responseLastBackupSuccessDateTime = apiObj.triggerGetApiLastBackupSuccessDateTimeForUserId();

//        Get and verify the status code.
        int status = responseLastBackupSuccessDateTime.extract().statusCode();
        if(status!=ApiResponseCodes.RESPONSECODE200.getValue()){
        	
    		FrameworkLogger.logStep("Something wrong in fetching LastBackupSuccessDateTimeForUserId"
    				+ "Goint to add a contact to add LastBackupSuccessDateTimeForUserId...");

    		String strUniqueValue=Utils.getUniqueValue();

    		String firstName = "testContactFN_FromLastBackupSuccessDateTimeForUserIdRA_1_" + strUniqueValue;
    		String lastName = "testContactLN_LastBackupSuccessDateTimeForUserId1_" + strUniqueValue;
    		String aditionalName = "testContactAN_LastBackupSuccessDateTimeForUserId1_" + strUniqueValue;
    		String emailID = "testContactEmail_LastBackupSuccessDateTimeForUserId1_" + strUniqueValue+"@test.com";
    		String phoneNumber = "tel:+" + Utils.getUniquePhoneNumber();

    		ValidatableResponse responseBackup=ContactBackupBaseScript.backupAcontact("true", "false", firstName, lastName, aditionalName, phoneNumber, emailID);
        	
//    		Call the API LastBackupSuccessDateTimeForUserId
    		responseLastBackupSuccessDateTime = apiObj.triggerGetApiLastBackupSuccessDateTimeForUserId();
        }

        //Verify the date of the API
        String timeLastBackupSuccessDateTime=responseLastBackupSuccessDateTime.extract().path("timestamp");
        FrameworkLogger.logStep("timeLastBackupSuccessDateTime:-> " + timeLastBackupSuccessDateTime);
        
        FrameworkLogger.logStep("getLastBackupSuccessDateTimeForUserId:-> End");
        return timeLastBackupSuccessDateTime;
    }

}
