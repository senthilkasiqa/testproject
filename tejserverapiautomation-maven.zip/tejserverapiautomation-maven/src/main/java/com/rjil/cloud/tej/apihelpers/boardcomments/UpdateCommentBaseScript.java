package com.rjil.cloud.tej.apihelpers.boardcomments;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;

public class UpdateCommentBaseScript extends BaseTestScript{

	protected static final String apiName = "UpdateComment";
	protected static String updateCommentJsonBody;
	public static String boardKey;
	
	protected String updateCommentBaseScriptUrl(String boardKey, String commentKey) {
		FrameworkLogger.logStep("updateCommentBaseScriptUrl: Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get("updateCommentUrl").replace("{boardKey}", boardKey).replace("{commentKey}", commentKey);
		FrameworkLogger.logStep("updateCommentBaseScriptUrl: End");
		return url;
	}
	
	protected String updateCommentBaseScriptUrl(String urlValue, String boardKey, String commentKey) {
		FrameworkLogger.logStep("updateCommentBaseScriptUrl: Start");
		String url = apiUrls.get("baseURL") + urlValue;
		FrameworkLogger.logStep("updateCommentBaseScriptUrl: End");
		return url;
	}
	
	protected String setUpdateCommentJsonBody() throws IOException{
		FrameworkLogger.logStep("setUpdateCommentJsonBody: Start");
		// load json file
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/updateCommentBody.js";
		File file = new File(path);
		updateCommentJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setUpdateCommentJsonBody: End");
		return updateCommentJsonBody;
	}


	protected ValidatableResponse triggerPutApiUpdateComment(String boardKey, String commentKey) throws IOException {

		FrameworkLogger.logStep("triggerPutApiUpdateComment: Start");
        String strApiUrl=updateCommentBaseScriptUrl(boardKey, commentKey);
		ValidatableResponse response=triggerPutApi(strApiUrl, headerMap, updateCommentJsonBody);
		FrameworkLogger.logStep("triggerPutApiUpdateComment: End");
		return response;
	}
	
	
	protected ValidatableResponse triggerPutApiUpdateComment(String boardKey, String commentKey, Map<String, String> headerMap) throws IOException {

		FrameworkLogger.logStep("triggerPutApiUpdateComment: Start");
		String strApiUrl=updateCommentBaseScriptUrl(boardKey, commentKey);
		
		// get response from create a Folder API
		ValidatableResponse response=triggerPutApi(strApiUrl, createHeader(headerMap), updateCommentJsonBody);
		FrameworkLogger.logStep("triggerPutApiUpdateComment: End");

		return response;
	}
	

	public static ValidatableResponse updateCommentServiceMethod(String comment, String boardKey, String commentKey) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("updateCommentServiceMethod: Start");
		
		UpdateCommentBaseScript updateComment = new UpdateCommentBaseScript();
		updateComment.createHeader();
		updateCommentJsonBody = updateComment.setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, updateCommentJsonBody);
		ValidatableResponse response = updateComment.triggerPutApiUpdateComment(boardKey, commentKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("postCommentServiceMethod: End");
		return response;
	}
	
	public static ValidatableResponse updateCommentServiceMethod(Map<String, String> headerMap1, String comment, String boardKey, String commentKey) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("postCommentServiceMethod: Start");
		

		UpdateCommentBaseScript updateComment = new UpdateCommentBaseScript();
		updateComment.createHeader();
		updateCommentJsonBody = updateComment.setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, updateCommentJsonBody);
		ValidatableResponse response = updateComment.triggerPutApiUpdateComment(boardKey, commentKey, headerMap1);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("postCommentServiceMethod: End");
		return response;
	}
	
}
