package com.rjil.cloud.tej.enums;

/**
 * NMS Parameters Enum
 */

public enum NmsParameters {

	//OBJECTS("objects"),
//	OBJECTKEYS("objectKeys"),

	XUSERID("X-User-Id"), 
	XDEVICEKEY("X-Device-Key"), 
	AUTHORIZATION("Authorization"), 
	ACCEPTLANGUAGE("Accept-Language"),
	IFMODIFIEDSINCE("If-Modified-Since"),
	PARENTOBJECTKEY("parentObjectKey"),
	OBJECTNAME("objectName"),
	SOURCENAME("sourceName"),
    STATUS("status"),
	OBJECTKEY("objectKey"),
	ISHIDDEN("isHidden"),
	ISLOCKED("isLocked"),
	ISREADONLY("isReadonly"),
	ISPINNED("isPinned"),
	SOURCEFOLDER("sourceFolder"),
	VERSION("version"),
	DESTINATIONOBJECTKEY("destinationObjectKey"),
	ROOTFOLDERKEY("rootFolderKey"),
	OPERATIONNAME("operationName");
	

	public String value;

	NmsParameters(String value) {
		this.value = value;

	}

	public String getValue() {
		return value;
	}
}
