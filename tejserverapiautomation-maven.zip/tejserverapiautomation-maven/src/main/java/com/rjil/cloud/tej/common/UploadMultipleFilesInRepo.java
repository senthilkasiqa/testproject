package com.rjil.cloud.tej.common;

import java.util.ArrayList;
import java.util.List;

import com.rjil.cloud.tej.apihelpers.fileupload.UploadBaseScript;

public class UploadMultipleFilesInRepo 
{
	public static void uploadMultipleFilsToRepo()
	{
		int noOfFiles = 10; 
        List<String>filedates = new ArrayList();
		
		filedates.add(UploadBaseScript.getFileCreatedTime(0, 1));
		filedates.add(UploadBaseScript.getFileCreatedTime(0, 2));
		filedates.add(UploadBaseScript.getFileCreatedTime(0, 3));
		filedates.add(UploadBaseScript.getFileCreatedTime(0, 4));
		try {
			UploadBaseScript.uploadMultipleFilesServiceMethod(noOfFiles, filedates);
		} catch (Exception e) {
		
			e.printStackTrace();
		}
	
	}
}
