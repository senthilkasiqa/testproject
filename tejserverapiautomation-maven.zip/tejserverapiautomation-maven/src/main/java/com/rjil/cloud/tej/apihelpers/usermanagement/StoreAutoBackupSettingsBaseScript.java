package com.rjil.cloud.tej.apihelpers.usermanagement;

import java.io.File;
import java.io.IOException;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

/**
 * @author Ashwini.Abhyankar : Base class for store auto backup api
 */
public class StoreAutoBackupSettingsBaseScript extends BaseTestScript {
	protected String storeAutoBackupSettingsJsonBody;
	protected static final String apiName = "StoreAutoBackupSettings";
	
	public StoreAutoBackupSettingsBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * Method for Creating Store Auto Backup Settings Url
	 */
	protected String getStoreAutoBackupSettingsURL() {
		FrameworkLogger.logStep("getStoreAutoBackupSettingsURL:-> Start");
		String url = apiUrls.get("baseURL") + serverConfig.get("storeAutoBackupSettingsUrl");

		FrameworkLogger.logStep("getStoreAutoBackupSettingsURL:-> End");
		return url;
	}

	/**
	 * Method for Creating Store Auto Backup Settings Url for invalid data
	 * 
	 * @return
	 */
	protected String getStoreAutoBackupSettingsURL(String url) {
		FrameworkLogger.logStep("getStoreAutoBackupSettingsURL:-> Start");
		String apiUrl = apiUrls.get("baseURL") + serverConfig.get(url);

		FrameworkLogger.logStep("getStoreAutoBackupSettingsURL:-> End");
		return apiUrl;
	}

	/**
	 * Method for Creating Store Auto Backup Settings body
	 * 
	 * @return
	 */

	protected String setStoreAutoBackupSettingsJsonBody() throws IOException {
		FrameworkLogger.logStep("setStoreAutoBackupSettingsJsonBody:-> Start");
		String path = System.getProperty("user.dir")
				+ "/resources/userManagementTestData/storeAutoBackupSettingsJsonBody.js";
		File file = new File(path);
		storeAutoBackupSettingsJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setStoreAutoBackupSettingsJsonBody:-> End");
		return storeAutoBackupSettingsJsonBody;
	}

	/**
	 * Method to get the response after triggering store auto backup settings
	 * api
	 * 
	 * @return
	 * @throws IOException
	 */
	protected ValidatableResponse triggerPostApiStoreAutoBackupSettings() throws IOException {

		FrameworkLogger.logStep("triggerPostApiStoreAutoBackupSettings:-> Start");

		// get url for store autobackup settings url
		String strApiUrl = getStoreAutoBackupSettingsURL();

		// get response from store auto backup settings api
		ValidatableResponse response = triggerPostApi(strApiUrl, headerMap, storeAutoBackupSettingsJsonBody);

		FrameworkLogger.logStep("triggerPostApiStoreAutoBackupSettings:-> End");
		return response;
	}

	protected ValidatableResponse triggerPostApiStoreAutoBackupSettings(String apiUrl) throws IOException {

		FrameworkLogger.logStep("triggerPostApiStoreAutoBackupSettings:-> Start");

		// get url for store autobackup settings url
		String strApiUrl = getStoreAutoBackupSettingsURL(apiUrl);

		// get response from store auto backup settings api
		ValidatableResponse response = triggerPostApi(strApiUrl, headerMap, storeAutoBackupSettingsJsonBody);

		FrameworkLogger.logStep("triggerPostApiStoreAutoBackupSettings:-> End");
		return response;
	}

}