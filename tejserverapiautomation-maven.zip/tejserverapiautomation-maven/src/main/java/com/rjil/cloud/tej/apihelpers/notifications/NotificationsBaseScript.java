package com.rjil.cloud.tej.apihelpers.notifications;

import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;

/**
 * Created by bharat on 08/09/16.
 */
public class NotificationsBaseScript extends BaseTestScript {
//	protected Map<String, String> headerMap = null;
	protected static final String apiName = "GetNotifications";
	
	public NotificationsBaseScript(){
		globalApiName=apiName;
	}

	protected String getNotificationsURL() {
		return apiUrls.get("baseURL") + serverConfig.get("getnotification");
	}
	
	protected String getNotificationsURL(String url) {
		return apiUrls.get("baseURL") + serverConfig.get(url);
	}

/*	protected void createHeader() {
		headerMap = new HashMap<>();
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);

		// Add X-API Header key if the value is set as YES in the configuration
		// file
		addXapiHeaderKey(headerMap);

	}
*/

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Remove from header for this API.
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), "1462370673");
		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	protected ValidatableResponse triggerGetApiGetNotification() {
		// createHeader();
		FrameworkLogger.logStep("triggerGetApiGetNotification:-> Start");
        // setContactBackupJsonBody();

    	String strApiUrl=getNotificationsURL();
    	ValidatableResponse response=triggerGetApi(strApiUrl, headerMap);
		
    	FrameworkLogger.logStep("triggerGetApiGetNotification:-> End");
    	
    	gettingNotificationInformation(response);
        return response;

	}
	
	protected ValidatableResponse triggerGetApiGetNotification(String url) {
		// createHeader();
		FrameworkLogger.logStep("triggerGetApiGetNotification:-> Start");
        // setContactBackupJsonBody();

    	String strApiUrl=getNotificationsURL(url);
    	ValidatableResponse response=triggerGetApi(strApiUrl, headerMap);
		
    	FrameworkLogger.logStep("triggerGetApiGetNotification:-> End");
    	
   // 	gettingNotificationInformation(response);
        return response;

	}

	/**
	 * @author Prateek
	 * 
	 *         Added service method for get notification api so that it can be
	 *         used in other test
	 */
	public static ValidatableResponse getNotificationServiceMethod() {
		NotificationsBaseScript notificationObject = new NotificationsBaseScript();
		notificationObject.createHeader();
		return notificationObject.triggerGetApiGetNotification();
	}

	/**
	 * 
	 * @author Prateek
	 * 
	 *         Method for getting notification information
	 * @param response
	 */

	public static void gettingNotificationInformation(ValidatableResponse response) {
		FrameworkLogger.logStep("gettingNotificationInformation:Start");

		/**
		 * This notificationId derived from getNotification API is used in other
		 * tests( notification related). if getNotification api is successful
		 * then valid notificationId is put into the Repository map and is
		 * available for other tests to retrieve this notificationId from the
		 * respositoryMap If the file fails to get uploaded, then this
		 * notificationId will have null value and corresponding tests related
		 * to notification would fail as the notificationIdused in those tests
		 * would be passed as null
		 *
		 */
		String strNotificationId = response.extract().path("notifications[0].notificationId");
		System.out.println("get NotificationId ========>>" + strNotificationId);
		repositoryMap.put(RepositoryParameterEnum.NOTIFICATIONID.getValue(), strNotificationId);
		long updatedTime = response.extract().path("lastSyncDate");
		String lastUpdatedTime = String.valueOf(updatedTime);

		FrameworkLogger.logStep("Time==============>" + lastUpdatedTime);

		repositoryMap.put(RepositoryParameterEnum.LASTUPDATEDTIME.getValue(), lastUpdatedTime);

		System.out.println("NOW THE NOTIFICATIONiD FROM REPOSITORY IS ="
				+ repositoryMap.get(RepositoryParameterEnum.NOTIFICATIONID.getValue()));
		Integer unseenCount = response.extract().path("totalUnseen");
		String totalUnseenCount = unseenCount.toString();
		repositoryMap.put(RepositoryParameterEnum.TOTALUNSEEN.getValue(), totalUnseenCount);
		FrameworkLogger.logStep("gettingNotificationInformation: End");
	}

}
