package com.rjil.cloud.tej.apihelpers.nms;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;

import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * 
 * @author Prateek
 * 
 * Base class for Restore all trash api 
 *
 */

public class RestoreAllTrashBaseScript extends BaseTestScript {

	protected static final String apiName = "RestoreAllTrash";
//	protected Map<String, String> headerMap = null;

	public RestoreAllTrashBaseScript(){
		globalApiName=apiName;
	}
	// created a Hashmap to save all the headers.
/*	protected void createHeader() {

		FrameworkLogger.logStep("createHeader:-> Start");
		headerMap = new HashMap<>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");

		// Add 'X-Api-Key' in header for the API.
		addXapiHeaderKey(headerMap);

		FrameworkLogger.logStep("createHeader:-> End");
	}
*/
	/**
	 * get a complete url for 'Restore All Trash API'
	 * 
	 * @return
	 */
	protected String getRestoreAllTrashUrl() {
		FrameworkLogger.logStep("getRestoreAllTrashUrl : Start");
		String url=apiUrls.get("baseURL") + serverConfig.get("restoreAllTrashUrl");
		FrameworkLogger.logStep("getRestoreAllTrashUrl : End");
		return url;
	}
	
	/**
	 * get a complete url for 'Restore All Trash API' for negative test
	 * 
	 * @return
	 */
	protected String getRestoreAllTrashUrl(String urlKey) {
		FrameworkLogger.logStep("getRestoreAllTrashUrl : Start");
		String url=apiUrls.get("baseURL") + serverConfig.get(urlKey);
		FrameworkLogger.logStep("getRestoreAllTrashUrl : End");
		return url;
	}

	/**
	 * Method to get Restore all trash Response 
	 * 
	 * 
	 */
	protected ValidatableResponse triggerGetApiRestoreAllTrash() throws IOException {
		FrameworkLogger.logStep("triggerGetApiRestoreAllTrash : Start");
		String strApiUrl=getRestoreAllTrashUrl();
		ValidatableResponse response=triggerPutApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiRestoreAllTrash : End");
		return response;
	}
	
	/**
	 * Method to get Restore all trash Response for negative test
	 * 
	 * 
	 */
	protected ValidatableResponse triggerGetApiRestoreAllTrash(String url) throws IOException {
		FrameworkLogger.logStep("triggerGetApiRestoreAllTrash : Start");
		String apiUrl=getRestoreAllTrashUrl(url);
		ValidatableResponse response=triggerPutApi(apiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiRestoreAllTrash : End");
		return response;
	}
	
	/**
	 * Get Restore All Trash Response
	 * @param response
	 * @throws VerificationFailException 
	 */

	public static void extractAndVerifyRestoreAllTrashResponse(ValidatableResponse response) throws VerificationFailException {
		FrameworkLogger.logStep("extractAndAssertRestoreAllTrashResponse : Start");
		String status = response.extract().path("objects[0].status");
		boolean isHidden = response.extract().path("objects[0].isHidden");
		boolean isLocked = response.extract().path("objects[0].isLocked");
		/*boolean isPinned = response.extract().path("objects[0].isPinned");
		boolean iLiked = response.extract().path("objects[0].iLiked");*/
		boolean isReadonly = response.extract().path("objects[0].isReadonly");
		
		Verify.verifyEquals(status, "A");
		Verify.verifyEquals(isHidden, false);
		Verify.verifyEquals(isLocked, false);
		/*Assert.assertEquals(isPinned, false);
		Assert.assertEquals(iLiked, false);*/
		Verify.verifyEquals(isReadonly, false);
		FrameworkLogger.logStep("extractAndAssertRestoreAllTrashResponse : End");

	}
	
	public static int getIndexIfObjectKeyPresentInResponse(ValidatableResponse response, String strObjectKeyValue)
			throws IOException {
		FrameworkLogger.logStep("getIndexIfObjectKeyPresentInResponse:-> start; strObjectKeyValue:-> " + strObjectKeyValue);
		int isObjectKeyMatchingIndex = -1;

		int sizeOfOjectArray = response.extract().jsonPath().getList("objects").size();
		FrameworkLogger.logStep("sizeOfOjectArray:-> " + sizeOfOjectArray);
		for (int i = 0; i < sizeOfOjectArray; i++) {
			String actualObjectKeyValue = response.extract().path("objects[" + i + "].objectKey");

			FrameworkLogger.logStep("Comparing strObjectKeyValue:-> " + strObjectKeyValue
					+ " With actualObjectKeyValue:-> " + actualObjectKeyValue);

			if (actualObjectKeyValue.equalsIgnoreCase(strObjectKeyValue)) {
				isObjectKeyMatchingIndex = i;
				FrameworkLogger.logStep("ObjectKeyValue matched.");
				break;
			}
		}
		FrameworkLogger.logStep("getIndexIfObjectKeyPresentInResponse:-> end");
		System.out.println("index of uploaded file in response="+isObjectKeyMatchingIndex);
		return isObjectKeyMatchingIndex;
		
	}

	
}
