/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.others;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author Prateek
 *
 */
public class AppSettingBaseScript extends BaseTestScript{

	protected static final String apiName="AppSetting";
	
	public AppSettingBaseScript(){
		globalApiName=apiName;
	}
	
	public void defaultLogin() throws IOException {
		//empty login
	}
	
	 //Overload the method.
    protected Map<String, String> createHeader() {
    	FrameworkLogger.logStep("createHeader: Start");
    	headerMap=initializeHeader();
    	//Remove device key from header for this API.
    	headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
    	headerMap.remove(HeaderParameters.XAPIKEY.getValue());
    	headerMap.remove(HeaderParameters.XUSERID.getValue());
    	headerMap.remove(HeaderParameters.ACCEPTLANGUAGE.getValue());
    	headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());
    	FrameworkLogger.logStep("createHeader: End");
    	return headerMap;
    }

	/**
	 * 
	 * Construct the final App Upgrade request. String that needs to be appended
	 * to the base url is passed directly from the test itself
	 * 
	 */

	public static String getAppSettingUrl(String os) {
		
		FrameworkLogger.logStep("getAppUpgradeUrl: Start");

		String url = apiUrls.get("URL") + serverConfig.get("appSettingUrl").replace("{os}", os);
		
		FrameworkLogger.logStep("URL:"+url);
		
		FrameworkLogger.logStep("getAppUpgradeUrl: End");
		return url;

	}

	/**
	 * Method to get App Upgrade Response
	 */
	protected  ValidatableResponse triggerGetApiAppSettings(String os){
//	protected ValidatableResponse getAppUpgradeResponse(String os) {

		FrameworkLogger.logStep("getAppUpgradeResponse: Start");
		
		ValidatableResponse response = triggerGetApi(getAppSettingUrl(os), headerMap);
	
		Utils.addRequestResponseToLogger();

		FrameworkLogger.logStep("getAppUpgradeResponse: End");
		return response;

	}
	
}
