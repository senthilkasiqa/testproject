/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.download;

import static com.jayway.restassured.RestAssured.given;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author Prateek
 *
 */
public class DownloadBaseScript extends BaseTestScript{
	
	protected static final String apiName= "DownloadFile";
	
	public DownloadBaseScript(){
		globalApiName=apiName;
	}
	
	
//	 protected  Map<String,String> headerMap = null;

	    /**In order to construct the header parameters for each test, we would call a createHeader method.
	     * This method would initialize a hashmap that would contain a key-value pair ( header parameters and its corresponding value)
	     *
	     * UserId
	     * Authorization
	     *
	     * The method would then put header parameters needed for each test case.
	     * Once the header parameters are available, we would call the API method to get response.
	     * The idea behing using a hashmap is that we would need only 3 methods in the middle layer base script to run
	     * all our test cases namely*/

/*	    protected void createHeader(){
	    	headerMap = new HashMap<>();
	        headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
	        headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
	        
	        addXapiHeaderKey(headerMap);
	    }
*/	

    //Overload the method.
    protected Map<String, String> createHeader() {
    	FrameworkLogger.logStep("createHeader: Start");
    	headerMap=initializeHeader();

    	//Remove device key from header for this API.
    	headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
    	FrameworkLogger.logStep("createHeader: End");
    	return headerMap;
    }

	/**
	 * 
	 * Construct the final Download request. 
	 * Need to add object key in the url by fetching object key from the Upload Response 
	 * 
	 */

	protected String getDownloadUrl(String objectKey) {
		FrameworkLogger.logStep("getDownloadUrl:Start");
		String url = apiUrls.get("downloadIp") + serverConfig.get("downloadUrl").replace("{objectKey}", objectKey);
		FrameworkLogger.logStep("getDownloadUrl:End");
		return url;

	}
	
	/**
	 * 
	 * Construct the final Download request. 
	 * Need to add object key in the url by fetching object key from the Upload Response 
	 * 
	 */

	protected String getDownloadUrl(String objectKey,String downloadUrl) {
		FrameworkLogger.logStep("getDownloadUrl:Start");
		String url = apiUrls.get("downloadIp") + serverConfig.get(downloadUrl).replace("{objectKey}", objectKey);
		FrameworkLogger.logStep("getDownloadUrl:End");
		return url;

	}
	
	
	/**
	 * Method to get Download File Response
	 */
	protected ValidatableResponse getDownloadFileResponse(String objectKey) {
		FrameworkLogger.logStep("getDownloadFileResponse: Start");
//		ValidatableResponse response = given().headers(headerMap).when().get(getDownloadUrl(objectKey)).then();
		ValidatableResponse response = triggerGetApi(getDownloadUrl(objectKey), headerMap);

		FrameworkLogger.logStep("getDownloadFileResponse: End");
		/**
		 * Return back the response to the test method
		 */
		return response;

	}
	
	/**
	 * Method to get Download File Response
	 */
	protected ValidatableResponse getDownloadFileResponse(String objectKey,String url) {
		FrameworkLogger.logStep("getDownloadFileResponse: Start");
//		ValidatableResponse response = given().headers(headerMap).when().get(getDownloadUrl(objectKey)).then();
		ValidatableResponse response = triggerGetApi(getDownloadUrl(objectKey,url), headerMap);
		FrameworkLogger.logStep("getDownloadFileResponse: End");
		/**
		 * Return back the response to the test method
		 */
		return response;

	}
	

}
