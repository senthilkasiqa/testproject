package com.rjil.cloud.tej.apiconstants;

public class NewBoardConstants {

	public static String getBoardName() {
		return "$.boardName";
	}
	
	public static String getParentObjectKey() {
		return "$.parentObjectKey";
	}
	
	public static String getHyperlink() {
		return "$.hyperLink";
	}
	
	public static String getFirstUserContact() {
		return "$.userContacts[0].userContact";
	}
	
	public static String getFirstUserType() {
		return "$.userContacts[0].userType";
	}
	
	public static String getFirstFirstName() {
		return "$.userContacts[0].firstName";
	}
	
	public static String getFirstLastName() {
		return "$.userContacts[0].lastName";
	}
	
	
	public static String getSecondUserContact() {
		return "$.userContacts[1].userContact";
	}
	
	public static String getSecondUserType() {
		return "$.userContacts[1].userType";
	}
	
	public static String getSecondFirstName() {
		return "$.userContacts[1].firstName";
	}
	
	public static String getSecondLastName() {
		return "$.userContacts[1].lastName";
	}
	
	public static String getCategoryKey() {
		return "$.categoryKey";
	}
	
	public static String getCategoryName() {
		return "$.categoryName";
	}
	
	public static String getStatus() {
		return "$.objects[0].status";
	}
	
	public static String getObjectKeyForRepositoryUploadToBoard() {
		return "$.objects[0].objectKey";
	}
	
	public static String getBoardCoverPicObjectKey() {
		return "$.boardCoverPicObjectKey";
	}
	

	public static String getMemberUserId(int index){
		return "$.members["+index+"].userId";
	}
	
	public static String getBoardDescription() {
		return "$.boardDescription";
	}
	
	public static String getSourceBoardKey()
	{
		return "$.copyFileList[0].sourceBoardKey";
	}
	
	public static String getSourceObjectKey()
	{
		return "$.copyFileList[0].sourceObjectKey";
	}
	
	
	public static String getComment()
	{
		return "$.comment";
	}
	
	public static String getBoardKey(int index)
	{
		return "$.operations["+index+"].object.boardKey";
	}
	
	public static String getObjectKey(int index)
	{
		return "$.operations["+index+"].object.objectKey";
	}
	
	
	public static String getUpdateMetdaDataBoardName(int index)
	{
		return "$.operations["+index+"].object.boardName";
	}
	
	public static String getUpdateMetdaDataBoardDescription(int index)
	{
		return "$.operations["+index+"].object.boardDescription";
	}
	
	public static String getObjectName(int index)
	{
		return "$.operations["+index+"].object.objectName";
	}
	
	public static String getOperationName(int index)
	{
		return "$.operations["+index+"].operation";
	}
	
	public static String getBoardKeyForRestoreTrashFile(int index)
	{
		return "$.objects["+index+"].boardKey";
	}
	
	public static String getObjectKeyForRestoreTrashFile(int index)
	{
		return "$.objects["+index+"].objectKey";
	}
	
	public static String getShareKey()
	{
		return "$.shareKey";
	}
	
	public static String getShareURL()
	{
		return "$.shareURL";
	}
	
	public static String getRecipients(int index)
	{
		return "$.recipients["+index+"].emailId";
	}
	
	public static String getRecipient()
	{
		return "$.recipients";
	}
	
	public static String getBoardKeyForDeleteFile(int index)
	{
		return "$.objects["+index+"].object.boardKey";
	}
	
	public static String getObjectForDeleteFile(int index)
	{
		return "$.objects["+index+"].object.objectKey";
	}
	
	public static String getboardEverCreated()
	{
		return "$.boardEverCreated";
	}
	
	public static String getBoardKeyForCreateSuggestedBoard()
	{
		return "$.boardKey";
	}
	
	public static String getBoardNameForCreateSuggestedBoard()
	{
		return "$.boardName";
	}
	
	public static String getObjectKeyForCreateSuggestedBoard(int index)
	{
		return "$.files["+index+"].objectKey";
	}
	
	public static String getSizeInBytesForCreateSuggestedBoard(int index)
	{
		return "$.files["+index+"].sizeInBytes";
	}
	

}
