package com.rjil.cloud.tej.apihelpers;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.EncoderConfig;
import com.jayway.restassured.config.LogConfig;
import com.jayway.restassured.config.RestAssuredConfig;
import com.jayway.restassured.filter.log.LogDetail;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseBodyExtractionOptions;
import com.jayway.restassured.response.ValidatableResponse;
import com.jayway.restassured.response.ValidatableResponseLogSpec;
import com.jayway.restassured.specification.RequestSpecification;
import com.rjil.cloud.tej.apiconstants.BoardConstants;
import com.rjil.cloud.tej.apiconstants.LoginConstants;
import com.rjil.cloud.tej.apihelpers.boards.BoardsFeedBaseScript;
import com.rjil.cloud.tej.apihelpers.usermanagement.LoginBaseScript;
import com.rjil.cloud.tej.apihelpers.usermanagement.LogoutBaseScript;
import com.rjil.cloud.tej.common.Base64;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.datadriven.model.DataContainer;
import com.rjil.cloud.tej.common.datadriven.model.TestDataRecord;
import com.rjil.cloud.tej.common.datadriven.reader.CSVDataReader;
import com.rjil.cloud.tej.common.datadriven.reader.ExcelDataReader;
import com.rjil.cloud.tej.common.datadriven.reader.JSONDataReader;
import com.rjil.cloud.tej.common.datadriven.reader.TestDataReader;
import com.rjil.cloud.tej.common.datadriven.reader.XMLDataReader;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.DataType;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.LoginParameters;
import com.rjil.cloud.tej.enums.MultiDeviceRepositoryParameters;


import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;

import org.apache.commons.io.FileUtils;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.Console;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.config.RestAssuredConfig.config;

public class BaseTestScript {

	// These are class variables as they are declared with static modifier
	public static String executionServer;
	public static boolean isIdam;
	public static boolean isBoard;
	protected DataContainer dataContainer;
	public static Map<String, String> apiUrls;
	public static Map<String, String> serverConfig;
	public static String accessToken;
	public static String shardKey;
	public static String userId;
	public static String refreshToken;
	public static String authProviderToken;
	public static String authorizationType = "Basic ";
	public static String rootFolderKey;
	protected static String loginJSONBody = "";
	protected static String loginURL = "";
	protected static LoginConstants loginConstants;
	protected static BoardConstants boardConstants;
	public static Map<String, String> repositoryMap;
	protected static boolean userIsLoggedIn;
	public static boolean loggedInSuccessful = false;
	private static String strLoggerFileNameForLogin = "Login";
	private static String strLoggerFileNameForLogout = "Logout";
	protected static Map<String, String> headerMap = null;
	protected static Map<String, Map<String, String>> multiDeviceRepositoryMap = null;
	public static String deviceKeyForWeb;
	private static ValidatableResponse currentRunningApiResponse = null;
	public static String strEmail;
	public static String strPassword;
	public String globalApiName = null;
	public static String getMethodName = null;
	protected static Map<String, Map<String, String>> multiUserRepositoryMap = null;
	// protected static Map<String, Map<String, Map<String, String>>>
	// multiUserRepositoryMap = null;

	// protected static ContactBackupConstants contactBackupConstants;
	public static String firstName;
	public static String lastName;
	public static String emailId;
	public static String mobileNumber;

	public static String firstNameOfOwner;
	public static String lastNameOfOwner;
	public static String contactInfoOfOwner;
	public static String userIdOfOwner;
	public static String firstNameOfContributor;
	public static String lastNameOfContributor;
	public static String contactInfoOfContributor;
	public static String userIdOfContributor;
	public static String firstNameOfSecondContributor;
	public static String lastNameOfSecondContributor;
	public static String contactInfoOfSecondContributor;
	public static String userIdOfSecondContributor;
	public static Map<String, String> deviceOwnerInfo;
	public static Map<String, String> deviceContributorInfo;
	public Map<String, String> deviceSecondContributorInfo;

	static BufferedWriter bw = null;
	static FileWriter fw = null;

	/**
	 * Base Test script Constructor
	 */
	public BaseTestScript() {
		// Reading variables from Jenkins/System variables.
		String strEnvValue = null;
		strEnvValue = System.getenv("environment");
		String strIsIDAM = null;
		strIsIDAM = System.getenv("isIDAM");
		String strIsBoard = null;
		strIsBoard = System.getenv("isBoard");
		strEmail = System.getenv("Email");
		strPassword = System.getenv("Password");

		String strDeviceKey = null;
		strDeviceKey = System.getenv("deviceKey");
		String strDeviceKey2 = null;
		strDeviceKey2 = System.getenv("deviceKey2");
		String strDeviceKey3 = null;
		strDeviceKey3 = System.getenv("deviceKey3");

		String strBuildNumber = null;
		strBuildNumber = System.getenv("BUILD_NUMBER");

		String strReleaseVersion = null;
		strReleaseVersion = System.getenv("RELEASE_VERSION");

		serverConfig = Utils.getServerConfigMAP();

		// Adding Jenkins variable/values (if passed from Jenkins) into
		// ServerConfig MAP.
		if (strEnvValue != null) {
			serverConfig.put("environment", strEnvValue);
		}
		if (strIsIDAM != null) {
			serverConfig.put("isIDAM", strIsIDAM);
		}
		
		if (strIsIDAM != null) {
			serverConfig.put("isBoard", strIsBoard);
		}
		if (strDeviceKey != null) {
			serverConfig.put("deviceKey", strDeviceKey);
		}
		if (strDeviceKey2 != null) {
			serverConfig.put("deviceKey2", strDeviceKey2);
		}
		if (strDeviceKey3 != null) {
			serverConfig.put("deviceKey3", strDeviceKey3);
		}
		if (strBuildNumber != null) {
			serverConfig.put("BUILD_NUMBER", strBuildNumber);
		} else {
			serverConfig.put("BUILD_NUMBER", "BUILD_NUMBER_NOT_PROVIDED");
		}
		if (strReleaseVersion != null) {
			serverConfig.put("RELEASE_VERSION", strReleaseVersion);
		} else {
			serverConfig.put("RELEASE_VERSION", "RELEASE_VERSION_NOT_PROVIDED");
		}

		executionServer = serverConfig != null ? serverConfig.get("environment") : null;
		isIdam = Boolean.parseBoolean(serverConfig != null ? serverConfig.get("isIDAM") : null);
		isBoard = Boolean.parseBoolean(serverConfig != null ? serverConfig.get("isBoard") : null);
		apiUrls = Utils.getPropertyMAP(executionServer);

		// initializeLogger();
		loginConstants = new LoginConstants();
	}

	/**
	 * Method to initialize Restassured logger
	 */
	public void initializeLogger() {
		try {
			FrameworkLogger.config(getClass());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void initializeLogger(String strLogFileName) {
		try {
			FrameworkLogger.config(strLogFileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to default logout.
	 * 
	 * @throws org.json.simple.parser.ParseException
	 */
	public void defaultLogout() throws IOException, org.json.simple.parser.ParseException {
		FrameworkLogger.logStep("BaseClass-defaultLogout -> Start");

		Set<String> allDeviceIds = multiUserRepositoryMap.keySet();
		FrameworkLogger.logStep("*****" + multiUserRepositoryMap.toString());
		FrameworkLogger.logStep("DeviceIDs:-" + allDeviceIds.toString());
		for (String deviceId : allDeviceIds) {
			FrameworkLogger.logStep("------------BaseClass-defaultLogout -> " + deviceId);
			LogoutBaseScript.logoutUserMultidevice(deviceId);
		}
		userIsLoggedIn = false;

		FrameworkLogger.logStep("BaseClass-defaultLogout -> End");
	}

	@BeforeMethod(alwaysRun = true)
	public void logReset() {
		File logFile = new File("./tempLog.txt");
		if (logFile.exists()) {
			logFile.delete();
		}
	}

	/**
	 * Precondition manager for any precondition. this method can be override in
	 * Feature Base Script
	 * 
	 * @throws org.json.simple.parser.ParseException
	 * @throws InterruptedException
	 */

	@BeforeSuite(alwaysRun = true)
	public void preConditionManager() throws IOException, org.json.simple.parser.ParseException, InterruptedException {
		// Below initializer must be first line in this method.

		initializeLogger(strLoggerFileNameForLogin);

		FrameworkLogger.logStep("preConditionManager-Started");

		File loginFail = new File("./tempLoginFailed.txt");
		if(loginFail.exists()){
			loginFail.delete();
		}
		
		repositoryMap = new HashMap<String, String>();
		multiUserRepositoryMap = new HashMap<String, Map<String, String>>();
		if (serverConfig.get("isBoard").equalsIgnoreCase("true"))
		{
		if (!(this instanceof LoginBaseScript)) {
			defaultLogin(serverConfig.get("deviceKey"));
			setOwnerAndContributorInfo();
			if (getEnvName() == "SIT") {
				deleteBoardData();
			}
		}
		}
		else
		{
			defaultLogin(serverConfig.get("deviceKey"));
		}
		
		if (serverConfig.get("clearUserData").equalsIgnoreCase("Yes")) {
			FrameworkLogger.logStep("Going to clear User's data.");
			String strEnv = serverConfig.get("environment");
			try {
				clearUserData(strEnv, userId);
			} catch (Exception e) {
				FrameworkLogger.logStep("Some issue during clearing data: " + e.toString());
				e.printStackTrace();
			}

		} else {
			FrameworkLogger.logStep("Don't clear User's data.");
		}

		FrameworkLogger.logStep("preConditionManager-Completed");
	}

	@AfterSuite(alwaysRun = true)
	/**
	 * Postcondition manager for any precondition. this method can be override
	 * in Feature Base Script
	 * 
	 * @throws IOException
	 * @throws org.json.simple.parser.ParseException
	 */
	public void postConditionManager() throws IOException, org.json.simple.parser.ParseException {

		// Below initializer must be first line in this method.
		initializeLogger(strLoggerFileNameForLogout);

		FrameworkLogger.logStep("postConditionManager -> Start");

		if (userIsLoggedIn == true) {
			FrameworkLogger.logStep("executing defaultLogout.");
			defaultLogout();
		}

		FrameworkLogger.logStep("postConditionManager -> End");

	}

	@BeforeClass(alwaysRun = true)
	public void beforeClassMethod() {
		FrameworkLogger.closeLogFile();
		initializeLogger();
		FrameworkLogger.logStep("+++++++++++++++++++++++++++" + this.getClass().getSimpleName()
				+ ":-> Start +++++++++++++++++++++++++++");

	}

	@AfterClass(alwaysRun = true)
	public void afterClassMethod() {
		FrameworkLogger.logStep("+++++++++++++++++++++++++++" + this.getClass().getSimpleName()
				+ ":-> End +++++++++++++++++++++++++++");

	}

	/**
	 * Method to default login
	 */
	public void defaultLogin(String strDeviceId) throws IOException {
		FrameworkLogger.logStep("defaultLogin-Started");
		userIsLoggedIn = false;

		headerMap = initializeHeader();

		// Remove from header for this API.
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());

		setIdamJsonBody(strDeviceId);
		ValidatableResponse response = triggerPostApi(loginURL, headerMap, loginJSONBody);

		// Verify the status code.
		int status = response.extract().statusCode();
		int intExpectedHttpCode = ApiResponseCodes.RESPONSECODE200.getValue();
		if (status != 200) {
			writeLoginLoginIfFailed(loginURL, status, response);
		}
		// set flag.
		if (status == intExpectedHttpCode) {
			userIsLoggedIn = true;
			loggedInSuccessful = true;
			FrameworkLogger.logStep("User logged in successfully.");
		}

		accessToken = getAccessToken(response);
		userId = getUserId(response);
		rootFolderKey = getRootFolderKey(response);
		shardKey = getShardKey(response);
		refreshToken = getRefreshToken(response);
		authProviderToken = getAuthProviderToken(response);
		deviceKeyForWeb = getDeviceKeyForWeb(response);
		firstName = getFirstName(response);
		lastName = getLastName(response);
		mobileNumber = getMobileNumber(response);

		Map<String, String> deviceHeaderMap = null;
		deviceHeaderMap = new HashMap<String, String>();
		String firstNameOfContributor = response.extract().path("firstName");
		deviceHeaderMap.put(MultiDeviceRepositoryParameters.FIRSTNAME.getValue(), firstNameOfContributor);
		String lastNameOfContributor = response.extract().path("lastName");
		deviceHeaderMap.put(MultiDeviceRepositoryParameters.LASTNAME.getValue(), lastNameOfContributor);
		String contactInfoOfContributor = response.extract().path("emailId");
		deviceHeaderMap.put(MultiDeviceRepositoryParameters.EMAILID.getValue(), contactInfoOfContributor);

		deviceHeaderMap.put(MultiDeviceRepositoryParameters.USERID.getValue(), userId);
		deviceHeaderMap.put(MultiDeviceRepositoryParameters.DEVICEKEY.getValue(), strDeviceId);
		deviceHeaderMap.put(MultiDeviceRepositoryParameters.AUTHTOKEN.getValue(), accessToken);
		deviceHeaderMap.put(MultiDeviceRepositoryParameters.REFRESHTOKEN.getValue(), refreshToken);

		deviceOwnerInfo = deviceHeaderMap;

		firstNameOfOwner = deviceOwnerInfo.get("firstName");
		lastNameOfOwner = deviceOwnerInfo.get("lastName");
		contactInfoOfOwner = deviceOwnerInfo.get("emailId");
		userIdOfOwner = deviceOwnerInfo.get("userId");

		multiUserRepositoryMap.put(strDeviceId, deviceHeaderMap);

		FrameworkLogger.logStep("defaultLogin-Completed");
	}

	/**
	 * Method multidevice login- It's logged in to multiple device(deviceKey) with same user details
	 * 
	 */
	public Map<String, String> multideviceLogin(String strDeviceId) throws IOException {
		FrameworkLogger.logStep("multideviceLogin-Started");
		// userIsLoggedIn = false;

		Map<String, String> oneDeviceMap = null;
		// using strDeviceId
		oneDeviceMap = multiUserRepositoryMap.get(strDeviceId);
		if (oneDeviceMap != null) {
			FrameworkLogger.logStep("Multidevice - User is already logged in deviceId : " + strDeviceId);
			return oneDeviceMap;
		} else {
			FrameworkLogger.logStep("Multidevice - User is NOT logged in into deviceId : " + strDeviceId);
			oneDeviceMap = new HashMap<String, String>();
		}
		// Check if already logged in then return the existing information.

		FrameworkLogger.logStep("Going to login with device: " + strDeviceId);
		headerMap = initializeHeader();

		// Remove from header for this API.
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());

		setIdamJsonBody(strDeviceId);

		ValidatableResponse response = triggerPostApi(loginURL, headerMap, loginJSONBody);

		// Verify the status code.
		int status = response.extract().statusCode();
		int intExpectedHttpCode = ApiResponseCodes.RESPONSECODE200.getValue();

		// set flag.
		if (status == intExpectedHttpCode) {
			FrameworkLogger.logStep("Multidevice - User is logged in successfully in deviceId : " + strDeviceId);

		}

		oneDeviceMap = new HashMap<String, String>();
		oneDeviceMap.put(MultiDeviceRepositoryParameters.USERID.getValue(), getUserId(response));
		oneDeviceMap.put(MultiDeviceRepositoryParameters.DEVICEKEY.getValue(), strDeviceId);
		oneDeviceMap.put(MultiDeviceRepositoryParameters.AUTHTOKEN.getValue(), getAccessToken(response));
		oneDeviceMap.put(MultiDeviceRepositoryParameters.REFRESHTOKEN.getValue(), getRefreshToken(response));

		multiUserRepositoryMap.put(strDeviceId, oneDeviceMap);

		FrameworkLogger.logStep("multideviceLogin-Completed");
		return oneDeviceMap;
	}

	/**
	 * Method to select dataType
	 *
	 * @param dataType
	 *            : Type of data (Excel, Json, XML, CSV)
	 * @return : Test Data
	 */
	private TestDataReader getTestDataReaderByDataType(DataType dataType) {

		FrameworkLogger.logStep("******Start**********getTestDataReaderByDataType***********");
		switch (dataType) {
		case JSON:
			return new JSONDataReader();
		case XML:
			return new XMLDataReader();
		case EXCEL:
			return new ExcelDataReader();
		case CSV:
			return new CSVDataReader();
		}
		return null;
	}

	/**
	 * Method to get test data for data driven test
	 *
	 * @param path:
	 *            Test data ile path
	 * @param dataType:
	 *            data type
	 * @return Test data record list in Array
	 * @throws ParseException
	 */
	public Object[][] getTesData(String path, DataType dataType) throws ParseException {
		String userDir = System.getProperty("user.dir");
		path = userDir + "/resources/" + path;

		FrameworkLogger.logStep("path:-> " + path);

		TestDataReader dataReader = getTestDataReaderByDataType(dataType);
		dataContainer = dataReader != null ? dataReader.readTestData(path) : null;
		List<TestDataRecord> testDataList = dataContainer != null ? dataContainer.getTestDataList() : null;
		Object[][] data = new Object[0][];
		if (testDataList != null) {
			data = new Object[testDataList.size()][1];
			for (int i = 0; i < testDataList.size(); i++) {
				TestDataRecord testDataRecord = testDataList.get(i);
				data[i] = new Object[1];
				data[i][0] = testDataRecord.getValueByIndex(0).getValue();
			}
		}

		FrameworkLogger.logStep("data:-> " + data);

		return data;
	}

	/**
	 * update Json for username, password and device key. also update json for
	 * IDAM and non IDAM accounts.
	 */
	public static void setIdamJsonBody(String strDeviceId) throws IOException {
		FrameworkLogger.logStep("setIdamJsonBody-Started");
		setUserData(strDeviceId);
		updateJsonIDAM();
		getLoginUrl();
		FrameworkLogger.logStep("setIdamJsonBody-Completed");
	}

	public static void setIdamJsonBodyForWeb(String strDeviceId) throws IOException {
		FrameworkLogger.logStep("setIdamJsonBody-Started");
		setUserData(strDeviceId);
		updateJsonIDAMForWeb();
		getLoginUrl();
		FrameworkLogger.logStep("setIdamJsonBody-Completed");
	}

	/**
	 * Method to get login URL IDAM/NON IDAM
	 */
	public static void getLoginUrl() {
		FrameworkLogger.logStep("getLoginUrl:-> Start");

		// set idam url
		if (!isIdam) {
			loginURL = apiUrls.get("publicBaseURL") + "/account/login";
		} else {
			loginURL = apiUrls.get("publicBaseURL") + "/account/idam/login";
		}

		FrameworkLogger.logStep("loginURL:-> " + loginURL);
		FrameworkLogger.logStep("getLoginUrl:-> End");
	}

	/**
	 * Update login json body for IDAM login
	 */
	public static void updateJsonIDAM() {
		// change Email Id field to Login ID and remove Auto provider ID for
		// Idam account
		if (isIdam) {
			loginJSONBody = JsonPath.parse(loginJSONBody).renameKey("@", "emailId", "loginId").jsonString();

			String strUniqueValue = Utils.getUniqueValue();
			loginJSONBody = JsonPath.parse(loginJSONBody).put("$.deviceInfo", "imsi", "111" + strUniqueValue)
					.jsonString();

			loginJSONBody = JsonPath.parse(loginJSONBody).delete(LoginConstants.getAuthProviderId()).jsonString();
			loginJSONBody = JsonPath.parse(loginJSONBody).delete(loginConstants.getImei()).jsonString();
		}
	}

	/**
	 * Set user specific data in login json body
	 * 
	 * @throws IOException
	 */
	public static void setUserData(String strDeviceId) throws IOException {
		FrameworkLogger.logStep("setUserData-Started");
		// load json file
		String path = null;
		if (serverConfig.get("deviceType").equalsIgnoreCase("W")) {
			FrameworkLogger.logStep("setUserData:Reading json file for web");
			path = System.getProperty("user.dir") + "/resources/loginTestData/loginBodyForWeb.js";

		} else {
			FrameworkLogger.logStep("setUserData:Reading json file for mobile");
			path = System.getProperty("user.dir") + "/resources/loginTestData/loginBody.js";
		}

		FrameworkLogger.logStep("Path: ");
		FrameworkLogger.logStep(path);
		File file = new File(path);

		loginJSONBody = JsonPath.parse(file).jsonString();

		// check strEmail and strPassword is not null means is from Jenkins job
		// and set values in apiUrls map
		if (strEmail != null) {
			apiUrls.put("Email", strEmail);
		}
		if (strPassword != null) {
			apiUrls.put("Password", strPassword);
		}

		// Set Email Address, Password and Device Key form Property file
		loginJSONBody = setJsonData(LoginConstants.getEmailId(), apiUrls.get("Email"), loginJSONBody);
		// If device type is "W", then send password in encrypted format
		if (serverConfig.get("deviceType").equalsIgnoreCase("W")) {
			String enPassword = Utils.encryptPassword(apiUrls.get("Password"));
			FrameworkLogger.logStep("ENCRYPTEDPASSWORD:" + enPassword);
			loginJSONBody = setJsonData(LoginConstants.getPassword(), enPassword, loginJSONBody);
		} else {
			loginJSONBody = setJsonData(LoginConstants.getPassword(), apiUrls.get("Password"), loginJSONBody);

		}

		loginJSONBody = setJsonData(LoginConstants.getDeviceKey(), strDeviceId, loginJSONBody);

		FrameworkLogger.logStep("setUserData-Completed");
	}

	/**
	 * Method to update Login JSON Body
	 */
	public static String setJsonData(String path, Object value, String jsonString) {
		FrameworkLogger.logStep("setJsonData:-> Start");
		String result = JsonPath.parse(jsonString).set(path, value).jsonString();

		FrameworkLogger.logStep("setJsonData:-> End");

		return result;
	}

	/**
	 * Method to update Login JSON Body
	 */
	public static String addJsonData(String path, Object value, String jsonString) {
		FrameworkLogger.logStep("setJsonData:-> Start");

		String result = JsonPath.parse(jsonString).add(path, value).jsonString();

		FrameworkLogger.logStep("setJsonData:-> End");

		return result;
	}

	/**
	 * Method to get Access Token
	 *
	 * @return Access Token
	 */
	public static String getAccessToken(ValidatableResponse response) {
		String accessToken = response.extract().path("authToken.accessToken");
		String token = Base64.b64encode(accessToken);
		accessToken = authorizationType.concat(token);
		FrameworkLogger.logStep("accessToken:-> " + accessToken);

		return accessToken;
	}

	/**
	 * Method to get User Id
	 *
	 * @return UserId
	 */
	public static String getUserId(ValidatableResponse response) {
		return response.extract().path("userId");
	}

	/**
	 * Method to get Root Folder Key
	 *
	 * @return rootFolderKey
	 */
	public static String getRootFolderKey(ValidatableResponse response) {
		return response.extract().path("rootFolderKey");
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to get shard Key
	 */

	public static String getShardKey(ValidatableResponse response) {
		return response.extract().path("shardKey");
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to get auth provider token
	 */

	public static String getAppSecretValue() {
		String appSecretKey = serverConfig.get("appSecretKey");
		String appSecretEncodedValue = Base64.b64encode(appSecretKey);
		return appSecretEncodedValue;
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to get auth provider token
	 */

	public static String getAppSecretValue(String appSecretKey) {
		String appSecretEncodedValue = Base64.b64encode(appSecretKey);
		return appSecretEncodedValue;
	}

	public static String getAuthProviderToken(ValidatableResponse response) {
		return response.extract().path("authProviderToken");
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to get refresh token
	 */

	public static String getRefreshToken(ValidatableResponse response) {
		return response.extract().path("authToken.refreshToken");
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to get device key for web
	 * 
	 */
	public static String getDeviceKeyForWeb(ValidatableResponse response) {
		return response.extract().path("deviceKey");
	}

	/**
	 * @author c.singh1
	 * 
	 *         Method to add XAPIKey in header.
	 */
	public static void addXapiHeaderKey(Map<String, String> headerMap) {
		String withXapiKey = apiUrls.get("withXapiKey");
		FrameworkLogger.logStep("withXapiKey:-> " + withXapiKey);

		if (withXapiKey.equalsIgnoreCase("yes")) {
			String xApiKeyValue = apiUrls.get("xApiKeyValue");
			headerMap.put(HeaderParameters.XAPIKEY.getValue(), xApiKeyValue);
			FrameworkLogger.logStep("Added header for xApiKeyValue:-> " + xApiKeyValue);
		}

	}

	/**
	 * @author c.singh1
	 * 
	 *         Method To get Invalid Authorization value.
	 */
	public static String getInvalidAccessToken() {
		// To get Invalid Authorization value.
		String invalidAuth = accessToken.substring(0, 6) + "Invalid" + accessToken.substring(13);
		return invalidAuth;
	}

	/**
	 * @author c.singh1
	 * 
	 *         Method to Provide Invalid user ID .
	 */
	public static String getInvalidUserid() {
		// Provide Invalid user ID .
		String invalidUserid = "Invalid" + userId.substring(7);
		return invalidUserid;
	}

	/**
	 * @author c.singh1
	 * 
	 *         Method to Provide Invalid Device ID .
	 */
	public static String getInvalidDeviceId(String strDeviceId) {
		// Provide Invalid Device ID .
		FrameworkLogger.logStep("getInvalidDeviceId:-> Start");
		String invalidDeviceId = "Invalid" + strDeviceId.substring(7);
		FrameworkLogger.logStep("getInvalidDeviceId:-> End");
		return invalidDeviceId;
	}

	/**
	 * @author c.singh1
	 * 
	 *         This is to validate the error scenario n error message.
	 */

	public static void validateErrorsInApiResponse(ValidatableResponse response, int intExpectedHttpErrorCode,
			String strExpectedResponseErrorCode, String strExpectedError) throws VerificationFailException {
		FrameworkLogger.logStep("validateErrorsInApiResponse:-> Start");

		// Read the actual error information from Response
		int status = response.extract().statusCode();
		String strActualError = response.extract().path("error").toString();
		String strActualErrors = response.extract().path("errors[0]");
		String strActualErrorCode = response.extract().path("code");

		// Validating the Actual and Expected error information
		Verify.verifyEquals(strActualError, strExpectedError, "Verifying the error message.");
		Verify.verifyEquals(strActualErrors, strExpectedError, "Verifying the errors message.");
		Verify.verifyEquals(strActualErrorCode, strExpectedResponseErrorCode,
				"Validating the Expected and Actual error codes.");
		Verify.verifyEquals(status, intExpectedHttpErrorCode,
				"Validating the Expected and Actual 'HTTP Codes for Error'.");

		FrameworkLogger.logStep("validateErrorsInApiResponse:-> End");
	}

	/**
	 * @author c.singh1
	 * 
	 *         This is to validate the error scenario for StatusCode, ErrorCode
	 *         and error message.
	 */

	public static void validateErrorsInApiResponseStatusCodeErroCodeNerror(ValidatableResponse response,
			int intExpectedHttpErrorCode, String strExpectedResponseErrorCode, String strExpectedError)
			throws VerificationFailException {
		FrameworkLogger.logStep("validateErrorsInApiResponseStatusCodeErroCodeNerror:-> Start");

		// Read the actual error information from Response
		int status = response.extract().statusCode();
		String strActualError = response.extract().path("error");
		String strActualErrorCode = response.extract().path("code");

		// Validating the Actual and Expected error information
		Verify.verifyEquals(status, intExpectedHttpErrorCode,
				"Validating the Expected and Actual 'HTTP Codes for Error'.");
		Verify.verifyEquals(strActualError, strExpectedError, "Verifying the error message.");
		Verify.verifyEquals(strActualErrorCode, strExpectedResponseErrorCode,
				"Validating the Expected and Actual error codes.");

		FrameworkLogger.logStep("validateErrorsInApiResponseStatusCodeErroCodeNerror:-> End");
	}

	/**
	 * @author c.singh1
	 *         <p>
	 *         It loads the mentioned JSON file and returns the content.
	 */
	protected String loadJsonFile(String filePath) {
		FrameworkLogger.logStep("BaseTestScript.loadJsonFile:-> Start");
		// load json file
		String path = System.getProperty("user.dir") + filePath;
		File file = new File(path);
		String contactBackupJSONBody = null;
		try {
			contactBackupJSONBody = JsonPath.parse(file).jsonString();
		} catch (IOException e) {
			FrameworkLogger.logStep("BaseTestScript.loadJsonFile:-> Something wrong during loading file...");
			FrameworkLogger.logStep("Exception:-> " + e.toString());
			e.printStackTrace();
		}
		return contactBackupJSONBody;
	}

	/**
	 * @return Validatable response for Get API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the Get API and return the Response
	 * @throws VerificationFailException
	 */
	protected static ValidatableResponse triggerGetApi(String strApiUrl, Map<String, String> headerMap) {
		FrameworkLogger.logStep("triggerGetApi:-> Start with URL:-> " + strApiUrl);
		ValidatableResponse response = given().urlEncodingEnabled(false).headers(headerMap).log().all().when()
				.get(strApiUrl).then();
		response.log().all();
		String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
		writeRequestResponseInTempLog(strApiUrl, headerMap, response, null, methodName);
		Utils.addRequestResponseToLogger();
		// This variable is used in AfterMethod for Re-Login
		currentRunningApiResponse = response;
		FrameworkLogger.logStep("triggerGetApi:-> End");
		return response;
	}

	/**
	 * @return Validatable response for Get API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the Get API and return the Response
	 * @throws VerificationFailException
	 */
	protected ValidatableResponse triggerGetApi(String strApiUrl, Map<String, String> headerMap,
			boolean urlEncodingFlag) {
		FrameworkLogger.logStep("triggerGetApi:-> Start with URL:-> " + strApiUrl);
		ValidatableResponse response = given().urlEncodingEnabled(urlEncodingFlag).headers(headerMap).log().all().when()
				.get(strApiUrl.toString()).then();
		response.log().all();
		String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
		writeRequestResponseInTempLog(strApiUrl, headerMap, response, null, methodName);
		// This variable is used in AfterMethod for Re-Login
		currentRunningApiResponse = response;
		FrameworkLogger.logStep("triggerGetApi:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetApi(String strApiUrl) {
		FrameworkLogger.logStep("triggerGetApi:-> Start with URL:-> " + strApiUrl);
		ValidatableResponse response = given()
				.headers(headerMap).log().all()
				.when().get(strApiUrl).then();
		response.log().all();
		String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
		writeRequestResponseInTempLog(strApiUrl, null, response, null, methodName);
		// This variable is used in AfterMethod for Re-Login
		currentRunningApiResponse = response;
		FrameworkLogger.logStep("triggerGetApi:-> End");
		return response;
	}

	/**
	 * @return Validatable response for Post API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the Get API and return the Response
	 * @throws VerificationFailException
	 */
	protected ValidatableResponse triggerPostApi(String strApiUrl, Map<String, String> headerMap, String strBody) {
		FrameworkLogger.logStep("triggerPostApi:-> Start with URL:-> " + strApiUrl);

		FrameworkLogger.logStep("triggerPostApi:-> End");

		ValidatableResponse response = given()
				.config(RestAssuredConfig.config()
						.encoderConfig(EncoderConfig.encoderConfig()
								.appendDefaultContentCharsetToContentTypeIfUndefined(false)))
				.body(strBody).headers(headerMap).log().all().when().post(strApiUrl).then();
		response.log().all();
		if (!strApiUrl.contains("login")) {
			String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
			writeRequestResponseInTempLog(strApiUrl, headerMap, response, strBody, methodName);
		}
		Utils.addRequestResponseToLogger();
		return response;
	}

	/**
	 * @return Validatable response for the API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the Delete API and return the Response
	 * @throws VerificationFailException
	 */
	protected ValidatableResponse triggerDeleteApi(String strApiUrl, Map<String, String> headerMap,
			boolean urlEncodingFlag) {
		FrameworkLogger.logStep("triggerDeleteApi:-> Start with URL:-> " + strApiUrl);

		ValidatableResponse response = given().urlEncodingEnabled(urlEncodingFlag).headers(headerMap).log().all().when()
				.delete(strApiUrl).then();
		response.log().all();
		String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
		writeRequestResponseInTempLog(strApiUrl, headerMap, response, null, methodName);
		// This variable is used in AfterMethod for Re-Login
		currentRunningApiResponse = response;
		FrameworkLogger.logStep("triggerDeleteApi:-> End");
		return response;
	}

	/**
	 * @return Validatable response for the API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the Delete API and return the Response
	 * @throws VerificationFailException
	 */
	protected ValidatableResponse triggerDeleteApi(String strApiUrl, Map<String, String> headerMap) {
		FrameworkLogger.logStep("triggerDeleteApi:-> Start with URL:-> " + strApiUrl);

		ValidatableResponse response = given().headers(headerMap).log().all().when().delete(strApiUrl).then();
		response.log().all();
		String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
		writeRequestResponseInTempLog(strApiUrl, headerMap, response, null, methodName);
		// This variable is used in AfterMethod for Re-Login
		currentRunningApiResponse = response;
		FrameworkLogger.logStep("triggerDeleteApi:-> End");
		return response;
	}

	/**
	 * @return Validatable response for the API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the PUT API and return the Response
	 * @throws VerificationFailException
	 */
	protected ValidatableResponse triggerPutApi(String strApiUrl, Map<String, String> headerMap) {
		FrameworkLogger.logStep("triggerPutApi:-> Start with URL:-> " + strApiUrl);
		ValidatableResponse response = given().headers(headerMap).log().all().when().put(strApiUrl).then();
		response.log().all();
		if (!strApiUrl.contains("logout")) {
			String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
			writeRequestResponseInTempLog(strApiUrl, headerMap, response, null, methodName);
		}
		Utils.addRequestResponseToLogger();

		// This variable is used in AfterMethod for Re-Login
		currentRunningApiResponse = response;
		FrameworkLogger.logStep("triggerPutApi:-> End");
		return response;
	}

	/**
	 * @return Validatable response for the API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the PUT API with BODY and return the Response
	 * @throws VerificationFailException
	 */
	protected ValidatableResponse triggerPutApi(String strApiUrl, Map<String, String> headerMap, String strBody) {
		FrameworkLogger.logStep("triggerPutApi:-> Start with URL:-> " + strApiUrl);

		ValidatableResponse response = given().body(strBody).headers(headerMap).log().all().when().put(strApiUrl)
				.then();
		response.log().all();
		if (!strApiUrl.contains("logout")) {
			String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
			writeRequestResponseInTempLog(strApiUrl, headerMap, response, strBody, methodName);
		}
		Utils.addRequestResponseToLogger();

		// This variable is used in AfterMethod for Re-Login
		currentRunningApiResponse = response;

		// This variable is used in AfterMethod for Re-Login
		currentRunningApiResponse = response;

		FrameworkLogger.logStep("triggerPutApi:-> End");
		return response;
	}

	/**
	 * @return header map
	 * @author Chandrashekhar Singh
	 */
	protected Map<String, String> createHeader() {
		headerMap = initializeHeader();
		return headerMap;
	}

	/**
	 * @return header map
	 * @author Chandrashekhar Singh
	 * 
	 *         Overloading createHeader to use in Multidevice
	 * @throws IOException
	 */
	protected Map<String, String> createHeader(Map<String, String> deviceInfoMap) throws IOException {
		headerMap = initializeHeader(deviceInfoMap);
		return headerMap;
	}

	// Default initializeHeader
	protected Map<String, String> initializeHeader() {
		Map<String, String> headerMapLocal = null;
		try {
			FrameworkLogger.logStep("-----------------DeviceKey:" + serverConfig.get("deviceKey"));
			headerMapLocal = multiUserRepositoryMap.get(serverConfig.get("deviceKey"));
		} catch (Exception e) {
			FrameworkLogger.logStep("-----------------initializeHeader(): Catch");
			headerMapLocal = null;
		}
		initializeHeader(headerMapLocal);
		return headerMap;
	}

	protected Map<String, String> initializeHeader(String emailId, String deviceKey) {

		headerMap = new HashMap<>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");
		headerMap.put(HeaderParameters.XAPPSECRET.getValue(), getAppSecretValue());

		// If device type is "W", then add User agent
		if (serverConfig.get("deviceType").equalsIgnoreCase("W")) {
			headerMap.put("User-Agent",
					"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
		}
		// Add 'X-Api-Key' in header for the API.
		addXapiHeaderKey(headerMap);

		return headerMap;
	}

	// Overloading with DeviceKey and Authtoken.
	protected Map<String, String> initializeHeader(Map<String, String> deviceInfoMap) {
		FrameworkLogger.logStep("initializeHeader: Start");
		headerMap = new HashMap<>();
		if (deviceInfoMap != null) {
			headerMap.put(HeaderParameters.XUSERID.getValue(),
					deviceInfoMap.get(MultiDeviceRepositoryParameters.USERID.getValue()));
			headerMap.put(HeaderParameters.XDEVICEKEY.getValue(),
					deviceInfoMap.get(MultiDeviceRepositoryParameters.DEVICEKEY.getValue()));
			headerMap.put(HeaderParameters.AUTHORIZATION.getValue(),
					deviceInfoMap.get(MultiDeviceRepositoryParameters.AUTHTOKEN.getValue()));
		}
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");
		headerMap.put(HeaderParameters.XAPPSECRET.getValue(), getAppSecretValue());

		// If device type is "W", then add User agent
		if (serverConfig.get("deviceType").equalsIgnoreCase("W")) {
			headerMap.put("User-Agent",
					"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
		}
		// Add 'X-Api-Key' in header for the API.
		addXapiHeaderKey(headerMap);
		FrameworkLogger.logStep("initializedHeader: " + headerMap.toString());

		FrameworkLogger.logStep("initializeHeader: End");
		return headerMap;
	}

	public static String getEnvName() {
		String result = null;
		String envValue = serverConfig.get("environment");

		// if(envValue.equalsIgnoreCase(arg0))
		switch (envValue.trim().toUpperCase()) {
		case "DEV":
			result = "DEV";
			break;
		case "SIT":
			result = "SIT";
			break;
		case "LT":
			result = "LT";
			break;
		case "PP":
			result = "PP";
			break;
		case "PROD":
			result = "PROD";

		}

		return result;
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to get build number
	 * @return
	 */
	public static String getBuildNumber() {
		String buildNumber = null;
		buildNumber = serverConfig.get("BUILD_NUMBER");

		return buildNumber;
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to get release version
	 * @return
	 */
	public static String getReleaseVersion() {
		String releaseVersion = null;
		releaseVersion = serverConfig.get("RELEASE_VERSION");

		return releaseVersion;
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to Delete JSON Body
	 */
	public static String deleteJsonData(String jsonString, String path) {
		FrameworkLogger.logStep("deleteJsonData:-> Start");

		String result = JsonPath.parse(jsonString).delete(path).jsonString();

		FrameworkLogger.logStep("deleteJsonData:-> End");

		return result;
	}

	public void clearUserData(String env, String strUserUniqueId) throws SQLException, ClassNotFoundException {
		FrameworkLogger.logStep("clearUserData -> Start");

		Connection connection = null;
		CallableStatement callableStatement = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			if (env.equalsIgnoreCase("sit")) {
				connection = DriverManager.getConnection(
						"jdbc:oracle:thin:@usm-dbserver-shard.sit-jiodrive.com:1521:tejsecdbsit", "tejrousr",
						"tejrousr");
				FrameworkLogger.logStep("Connection made to " + connection);
			} else {
				connection = DriverManager.getConnection(
						"jdbc:oracle:thin:@pp-usm-dbserver-shard-00.preprod-jiodrive.com:2512:tjscpp00", "tejrousr",
						"tejrousr");
			}
			String plsql = "{CALL tejaqusr.sp_trash_user( ? ) }";
			FrameworkLogger.logStep("Called Procedure " + plsql);
			callableStatement = connection.prepareCall(plsql);
			callableStatement.setString(1, strUserUniqueId);
			callableStatement.execute();
			FrameworkLogger.logStep("CS is " + callableStatement);
			FrameworkLogger.logStep("Result is " + callableStatement.execute());
			callableStatement.close();
			connection.close();
		} catch (Exception e) {
			FrameworkLogger.logStep(e.toString());
		}
		FrameworkLogger.logStep("clearUserData -> End");
	}

	public static void waitForTime(int waitTimeInSecond) {
		FrameworkLogger.logStep("waitForTime -> Start for " + waitTimeInSecond + " Seconds.");

		try {

			Thread.sleep(1000 * waitTimeInSecond);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		FrameworkLogger.logStep("waitForTime -> End");
	}

	/**
	 * Postcondition manager for each TestMethod. this method can be override in
	 * any child class.
	 */
	@AfterMethod(alwaysRun = true)
	public void postConditionManagerAfterMethod(ITestResult result) throws IOException {
		int apiStatus = 0;
		FrameworkLogger.logStep("postConditionManagerAfterMethod-Started");
		getMethodName = result.getMethod().getMethodName();
		if (result.getStatus() == ITestResult.FAILURE) {
			apiStatus = 0;
			String errorMessageForTokenExpired = "Authorization Token Expired or wrong";
			String strActualError = null;
			try {
				FrameworkLogger.logStep("AfterMethod-Reading error message from response.");
				strActualError = currentRunningApiResponse.extract().path("error");
			} catch (Exception e) {
				FrameworkLogger.logStep("AfterMethod-Token Expiry is not reason of failure...");
			}
			if (errorMessageForTokenExpired.equalsIgnoreCase(strActualError)) {
				FrameworkLogger.logStep("AfterMethod-Failed due to Token Expired...Going to Re-Login again...");
				defaultLogin(serverConfig.get("deviceKey"));
				setOwnerAndContributorInfo();

			} else {
				FrameworkLogger.logStep("AfterMethod-Token Expiry is not reason of failure...");
			}

		} else if (result.getStatus() == ITestResult.SKIP) {
			apiStatus = 2;
		} else {
			apiStatus = 1;
		}
		String[] groupArray = result.getMethod().getGroups();
		for (String group : groupArray) {
			//if (group.equalsIgnoreCase("Sanity"))
				if (group.equalsIgnoreCase(TestNgGroups.MONITORING_SANITY)){
				Utils.triggerAwsCloudWatchAgent(globalApiName + "_" + getMethodName, apiStatus);
			}
		}
		FrameworkLogger.logStep("postConditionManagerAfterMethod-Completed");

	}

	public static String removeLastCharacter(String str, char removeChar) {
		if (str != null && str.length() > 0 && str.charAt(str.length() - 1) == removeChar) {
			FrameworkLogger.logStep("Removing last char");
			str = str.substring(0, str.length() - 1);
		}
		return str;
	}

	/**
	 * Update login json body for IDAM login
	 */
	public static void updateJsonIDAMForWeb() {
		// change Email Id field to Login ID and remove Auto provider ID for
		// Idam account
		if (isIdam) {
			loginJSONBody = JsonPath.parse(loginJSONBody).renameKey("@", "emailId", "loginId").jsonString();

			String strUniqueValue = Utils.getUniqueValue();
			loginJSONBody = JsonPath.parse(loginJSONBody).put("$.deviceInfo", "imsi", "111" + strUniqueValue)
					.jsonString();

			loginJSONBody = JsonPath.parse(loginJSONBody).delete(LoginConstants.getAuthProviderId()).jsonString();
			loginJSONBody = JsonPath.parse(loginJSONBody).delete(loginConstants.getImei()).jsonString();
			loginJSONBody = setJsonData(LoginParameters.DEVICETYPE.getValue(), "W", loginJSONBody);
			loginJSONBody = setJsonData(LoginParameters.MODEL.getValue(), "browser", loginJSONBody);
			loginJSONBody = setJsonData(LoginParameters.PLATFORMTYPE.getValue(), "Chrome", loginJSONBody);
			loginJSONBody = setJsonData(LoginParameters.PLATFORMVERSION.getValue(), "5.0", loginJSONBody);
			loginJSONBody = setJsonData(LoginParameters.TYPE.getValue(), "browser", loginJSONBody);
		}

	}

	/**
	 * @author Prateek
	 * 
	 *         Method to add device key in repository map
	 */

	protected void addDeviceIdForWeb() {
		FrameworkLogger.logStep("addDeviceIdForWeb:Started");

		Map<String, String> oneDeviceMap = null;
		oneDeviceMap = multiUserRepositoryMap.get(serverConfig.get("deviceKey"));

		multiUserRepositoryMap.put(deviceKeyForWeb, oneDeviceMap);
		FrameworkLogger.logStep("addDeviceIdForWeb:End");

	}

	protected Map<String, String> createHeaderForXDeviceName(Map<String, String> deviceInfoMap, String deviceName)
			throws IOException {

		headerMap = initializeHeader(deviceInfoMap);
		headerMap.put(HeaderParameters.XDEVICENAME.getValue(), deviceName);
		return headerMap;
	}

	public void loginWithAnyEmailId(String Email, String Password, String strDeviceId) throws IOException {
		FrameworkLogger.logStep("defaultLogin-Started");
		userIsLoggedIn = false;

		headerMap = initializeHeader();

		// Remove from header for this API.
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());

		setIdamJsonBodyForAnyEmailId(Email, Password, strDeviceId);

		ValidatableResponse response = triggerPostApi(loginURL, headerMap, loginJSONBody);

		// Verify the status code.
		int status = response.extract().statusCode();
		int intExpectedHttpCode = ApiResponseCodes.RESPONSECODE200.getValue();

		// set flag.
		if (status == intExpectedHttpCode) {
			userIsLoggedIn = true;
			loggedInSuccessful = true;
			FrameworkLogger.logStep("User logged in successfully.");

		}

		accessToken = getAccessToken(response);
		userId = getUserId(response);
		rootFolderKey = getRootFolderKey(response);
		shardKey = getShardKey(response);
		refreshToken = getRefreshToken(response);
		authProviderToken = getAuthProviderToken(response);
		deviceKeyForWeb = getDeviceKeyForWeb(response);

		Map<String, String> oneDeviceMap = new HashMap<String, String>();
		oneDeviceMap.put(MultiDeviceRepositoryParameters.DEVICEKEY.getValue(), strDeviceId);
		oneDeviceMap.put(MultiDeviceRepositoryParameters.AUTHTOKEN.getValue(), accessToken);
		oneDeviceMap.put(MultiDeviceRepositoryParameters.REFRESHTOKEN.getValue(), refreshToken);

		multiDeviceRepositoryMap.put(strDeviceId, oneDeviceMap);

		FrameworkLogger.logStep("defaultLogin-Completed");
	}

	public static void setIdamJsonBodyForAnyEmailId(String Email, String Password, String strDeviceId)
			throws IOException {
		FrameworkLogger.logStep("setIdamJsonBody-Started");
		// setUserData();
		setUserDataForLoginIntoAnyEmailId(Email, Password, strDeviceId);
		updateJsonIDAM();
		getLoginUrl();

		FrameworkLogger.logStep("setIdamJsonBody-Completed");
	}

	public static void setUserDataForLoginIntoAnyEmailId(String Email, String Password, String strDeviceId)
			throws IOException {
		FrameworkLogger.logStep("setUserData-Started");
		// load json file
		String path = null;
		if (serverConfig.get("deviceType").equalsIgnoreCase("W")) {
			FrameworkLogger.logStep("setUserData:Reading json file for web");
			path = System.getProperty("user.dir") + "/resources/loginTestData/loginBodyForWeb.js";

		} else {
			FrameworkLogger.logStep("setUserData:Reading json file for mobile");
			path = System.getProperty("user.dir") + "/resources/loginTestData/loginBody.js";
		}

		FrameworkLogger.logStep("Path: ");
		FrameworkLogger.logStep(path);
		File file = new File(path);

		loginJSONBody = JsonPath.parse(file).jsonString();

		// Set Email Address, Password and Device Key form Property file
		loginJSONBody = setJsonData(LoginConstants.getEmailId(), Email, loginJSONBody);
		// If device type is "W", then send password in encrypted format
		if (serverConfig.get("deviceType").equalsIgnoreCase("W")) {
			String enPassword = Utils.encryptPassword(apiUrls.get("Password"));
			FrameworkLogger.logStep("ENCRYPTEDPASSWORD:" + enPassword);
			loginJSONBody = setJsonData(LoginConstants.getPassword(), enPassword, loginJSONBody);
		} else {
			loginJSONBody = setJsonData(LoginConstants.getPassword(), Password, loginJSONBody);

		}

		loginJSONBody = setJsonData(LoginConstants.getDeviceKey(), strDeviceId, loginJSONBody);
		FrameworkLogger.logStep("setUserData-Completed");
	}

	protected ValidatableResponse triggerPutApi(String strApiUrl) {
		FrameworkLogger.logStep("triggerPutApi:-> Start with URL:-> " + strApiUrl);
		ValidatableResponse response = given().headers(headerMap).log().all().when().put(strApiUrl).then();
		response.log().all();
		if (!strApiUrl.contains("logout")) {
			String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
			writeRequestResponseInTempLog(strApiUrl, headerMap, response, null, methodName);
		}
		Utils.addRequestResponseToLogger();

		// This variable is used in AfterMethod for Re-Login
		currentRunningApiResponse = response;
		FrameworkLogger.logStep("triggerPutApi:-> End");
		return response;
	}

	/**
	 * Method multiuser login
	 */
	public Map<String, String> multiUserLogin(String strDeviceId, String email, String password) throws IOException {
		FrameworkLogger.logStep("multiUserLogin-Started");
		// userIsLoggedIn = false;
		Map<String, String> deviceHeaderMap = null;
		FrameworkLogger.logStep("DeviceKey:" + strDeviceId);
		Map<String, String> oneDeviceMap = null;
		oneDeviceMap = multiUserRepositoryMap.get(strDeviceId);

		// Check if already logged in then return the existing information.

		if (oneDeviceMap != null) {
			FrameworkLogger.logStep("Multidevice - User is already logged in deviceId : " + strDeviceId);
			return oneDeviceMap;
		} else {
			FrameworkLogger.logStep("Going to login with email and device id: " + email + " DeviceKey:" + strDeviceId);
			headerMap = initializeHeader(email, strDeviceId);
			headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
			headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());

			setIdamJsonBody(strDeviceId, email, password);

			ValidatableResponse response = triggerPostApi(loginURL, headerMap, loginJSONBody);

			// Verify the status code.
			int status = response.extract().statusCode();
			int intExpectedHttpCode = ApiResponseCodes.RESPONSECODE200.getValue();

			// set flag.
			if (status == intExpectedHttpCode) {
				FrameworkLogger.logStep("Multidevice - User is logged in successfully in deviceId : " + strDeviceId);
			}

			deviceHeaderMap = new HashMap<String, String>();
			// FrameworkLogger.logStep(getUserId(response));
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.USERID.getValue(), getUserId(response));
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.DEVICEKEY.getValue(), strDeviceId);
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.AUTHTOKEN.getValue(), getAccessToken(response));
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.REFRESHTOKEN.getValue(), getRefreshToken(response));

			String firstNameOfContributor = response.extract().path("firstName");
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.FIRSTNAME.getValue(), firstNameOfContributor);
			String lastNameOfContributor = response.extract().path("lastName");
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.LASTNAME.getValue(), lastNameOfContributor);
			String contactInfoOfContributor = response.extract().path("emailId");
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.EMAILID.getValue(), contactInfoOfContributor);
			multiUserRepositoryMap.put(email, deviceHeaderMap);
			FrameworkLogger.logStep("EmailID Not found in Multiuser is not possible in MULTIDEVICE.");
		}

		// multiDeviceRepositoryMap.put(getUserId(response), deviceHeaderMap);
		FrameworkLogger.logStep("multiUserLogin-Completed");
		return deviceHeaderMap;
	}

	public Map<String, String> getHeaderInfo() throws IOException {

		Map<String, String> deviceHeaderMap = null;
		deviceHeaderMap = multideviceLogin(serverConfig.get("deviceKey"));
		return deviceHeaderMap;
	}

	public Map<String, String> getHeaderInfo(String strDeviceId) throws IOException {

		Map<String, String> deviceHeaderMap = null;
		deviceHeaderMap = multideviceLogin(strDeviceId);
		return deviceHeaderMap;
	}

	public Map<String, String> getHeaderInfo(String strDeviceId, String email, String password) throws IOException {

		Map<String, String> deviceHeaderMap = null;
		deviceHeaderMap = multiUserLogin(strDeviceId, email, password);
		return deviceHeaderMap;
	}

	/**
	 * Set user specific data in login json body
	 * 
	 * @throws IOException
	 */

	public static void setUserData(String strDeviceId, String email, String password) throws IOException {
		FrameworkLogger.logStep("setUserData-Started");
		// load json file
		String path = null;
		if (serverConfig.get("deviceType").equalsIgnoreCase("W")) {
			FrameworkLogger.logStep("setUserData:Reading json file for web");
			path = System.getProperty("user.dir") + "/resources/loginTestData/loginBodyForWeb.js";

		} else {
			FrameworkLogger.logStep("setUserData:Reading json file for mobile");
			path = System.getProperty("user.dir") + "/resources/loginTestData/loginBody.js";
		}

		FrameworkLogger.logStep("Path: ");
		FrameworkLogger.logStep(path);
		File file = new File(path);

		loginJSONBody = JsonPath.parse(file).jsonString();

		// check strEmail and strPassword is not null means is from Jenkins job
		// and set values in apiUrls map
		if (strEmail != null) {
			apiUrls.put("Email", strEmail);
		}
		if (strPassword != null) {
			apiUrls.put("Password", strPassword);
		}

		// Set Email Address, Password and Device Key form Property file
		loginJSONBody = setJsonData(LoginConstants.getEmailId(), email, loginJSONBody);
		// If device type is "W", then send password in encrypted format
		if (serverConfig.get("deviceType").equalsIgnoreCase("W")) {
			String enPassword = Utils.encryptPassword(password);
			FrameworkLogger.logStep("ENCRYPTEDPASSWORD:" + enPassword);
			loginJSONBody = setJsonData(LoginConstants.getPassword(), enPassword, loginJSONBody);
		} else {
			loginJSONBody = setJsonData(LoginConstants.getPassword(), password, loginJSONBody);

		}

		loginJSONBody = setJsonData(LoginConstants.getDeviceKey(), strDeviceId, loginJSONBody);
		FrameworkLogger.logStep("setUserData-Completed");
	}

	/**
	 * update Json for username, password and device key. also update json for
	 * IDAM and non IDAM accounts.
	 */
	public static void setIdamJsonBody(String strDeviceId, String email, String password) throws IOException {
		FrameworkLogger.logStep("setIdamJsonBody-Started");
		// setUserData();
		setUserData(strDeviceId, email, password);
		updateJsonIDAM();
		getLoginUrl();

		FrameworkLogger.logStep("setIdamJsonBody-Completed");
	}

	/**
	 * Method to get First Name
	 *
	 * @return First Name
	 */
	public static String getFirstName(ValidatableResponse response) {
		return response.extract().path("firstName");
	}

	public static String getEmailId(ValidatableResponse response) {
		return response.extract().path("emailId");
	}

	/**
	 * Method to get Last Name
	 *
	 * @return Last Name
	 */
	public static String getLastName(ValidatableResponse response) {
		return response.extract().path("lastName");
	}

	/**
	 * Method to get Mobile Number
	 *
	 * @return Mobile Number
	 */
	public static String getMobileNumber(ValidatableResponse response) {
		return response.extract().path("mobileNumber");
	}

	protected void setOwnerAndContributorInfo() throws IOException {

		// get Contributor details
		String strDeviceId2 = serverConfig.get("deviceKey2");
		String imsi2 = serverConfig.get("imsi2");
		String email1 = apiUrls.get("Email1");
		FrameworkLogger.logStep("EMAIL:" + email1);
		String password1 = apiUrls.get("Password1");
		FrameworkLogger.logStep("PASSWORD:" + password1);
		deviceContributorInfo = getHeaderInfo(strDeviceId2, email1, password1, imsi2);
		firstNameOfContributor = deviceContributorInfo.get("firstName");
		lastNameOfContributor = deviceContributorInfo.get("lastName");
		contactInfoOfContributor = deviceContributorInfo.get("emailId");
		userIdOfContributor = deviceContributorInfo.get("userId");

		// get Contributor details
		String strDeviceId3 = serverConfig.get("deviceKey3");
		String imsi3 = serverConfig.get("imsi3");
		String email2 = apiUrls.get("Email2");
		FrameworkLogger.logStep("EMAIL:" + email2);
		String password2 = apiUrls.get("Password2");
		FrameworkLogger.logStep("PASSWORD:" + password2);
		deviceSecondContributorInfo = getHeaderInfo(strDeviceId3, email2, password2, imsi3);
		firstNameOfSecondContributor = deviceSecondContributorInfo.get("firstName");
		lastNameOfSecondContributor = deviceSecondContributorInfo.get("lastName");
		contactInfoOfSecondContributor = deviceSecondContributorInfo.get("emailId");
		userIdOfSecondContributor = deviceSecondContributorInfo.get("userId");
	}

	/**
	 * Method multiuser login
	 */
	public Map<String, String> multiUserLoginDiffImsi(String strDeviceId, String email, String password, String imsi)
			throws IOException {
		FrameworkLogger.logStep("multiUserLogin-Started");
		// userIsLoggedIn = false;
		Map<String, String> deviceHeaderMap = null;
		FrameworkLogger.logStep("EMAIL:" + email);
		Map<String, String> oneDeviceMap = null;
		oneDeviceMap = multiUserRepositoryMap.get(strDeviceId);
		FrameworkLogger.logStep("multiUserRepositoryMap:- " + multiUserRepositoryMap.toString());
		ValidatableResponse response = null;
		// Check if already logged in then return the existing information.

		FrameworkLogger.logStep("Going to login with email and device id: " + email + " DeviceKey:" + strDeviceId);
		headerMap = initializeHeader(email, strDeviceId);
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());

		setIdamJsonBodyDiffImsi(strDeviceId, email, password, imsi);

		response = triggerPostApi(loginURL, headerMap, loginJSONBody);

		if (response != null) {
			// Verify the status code.
			int status = response.extract().statusCode();
			int intExpectedHttpCode = ApiResponseCodes.RESPONSECODE200.getValue();

			// set flag.
			if (status == intExpectedHttpCode) {
				FrameworkLogger.logStep("Multidevice - User is logged in successfully in deviceId : " + strDeviceId);

			}

			deviceHeaderMap = new HashMap<String, String>();
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.USERID.getValue(), getUserId(response));
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.DEVICEKEY.getValue(), strDeviceId);
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.AUTHTOKEN.getValue(), getAccessToken(response));
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.REFRESHTOKEN.getValue(), getRefreshToken(response));

			String firstNameOfContributor = response.extract().path("firstName");
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.FIRSTNAME.getValue(), firstNameOfContributor);
			String lastNameOfContributor = response.extract().path("lastName");
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.LASTNAME.getValue(), lastNameOfContributor);
			String contactInfoOfContributor = response.extract().path("emailId");
			deviceHeaderMap.put(MultiDeviceRepositoryParameters.EMAILID.getValue(), contactInfoOfContributor);

			multiUserRepositoryMap.put(strDeviceId, deviceHeaderMap);
			FrameworkLogger.logStep("multiUserRepositoryMap:- " + multiUserRepositoryMap.toString());

		}
		// multiDeviceRepositoryMap.put(getUserId(response), deviceHeaderMap);
		FrameworkLogger.logStep("multiUserLogin-Completed");
		return deviceHeaderMap;
	}

	/**
	 * update Json for username, password and device key. also update json for
	 * IDAM and non IDAM accounts.
	 */
	public static void setIdamJsonBodyDiffImsi(String strDeviceId, String email, String password, String imsi)
			throws IOException {
		FrameworkLogger.logStep("setIdamJsonBody-Started");
		// setUserData();
		setUserData(strDeviceId, email, password);
		updateJsonIDAMDiffImsi(imsi);
		getLoginUrl();

		FrameworkLogger.logStep("setIdamJsonBody-Completed");
	}

	/**
	 * Update login json body for IDAM login
	 */
	public static void updateJsonIDAMDiffImsi(String imsi) {
		// change Email Id field to Login ID and remove Auto provider ID for
		// Idam account
		if (isIdam) {
			loginJSONBody = JsonPath.parse(loginJSONBody).renameKey("@", "emailId", "loginId").jsonString();

			String strUniqueValue = Utils.getUniqueValue();
			loginJSONBody = JsonPath.parse(loginJSONBody).put("$.deviceInfo", "imsi", "111" + strUniqueValue)
					.jsonString();

			loginJSONBody = JsonPath.parse(loginJSONBody).delete(LoginConstants.getAuthProviderId()).jsonString();
			loginJSONBody = JsonPath.parse(loginJSONBody).delete(loginConstants.getImei()).jsonString();
		}
	}

	public Map<String, String> getHeaderInfo(String strDeviceId, String email, String password, String imsi)
			throws IOException {

		Map<String, String> deviceHeaderMap = null;
		deviceHeaderMap = multiUserLoginDiffImsi(strDeviceId, email, password, imsi);
		return deviceHeaderMap;
	}

	public static void deleteBoardData() throws IOException, InterruptedException {
		System.out.println("Start");
		for (int i = 0; i < 3; i++) {

			String[] userIds = { userIdOfOwner, userIdOfContributor, userIdOfSecondContributor };

			FrameworkLogger.logStep("USERID:" + userIds[i]);
			Process p = new ProcessBuilder("python", "DeleteScript.py", userIds[i]).start();

			BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line;
			while ((line = in.readLine()) != null) {
				System.out.println(line);
			}
			p.waitFor();
			System.out.println("ok!");

			in.close();
			// System.exit(0);
			System.out.println("End");
		}

	}


	@AfterSuite(alwaysRun = true)
	public void leaveAllBoards() throws IOException, VerificationFailException, InterruptedException 
	{
		/*if (serverConfig.get("clearAllBoards").equalsIgnoreCase("true")){

		try
		{
		FrameworkLogger.logStep("Leave all boards :-> Start");
		FrameworkLogger.logStep("Owner Leave all of his boards :-> Start");
		BoardsFeedBaseScript.getAllBoardKeysAndUnjoinBoard();
		FrameworkLogger.logStep("Owner Leave all of his boards :-> Start");

		FrameworkLogger.logStep("Contributor Leave all of his boards :-> Start");
		BoardsFeedBaseScript.getAllBoardKeysAndUnjoinBoardByContributor(deviceContributorInfo);
		BoardsFeedBaseScript.getAllBoardKeysAndUnjoinBoardByContributor(deviceSecondContributorInfo);
		FrameworkLogger.logStep("Contributor Leave all of his boards :-> Start");
		}
		catch(Exception e)
		{
			System.out.print("NO boards Found");
		}
		FrameworkLogger.logStep("Leave all boards :-> End");
		
		}*/

	}

	public static void writeRequestResponseInTempLog(String strApiUrl, Map<String, String> headerMap,
			ValidatableResponse response, String strBody, String methodName) {
		BufferedWriter bw = null;
		FileWriter fw = null;
		try {
			fw = new FileWriter("./tempLog.txt", true);
			bw = new BufferedWriter(fw);
			bw.write("\n	 	REQUEST:-" + methodName);
			bw.write("\n	 	URL:- " + strApiUrl);
			// bw.write("--Headers--: " + headerMap.toString() + " - ");
			bw.write("\n	 	Body:- " + strBody);
			bw.write("\n	 	RESPONSE:-	");
			bw.write("\n	 	Response Code:- " + response.extract().statusCode());
			if (!strApiUrl.contains("stream") || !strApiUrl.contains("share") || !strApiUrl.contains("-dl.")
					|| !strApiUrl.contains("sync")) {
				bw.write("\n	 	Response Body:- " + response.extract().body().asString());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void writeLoginLoginIfFailed(String loginURL, int status, ValidatableResponse response) {
		File loginFail = new File("./tempLoginFailed.txt");
		if (!loginFail.exists()) {
			BufferedWriter bw = null;
			FileWriter fw = null;
			try {
				fw = new FileWriter("./tempLoginFailed.txt", true);
				bw = new BufferedWriter(fw);
				bw.write("\n	 	LOGIN FAILED");
				bw.write("\n	 	REQUEST:- Login");
				bw.write("\n	 	URL:- " + loginURL);
				bw.write("\n	 	RESPONSE:-	");
				bw.write("\n	 	Response Code:- " + status);
				bw.write("\n	 	Response Body:- " + response.extract().body().asString());
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (bw != null)
						bw.close();
					if (fw != null)
						fw.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}
	}

}
