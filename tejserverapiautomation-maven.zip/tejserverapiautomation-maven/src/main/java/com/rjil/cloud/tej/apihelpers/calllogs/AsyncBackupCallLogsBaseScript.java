package com.rjil.cloud.tej.apihelpers.calllogs;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;

import com.rjil.cloud.tej.apiconstants.CallLogConstants;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.RandomNumberGenerator;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class AsyncBackupCallLogsBaseScript extends BaseTestScript
{
		protected static final String apiName = "AsyncBackupCallLogs";
		protected static String asyncBackupCallLogsJsonBody;
		
		
		protected String getAsyncBackupCallLogsURL()
		{
			FrameworkLogger.logStep("getAsyncBackupCallLogsURL: Start");
			String url = apiUrls.get("callLogsBaseUrl")+ serverConfig.get("getAsyncBackupCallLogsUrl");
			FrameworkLogger.logStep("getAsyncBackupCallLogsURL: End");
			return url;
		}
    
		
		
		
		protected String getAsyncBackupCallLogsURL(String urlValue) {
			FrameworkLogger.logStep("getAsyncBackupCallLogsURL: Start");
			String url = apiUrls.get("baseURL") + urlValue;
			FrameworkLogger.logStep("getAsyncBackupCallLogsURL: End");
			return url;
		}
		

		protected String setAsyncBackupCallLogsJsonBody() throws IOException{
			//String boardName = "Board___"+Utils.getUniqueId();
			// load json file
			String path = System.getProperty("user.dir") + "/resources/callLogsTestData/asyncBackupCallLogsBody.js";
			File file = new File(path);
			asyncBackupCallLogsJsonBody = JsonPath.parse(file).jsonString();
			return asyncBackupCallLogsJsonBody;
		}

		protected String setAsyncBackupCallLogsInvalidJsonBody() throws IOException{
			//String boardName = "Board___"+Utils.getUniqueId();
			// load json file
			String path = System.getProperty("user.dir") + "/resources/callLogsTestData/asyncBackupCallLogsInvalidBody.js";
			File file = new File(path);
			asyncBackupCallLogsJsonBody = JsonPath.parse(file).jsonString();
			return asyncBackupCallLogsJsonBody;
		}
		
		protected String setAsyncBackupCallLogsValidInvalidJsonBody() throws IOException{
			//String boardName = "Board___"+Utils.getUniqueId();
			// load json file
			String path = System.getProperty("user.dir") + "/resources/callLogsTestData/asyncBackupCallLogsBodyForSomeValidAndSomeInvalid.js";
			File file = new File(path);
			asyncBackupCallLogsJsonBody = JsonPath.parse(file).jsonString();
			return asyncBackupCallLogsJsonBody;
		}

		
		
		protected ValidatableResponse triggerPostApiAsyncBackupCallLogs() throws IOException {

			FrameworkLogger.logStep("triggerPostApiAsyncBackupCallLogs: Start");

			// get url for create metadata for folder API
			String strApiUrl=getAsyncBackupCallLogsURL();


			ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, asyncBackupCallLogsJsonBody);
			FrameworkLogger.logStep("triggerPostApiAsyncBackupCallLogs:");

			return response;
		}
		
		protected ValidatableResponse triggerPostApiAsyncBackupCallLogs( Map<String, String> headerMap) throws IOException {

			FrameworkLogger.logStep("triggerPostApiAsyncBackupCallLogs: Start");

			// get url for create metadata for folder API
			String strApiUrl=getAsyncBackupCallLogsURL();

			// get response from create a Folder API
			ValidatableResponse response=triggerPostApi(strApiUrl, createHeader(headerMap), asyncBackupCallLogsJsonBody);

			FrameworkLogger.logStep("triggerPostApiAsyncBackupCallLogs");

			return response;
		}
		

		protected ValidatableResponse triggerPostApiAsyncBackupCallLogs(String urlValue) throws IOException {

			FrameworkLogger.logStep("triggerPostApiAsyncBackupCallLogs: Start");

			String strApiUrl=getAsyncBackupCallLogsURL(urlValue);
			ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, asyncBackupCallLogsJsonBody);

			FrameworkLogger.logStep("triggerPostApiAsyncBackupCallLogs:-> ");

			return response;
		}
		

		public static ValidatableResponse asyncBackupCallLogsServiceMethod(String dvcCallLogId, String date, String callLogType) throws IOException, VerificationFailException, ParseException {
			FrameworkLogger.logStep("asyncBackupCallLogsServiceMethod: Start");
			
			AsyncBackupCallLogsBaseScript asyncBackup = new AsyncBackupCallLogsBaseScript();
			asyncBackup.createHeader();
			asyncBackupCallLogsJsonBody = asyncBackup.setAsyncBackupCallLogsJsonBody();
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getDvcCallLogId(0), dvcCallLogId, asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getDuration(0),36000 , asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getName(0), "Name"+dvcCallLogId, asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getPhoneNo(0),RandomNumberGenerator.getRandomPhoneNo() , asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getDateTime(0), AsyncBackupCallLogsBaseScript.getCallLogDateTime("15.08.2017 00:45:09"), asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getType(0), "outgoing", asyncBackupCallLogsJsonBody);
			ValidatableResponse response = asyncBackup.triggerPostApiAsyncBackupCallLogs();
			int statusCode = response.extract().statusCode();
			Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Create Board Status");
			FrameworkLogger.logStep("asyncBackupCallLogsServiceMethod: End");
			return response;
		}
		
		public static ValidatableResponse asyncBackupCallLogsServiceMethod(Map<String, String> headerMap1, String dvcCallLogId, String date, String callLogType) throws IOException, VerificationFailException, ParseException {
			FrameworkLogger.logStep("asyncBackupCallLogsServiceMethod: Start");
			
			AsyncBackupCallLogsBaseScript asyncBackup = new AsyncBackupCallLogsBaseScript();
			asyncBackup.createHeader(headerMap1);
			asyncBackupCallLogsJsonBody = asyncBackup.setAsyncBackupCallLogsJsonBody();
			asyncBackupCallLogsJsonBody = asyncBackup.setAsyncBackupCallLogsJsonBody();
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getDvcCallLogId(0), dvcCallLogId, asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getDuration(0),36000 , asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getName(0), "Name"+dvcCallLogId, asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getPhoneNo(0),RandomNumberGenerator.getRandomPhoneNo() , asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getDateTime(0), AsyncBackupCallLogsBaseScript.getCallLogDateTime("15.08.2017 00:45:09"), asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getType(0), "outgoing", asyncBackupCallLogsJsonBody);
			ValidatableResponse response = asyncBackup.triggerPostApiAsyncBackupCallLogs(headerMap1);
			int statusCode = response.extract().statusCode();
			Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Create Board Status");
			FrameworkLogger.logStep("asyncBackupCallLogsServiceMethod: End");
			return response;
		}
		
	    public static String getCallLogDateTime(String callLogDate) throws ParseException
	    
	       {
	    	   SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss"); // Month.Day.Year

	    	   Date d = formatter.parse(callLogDate);
	    	   long timestamp = d.getTime();
	    	   System.out.println("Date final date============="+timestamp);
			return timestamp+"";
	    	   
	       }
	    
	    public  static long getCallLogDateTime1(String callLogDate) throws ParseException
	    
	       {
	    	   SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss"); // Month.Day.Year

	    	   Date d = formatter.parse(callLogDate);
	    	   long timestamp = d.getTime();
	    	   System.out.println("Date final date============="+timestamp);
			return timestamp;
			
	       }
	    
	    
		public static ValidatableResponse asyncBackupCallLogsServiceMethodForDifferentDevices(String deviceKey, String deviceName, String dvcCallLogId, String date, String callLogType) throws IOException, VerificationFailException, ParseException {
			FrameworkLogger.logStep("asyncBackupCallLogsServiceMethodForDifferentDevices: Start");
			
			AsyncBackupCallLogsBaseScript asyncBackup = new AsyncBackupCallLogsBaseScript();
			asyncBackup.createHeader();
			asyncBackup.headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), deviceKey);
			asyncBackup.headerMap.put(HeaderParameters.XDEVICENAME.getValue(), deviceName);
			asyncBackupCallLogsJsonBody = asyncBackup.setAsyncBackupCallLogsJsonBody();
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getDvcCallLogId(0), dvcCallLogId, asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getDuration(0),36000 , asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getName(0), "Name"+dvcCallLogId, asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getPhoneNo(0),RandomNumberGenerator.getRandomPhoneNo() , asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getDateTime(0), AsyncBackupCallLogsBaseScript.getCallLogDateTime("15.08.2017 00:45:09"), asyncBackupCallLogsJsonBody);
			asyncBackupCallLogsJsonBody = setJsonData(CallLogConstants.getType(0), "outgoing", asyncBackupCallLogsJsonBody);
			ValidatableResponse response = asyncBackup.triggerPostApiAsyncBackupCallLogs();
			int statusCode = response.extract().statusCode();
			Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Create Board Status");
			FrameworkLogger.logStep("asyncBackupCallLogsServiceMethodForDifferentDevices: End");
			return response;
		}
		
	
}

