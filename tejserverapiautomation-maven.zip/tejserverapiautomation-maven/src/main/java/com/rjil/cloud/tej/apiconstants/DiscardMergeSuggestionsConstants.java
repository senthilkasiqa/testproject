package com.rjil.cloud.tej.apiconstants;

/**
 * Discard Merge Summary API, JSON path Constants
 * 
 */

public class DiscardMergeSuggestionsConstants {

    public static String getDupidJsonPath() {
        return "$.dupid";
    }
}
