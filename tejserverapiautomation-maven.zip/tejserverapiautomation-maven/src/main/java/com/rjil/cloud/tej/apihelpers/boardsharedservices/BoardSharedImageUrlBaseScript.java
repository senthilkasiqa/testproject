package com.rjil.cloud.tej.apihelpers.boardsharedservices;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class BoardSharedImageUrlBaseScript extends BaseTestScript{

	
	protected static final String apiName = "BoardSharedImageUrl";
	
	public BoardSharedImageUrlBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * get a complete url for 'BoardSharedImageUrl'
	 * 
	 * @return
	 */

	protected String getBoardSharedImageUrl(String shareKey) {

		FrameworkLogger.logStep("BoardSharedImageUrl:-> Start");
		String aplUrl = apiUrls.get("boardUrl") + serverConfig.get("boardSharedImageUrl").replace("{shareKey}",shareKey);
		
		FrameworkLogger.logStep("BoardSharedImageUrl : End");
		return aplUrl;
	}
	
	

	/**
	 * Method to get the response after triggering BoardSharedImageUrl
	 * API
	 */
	protected ValidatableResponse triggerGetApiBoardSharedImageUrl(String shareKey) throws IOException {
		FrameworkLogger.logStep("triggerGetApiBoardSharedImageUrl:-> Start");
		String strApiUrl = getBoardSharedImageUrl(shareKey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiBoardSharedImageUrl:-> End");
		return response;
	}
	
	
	/**
	 * Method to get the response after triggering BoardSharedImageUrl
	 * API
	 */
	protected ValidatableResponse triggerGetApiBoardSharedImageUrl(String shareKey, Map<String, String>headerMap) throws IOException {
		headerMap = createHeader(deviceContributorInfo);
		FrameworkLogger.logStep("triggerGetApiBoardSharedImageUrl:-> Start");
		String strApiUrl = getBoardSharedImageUrl(shareKey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiBoardSharedImageUrl:-> End");
		return response;
	}

	/**
	 * Method to get the response after triggering Get All Shared Image Url
	 * API
	 */
	protected ValidatableResponse triggerGetApiBoardSharedImageUrlService(String shareKey) throws IOException {
		FrameworkLogger.logStep("triggerGetApiBoardSharedImageUrlService:-> Start");
		
		createHeader();
		String strApiUrl = getBoardSharedImageUrl(shareKey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		
		FrameworkLogger.logStep("triggerGetApiBoardSharedImageUrlService:-> End");
		return response;
	}
}
