package com.rjil.cloud.tej.apihelpers.messages;

import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class GetLastModifiedDateTimeForMessagesBaseScript extends BaseTestScript{
	
	  protected static final String apiName="LastModifiedDateAndTimeForMessages";
	  
	  public GetLastModifiedDateTimeForMessagesBaseScript(){
		  globalApiName=apiName;
	  }

	    /**
	     * @author Sanjeevanee Kanase
	     * <p>
	     * It creates the url for API 
	     */
	    private String getLastModifiedDateTimeForMessagesUrl() {
			FrameworkLogger.logStep("getLastModifiedDateTimeForMessagesUrl:-> Start");

			String apiUrl=apiUrls.get("baseMessagesURL") + serverConfig.get("lastModifiedDateTimeForMessagesUrl");
			FrameworkLogger.logStep("getLastModifiedDateTimeForMessagesUrl:-> End");
			return apiUrl;
	    }
	    
	    private String getLastModifiedDateTimeForMessagesWithDeviceKeysUrl(String deviceKey) {
			FrameworkLogger.logStep("getLastModifiedDateTimeForMessagesWithDeviceKeysUrl:-> Start");

			String apiUrl=apiUrls.get("baseMessagesURL") + serverConfig.get("lastModifiedDateTimeForMessagesUrl")+"?deviceKeys="+deviceKey;
			FrameworkLogger.logStep("getLastModifiedDateTimeForMessagesWithDeviceKeysUrl:-> End");
			return apiUrl;
	    }
	    
	//    /messages_lastmodified/1.0?deviceKeys=
	    
	    // Overload the method.
	 	protected Map<String, String> createHeader() {
	 		FrameworkLogger.logStep("createHeader -> Start");

	 		headerMap = initializeHeader();
	 //		headerMap.remove(HeaderParameters.XAPPSECRET.getValue(), getAppSecretValue());
	//		headerMap.remove(HeaderParameters.XAPIKEY.getValue());
	 		FrameworkLogger.logStep("createHeader -> End");
	 		return headerMap;
	 	}
	
	    /**
	     * @return validatable response for LastModifiedDateTimeforMessages
	     * @author 
	     * <p>
	     * Call the API and return the Response
	     */
	    
	    protected ValidatableResponse triggerGetApiLastModifiedDateTimeforMessages() {
			FrameworkLogger.logStep("triggerGetApiLastModifiedDateTimeforMessages:-> Start");
	        // setContactBackupJsonBody();
			
			String strApiUrl=getLastModifiedDateTimeForMessagesUrl();
			
			//Call method to trigger GET API.
			ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
			
			FrameworkLogger.logStep("triggerGetApiLastModifiedDateTimeforMessages:-> End");
			return response;
	    }
	    
	    
	    
	    protected ValidatableResponse triggerGetApiLastModifiedDateTimeforMessages(String deviceKeys) {
			FrameworkLogger.logStep("triggerGetApiLastModifiedDateTimeforMessages:-> Start");
	        // setContactBackupJsonBody();
			
			String strApiUrl=getLastModifiedDateTimeForMessagesWithDeviceKeysUrl(deviceKeys);
			
			//Call method to trigger GET API.
			ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
			
			FrameworkLogger.logStep("triggerGetApiLastModifiedDateTimeforMessages:-> End");
			return response;
	    }
	    
	    
	    public static ValidatableResponse getLastModifiedDateTimeforMessages()
	    {
			FrameworkLogger.logStep("getLastModifiedDateTimeforMessages:-> Start");
			GetLastModifiedDateTimeForMessagesBaseScript modifiedDate = new GetLastModifiedDateTimeForMessagesBaseScript();

			modifiedDate.createHeader();
	    	
            String strApiUrl=modifiedDate.getLastModifiedDateTimeForMessagesUrl();
            
			//Call method to trigger GET API.
			ValidatableResponse response = modifiedDate.triggerGetApi(strApiUrl,modifiedDate.headerMap);
			
			FrameworkLogger.logStep("getLastModifiedDateTimeforMessages:-> End");

			return response;
	    	
	    	
	    }
	    
	    public static ValidatableResponse getLastModifiedDateTimeforMessages(String deviceKeys)
	    {
			FrameworkLogger.logStep("getLastModifiedDateTimeforMessages:-> Start");
			GetLastModifiedDateTimeForMessagesBaseScript modifiedDate = new GetLastModifiedDateTimeForMessagesBaseScript();

			modifiedDate.createHeader();
	    	
            String strApiUrl=modifiedDate.getLastModifiedDateTimeForMessagesWithDeviceKeysUrl(deviceKeys);
            
			//Call method to trigger GET API.
			ValidatableResponse response = modifiedDate.triggerGetApi(strApiUrl,modifiedDate.headerMap);
			
			FrameworkLogger.logStep("getLastModifiedDateTimeforMessages:-> End");

			return response;
	    	
	    	
	    }
}
