package com.rjil.cloud.tej.enums;

/**
 * Add Idam User API Enum
 */
public enum UserManagementParameters {
	IDAMUNIQUE("idamUnique"),
	EMAILID("emailId"),
	FIRSTNAME("firstName"),
	LASTNAME("lastName"),
	MOBILENUMBER("mobileNumber"),
	FEATURECODE("featureCode"),
	COUNTRY("country"),
	LANGUAGE("language"),
	TIMEZONE("timeZone");
  

    public String value;

    UserManagementParameters(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
