package com.rjil.cloud.tej.apihelpers.usermanagement;

import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import java.io.IOException;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

/**
 * 
 * @author Ashwini.Abhyankar
 *
 *         Base Class for Get Auto Backup Settings API
 */

public class GetAutoBackupSettingsBaseScript extends BaseTestScript { 
	protected static final String apiName = "GetAutoBackupSettings";
	
	public GetAutoBackupSettingsBaseScript(){
		globalApiName=apiName;
	}
	/**
	 * Method for getting auto backup settings url
	 * @return
	 */
	protected String getGetAutoBackupSettingsURL() {
		
		FrameworkLogger.logStep("getGetAutoBackupSettingsURL:-> Start");
		String url = apiUrls.get("baseURL") + serverConfig.get("getAutoBackupSettingsUrl");

		FrameworkLogger.logStep("getGetAutoBackupSettingsURL:-> End");
		return url;
	}
	
	protected String getGetAutoBackupSettingsURL(String url) {
		FrameworkLogger.logStep("getGetAutoBackupSettingsURL:-> Start");
		String apiUrl = apiUrls.get("baseURL") + serverConfig.get(url);

		FrameworkLogger.logStep("getGetAutoBackupSettingsURL:-> End");
		return apiUrl;
	}

	/**
	 * Method to get the response after triggering Get Auto Backup Settings API
	 * @return
	 * @throws IOException
	 */
	protected ValidatableResponse triggerGetApiGetAutoBackupSettings() throws IOException {

		FrameworkLogger.logStep("triggerGetApiGetAutoBackupSettings:-> Start");

		// get url for get auto backup settings api
		String strApiUrl = getGetAutoBackupSettingsURL();

		// get url for get auto backup settings api
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);

		FrameworkLogger.logStep("triggerGetApiGetAutoBackupSettings:-> End");
		return response;
	}
	
	/**
	 * Method to get the response after triggering Get Auto Backup Settings API for invalid data
	 * @return
	 * @throws IOException
	 */
	protected ValidatableResponse triggerGetApiGetAutoBackupSettings(String apiUrl) throws IOException {

		FrameworkLogger.logStep("triggerGetApiGetAutoBackupSettings:-> Start");

		// get url for get auto backup settings api
		String strApiUrl = getGetAutoBackupSettingsURL(apiUrl);

		// get url for get auto backup settings api
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);

		FrameworkLogger.logStep("triggerGetApiGetAutoBackupSettings:-> End");
		return response;
	}
}

