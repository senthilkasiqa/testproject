package com.rjil.cloud.tej.apihelpers.gatewayservices;


import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import com.jayway.jsonpath.JsonPath;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;


import static com.jayway.restassured.RestAssured.given;

/**
 * Created by bharat on 02/09/16.
 */
public class ValidateOneTimeAccessTokenAndCreateNewWebTokenBaseScript extends BaseTestScript{
//    protected static Map<String,String>headerMap = null;
    private String validateJsonBody = null;

//    protected static String getvalidateURL() {
    protected String getvalidateURL() {
        return apiUrls.get("URL") + serverConfig.get("getValidateUrl");
    }

	// Overload the method.
/*	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");
        headerMap = new HashMap<>();
        headerMap.put(HeaderParameters.AUTHORIZATION.getValue(),repositoryMap.get("Authorization"));
        headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");

        //Pass X-API header key
        addXapiHeaderKey(headerMap);

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
    }
*/
	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Add additional header parameters.
        headerMap.put(HeaderParameters.AUTHORIZATION.getValue(),repositoryMap.get("Authorization"));

		// Remove from header for this API.
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

    
    protected ValidatableResponse validatetOneTimeAccessTokenResponse() throws IOException {
        setValidateJsonBody();
/*        ValidatableResponse response = given()
                .body(validateJsonBody)
                .headers(headerMap).log().all()
                .when()
                .post(getvalidateURL())
                .then();
        Utils.addRequestResponseToLogger();
*/ 
        ValidatableResponse response = triggerPostApi(getvalidateURL(), headerMap, validateJsonBody);
        return response;


    }

    protected String setValidateJsonBody() throws IOException {
        String path = System.getProperty("user.dir") + "/resources/gatewayServicesTestData/validateBody.js";
        File file = new File(path);
        validateJsonBody = JsonPath.parse(file).jsonString();
        String result = JsonPath.parse(validateJsonBody).jsonString();
        return result;
        //validateJsonBody = setJsonData()
    }




}
