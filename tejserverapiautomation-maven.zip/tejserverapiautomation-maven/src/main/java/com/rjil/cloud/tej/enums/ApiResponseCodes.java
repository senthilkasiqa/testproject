package com.rjil.cloud.tej.enums;

/**
 * @author: Chandra
 * 
 * API Response Codes Enum
 * This is for all API's Response http codes.
 */

public enum ApiResponseCodes {
	
    RESPONSECODE200(200),
    RESPONSECODE201(201),
    RESPONSECODE202(202),
    RESPONSECODE204(204),
    RESPONSECODE206(206),
    RESPONSECODE400(400),
    RESPONSECODE401(401),
    RESPONSECODE404(404),
    RESPONSECODE405(405),
    RESPONSECODE407(407),
    RESPONSECODE415(415),
    RESPONSECODE416(416),
    RESPONSECODE500(500), 
    RESPONSECODE412(412);

	

    public int value;

    ApiResponseCodes(int value) {
        this.value = value;

    }

    public int getValue() {
        return value;
    }
}

