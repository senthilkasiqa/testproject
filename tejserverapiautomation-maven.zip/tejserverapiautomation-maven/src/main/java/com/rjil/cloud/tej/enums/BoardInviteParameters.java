package com.rjil.cloud.tej.enums;

public enum BoardInviteParameters {

	XUSERID("X-User-Id"),
    XDEVICEKEY("X-Device-Key"),
	BOARDNAME("boardName"),
	USERCONTACTS("userContacts"),
	FIRSTNAME("firstName"),
	LASTNAME("lastName"),
	USERCONTACT("userContact"),
	USERTYPE("userType"),
	AUTHORIZATION("Authorization"),
	ACCEPTLANGUAGE("Accept-Language");
	
    public String value;

    BoardInviteParameters(String value) {
        this.value = value;

    }

    public String getValue() {
        return value;
    }
}
