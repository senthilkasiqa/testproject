package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.UpdateCopyContactDeviceMappingConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;

/**
 * @author Chandrashekhar Singh
 * 
 *         Base script for UpdateCopyContactDeviceMapping API.
 * */

public class UpdateCopyContactDeviceMappingBaseScript extends BaseTestScript {
	protected static final String apiName = "UpdateCopyContactDeviceMappingAPI";
	protected String jsonBody;
	public UpdateCopyContactDeviceMappingBaseScript(){
  		globalApiName=apiName;
  	}

	
	/**
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         It creates the url for API
	 */
	protected String getUpdateCopyContactDeviceMappingApiUrl() {
		FrameworkLogger.logStep("getUpdateCopyContactDeviceMappingApiUrl:-> Start");
		
		String url=apiUrls.get("baseContactURL")
				+ serverConfig.get("updateCopyContactDeviceMappingApiUrl");

		FrameworkLogger.logStep("getUpdateCopyContactDeviceMappingApiUrl:-> Start");
		return url;
	}

	/**
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         It loads the default JSON body.
	 */

	protected void loadJsonFile() {
		FrameworkLogger.logStep("loadJsonFile:-> Start");
		// load json file
		String filePath = "/resources/updateCopyContactDeviceMappingTestData/updateCopyContactDeviceMappingApiJsonBody.js";
		jsonBody = loadJsonFile(filePath);

		FrameworkLogger.logStep("loadJsonFile:-> End");
	}

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It will set the value on provided json path
     * @throws ParseException 
     */
    protected void setUpdateCopyContactDeviceMappingInfoInJsonFile(List<String> contactList) throws ParseException {
		FrameworkLogger.logStep("setUpdateCopyContactDeviceMappingInfoInJsonFile:-> Start");

    	JSONArray listAllContacts = new JSONArray();
    	for(String oneContact: contactList){
    		listAllContacts.add(oneContact);
    	}
    	
//		setJsonBody(UpdateCopyContactDeviceMappingConstants.getContactsJsonPath(), strContactId);
    	JSONParser parser=new JSONParser();
//    	JSONParser parserAllContacts=new JSONParser();
    	Object objAllRequest=parser.parse(jsonBody);
    	JSONObject jsonObjectAllRequest=(JSONObject)objAllRequest;
    	jsonObjectAllRequest.put("contacts", listAllContacts);

		jsonBody=jsonObjectAllRequest.toJSONString();
		
		FrameworkLogger.logStep("setUpdateCopyContactDeviceMappingInfoInJsonFile:-> End");
    }

	/**
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         It will set the value on provided json path
	 */
	private void setJsonBody(String jsonPath, String value) {
		FrameworkLogger.logStep("setJsonBody:-> Start");
		jsonBody = setJsonData(jsonPath, value, jsonBody);

		FrameworkLogger.logStep("setJsonBody:-> End");
	}


	/**
	 * @return validatable response for API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the API and return the Response
	 */
	protected ValidatableResponse triggerPutApiUpdateCopyContactDeviceMapping() {
		FrameworkLogger
				.logStep("triggerPutApiUpdateCopyContactDeviceMapping:-> Start");

		String strApiUrl=getUpdateCopyContactDeviceMappingApiUrl();
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,jsonBody);
		
		FrameworkLogger
				.logStep("triggerPutApiUpdateCopyContactDeviceMapping:-> End");

		return response;
	}

	//Verify success status.
	public static void verifyUpdateCopyContactDeviceMappingSuccessMessageServiceMethod(ValidatableResponse response, int intExpCode, String strExpStatus) throws VerificationFailException{
		FrameworkLogger.logStep("verifyUpdateCopyContactDeviceMappingSuccessMessageServiceMethod:-> Start");
		
		//Read the actual information from Response
		int intActStatus = response.extract().statusCode();	//200

		String strActCode = response.extract().path("status");

		//Validating the Actual and Expected information
		Verify.verifyEquals(strActCode, strExpStatus,
				"Verifying the response code.");
		Verify.verifyEquals(intActStatus, intExpCode,
				"Validating the Expected and Actual 'HTTP Codes for Error'.");

		FrameworkLogger.logStep("verifyUpdateCopyContactDeviceMappingSuccessMessageServiceMethod:-> End");
	}

	// This method accepts the response and returns the list of contacts not matching with deviceId.
	public static List<String> getContactListNotForDeviceIdFromCabApiResponse(ValidatableResponse response, String deviceId, int numberOfContacts){
        FrameworkLogger.logStep("getContactListFromCabApiResponse:-> Start");

//        String deviceId=serverConfig.get("deviceKey");
        List<String> contactList=new ArrayList<>();

        int size=-1;
		size= CabBaseScript.getSizeOfContactsInCabApiResponse(response);

		for(int i=0; i<size; i++){
			if(contactList.size()==numberOfContacts) break;
			String strDeviceIdInResponse=response.extract().path("contacts["+i+"].device_id_list");
	        FrameworkLogger.logStep("Comparing device_id_list= "+strDeviceIdInResponse +"; with deviceId="+deviceId);
			
	        if(!strDeviceIdInResponse.contains(deviceId)){
		        FrameworkLogger.logStep("Contact is for OTHER device: "+strDeviceIdInResponse);
	        	String strContactIdInResponse=response.extract().path("contacts["+i+"].contactid");
	        	contactList.add(strContactIdInResponse);
	        } else{
		        FrameworkLogger.logStep("Contact is for SAME device: "+strDeviceIdInResponse);
	        	
	        }
			
		}
        FrameworkLogger.logStep("getContactListFromCabApiResponse:-> End");
		return contactList;
	}

	// This method accepts the response and verifies the mapping of contact and device in CAB response.
	public static List<String> verifyCopyContactDeviceMappingInCabApiResponse(ValidatableResponse response, List<String> contactList, String deviceId) throws VerificationFailException{
        FrameworkLogger.logStep("verifyCopyContactDeviceMappingInCabApiResponse:-> Start");

//        String deviceId=serverConfig.get("deviceKey");
//        List<String> contactList=new ArrayList<>();

        int size=-1;
		size= CabBaseScript.getSizeOfContactsInCabApiResponse(response);
		int numberOfVerifiedContacts=0;
		for(int i=0; i<size; i++){
			if(contactList.size()==numberOfVerifiedContacts) break;
        	String strContactIdInResponse=response.extract().path("contacts["+i+"].contactid");

//        	String strDeviceIdInResponse=response.extract().path("contacts["+i+"].device_id_list");
//	        FrameworkLogger.logStep("Comparing device_id_list= "+strDeviceIdInResponse +"; with deviceId="+deviceId);
			if(contactList.contains(strContactIdInResponse)){
	        	String strDeviceIdInResponse=response.extract().path("contacts["+i+"].device_id_list");
				
		        FrameworkLogger.logStep("ContactId= "+strContactIdInResponse +";Comparing deviceId="+deviceId +"; with deviceIdList=" + strDeviceIdInResponse);
		        
		        if(!strDeviceIdInResponse.contains(deviceId)){
			        FrameworkLogger.logStep("Device id is not mapped with contact.");
					Verify.verifyEquals("DeviceId is NOT matched with Contact"+strContactIdInResponse, "DeviceId SHOULD matched with Contact"+strContactIdInResponse,
							"Validating the mapping of device Id with contact."+strContactIdInResponse);
					numberOfVerifiedContacts++;
		        }
			}
		}
        FrameworkLogger.logStep("verifyCopyContactDeviceMappingInCabApiResponse:-> End");
		return contactList;
	}
}
