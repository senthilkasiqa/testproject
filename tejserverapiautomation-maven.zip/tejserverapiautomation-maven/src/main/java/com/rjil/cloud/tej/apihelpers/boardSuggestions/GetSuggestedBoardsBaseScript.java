package com.rjil.cloud.tej.apihelpers.boardSuggestions;

import java.io.IOException;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boards.GetBoardCategoriesBaseScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

public class GetSuggestedBoardsBaseScript extends BaseTestScript 

{
	protected static final String apiName = "GetSuggestedBoards";
	
	protected String getSuggestedBoardsURL() {
	FrameworkLogger.logStep(" getSuggestedBoardsURL:-> Start");
	return apiUrls.get("boardUrl") + serverConfig.get("getSuggestedBoardsUrl");
	
}
	
protected String getSuggestedBoardsURL(String url) {
		FrameworkLogger.logStep(" getSuggestedBoardsURL:-> Start");
		return apiUrls.get("boardUrl") + url;
	}

protected ValidatableResponse triggerGetSuggestedBoards() throws IOException {
	FrameworkLogger.logStep("triggerGetSuggestedBoards:-> Start");
	String strApiUrl = getSuggestedBoardsURL();
	ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
	FrameworkLogger.logStep("triggerGetSuggestedBoards:-> End");
	return response;
}

protected ValidatableResponse triggerGetSuggestedBoards(String url) throws IOException {
	FrameworkLogger.logStep("triggerGetSuggestedBoards:-> Start");
	String strApiUrl = getSuggestedBoardsURL(url);
	ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
	FrameworkLogger.logStep("triggerGetSuggestedBoards:-> End");
	return response;
}

public static ValidatableResponse getSuggestedBoardsBaseScriptService()
{
	GetSuggestedBoardsBaseScript getSuggestedBoards = new GetSuggestedBoardsBaseScript();
	getSuggestedBoards.createHeader();
	String strApiUrl = getSuggestedBoards.getSuggestedBoardsURL();
	ValidatableResponse response =getSuggestedBoards.triggerGetApi(strApiUrl, getSuggestedBoards.headerMap);
	return response;
}


public int getIndexOfSuggestedBoard(ValidatableResponse suggestedBoardsResponse, String BoardNameExpected)
{
	int  noOfBoards = suggestedBoardsResponse.extract().jsonPath().getList("boards").size();
	System.out.println("No. of suggested boards===="+noOfBoards);
	int boardIndex = -1;
	for(int i=0;i<noOfBoards;i++)
	{
		String boardName = suggestedBoardsResponse.extract().path("boards["+i+"].boardName");
		System.out.println("Name of suggetsed board ===="+boardName);
		
		if(boardName.contains(BoardNameExpected))
		{
			
			System.out.println("expected suggested board name ===="+BoardNameExpected);
			System.out.println("Found suggested board name ===="+boardName);
			System.out.println("Found suggested board name @@@@@ ===="+i);
			
			boardIndex = i;
			
		}
		
	}
	return boardIndex;
}


public int getfilesCountFromAPI(ValidatableResponse suggestedBoardsResponse, int suggestionIndex)
{
	
	int fileCount = suggestedBoardsResponse.extract().path("boards["+suggestionIndex+"].filesCount");
	return fileCount;

}


public long getStartDateOfSuggestedBoard(ValidatableResponse suggestedBoardsResponse, int suggestionIndex)
{
	
	long startDate = suggestedBoardsResponse.extract().path("boards["+suggestionIndex+"].startDate");
	return startDate;

}


public long getEndDateOfSuggestedBoard(ValidatableResponse suggestedBoardsResponse, int suggestionIndex)
{
	
	long endDate = suggestedBoardsResponse.extract().path("boards["+suggestionIndex+"].endDate");
	return endDate;

}

public int getfilesCountFromFilesArray(ValidatableResponse suggestedBoardsResponse, int suggestionIndex)
{
	
	int  fileCountFromFilesArray = suggestedBoardsResponse.extract().jsonPath().getList("boards["+suggestionIndex+"].files").size();

	return fileCountFromFilesArray;

}


public boolean getfilesMimeType(ValidatableResponse suggestedBoardsResponse, int suggestionIndex)
{
	int  fileCountFromFilesArray = suggestedBoardsResponse.extract().jsonPath().getList("boards["+suggestionIndex+"].files").size();
	boolean isValidMimeType = false;
	for(int i=0; i<fileCountFromFilesArray;i++)
	{
	String mimeType = suggestedBoardsResponse.extract().path("boards["+suggestionIndex+"].files["+i+"].mimeType");
	System.out.println("MIMETYPE=============="+mimeType);
	if((mimeType.equalsIgnoreCase("video"))||(mimeType.equalsIgnoreCase("image")))
	{
		System.out.println("MIMETYPE******************=============="+mimeType);
		isValidMimeType = true;
	}
	}

	return isValidMimeType;

}




}
