package com.rjil.cloud.tej.apiconstants;

public class BoardInviteConstants {
	public static String getInviteMessage() {
        return "$.inviteMessage";
    }

    public static String getUserContacts() {
        return "$.userContacts";
    }

    public static String getFirstName() {
        return "$.userContacts[0].firstName";
    }

    public static String getLastName() {
        return "$.userContacts[0].lastName";
    }

    public static String getUserContact() {
        return "$.userContacts[0].userContact";
    }

    public static String getUserType() {
        return "$.userContacts[0].userType";
    }
    
    public static String getInviteCode(){
    	return "$.processed.inviteCode";
    }

    
}
