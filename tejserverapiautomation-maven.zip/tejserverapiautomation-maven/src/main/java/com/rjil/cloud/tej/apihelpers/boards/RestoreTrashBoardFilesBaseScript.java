/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boards;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 * 
 * Base class for restore trash board files
 *
 */
public class RestoreTrashBoardFilesBaseScript extends BaseTestScript{

	protected static final String apiName = "RestoreTrashBoardFile";
	protected String restoreTrashBoardFileJsonBody;

	public RestoreTrashBoardFilesBaseScript(){
		globalApiName=apiName;
	}
	
	protected Map<String, String> createHeader() {
		headerMap = initializeHeader();
		return headerMap;
	}
	/**
	 * get a complete url for 'Restore metadata API'
	 * 
	 * @return
	 */
	protected String getRestoreTrashBoardFileUrl() {
		FrameworkLogger.logStep("getRestoreTrashBoardFileUrl: Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get("restoreTrashBoardFileUrl");
		FrameworkLogger.logStep("getRestoreTrashBoardFileUrl: End");
		return url;
	}

	/**
	 * get a complete url for "restore metadata api with invalid data"
	 */
		
	protected String getRestoreTrashBoardFileUrl(String url) {
		FrameworkLogger.logStep("getRestoreTrashBoardFileUrl: Start");
		String apiUrl = apiUrls.get("boardUrl") + serverConfig.get(url);
		FrameworkLogger.logStep("getRestoreTrashBoardFileUrl: End");
		return apiUrl;
	}

	// Set the jsonBody for RestoreMetadata API
	protected String setRestoreTrashBoardFileJsonBody() throws IOException {
		// load json file
		FrameworkLogger.logStep("setRestoreTrashBoarFileJsonBody: Start");
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/restoreTrashBoardFileBody.js";
		File file = new File(path);
		restoreTrashBoardFileJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setRestoreTrashBoarFileJsonBody: End");
		return restoreTrashBoardFileJsonBody;
	}

	/**
	 * Method to get Restore Metadata API Response
	 * 
	 * @return
	 * @throws IOException
	 */
	protected ValidatableResponse triggerPostApiRestoreTrashBoardFile() throws IOException {
		// setTrashMetadataJsonBody();
		FrameworkLogger.logStep("triggerPostApiRestoreTrashBoardFile: Start");

		String strApiUrl = getRestoreTrashBoardFileUrl();
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPostApi(strApiUrl, headerMap, restoreTrashBoardFileJsonBody);

		FrameworkLogger.logStep("triggerPostApiRestoreTrashBoardFile: End");
		return response;
	}
	
	public  ValidatableResponse triggerPostApiRestoreTrashBoardFile(String boardKey,String objectKey) throws IOException {
		// setTrashMetadataJsonBody();
		FrameworkLogger.logStep("triggerPostApiRestoreTrashBoardFile: Start");
		RestoreTrashBoardFilesBaseScript restoreTrashBoardFilesBaseScript= new RestoreTrashBoardFilesBaseScript();
		String strApiUrl = getRestoreTrashBoardFileUrl();
		restoreTrashBoardFilesBaseScript.setRestoreTrashBoardFileJsonBody();
		restoreTrashBoardFileJsonBody=setJsonData(NewBoardConstants.getBoardKeyForRestoreTrashFile(0), boardKey, restoreTrashBoardFileJsonBody);
		restoreTrashBoardFileJsonBody=setJsonData(NewBoardConstants.getObjectKeyForRestoreTrashFile(0), objectKey, restoreTrashBoardFileJsonBody);
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPostApi(strApiUrl, headerMap, restoreTrashBoardFileJsonBody);

		FrameworkLogger.logStep("triggerPostApiRestoreTrashBoardFile: End");
		return response;
	}
	
	public  ValidatableResponse triggerPostApiRestoreTrashBoardFile(Map<String,String> headerMap,String boardKey,String objectKey) throws IOException {
		// setTrashMetadataJsonBody();
		FrameworkLogger.logStep("triggerPostApiRestoreTrashBoardFile: Start");
		RestoreTrashBoardFilesBaseScript restoreTrashBoardFilesBaseScript= new RestoreTrashBoardFilesBaseScript();
		Map<String,String> headerMap1= createHeader(headerMap);
		String strApiUrl = getRestoreTrashBoardFileUrl();
		restoreTrashBoardFilesBaseScript.setRestoreTrashBoardFileJsonBody();
		restoreTrashBoardFileJsonBody=setJsonData(NewBoardConstants.getBoardKeyForRestoreTrashFile(0), boardKey, restoreTrashBoardFileJsonBody);
		restoreTrashBoardFileJsonBody=setJsonData(NewBoardConstants.getObjectKeyForRestoreTrashFile(0), objectKey, restoreTrashBoardFileJsonBody);
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPostApi(strApiUrl, headerMap1, restoreTrashBoardFileJsonBody);

		FrameworkLogger.logStep("triggerPostApiRestoreTrashBoardFile: End");
		return response;
	}
	
	public static ValidatableResponse restoreTrashBoardFileServiceMetod(String boardKey,String objectKey) throws IOException, VerificationFailException{
		FrameworkLogger.logStep("restoreTrashBoardFileServiceMetod: Start");
		RestoreTrashBoardFilesBaseScript restoreTrashBoardFilesBaseScript= new RestoreTrashBoardFilesBaseScript();
		Map<String,String> headerMap1= restoreTrashBoardFilesBaseScript.createHeader();
		String strApiUrl =restoreTrashBoardFilesBaseScript. getRestoreTrashBoardFileUrl();
		restoreTrashBoardFilesBaseScript.setRestoreTrashBoardFileJsonBody();
		restoreTrashBoardFilesBaseScript.restoreTrashBoardFileJsonBody=setJsonData(NewBoardConstants.getBoardKeyForRestoreTrashFile(0), boardKey, restoreTrashBoardFilesBaseScript.restoreTrashBoardFileJsonBody);
		restoreTrashBoardFilesBaseScript.restoreTrashBoardFileJsonBody=setJsonData(NewBoardConstants.getObjectKeyForRestoreTrashFile(0), objectKey, restoreTrashBoardFilesBaseScript.restoreTrashBoardFileJsonBody);
		// Call method to trigger PUT API.
		ValidatableResponse response = restoreTrashBoardFilesBaseScript.triggerPostApi(strApiUrl, headerMap1, restoreTrashBoardFilesBaseScript.restoreTrashBoardFileJsonBody);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Restore Trash Board File Status");

		FrameworkLogger.logStep("restoreTrashBoardFileServiceMetod: End");
		return response;
	}

	/**
	 * Method to get Restore metadata api response for invalid cases
	 * 
	 *//*

	protected ValidatableResponse getRestoreMetadataAPIResponse(String apiUrl) throws IOException {
		// setTrashMetadataJsonBody();
		FrameworkLogger.logStep("getRestoreMetadataAPIResponse: Start");

		String strApiUrl = getRestoreMetadataURL(apiUrl);
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, restoreMetadataJSONBody);

		FrameworkLogger.logStep("getRestoreMetadataAPIResponse: End");
		return response;
	}

	public static void extractAndVerifyRestoreMetadataResponse(ValidatableResponse response) throws VerificationFailException {
		String status = response.extract().path("objects[0].status");
		boolean isHidden = response.extract().path("objects[0].isHidden");
		boolean isLocked = response.extract().path("objects[0].isLocked");
		//boolean isPinned = response.extract().path("objects[0].isPinned");
		//boolean iLiked = response.extract().path("objects[0].iLiked");
		boolean isReadonly = response.extract().path("objects[0].isReadonly");

		Verify.verifyEquals(status, "A");
		Verify.verifyEquals(isHidden, false);
		Verify.verifyEquals(isLocked, false);
		//Assert.assertEquals(isPinned, false);
		//Assert.assertEquals(iLiked, false);
		Verify.verifyEquals(isReadonly, false);

	}

	 
	public  ValidatableResponse getRestoreMetadataAPIService() throws IOException {
		// setTrashMetadataJsonBody();
		FrameworkLogger.logStep("getRestoreMetadataAPIResponse: Start");
		createHeader();
		String strApiUrl = getRestoreMetadataURL();
		// Call method to trigger PUT API.
		setRestoreMetadataJsonBody();
		// Update Json body for restore metadata api
		restoreMetadataJSONBody = setJsonData(NmsConstants.getObjectKey(0),
						repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue()), restoreMetadataJSONBody);
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, restoreMetadataJSONBody);

		FrameworkLogger.logStep("getRestoreMetadataAPIResponse: End");
		return response;
	}*/
}
