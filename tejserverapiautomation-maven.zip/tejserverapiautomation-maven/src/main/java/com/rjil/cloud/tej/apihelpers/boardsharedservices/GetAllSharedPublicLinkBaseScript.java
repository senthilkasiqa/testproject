package com.rjil.cloud.tej.apihelpers.boardsharedservices;

import java.io.IOException;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

/**
 * 
 * @author Ashwini.Abhyankar: Base Class For Get All Shared Base Script API
 *
 */
public class GetAllSharedPublicLinkBaseScript extends BaseTestScript {

	protected static final String apiName = "GetAllSharedPublicLink";
	
	public GetAllSharedPublicLinkBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * Method to create Get All Shared Public Link URL
	 */
	protected String getGetAllSharedPublicLinkUrl() {
		FrameworkLogger.logStep("getGetAllSharedPublicLinkUrl:-> Start");
		String url = apiUrls.get("baseURL") + serverConfig.get("getAllSharedPublicLinkUrl");
		FrameworkLogger.logStep("URL" + url);
		FrameworkLogger.logStep("getGetAllSharedPublicLinkUrl:-> End");
		return url;
	}

	/**
	 * Overloaded method to create invalid Get All Shared Public Link URL
	 */
	protected String getGetAllSharedPublicLinkUrl(String url) {
		FrameworkLogger.logStep("getGetAllSharedPublicLinkUrl:-> Start");
		String apiUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		FrameworkLogger.logStep("URL" + url);
		FrameworkLogger.logStep("getGetAllSharedPublicLinkUrl:-> End");
		return apiUrl;
	}

	/**
	 * Method to get the response after triggering Get All Shared Public Link
	 * API
	 */
	protected ValidatableResponse triggerGetApiGetAllSharedPublicLink() throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetAllSharedPublicLink:-> Start");
		String strApiUrl = getGetAllSharedPublicLinkUrl();
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetAllSharedPublicLink:-> End");
		return response;
	}

	/**
	 * Overloaded method to get the reponse after triggering Get All Shared
	 * Public Link with Parameter
	 */
	protected ValidatableResponse triggerGetApiGetAllSharedPublicLink(String apiUrl) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetAllSharedPublicLink:-> Start");
		String strApiUrl = getGetAllSharedPublicLinkUrl(apiUrl);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetAllSharedPublicLink:-> End");
		return response;
	}
}