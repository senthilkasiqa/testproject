package com.rjil.cloud.tej.apihelpers.usermanagement;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.LoginParameters;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;

public class LoginBaseScript extends BaseTestScript {

public LoginBaseScript(){
	globalApiName="Login";
}


//    private static Map<String,String>headerMap = null;

/*    protected void createHeader() {
        headerMap = new HashMap<>();
        headerMap.put("Content-Type", "application/json");

        //Add X-APi header key
        addXapiHeaderKey(headerMap);

    }
*/

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Remove from header for this API.
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
     * Method to get Login Response
     *
     * @return Login validatable response
     */
//    public static ValidatableResponse getLoginResponse() throws IOException {
    public ValidatableResponse getLoginResponse() throws IOException {
        getLoginUrl();
        setIdamJsonBody(serverConfig.get("deviceKey"));
/*        ValidatableResponse response = given()
                .body(loginJSONBody)
                .headers(headerMap).log().all()
                .when()
                .post(loginURL)
                .then();
        response.log().all();
        Utils.addRequestResponseToLogger();
*/        
		String strApiUrl=loginURL;
		//Call method to trigger POST API.
    	ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, loginJSONBody);

        return response;
    }
    

    /*  public ValidatableResponse getLoginResponseForWeb() throws IOException {
        getLoginUrl();
        setIdamJsonBodyForWeb(serverConfig.get("deviceKey"));
        ValidatableResponse response = given()

    /**
     * Method to get Login Response for web
     *
     * @return Login validatable response
     */
//    public static ValidatableResponse getLoginResponse() throws IOException {
   /* public ValidatableResponse getLoginResponseForWeb() throws IOException {
        getLoginUrl();
 //       setIdamJsonBody(serverConfig.get("deviceKey"));
        ValidatableResponse response = given()

                .body(loginJSONBody)
                .headers(headerMap).log().all()
                .when()
                .post(loginURL)
                .then();
        response.log().all();
        Utils.addRequestResponseToLogger();

  

        
		String strApiUrl=loginURL;
		String enPassword=Utils.encryptPassword(apiUrls.get("Password"));
		FrameworkLogger.logStep("ENCRYPTEDPASSWORD:"+enPassword);
	//	String decryptPassword=Utils.
		loginJSONBody=setJsonData(loginConstants.getDeviceType(), "W", loginJSONBody);
		loginJSONBody = JsonPath.parse(loginJSONBody).renameKey("@", "emailId", "loginId").jsonString();
		//updateJsonIDAM();
		FrameworkLogger.logStep("EMAIL:"+apiUrls.get("Email"));
		
		loginJSONBody=setJsonData(loginConstants.getPassword(), enPassword, loginJSONBody);
		//Call method to trigger POST API.
		headerMap.put("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
    	headerMap.put("X-Device-Type", "W");
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, loginJSONBody);


        return response;
    }
*/
    public  ValidatableResponse getWebLoginResponse() throws IOException {
    	createHeader();
        getLoginUrl();
        setIdamJsonBodyForWeb(serverConfig.get("deviceKey"));
/*        ValidatableResponse response = given()
                .body(loginJSONBody)
                .headers(headerMap).log().all()
                .when()
                .post(loginURL)
                .then();
        response.log().all();
        Utils.addRequestResponseToLogger();
*/        
		String strApiUrl=loginURL;
		//Call method to trigger POST API.
    	ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, loginJSONBody);

        return response;
    }
    
}
