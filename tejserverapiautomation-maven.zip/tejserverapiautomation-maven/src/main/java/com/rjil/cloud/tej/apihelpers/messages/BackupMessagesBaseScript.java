package com.rjil.cloud.tej.apihelpers.messages;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.JsonArray;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.parsing.Parser;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.MessageBackupConstants;
import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.contacts.ContactBackupBaseScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;


public class BackupMessagesBaseScript extends BaseTestScript{

    protected  String messageBackupJSONBody;
 //   protected  String generalMessageBackupJSONBody;
    protected static final String apiName="MessageBackup";

    /**
     * @author Sanjeevanee Kanase
     * <p>
     * It loads the file in constructor
     */
    
  //********************************** Get Message Backup RequestBody  *******************************************************************************//   

    public BackupMessagesBaseScript() {
		FrameworkLogger.logStep("MessageBackupBaseScript:-> Start");
            //load json file
		globalApiName=apiName;
        loadJsonFile();
		FrameworkLogger.logStep("MessageBackupBaseScript:-> End");
    }

 // Overload the method.
 	protected Map<String, String> createHeader() {
 		FrameworkLogger.logStep("createHeader -> Start");

 		headerMap = initializeHeader();
 		headerMap.put(HeaderParameters.XDEVICENAME.getValue(), "Samsung galaxy J5");
 //		headerMap.remove(HeaderParameters.XAPPSECRET.getValue(), getAppSecretValue());
	//	headerMap.remove(HeaderParameters.XAPIKEY.getValue());
 		FrameworkLogger.logStep("createHeader -> End");
 		return headerMap;
 	}

    /**
     * @author Sanjeevanee Kanase
     * <p>
     * It loads the default message Backup JSON body.
     */

    protected String loadJsonFile(){
		FrameworkLogger.logStep("loadJsonFile:-> Start");
		
        //load json file
		String filePath="/resources/messageBackupTestData/messageBackupBody.js";
		messageBackupJSONBody= loadJsonFile(filePath);
    	String strUniqueValue=Utils.getUniqueValue();
		FrameworkLogger.logStep("loadJsonFile:-> End");
		return messageBackupJSONBody;
    }
    
    /**
     * @author Sanjeevanee Kanase
     * <p>
     * It will set the value on provided json path
     */
    protected String setMessageBackupJsonBody(String jsonPath, Object value) {
		FrameworkLogger.logStep("setMessageBackupJsonBody:-> Start");
		messageBackupJSONBody = setJsonData(jsonPath, value, messageBackupJSONBody);
		FrameworkLogger.logStep("setMessageBackupJsonBody:-> End");
		return messageBackupJSONBody;
    }

   
    
    /**
     * @author Sanjeevanee Kanase
     * <p>
     * It creates the url for API
     */
    protected String getMessageBackupUrl() {
		FrameworkLogger.logStep("getMessageBackupUrl:-> Start");
        return apiUrls.get("baseMessagesURL") + serverConfig.get("messageBackupURL");
    }

    
    /**
     * @return validatable response for message Backup
     * @author Sanjeevanee Kanase
     * <p>
     * Call the Backup API and return the Response
     */
    protected ValidatableResponse triggerPostApiMessageBackup() {
		FrameworkLogger.logStep("triggerPostApiMessageBackup:-> Start");

	
    
    	String strApiUrl=getMessageBackupUrl();

    	ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, messageBackupJSONBody);
		
    	FrameworkLogger.logStep("triggerPostApiMessageBackup:-> End");
        return response;
    }
    
    public static ValidatableResponse backupMessagesService(String dvcMsgId, int dateTime, String operation) throws VerificationFailException, ParseException
    {
    
    	FrameworkLogger.logStep("backupMessagesService:-> Start");
		BackupMessagesBaseScript backup = new BackupMessagesBaseScript();
		backup.createHeader();
    	String strApiUrl=backup.getMessageBackupUrl();
    	backup.messageBackupJSONBody =backup.createMessageBody("HNY",dvcMsgId,"Pooja", "+91998652341525", "1",dateTime,"outbox", "hangout", operation);
    	ValidatableResponse response=backup.triggerPostApi(strApiUrl, backup.headerMap, backup.messageBackupJSONBody);
  
    	FrameworkLogger.logStep("backupMessagesService:-> End");
    	return response;
    	
    }
    
    public static ValidatableResponse backupMessagesService(Map device2Info,String dvcMsgId, int dateTime, String operation) throws VerificationFailException, ParseException, IOException
    {
    
    	FrameworkLogger.logStep("backupMessagesService:-> Start");
		BackupMessagesBaseScript backup = new BackupMessagesBaseScript();
		backup.createHeader(device2Info);
    	String strApiUrl=backup.getMessageBackupUrl();
    	backup.messageBackupJSONBody =backup.createMessageBody("HNY",dvcMsgId,"Pooja", "+91998652341525", "1",dateTime,"outbox", "hangout", operation);
    	ValidatableResponse response=backup.triggerPostApi(strApiUrl, backup.headerMap, backup.messageBackupJSONBody);
  
    	FrameworkLogger.logStep("backupMessagesService:-> End");
    	return response;
    	
    }
    
    
    public String createMessageBody(String text, String dvcMsgId, String name, String phoneNo, String convId, int dateTime, String msgType, String appType, String operation) throws ParseException
    {
    	FrameworkLogger.logStep("createMessageBody:-> Start");
  //  	  loadJsonFile();
  //	    String filePath="/resources/messageBackupTestData/messageBackupBody.js";
  //		messageBackupJSONBody=loadJsonFile(filePath);

    	
    	String messageBody= "{"+"\"dvcMsgId\"" + ":\""+dvcMsgId+ "\","+"\"text\"" + ":\""+text+ "\","+
    			"\"name\"" + ":\""+name+ "\","+"\"phoneNo\"" + ":\""+phoneNo+ "\","+
    			"\"convId\"" + ":\""+convId+ "\","+"\"dateTime\"" + ":"+dateTime+","+
    			"\"msgType\"" + ":\""+msgType+ "\","+"\"appType\"" + ":\""+appType+ "\","+
    			"\"operation\""+ ":\""+ operation+ "\"}";
    	
    	System.out.println("MessageBody="+messageBody);
    	JSONParser parser=new JSONParser();
    	Object Message =parser.parse(messageBody);
    	JSONObject jsonObjectMessage=(JSONObject)Message;
   // 	messageBackupJSONBody=setMessageBackupJsonBody(MessageBackupConstants.getFirstMessageJsonPath(), messageBody);
    	messageBackupJSONBody=setJsonData(MessageBackupConstants.getFirstMessageJsonPath(), jsonObjectMessage, messageBackupJSONBody);
    	System.out.println("messageBackupBody after converting="+messageBackupJSONBody);
    	
    	FrameworkLogger.logStep("createMessageBody:-> End");
	    return messageBackupJSONBody;
	 
    }
   
    
    public String createMessageBodyForNmessages(int noOfMessages, String text, String dvcMsgId, String name, String phoneNo, String convId, int dateTime, String msgType, String appType, String operation) throws ParseException
    {
    	FrameworkLogger.logStep("createMessageBodyForNmessages:-> Start");
    	int i;
    	JSONArray listAllContacts = new JSONArray();
    	
    	for(i=0;i<noOfMessages;i++)
    	{	
 		
    	dvcMsgId = "devMes"+System.currentTimeMillis();
		dateTime = 22222222+i;
		text = "abc"+System.currentTimeMillis();
		String messageBody= "{"+"\"dvcMsgId\"" + ":\""+dvcMsgId+ "\","+"\"text\"" + ":\""+text+ "\","+
    			"\"name\"" + ":\""+name+ "\","+"\"phoneNo\"" + ":\""+phoneNo+ "\","+
    			"\"convId\"" + ":\""+convId+ "\","+"\"dateTime\"" + ":"+dateTime+","+
    			"\"msgType\"" + ":\""+msgType+ "\","+"\"appType\"" + ":\""+appType+ "\","+
    			"\"operation\""+ ":\""+ operation+ "\"}";
    	
    	System.out.println("MessageBody="+messageBody);
    	JSONParser parser=new JSONParser();
    	Object Message =parser.parse(messageBody);
    	JSONObject jsonObjectMessage=(JSONObject)Message;
 			listAllContacts.add(jsonObjectMessage);
     	}
		
    	String messageBody= "{"+"\"messages\"" +":[]"+"}";
    	System.out.println("messageBody to be parse for error="+messageBody);
    	
    	System.out.println("MessageBody="+messageBody);
    	JSONParser parser=new JSONParser();
    	Object Message =parser.parse(messageBody);
    	JSONObject jsonObjectMessage=(JSONObject)Message;
    	jsonObjectMessage.put("messages", listAllContacts);
    //	messageBackupJSONBody=setJsonData(MessageBackupConstants.getMessagesJsonPath(), jsonObjectMessage, messageBackupJSONBody);
  
		messageBackupJSONBody=jsonObjectMessage.toString();
		System.out.println("messageBackupBody after converting="+messageBackupJSONBody); 
		FrameworkLogger.logStep("createMessageBodyForNmessages:-> End");
    return messageBackupJSONBody;

    	}
    
    public JSONObject createMessageBodyJSON(String text, String dvcMsgId, String name, String phoneNo, String convId, int dateTime, String msgType, String appType, String operation) throws ParseException
    {
    	FrameworkLogger.logStep("createMessageBodyJSON:-> Start");
		String messageBody= "{"+"\"dvcMsgId\"" + ":\""+dvcMsgId+ "\","+"\"text\"" + ":\""+text+ "\","+
    			"\"name\"" + ":\""+name+ "\","+"\"phoneNo\"" + ":\""+phoneNo+ "\","+
    			"\"convId\"" + ":\""+convId+ "\","+"\"dateTime\"" + ":"+dateTime+","+
    			"\"msgType\"" + ":\""+msgType+ "\","+"\"appType\"" + ":\""+appType+ "\","+
    			"\"operation\""+ ":\""+ operation+ "\"}";
    	
    	JSONParser parser=new JSONParser();
    	Object Message =parser.parse(messageBody);
    	JSONObject jsonObjectMessage=(JSONObject)Message;
    	FrameworkLogger.logStep("createMessageBodyJSON:-> End");
    	return jsonObjectMessage;
    }
    
    public String makeMessageBody(List <JSONObject> jsonObjectMessage) throws ParseException
    {
    	FrameworkLogger.logStep("makeMessageBody:-> Start");
    	JSONArray listAllContacts = new JSONArray();
    	for(int i=0;i<jsonObjectMessage.size();i++)
    	{
    	listAllContacts.add(jsonObjectMessage.get(i));
    	}
    	String messageBody= "{"+"\"messages\"" +":[]"+"}";
    	JSONParser parser=new JSONParser();
    	Object Message =parser.parse(messageBody);
    	JSONObject jsonObjectMessageBody=(JSONObject)Message;
    	jsonObjectMessageBody.put("messages", listAllContacts);
    	messageBackupJSONBody=jsonObjectMessageBody.toString();
    	FrameworkLogger.logStep("makeMessageBody:-> End");
        return messageBackupJSONBody;
    }
    
    public static ValidatableResponse backupMessagesServiceForXDeviceName(Map device2Info,String dvcMsgId, int dateTime, String operation, String deviceName) throws VerificationFailException, ParseException, IOException
    {
    
    	FrameworkLogger.logStep("backupMessagesServiceForXDeviceName:-> Start");
		BackupMessagesBaseScript backup = new BackupMessagesBaseScript();
		backup.createHeaderForXDeviceName(device2Info, deviceName);
    	String strApiUrl=backup.getMessageBackupUrl();
    	backup.messageBackupJSONBody =backup.createMessageBody("HNY",dvcMsgId,"Pooja", "+91998652341525", "1",dateTime,"outbox", "hangout", operation);
    	ValidatableResponse response=backup.triggerPostApi(strApiUrl, backup.headerMap, backup.messageBackupJSONBody);
  
    	FrameworkLogger.logStep("backupMessagesServiceForXDeviceName:-> End");
    	return response;
    	
    }
    
    
    public static ValidatableResponse backupMessagesServiceForXDeviceName(Map device2Info,String dvcMsgId, int dateTime, String operation, String deviceName, String phoneNo) throws VerificationFailException, ParseException, IOException
    {
    
    	FrameworkLogger.logStep("backupMessagesServiceForXDeviceName:-> Start");
		BackupMessagesBaseScript backup = new BackupMessagesBaseScript();
		backup.createHeaderForXDeviceName(device2Info, deviceName);
    	String strApiUrl=backup.getMessageBackupUrl();
    	backup.messageBackupJSONBody =backup.createMessageBody("HNY",dvcMsgId,"Pooja", phoneNo, "1",dateTime,"outbox", "hangout", operation);
    	ValidatableResponse response=backup.triggerPostApi(strApiUrl, backup.headerMap, backup.messageBackupJSONBody);
  
    	FrameworkLogger.logStep("backupMessagesServiceForXDeviceName:-> End");
    	return response;
    	
    }


}
