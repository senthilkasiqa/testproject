package com.rjil.cloud.tej.apiconstants;

/**
 * Login API Constants Class
 */
public class LoginConstants {

    public static String getAuthProviderId() {
        return "$.authProviderId";
    }

    public static String getEmailId() {
        return "$.emailId";
    }

    public static String getLoginId() {
        return "$.loginId";
    }

    public static String getPassword() {
        return "$.password";
    }

    public static String getDeviceType() {
        return "$.deviceType";
    }

    public static String getDeviceName() {
        return "$.deviceInfo.deviceName";
    }

    public static String getDeviceKey() {
        return "$.deviceInfo.deviceKey";
    }

    public String getRegistrationId() {
        return "$.deviceInfo.registrationId";
    }

    public String getImei() {
        return "$.deviceInfo.imei";
    }
    
    public String getImsi() {
        return "$.deviceInfo.imsi";
    }

    public String getSerial() {
        return "$.deviceInfo.serial";
    }

    public String getPlatformType() {
        return "$.deviceInfo.platformType";
    }

    public String getPlatformVersion() {
        return "$.deviceInfo.platformVersion";
    }

    public String getApiLevel() {
        return "$.deviceInfo.apiLevel";
    }

    public String getClientVersion() {
        return "$.deviceInfo.clientVersion";
    }

    public String getBrand() {
        return "$.deviceInfo.brand";
    }

    public String getModel() {
        return "$.deviceInfo.model";
    }

    public String getManufacturer() {
        return "$.deviceInfo.manufacturer";
    }

    public String getProduct() {
        return "$.deviceInfo.product";
    }

    public String getScreenSize() {
        return "$.deviceInfo.screenSize";
    }

    public String getScreenResolution() {
        return "$.deviceInfo.screenResolution";
    }

    public String getScreenDensity() {
        return "$.deviceInfo.screenDensity";
    }

    public String getType() {
        return "$.deviceInfo.type";
    }
}
