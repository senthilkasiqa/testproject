package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.DiscardMergeSuggestionsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;
/**
 * @author Chandrashekhar Singh
 * 
/**
 * @author Chandrashekhar Singh
	4.2.29		Discard Suggestion
	4.2.29.1	[Sequence Diagram for Service]
	4.2.29.2	After get merge summary this API will be called. This API discard the suggestion based on the Dedup ID, that is provided in Merge Summary API response.
 *
 */

public class DiscardMergeSuggestionsBaseScript extends BaseTestScript {
    protected  String discardMergeSuggestionsJSONBody;
    protected static final String apiName="DiscardMergeSuggestions";

    //Constructor of the base class.
   
    
    
    public DiscardMergeSuggestionsBaseScript(){
  		globalApiName=apiName;
  	}
    /**
     * @author Chandrashekhar Singh
     * <p>
     * It loads the default Contact Backup JSON body.
     */

    protected void loadJsonFile(){
        //load json file
		String filePath="/resources/discardMergeSuggestionsTestData/discardMergeSuggestionsApiBody.js";
    	
    	discardMergeSuggestionsJSONBody=loadJsonFile(filePath);
    }

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It will set the value on provided json path
     */
    protected void setJsonBody(String jsonPath, String value) {
        discardMergeSuggestionsJSONBody = setJsonData(jsonPath, value, discardMergeSuggestionsJSONBody);
    }

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It creates the url for API
     */
    protected String getDiscardMergeSuggestionsUrl() {
		String methodName="getDiscardMergeSuggestionsUrl";
		FrameworkLogger.logStep(methodName+" -> Start");
		
		String result=apiUrls.get("baseContactURL") + serverConfig.get("discardMergeSuggestionsUrl");
		
		FrameworkLogger.logStep(methodName+" -> End");
		
        return result;
    }


    /**
     * @return validatable response for Discard Merge Suggestions
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    protected ValidatableResponse triggerPostApiDiscardMergeSuggestions() {
		FrameworkLogger.logStep("triggerPostApiDiscardMergeSuggestions -> Start");
		
		//Get the URL of the API.
		String strApiUrl=getDiscardMergeSuggestionsUrl();

		//Call method to trigger POST API.
    	ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, discardMergeSuggestionsJSONBody);


		FrameworkLogger.logStep("triggerPostApiDiscardMergeSuggestions -> End");

        return response;
    }

    /**
     * @return validatable response for Discard Merge Suggestions
     * @author Chandrashekhar Singh
     * <p>
     * Service method to call DiscardMergeSuggestions API and return the Response
     */
    public static ValidatableResponse triggerDiscardMergeSuggestionsApi(String dedupeGuId) {
		FrameworkLogger.logStep("triggerDiscardMergeSuggestionsApi -> Start");
		
		DiscardMergeSuggestionsBaseScript apiObj=new DiscardMergeSuggestionsBaseScript();
        // Creating header with default values.
		apiObj.createHeader();
		apiObj.loadJsonFile();
		apiObj.setJsonBody(DiscardMergeSuggestionsConstants.getDupidJsonPath(), dedupeGuId);

        FrameworkLogger.logStep("Hitting the Discard Merge Suggestions API");
		//Get the URL of the API.
		String strApiUrl=apiObj.getDiscardMergeSuggestionsUrl();

		//Call method to trigger POST API.
    	ValidatableResponse response=apiObj.triggerPostApi(strApiUrl, apiObj.headerMap, apiObj.discardMergeSuggestionsJSONBody);

		FrameworkLogger.logStep("triggerDiscardMergeSuggestionsApi -> End");

        return response;
    }
    /**
     * @return validatable response for Discard Merge Suggestions
     * @author Chandrashekhar Singh
     * <p>
     * Service method to call for Blank DedupeId and return the Response
     */
    public static ValidatableResponse triggerDiscardMergeSuggestionsApiWithBlankDedupId() {
		FrameworkLogger.logStep("triggerDiscardMergeSuggestionsApiWithBlankDedupId -> Start");
		
		DiscardMergeSuggestionsBaseScript apiObj=new DiscardMergeSuggestionsBaseScript();
        // Creating header with default values.
		apiObj.createHeader();
		apiObj.loadJsonFile();
		apiObj.setJsonBody(DiscardMergeSuggestionsConstants.getDupidJsonPath(), "");

        FrameworkLogger.logStep("Hitting the Discard Merge Suggestions API");
		//Get the URL of the API.
		String strApiUrl=apiObj.getDiscardMergeSuggestionsUrl();

		apiObj.discardMergeSuggestionsJSONBody=apiObj.discardMergeSuggestionsJSONBody.replace("\"\"", "");
		//Call method to trigger POST API.
    	ValidatableResponse response=apiObj.triggerPostApi(strApiUrl, apiObj.headerMap, apiObj.discardMergeSuggestionsJSONBody);

		FrameworkLogger.logStep("triggerDiscardMergeSuggestionsApi -> End");

        return response;
    }
    
}
