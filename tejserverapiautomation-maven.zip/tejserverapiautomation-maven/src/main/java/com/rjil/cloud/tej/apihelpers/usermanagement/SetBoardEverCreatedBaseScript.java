/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.usermanagement;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author User
 *
 */
public class SetBoardEverCreatedBaseScript extends BaseTestScript{

protected static final String apiName = "SetBoardEverCreatedApi";
protected static String SetBoardEverCreatedJsonBody;
	public SetBoardEverCreatedBaseScript(){
		globalApiName=apiName;
	}

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Remove device key from header for this API.
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * 
	 * Method to get user profile pic url
	 * 
	 * URL=http://{envUrl}/security/users
	 * 
	 */
	protected String getSetBoardEverCreatedUrl(String url,String boardEverCreatedValue ) {
		FrameworkLogger.logStep("getSetBoardEverCreatedUrl: Start");
		String getUserProfileUrl = apiUrls.get("baseURL") + serverConfig.get(url).replace("{boardEverCreated}", boardEverCreatedValue);
		FrameworkLogger.logStep("getSetBoardEverCreatedUrl:" + url);
		FrameworkLogger.logStep("getSetBoardEverCreatedUrl: End");
		return getUserProfileUrl;

	}


	/**
	 * Method to get  user profile api Response
	 * 
	 * @return trashMetadata validatable response
	 */
	protected String setPutSetBoardEverCreatedJsonBody() throws IOException{
		FrameworkLogger.logStep("setPostCommentJsonBody: Start");
		// load json file
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/SetBoardEverCreated.js";
		File file = new File(path);
		SetBoardEverCreatedJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setPostCommentJsonBody: End");
		return SetBoardEverCreatedJsonBody;
	}


	protected ValidatableResponse triggerPutApiSetBoardEverCreated(String url,String value, String jsonbody) throws IOException {

		FrameworkLogger.logStep("triggerPostApiSetBoardEverCreated: Start");

		String strApiUrl =getSetBoardEverCreatedUrl(url,value) ;
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, jsonbody);

		FrameworkLogger.logStep("triggerPostApiSetBoardEverCreated: End");

		return response;
	}
	
	
}


