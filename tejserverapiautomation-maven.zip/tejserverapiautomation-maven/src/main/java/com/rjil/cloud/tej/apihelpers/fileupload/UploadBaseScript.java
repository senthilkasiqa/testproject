package com.rjil.cloud.tej.apihelpers.fileupload;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.UploadConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.nms.CreateFolderBaseScript;
import com.rjil.cloud.tej.common.UniqueImageGenerator;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;
import com.rjil.cloud.tej.enums.UploadParameters;
import com.rjil.cloud.tej.utility.CommonUtilityMethods;

import groovy.json.JsonException;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.jayway.restassured.RestAssured.given;

public class UploadBaseScript extends BaseTestScript {

	protected String uploadJSONBody;
	protected String fileName = null;
	protected static final String apiName = "Upload";
	// protected Map<String,String>headerMap = null;
	static String filePath;
	// = System.getProperty("user.dir") + "/resources/uploadTestData/"+fileName;
	static File file;
	// new File(filePath);
	
	
	
	public UploadBaseScript(){
        globalApiName=apiName;
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to get the file name
	 * 
	 */
	protected void getFileName(String fileName) {
		FrameworkLogger.logStep("getFileName: Start");
		// filePath=System.getProperty("user.dir") +
		// "/resources/uploadTestData/download.jpg";
		filePath = System.getProperty("user.dir") + "/resources/uploadTestData/" + fileName;
		file = new File(filePath);
		FrameworkLogger.logStep("getFileName: End");
	}

	/**
	 * @author Prateek 
	 * Method to get Upload URL for Fie upload
	 * @return url
	 */
	protected String getUploadUrl() {

		FrameworkLogger.logStep("getUploadUrl: Start");
		/**
		 * The SIT url for upload is different compared to other environments
		 * So, we need to add this check
		 */
		/*
		 * if(Objects.equals(executionServer, "SIT")) { return
		 * serverConfig.get("uploadURL");
		 * 
		 * }
		 */
//		String uploadUrl = apiUrls.get("uploadIp") + serverConfig.get("uploadUrl");
		String uploadUrl = getUploadUrl("uploadUrl");

		FrameworkLogger.logStep("UploadUrl=========>" + uploadUrl);
		return uploadUrl;

	}
	
	protected String getUploadUrl(String url) {

		FrameworkLogger.logStep("getUploadUrl: Start");
		/**
		 * The SIT url for upload is different compared to other environments
		 * So, we need to add this check
		 */
		/*
		 * if(Objects.equals(executionServer, "SIT")) { return
		 * serverConfig.get("uploadURL");
		 * 
		 * }
		 */
		String uploadUrl = apiUrls.get("uploadIp") + serverConfig.get(url);
		FrameworkLogger.logStep("UploadUrl=========>" + uploadUrl);
		return uploadUrl;

	}

	/*
	 * protected void createHeader(){ FrameworkLogger.logStep(
	 * "createHeader: Start"); headerMap = new HashMap<>();
	 * headerMap.put("Content-Type", "multipart/related;boundary=*****");
	 * headerMap.put(UploadParameters.XUSERID.getValue(), userId);
	 * headerMap.put(UploadParameters.XDEVICEKEY.getValue(),
	 * serverConfig.get("deviceKey"));
	 * headerMap.put(UploadParameters.AUTHORIZATION.getValue(), accessToken);
	 * 
	 * //Add 'X-Api-Key' in header for the API. addXapiHeaderKey(headerMap);
	 * FrameworkLogger.logStep("createHeader: End");
	 * 
	 * }
	 */
	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		headerMap.put("Content-Type", "multipart/related;boundary=*****");

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * Method to set file upload Json Body
	 * 
	 * @throws IOException
	 */
	protected String setUploadJsonBody(String fileName) throws IOException {
		FrameworkLogger.logStep("setUploadJsonBody: Start");
		FrameworkLogger.logStep("FilePATH==============>" + filePath);
		Utils.fileCheckSum(filePath);
	//	String path = System.getProperty("user.dir") + "/resources/uploadTestData/uploadFileBody.js";
	//	String path = System.getProperty("user.dir") + "/resources/uploadTestData/entireFileUploadBody.js";
		String path = System.getProperty("user.dir") + "/resources/uploadTestData/entireFileUploadBody.js";
		
		File file = new File(path);
		uploadJSONBody = JsonPath.parse(file).jsonString();
		uploadJSONBody=setJsonData(UploadConstants.getName(), fileName, uploadJSONBody);
		uploadJSONBody = setJsonData(UploadConstants.getSize(), Utils.getLen(), uploadJSONBody);
		uploadJSONBody = setJsonData(UploadConstants.getHash(), Utils.getOutput(), uploadJSONBody);
		
		if (CreateFolderBaseScript.folderKey != null) {
			uploadJSONBody = JsonPath.parse(uploadJSONBody)
					.put("@", "folderKey", repositoryMap.get(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue()))
					.jsonString();
		}
		
		FrameworkLogger.logStep("setUploadJsonBody:"+uploadJSONBody);
		FrameworkLogger.logStep("setUploadJsonBody: End");
		return uploadJSONBody;
	}
	
	protected String setUploadJsonBody(String fileName,String uploadJsonBody) throws IOException {
		FrameworkLogger.logStep("setUploadJsonBody: Start");
		FrameworkLogger.logStep("FilePATH==============>" + filePath);
		Utils.fileCheckSum(filePath);
	//	String path = System.getProperty("user.dir") + "/resources/uploadTestData/uploadFileBody.js";
	//	String path = System.getProperty("user.dir") + "/resources/uploadTestData/entireFileUploadBody.js";
		String path = System.getProperty("user.dir") + "/resources/uploadTestData/"+uploadJsonBody+"";
		
		File file = new File(path);
		uploadJSONBody = JsonPath.parse(file).jsonString();
		uploadJSONBody=setJsonData(UploadConstants.getName(), fileName, uploadJSONBody);
		uploadJSONBody = setJsonData(UploadConstants.getSize(), Utils.getLen(), uploadJSONBody);
		uploadJSONBody = setJsonData(UploadConstants.getHash(), Utils.getOutput(), uploadJSONBody);
		
		if (CreateFolderBaseScript.folderKey != null) {
			uploadJSONBody = JsonPath.parse(uploadJSONBody)
					.put("@", "folderKey", repositoryMap.get(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue()))
					.jsonString();
		}
		
		FrameworkLogger.logStep("setUploadJsonBody:"+uploadJSONBody);
		FrameworkLogger.logStep("setUploadJsonBody: End");
		return uploadJSONBody;
	}

	/**
	 * Method to get Upload Response
	 *
	 * @return Upload response
	 * @throws VerificationFailException 
	 */
	protected ValidatableResponse getUploadFileResponse() throws IOException, VerificationFailException {

		FrameworkLogger.logStep("getUploadFileResponse: Start");
		FrameworkLogger.logStep("Upload request="+uploadJSONBody);
		//setUploadJsonBody();
		ValidatableResponse response = given().multiPart("metadata", uploadJSONBody, "application/json").multiPart(file)
				.headers(headerMap).log().all().when().post(getUploadUrl()).then();
		response.log().all();
		
		writeRequestResponseInTempLog(getUploadUrl(),headerMap,response,uploadJSONBody, "UploadFile");
		Utils.addRequestResponseToLogger();

		FrameworkLogger.logStep("Setting ObjectKey...");

		/**
		 * This object key derived when a file is uploaded is used in other
		 * tests(Board related). If the file is successfully uploaded, then
		 * valid object key is put into the Repository map and is available for
		 * other tests to retrieve this object key from the respositoryMap If
		 * the file fails to get uploaded, then this object key will have null
		 * value and corresponding tests related to Boards would fail as the
		 * object key used in those tests would be passed as null
		 *    
		 */

		return response;
	}
	
	/**
	 * Method to get Upload Response
	 *
	 * @return Upload response
	 */
	protected ValidatableResponse getUploadFileResponse(String url) throws IOException {

		FrameworkLogger.logStep("getUploadFileResponse: Start");
		//setUploadJsonBody();
		ValidatableResponse response = given().multiPart("metadata", uploadJSONBody, "application/json").multiPart(file)
				.headers(headerMap).log().all().when().post(getUploadUrl(url)).then();
		response.log().all();
		Utils.addRequestResponseToLogger();

		FrameworkLogger.logStep("Setting ObjectKey...");

		/**
		 * This object key derived when a file is uploaded is used in other
		 * tests(Board related). If the file is successfully uploaded, then
		 * valid object key is put into the Repository map and is available for
		 * other tests to retrieve this object key from the respositoryMap If
		 * the file fails to get uploaded, then this object key will have null
		 * value and corresponding tests related to Boards would fail as the
		 * object key used in those tests would be passed as null
		 *
		 */

		String strObjectKey = response.extract().path("objectKey");
		FrameworkLogger.logStep("Upload Object Key========>>" + strObjectKey);
		repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(), strObjectKey);

		Long lastUpdatedDate=response.extract().path("lastUpdatedDate");
		//Long lastUpdatedDate= Long.valueOf(value);
		if (lastUpdatedDate==null){
			FrameworkLogger.logStep("Last Update Date is null");
		}else{
		repositoryMap.put(RepositoryParameterEnum.LASTUPDATEDTIME.getValue(), lastUpdatedDate.toString());
		}
		String documentUrl=response.extract().path("documentUrl");
		repositoryMap.put(RepositoryParameterEnum.DOCUMENTURL.getValue(), documentUrl);
		
		FrameworkLogger.logStep("getUploadFileResponse: End");
		return response;
		//FrameworkLogger.logStep("getUploadFileResponse: End");
		//return response;
	}
	
	
	/**
	 * 
	 * Service Method for Upload File
	 * 
	 * @param fileName
	 * @return 
	 * @throws IOException
	 * @throws VerificationFailException
	 * @throws InterruptedException 
	 */


	public static ValidatableResponse getUploadFileServiceMethod(String fileName) throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("getUploadFileServiceMethod: Start");
		UploadBaseScript apiObject = new UploadBaseScript();
		// fileName="Sample.aac";

		FrameworkLogger.logStep("FileName========>" + fileName);
		apiObject.getFileName(fileName);

		// Create header parameters needed for upload api request
		apiObject.createHeader();
		apiObject.setUploadJsonBody(fileName);
		ValidatableResponse response = apiObject.getUploadFileResponse();
		
		  String strObjectKey = response.extract().path( "objectKey");
		  System.out.println("Upload Object Key========>>"+strObjectKey);
		  repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(),
		  strObjectKey);
		 
		// CommonUtilityMethods.updateInputFile(fileName);
		FrameworkLogger.logStep("getUploadFileServiceMethod: End");
		// int status = response.extract().statusCode();
		// Verify.verifyEquals(status,
		// ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success
		// Status");

		return response;


	}
	// this code is no more in use.
 //	Hence commenting it.
/*	public static void getUploadFileToFolderServiceMethod(String fileName) throws IOException, VerificationFailException, InterruptedException 
	{	
	UploadBaseScript apiObject = new UploadBaseScript();
	apiObject.getFileName(fileName);

	// Create header parameters needed for upload api request
	apiObject.createHeader();
	
	apiObject.setUploadJsonBody(fileName);
	ValidatableResponse response = apiObject.getUploadFileResponse();
	
	}*/
	
	public static ValidatableResponse getUploadFileServiceMethodResponse(String fileName) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getUploadFileServiceMethod: Start");
		UploadBaseScript apiObject = new UploadBaseScript();
		// fileName="Sample.aac";

		FrameworkLogger.logStep("FileName========>" + fileName);
		apiObject.getFileName(fileName);

		// Create header parameters needed for upload api request
		apiObject.createHeader();
		apiObject.setUploadJsonBody(fileName);
		ValidatableResponse response = apiObject.getUploadFileResponse();
		
		  String strObjectKey = response.extract().path( "objectKey");
		  System.out.println("Upload Object Key========>>"+strObjectKey);
		  repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(),
		  strObjectKey);
		 
		// CommonUtilityMethods.updateInputFile(fileName);
		FrameworkLogger.logStep("getUploadFileServiceMethod: End");
		// int status = response.extract().statusCode();
		// Verify.verifyEquals(status,
		// ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success
		// Status");
		
		return response;

	}
	
	
	public static ValidatableResponse getResponseOfUploadFileServiceMethod(String fileName) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getResponseOfUploadFileServiceMethod: Start");
		
		UploadBaseScript apiObject = new UploadBaseScript();
		FrameworkLogger.logStep("FileName========>" + fileName);
		apiObject.getFileName(fileName);

		//Create header parameters needed for upload api request
		apiObject.createHeader();
		apiObject.setUploadJsonBody(fileName);
		ValidatableResponse response = apiObject.getUploadFileResponse();
		int uploadFileResponseCode = response.extract().statusCode();
		Verify.verifyEquals(uploadFileResponseCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Upload File Status");

		FrameworkLogger.logStep("getUploadFileServiceMethod: End");
		String strObjectKey = response.extract().path("objectKey");
		FrameworkLogger.logStep("Upload Object Key========>>" + strObjectKey);
		repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(), strObjectKey);
		return response;

	}
	
	public static ValidatableResponse getResponseOfUploadFileServiceMethod(String fileName, Map<String,String> deviceInfoMap) throws IOException, VerificationFailException, InterruptedException {
		
		FrameworkLogger.logStep("getResponseOfUploadFileServiceMethod: Start");
		UploadBaseScript apiObject = new UploadBaseScript();
		FrameworkLogger.logStep("FileName========>" + fileName);
		apiObject.getFileName(fileName);

		//Create header parameters needed for upload api request
		Map<String,String> headerMap = apiObject.createHeader(deviceInfoMap);
		headerMap.put("Content-Type", "multipart/related;boundary=*****");
		apiObject.setUploadJsonBody(fileName);
		ValidatableResponse response = apiObject.getUploadFileResponse();
		FrameworkLogger.logStep("getUploadFileServiceMethod: End");
		String strObjectKey = response.extract().path("objectKey");
		FrameworkLogger.logStep("Upload Object Key========>>" + strObjectKey);
		repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(), strObjectKey);
		return response;

	}
	
	
	protected String setUploadJsonBodyForBoard(String fileName) throws IOException {
		FrameworkLogger.logStep("setUploadJsonBody: Start");
		FrameworkLogger.logStep("FilePATH==============>" + filePath);
		Utils.fileCheckSum(filePath);
	//	String path = System.getProperty("user.dir") + "/resources/uploadTestData/uploadFileBody.js";
	//	String path = System.getProperty("user.dir") + "/resources/uploadTestData/entireFileUploadBody.js";
		String path = System.getProperty("user.dir") + "/resources/uploadTestData/fileUploadBodyForBoard.js";
		
		File file = new File(path);
		uploadJSONBody = JsonPath.parse(file).jsonString();
		uploadJSONBody=setJsonData(UploadConstants.getName(), fileName, uploadJSONBody);
		uploadJSONBody = setJsonData(UploadConstants.getSize(), Utils.getLen(), uploadJSONBody);
		uploadJSONBody = setJsonData(UploadConstants.getHash(), Utils.getOutput(), uploadJSONBody);
		
		if (CreateFolderBaseScript.folderKey != null) {
			uploadJSONBody = JsonPath.parse(uploadJSONBody)
					.put("@", "folderKey", repositoryMap.get(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue()))
					.jsonString();
		}
		
		FrameworkLogger.logStep("setUploadJsonBody:"+uploadJSONBody);
		FrameworkLogger.logStep("setUploadJsonBody: End");
		return uploadJSONBody;
	}
	
	protected ValidatableResponse getUploadFileResponseForOtherUser(Map<String, String> headerMap) throws IOException, VerificationFailException {

		FrameworkLogger.logStep("getUploadFileResponseForOtherUser: Start");
		FrameworkLogger.logStep("Upload request="+uploadJSONBody);
		UploadBaseScript upload = new UploadBaseScript();
		headerMap= upload.createHeader(headerMap);
		headerMap.put("Content-Type", "multipart/related;boundary=*****");
		//setUploadJsonBody();
		ValidatableResponse response = given().multiPart("metadata", uploadJSONBody, "application/json").multiPart(file)
				.headers(headerMap).log().all().when().post(getUploadUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();

		FrameworkLogger.logStep("Setting ObjectKey...");

		/**
		 * This object key derived when a file is uploaded is used in other
		 * tests(Board related). If the file is successfully uploaded, then
		 * valid object key is put into the Repository map and is available for
		 * other tests to retrieve this object key from the respositoryMap If
		 * the file fails to get uploaded, then this object key will have null
		 * value and corresponding tests related to Boards would fail as the
		 * object key used in those tests would be passed as null
		 *    
		 */
		
	//	String strObjectKey = response.extract().path("objectKey");
	//	FrameworkLogger.logStep("Upload Object Key========>>" + strObjectKey);
	//	repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(), strObjectKey);
	//	Long lastUpdatedDate=response.extract().path("lastUpdatedDate");
		//Long lastUpdatedDate= Long.valueOf(value);
	/*	if(lastUpdatedDate==null){
			FrameworkLogger.logStep("Last update date is null");
		}else{
		repositoryMap.put(RepositoryParameterEnum.LASTUPDATEDTIME.getValue(), lastUpdatedDate.toString());
		}
		FrameworkLogger.logStep("getUploadFileResponse: End");*/
		return response;
	}
	
	public static ValidatableResponse getUploadFileToBoardServiceMethod(String fileName,String boardKey) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getUploadFileToBoardServiceMethod: Start");
		UploadBaseScript apiObject = new UploadBaseScript();
		// fileName="Sample.aac";

		FrameworkLogger.logStep("FileName========>" + fileName);
		apiObject.getFileName(fileName);

		// Create header parameters needed for upload api request
		apiObject.createHeader();
		apiObject.setUploadJsonBodyForBoard(fileName);
		apiObject.uploadJSONBody = setJsonData(UploadConstants.getBoardKey(), boardKey, apiObject.uploadJSONBody);
		apiObject.uploadJSONBody = JsonPath.parse(apiObject.uploadJSONBody).delete(UploadConstants.getFolderKey()).jsonString();
    
		ValidatableResponse response = apiObject.getBoardUploadFileResponse();
		
		  String strObjectKey = response.extract().path( "objectKey");
		  System.out.println("Upload Object Key========>>"+strObjectKey);
		  repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(),
		  strObjectKey);
			FrameworkLogger.logStep("getUploadFileToBoardServiceMethod: End");
		  return response;
		// CommonUtilityMethods.updateInputFile(fileName);
	
		// int status = response.extract().statusCode();
		// Verify.verifyEquals(status,
		// ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success
		// Status");

	}
	
	protected String getBoardUploadUrl(String url) {

		FrameworkLogger.logStep("getUploadUrl: Start");
		/**
		 * The SIT url for upload is different compared to other environments
		 * So, we need to add this check
		 */
		/*
		 * if(Objects.equals(executionServer, "SIT")) { return
		 * serverConfig.get("uploadURL");
		 * 
		 * }
		 */
		String uploadUrl = apiUrls.get("boardUploadUrl") + serverConfig.get(url);
		FrameworkLogger.logStep("UploadUrl=========>" + uploadUrl);
		return uploadUrl;

	}
	
	protected String getBoardUploadUrl() {

		FrameworkLogger.logStep("getBoardUploadUrl: Start");
		
	//	String uploadUrl = getBoardUploadUrl("boardUploadUrl")+serverConfig.get("uploadUrl");
		String uploadUrl = apiUrls.get("boardUploadUrl") + serverConfig.get("uploadUrl");
		FrameworkLogger.logStep("getBoardUploadUrl=========>" + uploadUrl);
		return uploadUrl;

	}
	
	protected ValidatableResponse getBoardUploadFileResponse() throws IOException, VerificationFailException {

		FrameworkLogger.logStep("getUploadFileResponse: Start");
		FrameworkLogger.logStep("Upload request="+uploadJSONBody);
		//setUploadJsonBody();
		ValidatableResponse response = given().multiPart("metadata", uploadJSONBody, "application/json").multiPart(file)
				.headers(headerMap).log().all().when().post(getBoardUploadUrl()).then();
		response.log().all();
		writeRequestResponseInTempLog(getUploadUrl(),headerMap,response,uploadJSONBody, "UploadFileToBoard");
		Utils.addRequestResponseToLogger();

		FrameworkLogger.logStep("Setting ObjectKey...");

		/**
		 * This object key derived when a file is uploaded is used in other
		 * tests(Board related). If the file is successfully uploaded, then
		 * valid object key is put into the Repository map and is available for
		 * other tests to retrieve this object key from the respositoryMap If
		 * the file fails to get uploaded, then this object key will have null
		 * value and corresponding tests related to Boards would fail as the
		 * object key used in those tests would be passed as null
		 *    
		 */

		return response;
	}
	
	protected ValidatableResponse getBoardUploadFileResponseForOtherUser(Map<String, String> headerMap) throws IOException, VerificationFailException {

		FrameworkLogger.logStep("getUploadFileResponseForOtherUser: Start");
		FrameworkLogger.logStep("Upload request="+uploadJSONBody);
		UploadBaseScript upload = new UploadBaseScript();
		headerMap= upload.createHeader(headerMap);
		headerMap.put("Content-Type", "multipart/related;boundary=*****");
		//setUploadJsonBody();
		ValidatableResponse response = given().multiPart("metadata", uploadJSONBody, "application/json").multiPart(file)
				.headers(headerMap).log().all().when().post(getBoardUploadUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();

		FrameworkLogger.logStep("Setting ObjectKey...");

		/**
		 * This object key derived when a file is uploaded is used in other
		 * tests(Board related). If the file is successfully uploaded, then
		 * valid object key is put into the Repository map and is available for
		 * other tests to retrieve this object key from the respositoryMap If
		 * the file fails to get uploaded, then this object key will have null
		 * value and corresponding tests related to Boards would fail as the
		 * object key used in those tests would be passed as null
		 *    
		 */
	//	String strObjectKey = response.extract().path("objectKey");
	//	FrameworkLogger.logStep("Upload Object Key========>>" + strObjectKey);
	//	repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(), strObjectKey);
	//	Long lastUpdatedDate=response.extract().path("lastUpdatedDate");
		//Long lastUpdatedDate= Long.valueOf(value);
	/*	if(lastUpdatedDate==null){
			FrameworkLogger.logStep("Last update date is null");
		}else{
		repositoryMap.put(RepositoryParameterEnum.LASTUPDATEDTIME.getValue(), lastUpdatedDate.toString());
		}
		FrameworkLogger.logStep("getUploadFileResponse: End");*/
		return response;
	}
	


	public static ValidatableResponse getUploadFileToBoardServiceMethodForBoardCoverPic(String fileName,String boardKey, boolean boardCoverPic) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getUploadFileToBoardServiceMethod: Start");
		UploadBaseScript apiObject = new UploadBaseScript();
		// fileName="Sample.aac";

		FrameworkLogger.logStep("FileName========>" + fileName);
		apiObject.getFileName(fileName);

		// Create header parameters needed for upload api request
		apiObject.createHeader();
		apiObject.setUploadJsonBodyForBoard(fileName);
		apiObject.uploadJSONBody = setJsonData(UploadConstants.getBoardKey(), boardKey, apiObject.uploadJSONBody);
		apiObject.uploadJSONBody = setJsonData(UploadConstants.getBoardCoverPic(), boardCoverPic, apiObject.uploadJSONBody);
		apiObject.uploadJSONBody = JsonPath.parse(apiObject.uploadJSONBody).delete(UploadConstants.getFolderKey()).jsonString();
    
		ValidatableResponse response = apiObject.getBoardUploadFileResponse();
		
		  String strObjectKey = response.extract().path( "objectKey");
		  System.out.println("Upload Object Key========>>"+strObjectKey);
		  repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(),
		  strObjectKey);
			FrameworkLogger.logStep("getUploadFileToBoardServiceMethod: End");
		  return response;
		// CommonUtilityMethods.updateInputFile(fileName);
	
		// int status = response.extract().statusCode();
		// Verify.verifyEquals(status,
		// ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success
		// Status");

	}
	
	protected String setUploadJsonBodyForTest(String fileName, String fileCreatedDate) throws IOException {
		FrameworkLogger.logStep("setUploadJsonBodyForTest: Start");
		FrameworkLogger.logStep("FilePATH==============>" + filePath);
		Utils.fileCheckSum(filePath);
	//	String path = System.getProperty("user.dir") + "/resources/uploadTestData/uploadFileBody.js";
	//	String path = System.getProperty("user.dir") + "/resources/uploadTestData/entireFileUploadBody.js";
		String path = System.getProperty("user.dir") + "/resources/uploadTestData/entireFileUploadBody.js";
		
		File file = new File(path);
		uploadJSONBody = JsonPath.parse(file).jsonString();
		uploadJSONBody=setJsonData(UploadConstants.getName(), fileName, uploadJSONBody);
		uploadJSONBody = setJsonData(UploadConstants.getSize(), Utils.getLen(), uploadJSONBody);
		uploadJSONBody = setJsonData(UploadConstants.getHash(), Utils.getOutput(), uploadJSONBody);
		uploadJSONBody = setJsonData(UploadConstants.getHash(), Utils.getOutput(), uploadJSONBody);
		uploadJSONBody = setJsonData(UploadConstants.getFileCreatedDate(), fileCreatedDate, uploadJSONBody);
		
		FrameworkLogger.logStep("setUploadJsonBody:"+uploadJSONBody);
		FrameworkLogger.logStep("setUploadJsonBodyForTest: End");
		return uploadJSONBody;
	}
	
	
	protected ValidatableResponse getUploadFileResponseTest(String uploadJSONBodyTest) throws IOException, VerificationFailException {

		FrameworkLogger.logStep("getUploadFileResponse: Start");
		FrameworkLogger.logStep("Upload request="+uploadJSONBodyTest);
		//setUploadJsonBody();
		ValidatableResponse response = given().multiPart("metadata", uploadJSONBodyTest, "application/json").multiPart(file)
				.headers(headerMap).log().all().when().post(getUploadUrl()).then();
		FrameworkLogger.logStep("Setting ObjectKey...");

		
		return response;
	}

       public static ValidatableResponse uploadFileTestServiceMethod(String fileName, String fileCreatedDate) throws IOException, VerificationFailException, InterruptedException {
		
		FrameworkLogger.logStep("getResponseOfUploadFileServiceMethod: Start");
		
		UploadBaseScript apiObject = new UploadBaseScript();
		
		FrameworkLogger.logStep("FileName========>>>>>>>>>>" + fileName);
		
		apiObject.getFileNameTest(fileName+".jpg");
		Map<String,String> headerMap = apiObject.createHeader();
		headerMap.put("Content-Type", "multipart/related;boundary=*****");
		String uploadJSONBodyTest = apiObject.setUploadJsonBodyForTest(fileName+".jpg", fileCreatedDate);
		ValidatableResponse response = apiObject.getUploadFileResponseTest(uploadJSONBodyTest);
		response.log().all();
		FrameworkLogger.logStep("getUploadFileServiceMethod: End");
		FrameworkLogger.logStep("Fileupload response=="+response.toString());
		return response;

	}
       protected void getFileNameTest(String fileName) {
   		FrameworkLogger.logStep("getFileName: Start");
   		// filePath=System.getProperty("user.dir") +
   		// "/resources/uploadTestData/download.jpg";
   		filePath = System.getProperty("user.dir") + "/resources/SuggestedBoardsTestData/" + fileName;
   		file = new File(filePath);
   		FrameworkLogger.logStep("getFileName: End");
   	}
       
       
       
       public static void uploadMultipleFilesServiceMethod(int noOfFiles, List<String>fileCreatedDate) throws Exception
       {
    	 
    	 
    	   for (int i = 0; i < noOfFiles; i++) 
   	 	{
    		   System.out.println("FILE DATE=====>>>>>>>>>>>>>>>"+fileCreatedDate.get(i));
    		//String fileName = "TestImage-Test" + i +System.currentTimeMillis()+ "-";
    		   DateFormat dateFormat = new SimpleDateFormat("ddMMM-yyyy-HHmmssSS-EEE");
    		   long fileDate = Long.parseLong(fileCreatedDate.get(i));
    		   Date dateString = new Date(fileDate);
       		String fileName = dateFormat.format(dateString);
       		System.out.println("************fileName****: " + fileName);
   			UniqueImageGenerator.generate(fileName, i);
   		 System.out.println("Now calling uploadFile test service method=============="+fileCreatedDate.get(i));
   		    UploadBaseScript.uploadFileTestServiceMethod(fileName, fileCreatedDate.get(i));
    	
   		}
    	  
       }
       
       
       public static String getFileCreatedTime(int day, int hours)
       {
    	  /*long currentTime = System.currentTimeMillis();
    	  System.out.println("CURRENT TIME ========"+currentTime);
    	  System.out.println("NO OF DAYS==========="+day);
    	  System.out.println("NO OF HOURS==========="+hours);
    	  long fileCreatedDate_temp = ((currentTime)-((day*24*3600000)+(hours*3600000)));
    	  System.out.println("FINAL TIME==========="+fileCreatedDate_temp);
    	  String fileCreatedDate = fileCreatedDate_temp+"";
    	  System.out.println("FINALEST TIME==========="+fileCreatedDate);
       	 return fileCreatedDate;*/
    	   
    	   long currentTime = System.currentTimeMillis();

    	   
      	  System.out.println("CURRENT TIME ========"+currentTime);
      	 long fileCreatedDate_temp_day = (day*24*3600000);
      	 long fileCreatedDate_temp_hour = (hours*3600000);
      	 System.out.println("fileCreatedDate_temp_day========"+fileCreatedDate_temp_day);
      	 System.out.println("fileCreatedDate_temp_hour ========"+fileCreatedDate_temp_hour);
      	 long addition = fileCreatedDate_temp_day + fileCreatedDate_temp_hour;
      	System.out.println("addition ========"+addition);
      	long finalValue = currentTime - addition;
      	
      	 System.out.println("final time ========"+finalValue);
      	return finalValue+"";
    	   
       }
       
       
       public static String getFileCreatedTimeAsPerUser(String fileCreatedDate) throws ParseException
       {
    	
    	 //  String someDate = "14.08.2017 11:09:30";
    	/*   SimpleDateFormat sdf = new SimpleDateFormat("MM.dd.yyyy HH:mm");
    	   Date date = sdf.parse(someDate);
    	   System.out.println("Date final date============="+date.getTime());
    	   */
    	   
    	/* long currentTime = System.currentTimeMillis();
      	 System.out.println("CURRENT TIME ========"+currentTime);
      	 long fileCreatedDate_temp_day = (day*24*3600000);
      	 long fileCreatedDate_temp_hour = (hours*3600000);
      	 System.out.println("fileCreatedDate_temp_day========"+fileCreatedDate_temp_day);
      	 System.out.println("fileCreatedDate_temp_hour ========"+fileCreatedDate_temp_hour);
      	 long addition = fileCreatedDate_temp_day + fileCreatedDate_temp_hour;
      	System.out.println("addition ========"+addition);
      	long finalValue = currentTime - addition;
      	
      	 System.out.println("final time ========"+finalValue);
      	return finalValue+"";*/
    	   SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss"); // Month.Day.Year

    	   Date d = formatter.parse(fileCreatedDate);
    	   long timestamp = d.getTime();
    	   System.out.println("Date final date============="+timestamp);
		return timestamp+"";
    	   
       }
       
       
       public static void main(String[] args) throws ParseException {
    	   getFileCreatedTimeAsPerUser("14.08.2017 11:09:30");
    	   
	}
     
	
}
