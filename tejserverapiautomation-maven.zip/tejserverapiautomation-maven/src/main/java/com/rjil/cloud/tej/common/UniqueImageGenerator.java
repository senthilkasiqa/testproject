package com.rjil.cloud.tej.common;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.plugins.jpeg.JPEGImageWriteParam;
import javax.imageio.stream.ImageOutputStream;

public class UniqueImageGenerator {

	/*
	 * Creates a randomly generated two color JPEG and writes it to a file
	 *
	 * 
	 * 
	 */

	public static String generate(String prefix, int fileCount) throws Exception {

		Random random = new Random(56743793);

		int x, y = 0;

		// image block size in pixels, 1 is 1px, use smaller values for

		// greater granularity

		//int PIX_SIZE = 6;
		int PIX_SIZE = RandomNumberGenerator.getRandomNumber();
		int modSize = RandomNumberGenerator.getRandomNumberSmall();

		// image size in pixel blocks
		int X, Y=100;
		int imageSize = RandomNumberGenerator.getRandomNumber2();
		X = imageSize;
		Y = imageSize;
		BufferedImage bi = new BufferedImage(PIX_SIZE * X, PIX_SIZE * Y,

				BufferedImage.TYPE_INT_RGB);

		Graphics2D g = (Graphics2D) bi.getGraphics();
		
		int randomColor = RandomNumberGenerator.getRandomNumber3();

		String filename = prefix + ".jpg";
		int randomColor1 = RandomNumberGenerator.getRandomNumber3();
		int randomColor2 = RandomNumberGenerator.getRandomNumber3();
		int randomColor3 = RandomNumberGenerator.getRandomNumber3();
		int randomColor4 = RandomNumberGenerator.getRandomNumber3();
		for (int i = 0; i < X; i++) {

			for (int j = 0; j < Y; j++) {

				x = i * PIX_SIZE;

				y = j * PIX_SIZE;

				// this is a writing condition, my choice here is purely random

				// just to generate some pattern

				// this condition

				if ((i * j) % modSize == 0) {
					
					g.setColor(setRandomColour(randomColor1));

				} else if ((i + j) % (modSize + 3) == 0) {
					

					g.setColor(setRandomColour(randomColor2));

				} else if ((i + j) % (modSize + 1) == 0) {
					

					g.setColor(setRandomColour(randomColor3));

				} else{
					
					g.setColor(setRandomColour(randomColor4));
					// end else
				}

				// fil the rectangles with the pixel blocks in chosen color
				g.setBackground(Color.WHITE);
				
				g.fillRect(y, x, PIX_SIZE, PIX_SIZE);
				

			} // end for j

		} // end for i

		g.dispose();

		saveToFile(bi, new File(System.getProperty("user.dir") + "/resources/SuggestedBoardsTestData/" + filename));

		return filename;

	}// end method

	/**
	 * Saves jpeg to file
	 * @return 
	 *
	 * 
	 * 
	 */
	
	public static Color setRandomColour(int randomNo)
	{
		Color color = null;
		if(randomNo==1)
		{
			color = Color.WHITE;
		}
		
		if(randomNo==2)
		{
			color = Color.GREEN;
		}
		
		if(randomNo==3)
		{
			color = Color.PINK;
		}
		
		if(randomNo==4)
		{
			color = Color.ORANGE;
		}
		
		if(randomNo==5)
		{
			color = Color.BLUE;
		}
		if(randomNo==6)
		{
			color = Color.RED;
		}
		
		if(randomNo==7)
		{
			color = Color.RED;
		}
		
		if(randomNo==8)
		{
			color = Color.CYAN;
		}
		
		if(randomNo==9)
		{
			color = Color.YELLOW;
		}
		
		if(randomNo==10)
		{
			color = Color.YELLOW;
		}
		
		return color;
		
	}

	public static void saveToFile(BufferedImage img, File file) throws IOException {

		ImageWriter writer = null;

		java.util.Iterator iter = ImageIO.getImageWritersByFormatName("jpg");

		if (iter.hasNext()) {

			writer = (ImageWriter) iter.next();

		}

		ImageOutputStream ios = ImageIO.createImageOutputStream(file);

		writer.setOutput(ios);

		ImageWriteParam param = new JPEGImageWriteParam(java.util.Locale.getDefault());

		param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);

		param.setCompressionQuality(0.98f);

		writer.write(null, new IIOImage(img, null, null), param);

	}// end method

	
	
}
