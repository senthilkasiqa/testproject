package com.rjil.cloud.tej.common;




import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.NetworkMode;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

import org.testng.*;
import org.testng.annotations.Test;
import org.testng.xml.XmlSuite;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.testng.IMethodInstance;
import org.testng.IMethodInterceptor;
import org.testng.IReporter;
import org.testng.IResultMap;
import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import org.testng.ITestResult;

/**
 * Created by bharat on 09/08/16.
 * This is a generic class derived from another project that is used for Extent based reporting.
 * More details about Extent Reporting can be found here - http://extentreports.relevantcodes.com/java/#javadoc
 */

public class ExtentReporterNG implements IReporter, IMethodInterceptor {
    ExtentReports extent;
    //private String reportFileName = "DefaultReportName.html";

    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {
       
    	Date date = new Date() ;
    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss") ;
    	extent = new ExtentReports(outputDirectory + File.separator + "JioCloudApiReportExtent"+dateFormat.format(date)+".html", NetworkMode.ONLINE);
    	extent.loadConfig(new File("./resources/extent-config.xml"));
        for (ISuite suite : suites) {
            Map<String, ISuiteResult> result = suite.getResults();

            for (ISuiteResult r : result.values()) {
                ITestContext context = r.getTestContext();


                buildTestNodes(context.getPassedTests(), LogStatus.PASS );
                buildTestNodes(context.getFailedTests(), LogStatus.FAIL);
                buildTestNodes(context.getSkippedTests(), LogStatus.SKIP);
            }
        }

        extent.flush();
        extent.close();
    }

    private void buildTestNodes(IResultMap tests, LogStatus status) {
        ExtentTest test;

        if (tests.size() > 0) {

            for (ITestResult result : tests.getAllResults()) {

                // commented below lines to print the result as per the management requirement

                //	test = extent.startTest(result.getMethod().getMethodName(), result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(Test.class)
                //          .description());

                String newLine = System.getProperty("line.separator");
                test = extent.startTest(result.getMethod().getConstructorOrMethod().getMethod().getAnnotation(Test.class)
                        .description());

                //FrameworkLogger.logStep(test.toString());
               // System.out.println(test);

                test.setStartedTime(getTime(result.getStartMillis()));
                test.setEndedTime(getTime(result.getEndMillis()));

                for (String group : result.getMethod().getGroups())
                    test.assignCategory(group);

                if (result.getThrowable() != null) {
                    test.log(status, result.getThrowable()+ "**Hi**");
                } else {
                    test.log(status, "Test " + status.toString().toLowerCase() + "ed");

                }

                extent.endTest(test);
            }
        }
    }

    private Date getTime(long millis) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        return calendar.getTime();
    }

    public List<IMethodInstance> intercept(List<IMethodInstance> methods, ITestContext context) {
        int methCount = methods.size();

        for (int i = 0; i < methCount; i++)
        {
            IMethodInstance instns = methods.get(i);
       // log.info(instns.getMethod().getConstructorOrMethod().getMethod().getAnnotation(Test.class)
        //            .description());
        }

        return methods;
    }

}

