package com.rjil.cloud.mailchamp.common.helper;


public class CompleteOperationBaseClass extends MailChampBaseTestScript {

/*	protected Map<String, String> createHeaderMap() {
		System.out.println("create Header from SummaryBaseClass");

		Map<String, String> headerMap = initializeHeaderMap(getValueFromEnvConfig("userEmail"));
		return headerMap;

	}
*/
	protected String getCompleteOperationUrl() {
		String baseUrl = getValueFromEnvConfig("baseURL");
		String subUrl = getValueFromProjectConfig("completeOperationURL");	
		return baseUrl + subUrl;
		}
}
