package com.rjil.cloud.tej.apiconstants;

/**
 * Contact Backup API, JSON path Constants
 * 
 */

public class ContactBackupConstants {

    public static String getActTranIdJsonPath() {
        return "$.actTranId";
    }

    public static String getHasMoreJsonPath() {
        return "$.hasMore";
    }
    
    public static String getFirstFldHashJsonPath() {
        return "$.contacts[0].fldHash";
    }
    
    public static String getSecondFldHashJsonPath() {
        return "$.contacts[1].fldHash";
    }
    
    public static String getThirdFldHashJsonPath() {
        return "$.contacts[2].fldHash";
    }
    
    public static String getFirstVcHashJsonPath() {
        return "$.contacts[0].vcHash";
    }
    
    public static String getSecondVcHashJsonPath() {
        return "$.contacts[1].vcHash";
    }
    
    public static String getThirdVcHashJsonPath() {
        return "$.contacts[2].vcHash";
    }

    public static String getIsFirstTimeJsonPath() {
        return "$.isFirstTime";
    }

    public static String getTotalRecordsJsonPath() {
        return "$.totalRecords";
    }

    public static String getContactJsonPath() {
        return "$.contacts";
    }

    public static String getFirstContactJsonPath() {
        return "$.contacts[0]";
    }

    public static String getFirstContactDguidJsonPath() {
        return "$.contacts[0].dguid";
    }

    public static String getFirstContactSerGuidJsonPath() {
        return "$.contacts[0].serGuid";
    }
    public static String getSecondContactSerGuidJsonPath() {
        return "$.contacts[1].serGuid";
    }
    public static String  getThirdContactSerGuidJsonPath()
    {
    	 return "$.contacts[2].serGuid";
    	
    }
    public static String getFirstContactOperationJsonPath() {
        return "$.contacts[0].operation";
    }

    public static String getFirstContactConSrcTypeJsonPath() {
        return "$.contacts[0].conSrcType";
    }

    public static String getFirstContactConSrcNameJsonPath() {
        return "$.contacts[0].conSrcName";
    }

    public static String getFirstContactVcardJsonPath() {
        return "$.contacts[0].vcard";
    }
    
    public static String getSecondContactVcardJsonPath() {
        return "$.contacts[1].vcard";
    }
    
    public static String getThirdContactVcardJsonPath() {
        return "$.contacts[2].vcard";
    }
    
    public static String getDguidJsonPath() {
        return "$.contacts[0].dguid";
    }
    
    public static String getSecondContactDguidJsonPath() {
        return "$.contacts[1].dguid";
    }
    public static String getThirdContactDguidJsonPath()
    {
    	return "$.contacts[2].dguid";
    }
    public static String getFirstVersionNoJsonPath() {
        return "$.contacts[0].versionNo";
    }
    
    public static String getSecondVersionNoJsonPath() {
        return "$.contacts[1].versionNo";
    }

    public static String getFirstImageHashJsonPath() {
        return "$.contacts[0].imgHash";
    }
    
    public static String getSecondImageHashJsonPath() {
        return "$.contacts[1].imgHash";
    }
    
    public static String getFirstImageBinaryJsonPath() {
        return "$.contacts[0].imgbinary";
    }
    
    public static String getSecondImageBinaryJsonPath() {
        return "$.contacts[1].imgbinary";
    }
    
    
    public static String getFourthContactVcardJsonPath() {
        return "$.contacts[3].vcard";
    }
    
    public static String getFourthVcHashJsonPath() {
        return "$.contacts[3].vcHash";
    }
    public static String getFourthFldHashJsonPath() {
        return "$.contacts[3].fldHash";
    }
    
    
    public static String getFifthContactVcardJsonPath() {
        return "$.contacts[4].vcard";
    }
    
    public static String getFifthVcHashJsonPath() {
        return "$.contacts[4].vcHash";
    }
    public static String getFifthFldHashJsonPath() {
        return "$.contacts[4].fldHash";
    }
    
    
    public static String getSixthContactVcardJsonPath() {
        return "$.contacts[5].vcard";
    }
    
    public static String getSixthVcHashJsonPath() {
        return "$.contacts[5].vcHash";
    }
    public static String getSixthFldHashJsonPath() {
        return "$.contacts[5].fldHash";
    }
    
    public static String getSeventhContactVcardJsonPath() {
        return "$.contacts[6].vcard";
    }
    
    public static String getSeventhVcHashJsonPath() {
        return "$.contacts[6].vcHash";
    }
    public static String getSeventhFldHashJsonPath() {
        return "$.contacts[6].fldHash";
    }
    
    public static String getEighthContactVcardJsonPath() {
        return "$.contacts[7].vcard";
    }
    
    public static String getEighthVcHashJsonPath() {
        return "$.contacts[7].vcHash";
    }
    public static String getEighthFldHashJsonPath() {
        return "$.contacts[7].fldHash";
    }
    
    public static String getNinethContactVcardJsonPath() {
        return "$.contacts[8].vcard";
    }
    
    public static String getNinethVcHashJsonPath() {
        return "$.contacts[8].vcHash";
    }
    public static String getNinethFldHashJsonPath() {
        return "$.contacts[8].fldHash";
    }
    
    public static String getTenthContactVcardJsonPath() {
        return "$.contacts[9].vcard";
    }
    
    public static String getTenthVcHashJsonPath() {
        return "$.contacts[9].vcHash";
    }
    public static String getTenthFldHashJsonPath() {
        return "$.contacts[9].fldHash";
    }
    
    public static String getEleventhContactVcardJsonPath() {
        return "$.contacts[10].vcard";
    }
    
    public static String getEleventhVcHashJsonPath() {
        return "$.contacts[10].vcHash";
    }
    public static String getEleventhFldHashJsonPath() {
        return "$.contacts[10].fldHash";
    }
    
    public static String getThirdImageHashJsonPath() {
        return "$.contacts[2].imgHash";
    }
    
    public static String getThirdImageBinaryJsonPath() {
        return "$.contacts[2].imgbinary";
    }
    
    public static String  getFourthContactSerGuidJsonPath()
    {
    	 return "$.contacts[3].serGuid";
    }
    
    public static String getFourthImageHashJsonPath() {
        return "$.contacts[3].imgHash";
    }
    
    public static String getFourthImageBinaryJsonPath() {
        return "$.contacts[3].imgbinary";
    }
    
    public static String getFifthContactSerGuidJsonPath()
    {
    	 return "$.contacts[4].serGuid";
    }
    
    public static String getFifthImageHashJsonPath() {
        return "$.contacts[4].imgHash";
    }
    
    public static String getFifththImageBinaryJsonPath() {
        return "$.contacts[4].imgbinary";
    }
    
    public static String getSixthContactSerGuidJsonPath()
    {
    	 return "$.contacts[5].serGuid";
    }
    
    public static String getSixthImageHashJsonPath() {
        return "$.contacts[5].imgHash";
    }
    
    public static String getSixthImageBinaryJsonPath() {
        return "$.contacts[5].imgbinary";
    }
    
    public static String getSeventhContactSerGuidJsonPath()
    {
    	 return "$.contacts[6].serGuid";
    }
    
    public static String getSeventhImageHashJsonPath() {
        return "$.contacts[6].imgHash";
    }
    
    public static String getSeventhImageBinaryJsonPath() {
        return "$.contacts[6].imgbinary";
    }
    
    public static String getEighthContactSerGuidJsonPath()
    {
    	 return "$.contacts[7].serGuid";
    }
    
    public static String getEighthImageHashJsonPath() {
        return "$.contacts[7].imgHash";
    }
    
    public static String getEighthImageBinaryJsonPath() {
        return "$.contacts[7].imgbinary";
    }
    
    public static String getNinethContactSerGuidJsonPath()
    {
    	 return "$.contacts[8].serGuid";
    }
    
    public static String getNinethImageHashJsonPath() {
        return "$.contacts[8].imgHash";
    }
    
    public static String getNinethImageBinaryJsonPath() {
        return "$.contacts[8].imgbinary";
    }
     
    public static String getTenthContactSerGuidJsonPath()
    {
    	 return "$.contacts[9].serGuid";
    }
    
    public static String getTenthImageHashJsonPath() {
        return "$.contacts[9].imgHash";
    }
    
    public static String getTenthImageBinaryJsonPath() {
        return "$.contacts[9].imgbinary";
    }
    
    public static String getEleventhContactSerGuidJsonPath()
    {
    	 return "$.contacts[10].serGuid";
    }
    
    public static String getEleventhImageHashJsonPath() {
        return "$.contacts[10].imgHash";
    }
    
    public static String getEleventhImageBinaryJsonPath() {
        return "$.contacts[10].imgbinary";
    }
    
    public static String getFirstNameJsonPath() {
        return "$.contacts[0].fpvcard[0].name[0]";
    }

    public static String getFamilyNameJsonPath() {
        return "$.contacts[0].fpvcard[0].familyName[0]";
    }
    
    public static String getFeaturePhoneOperationJsonPath() {
        return "$.contacts[0].operation";
    }
    
    public static String getFeaturePhoneConSrcTypeJsonPath() {
        return "$.contacts[0].conSrcType";
    }
    
    public static String getFeaturePhoneConSrcNameJsonPath() {
        return "$.contacts[0].conSrcName";
    }
    
    public static String getFeaturePhoneTelephoneJsonPath() {
        return "$.contacts[0].fpvcard[0].tel[0].value";
    }
    
    public static String getFeaturePhoneEmailJsonPath() {
        return "$.contacts[0].fpvcard[0].email[0].value";
    }
    
    public static String getFeaturePhoneSerGuidJsonPath() {
        return "$.contacts[0].serGuid";
    }
    
    public static String getFeaturePhoneVersionNoJsonPath() {
        return "$.contacts[0].versionNo";
    }
    
    public static String getFeaturePhoneIdJsonPath() {

        return "$.contacts[0].fpvcard[0].id";
    }
    
}
