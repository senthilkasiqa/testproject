/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boardinvites;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

/**
 * @author Prateek
 *
 */
public class GetMembersOfBoardBaseScript extends BaseTestScript {

	protected static final String apiName = "GetMembersOfBoard";

	protected GetMembersOfBoardBaseScript() {
		globalApiName = apiName;
	}

	protected String getBoardMembersUrl(String url, String boardKey) {
		FrameworkLogger.logStep(" getBoardMembersUrl:-> Start");
		String apiUrl = apiUrls.get("boardInviteUrl") + serverConfig.get(url).replace("{boardKey}", boardKey);
		return apiUrl;
	}

	protected ValidatableResponse triggerGetApiGetBoardMembers(String url, String boardKey) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetBoardMembers:-> Start");
		String strApiUrl = getBoardMembersUrl(url, boardKey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetBoardMembers:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetApiGetBoardMembers(String boardKey) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetBoardMembers:-> Start");
		String strApiUrl = getBoardMembersUrl("getBoardMembersUrl", boardKey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetBoardMembers:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetApiGetBoardMembers(String boardKey, Map<String, String> headerMap1)
			throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetBoardMembers:-> Start");
		String strApiUrl = getBoardMembersUrl("getBoardMembersUrl", boardKey);
		Map<String, String> headerMap = createHeader(headerMap1);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetBoardMembers:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetApiGetBoardMembers(String url, String boardKey, String userId)
			throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetBoardMembers:-> Start");
		String strApiUrl = getBoardMembersUrl(url, boardKey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		getUserIdPresentInBoardMemberResponse(response, userId);
		FrameworkLogger.logStep("triggerGetApiGetBoardMembers:-> End");
		return response;
	}

	public static ValidatableResponse getGetBoardMemberService(String boardKey) {
		GetMembersOfBoardBaseScript boardMembers = new GetMembersOfBoardBaseScript();
		boardMembers.createHeader();
		String strApiUrl = boardMembers.getBoardMembersUrl("getBoardMembersUrl", boardKey);
		ValidatableResponse response = boardMembers.triggerGetApi(strApiUrl, boardMembers.headerMap);
		return response;
	}

	protected int getUserIdPresentInBoardMemberResponse(ValidatableResponse response, String userId)
			throws IOException {
		FrameworkLogger.logStep("getUserIdPresentInBoardMemberResponse:-> start; strObjectKeyValue:-> " + userId);
		int isObjectKeyMatchingIndex = -1;

		int sizeOfBoardMemberArray = response.extract().jsonPath().getList("boardMembers").size();
		FrameworkLogger.logStep("sizeOfBoardMemberArray:-> " + sizeOfBoardMemberArray);
		for (int i = 0; i < sizeOfBoardMemberArray; i++) {
			String actualUserIdValue = response.extract().path("boardMembers[" + i + "].userId");

			FrameworkLogger.logStep(
					"Comparing strObjectKeyValue:-> " + userId + " With actualObjectKeyValue:-> " + actualUserIdValue);

			if (userId.equalsIgnoreCase(actualUserIdValue)) {
				isObjectKeyMatchingIndex = i;
				FrameworkLogger.logStep("UserId matched.");
				break;
			} else {
				FrameworkLogger.logStep("UserId not matched.");
			}
		}
		FrameworkLogger.logStep("getUserIdPresentInBoardMemberResponse:-> end");
		return isObjectKeyMatchingIndex;

	}

	public static List<String> getListKeyValuesFromGetMembersOfBoardResponse(ValidatableResponse response, String key) {
		List<String> valueFromResponse = new ArrayList<String>();
		for (int i = 0; i < response.extract().jsonPath().getList("boardMembers").size(); i++) {
			String indexValue = (String) response.extract().jsonPath().get("boardMembers[" + i + "]." + key);
			valueFromResponse.add(indexValue);
		}
		return valueFromResponse;
	}


}
