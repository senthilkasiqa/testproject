package com.rjil.cloud.tej.apihelpers.usermanagement;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.AfterMethod;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.LogoutUserConstants;
import com.rjil.cloud.tej.apiconstants.UserManagementConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class LogoutAuserBaseScript extends BaseTestScript {
	
	protected static String logoutJSONBody;
	protected static final String apiName="Logout";
	protected static boolean loggedIn=true;
	
//    protected static Map<String, String> headerMap = null;
	
	public LogoutAuserBaseScript(){
		globalApiName=apiName;
	}
    
    public void defaultLogin() throws IOException {
    	//Empty body login.
    }

	/**
	 * Method to get logout api url
	 * 
	 * @return
	 */
//	protected static String getLogoutUrl() {
	protected String getLogoutUrl() {
		FrameworkLogger.logStep("getLogoutUrl -> End");

		String result=apiUrls.get("baseURL") + serverConfig.get("logOutUserUrl");

		FrameworkLogger.logStep("getLogoutUrl -> End");
		
		return result;
}
	

//    protected static void createHeader(String strUserId, String strDeviceKey, String strAccessToken) {
    protected void createHeader(String strUserId, String strDeviceKey, String strAccessToken) {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap=new HashMap<>();
        headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
        headerMap.put(HeaderParameters.XUSERID.getValue(), strUserId);
        headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), strDeviceKey);
        headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), strAccessToken);
        headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");

        //Add 'X-Api-Key' in header for the API.
        String withXapiKey=apiUrls.get("withXapiKey");
		FrameworkLogger.logStep("withXapiKey:-> " + withXapiKey);

		if(withXapiKey.equalsIgnoreCase("yes")){
            String xApiKeyValue=apiUrls.get("xApiKeyValue");
            headerMap.put(HeaderParameters.XAPIKEY.getValue(), xApiKeyValue);
    		FrameworkLogger.logStep("Added header for xApiKeyValue:-> " + xApiKeyValue);
        }

		FrameworkLogger.logStep("createHeader -> End");
}


	/**
	 * Method to create logout api body
	 * 
	 * @throws IOException
	 */
//	protected static void createLogoutBody(String deviceKey) throws IOException {
	protected void createLogoutBody(String deviceKey) throws IOException {
		FrameworkLogger.logStep("createLogoutBody -> Start");

		String path = System.getProperty("user.dir") + "/resources/logoutTestData/logoutBody.js";
		File file = new File(path);
		logoutJSONBody = JsonPath.parse(file).jsonString();
		logoutJSONBody = setJsonData(LogoutUserConstants.getDeviceKeyOneJsonPath(), deviceKey, logoutJSONBody);

		FrameworkLogger.logStep("createLogoutBody -> End");
}
	
	
	
	/**
	 * Method to Logout for the logged in user.
	 * 
	 * @return
	 * @throws IOException
	 */
	public static ValidatableResponse logoutUser(String userId, String deviceKey, String accessToken) throws IOException {
		FrameworkLogger.logStep("logoutUser -> Start");
		
		LogoutAuserBaseScript apiObj=new LogoutAuserBaseScript();
		
//		createHeader(userId, deviceKey, accessToken);
		apiObj.createHeader();

		apiObj.createLogoutBody(deviceKey);
		ValidatableResponse response = apiObj.triggerLogoutApi();

		FrameworkLogger.logStep("logoutUser -> End");

		return response;
	}
	
	/**
	 * Method to Trigger the Logout API.
	 * 
	 * @return
	 * @throws IOException
	 */
//	public static ValidatableResponse triggerLogoutApi() throws IOException {
	public ValidatableResponse triggerLogoutApi() throws IOException {
		FrameworkLogger.logStep("triggerLogoutApi -> Start");

/*		ValidatableResponse response = given().body(logoutJSONBody)
				.headers(headerMap).log().all()
                .when()
                .put(getLogoutUrl())
                .then();
		
		response.log().all();
*/
		String strApiUrl=getLogoutUrl();
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,logoutJSONBody);

		// Verify the status code.
		int status = response.extract().statusCode();
		int intExpectedHttpCode = ApiResponseCodes.RESPONSECODE204
				.getValue();

		if(status==intExpectedHttpCode){
			loggedIn=false;
			FrameworkLogger.logStep("User logged out successfully.");
	}

		FrameworkLogger.logStep("triggerLogoutApi -> End");

		return response;
	}
	

}
