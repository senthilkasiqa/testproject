package com.rjil.cloud.tej.apiconstants;

/**
 * UpdateCopyContactDeviceMapping API, JSON path Constants
 * 
 */

public class UpdateCopyContactDeviceMappingConstants {

    public static String getContactsJsonPath() {
        return "$.contacts";
    }

    public static String getContactsJsonPath(int position) {
        return "$.contacts["+position+"]";
    }
}
