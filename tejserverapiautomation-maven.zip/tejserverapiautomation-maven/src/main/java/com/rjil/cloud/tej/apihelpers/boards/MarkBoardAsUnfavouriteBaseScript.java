package com.rjil.cloud.tej.apihelpers.boards;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

public class MarkBoardAsUnfavouriteBaseScript extends BaseTestScript{
protected static final String apiName = "MarkBoardAsUnfavouriteApi";
	
	protected String markBoardAsUnfavouriteURL(String boardKey) {
		FrameworkLogger.logStep("markBoardAsUnfavouriteURL: Start");
		return apiUrls.get("boardUrl") + serverConfig.get("markBoardAsUnfavouriteUrl").replace("{boardKey}", boardKey);
	}
	
	
	protected String markBoardAsUnfavouriteURL(String urlValue, String boardKey) {
		FrameworkLogger.logStep("markBoardAsUnfavouriteURL: Start");
		return (apiUrls.get("boardUrl") + urlValue);
	}
  
    
    protected ValidatableResponse triggerPutApiMarkBoardAsUnfavourite(String boardKey) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiMarkBoardAsUnfavourite: Start");
 
		String strApiUrl=markBoardAsUnfavouriteURL(boardKey);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiMarkBoardAsUnfavourite: End");

    	return response;
    }
    
    protected ValidatableResponse triggerPutApiMarkBoardAsUnfavourite(String boardKey, Map<String, String>headerMap1) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiMarkBoardAsUnfavourite: Start");
 
		String strApiUrl=markBoardAsUnfavouriteURL(boardKey);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap1);
		FrameworkLogger.logStep("triggerPutApiMarkBoardAsUnfavourite: End");

    	return response;
    }
    
    protected ValidatableResponse triggerPutApiMarkBoardAsUnfavourite(String urlValue, String boardKey) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiMarkBoardAsUnfavourite: Start");
 
		String strApiUrl=markBoardAsUnfavouriteURL(urlValue, boardKey);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiMarkBoardAsUnfavourite: End");

    	return response;
    }
    
    
    public static ValidatableResponse markBoardAsUnfavouriteService(String boardKey) throws IOException
    {
    	FrameworkLogger.logStep("markBoardAsUnfavouriteService: Start");
    	MarkBoardAsUnfavouriteBaseScript markFavourite = new MarkBoardAsUnfavouriteBaseScript();
    	markFavourite.createHeader();
    	ValidatableResponse response = markFavourite.triggerPutApiMarkBoardAsUnfavourite(boardKey);
    	FrameworkLogger.logStep("markBoardAsUnfavouriteService: End");
    	return response;
    	
    }
	
}
