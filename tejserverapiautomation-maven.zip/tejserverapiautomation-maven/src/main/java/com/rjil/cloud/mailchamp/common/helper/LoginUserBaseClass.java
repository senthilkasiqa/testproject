package com.rjil.cloud.mailchamp.common.helper;

import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;


public class LoginUserBaseClass extends MailChampBaseTestScript {

	protected Map<String, String> createHeaderMap() {
		System.out.println("create Header from SummaryBaseClass");

		//Map<String, String> headerMap = initializeHeaderMapForLogin(getValueFromEnvConfig("xcode"));
		Map<String, String> headerMap = initializeHeaderMapForLogin(getValueFromEnvConfig("X-Offline-Code"));
		return headerMap;

	}
	protected Map<String, String> createHeaderMap(String xCode) {
		System.out.println("create Header from SummaryBaseClass");

		Map<String, String> headerMap = initializeHeaderMapForLogin(xCode);
//		headerMap.remove(HeaderParameters.XEMAILID.getValue());
//		headerMap.put(HeaderParameters.XCODE.getValue(), xcode);
		return headerMap;

	}

/*	protected Map<String, String> createHeaderMap() {
		System.out.println("create Header from AuthenticateUserBaseClass");
		Map<String, String> headerMap = initializeHeaderMap();
				headerMap.remove("X-Email-Id");
		headerMap.put("xCode", getValueFromEnvConfig("xcode"));
				return headerMap;
	}
*/
	protected String getLoginUserUrl() {
		String baseUrl = getValueFromEnvConfig("baseURL");
		FrameworkLogger.logStep("URL---->"+baseUrl);
		String subUrl = getValueFromProjectConfig("userLoginURL");	
		FrameworkLogger.logStep("SUBURL---->"+subUrl);
		return baseUrl + subUrl;
		}

	public static ValidatableResponse triggerLoginApi(){
		LoginUserBaseClass obj = new LoginUserBaseClass();
		ValidatableResponse response = obj.triggerPostApi(obj.getLoginUserUrl(), obj.createHeaderMap());
		return response;
	}
}
