package com.rjil.cloud.tej.apihelpers.notifications;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Sanjeevanee.Kanase
 *class for having methods - for creating headers, get url for calling update notification url, and getting response for api
 */
public class UpdateNotificationBaseScript extends BaseTestScript {
	
    protected static String updateNotificationJSONBody;
    protected static final String apiName = "UpdateNotification";
//    protected static Map<String, String> headerMap = null;
    
    public UpdateNotificationBaseScript(){
    	globalApiName=apiName;
    }
	
	// created a Hashmap to save all the headers.
/*	protected static void createHeader() {
		
		FrameworkLogger.logStep("createHeader:-> Start");
		headerMap=new HashMap<>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");
		
		 //Add 'X-Api-Key' in header for the API.
        addXapiHeaderKey(headerMap);
        
        FrameworkLogger.logStep("createHeader:-> End");
	}
*/

    /**get a complete url for 'Update Notification API'
     * @return
     */
    public String getUpdateNotificationUrl() {
        //String url= apiUrls.get("baseURL") + serverConfig.get("updateNotificationUrl");
    	FrameworkLogger.logStep("getUpdateNotificationUrl: Start");
        String url= getUpdateNotificationUrl("updateNotificationUrl");
        FrameworkLogger.logStep("getUpdateNotificationUrl: End");
        return url;
    }
    
    /**get a complete url for 'Update Notification API' negative test cases
     * @return
     */
    public String getUpdateNotificationUrl(String url) {
    	FrameworkLogger.logStep("getUpdateNotificationUrl: Start");
        String apiUrl= apiUrls.get("baseURL") + serverConfig.get(url);
        FrameworkLogger.logStep("getUpdateNotificationUrl: Start");
        return apiUrl;
    }
    
    protected String setUpdateNotificationJsonBody() throws IOException {
        //load json file
    	//createHeader();
    	FrameworkLogger.logStep("setUpdateNotificationJsonBody: Start");
        String path = System.getProperty("user.dir") + "/resources/notificationsTestData/updateNotificationBody.js";
        File file = new File(path);
        updateNotificationJSONBody = JsonPath.parse(file).jsonString();
        FrameworkLogger.logStep("setUpdateNotificationJsonBody: End");
       return updateNotificationJSONBody;
    }
    
   
    /**
     * Method to get Update Notification Response
     * @return Update Notification validatable response
     */
    public ValidatableResponse getUpdateNotificationApiResponse() throws IOException {
    	
    	FrameworkLogger.logStep("getUpdateNotificationApiResponse: Start");
    	//System.out.println("userId for update notification="+userId);
/*        ValidatableResponse response = given().body(updateNotificationJSONBody)
                .headers(headerMap)
                .log().all()
                .when()
                .put(getUpdateNotificationURL())
                .then();
        response.log().all();
        Utils.addRequestResponseToLogger();
*/        
		//String strApiUrl=getUpdateNotificationUrl();
		//Call method to trigger PUT API.
		//ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,updateNotificationJSONBody);

		ValidatableResponse response = getUpdateNotificationApiResponse("updateNotificationUrl");
		FrameworkLogger.logStep("getUpdateNotificationApiResponse: End");
    	return response;
    }
    
    /**
     * Method to get Update Notification Response for negative test
     * @return Update Notification validatable response
     */
    public ValidatableResponse getUpdateNotificationApiResponse(String url) throws IOException {
    	
    	FrameworkLogger.logStep("getUpdateNotificationApiResponse: Start");
/*        ValidatableResponse response = given().body(updateNotificationJSONBody)
                .headers(headerMap)
                .log().all()
                .when()
                .put(getUpdateNotificationURL())
                .then();
        response.log().all();
        Utils.addRequestResponseToLogger();
*/        
		String strApiUrl=getUpdateNotificationUrl(url);
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,updateNotificationJSONBody);

		FrameworkLogger.logStep("getUpdateNotificationApiResponse: End");
    	return response;
    }
    
}
