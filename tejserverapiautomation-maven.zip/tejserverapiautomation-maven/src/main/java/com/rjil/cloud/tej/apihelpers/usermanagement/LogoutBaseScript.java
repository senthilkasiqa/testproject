package com.rjil.cloud.tej.apihelpers.usermanagement;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Set;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.LogoutUserConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.MultiDeviceRepositoryParameters;

public class LogoutBaseScript extends BaseTestScript {

	protected String logoutJSONBody;
	protected static final String apiName = "Logout";
	
	public LogoutBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * Method to get logout api url
	 * 
	 * @return
	 */
	protected String getLogoutUrl() {
		FrameworkLogger.logStep("getLogoutUrl -> End");

		String result = apiUrls.get("baseURL") + serverConfig.get("logOutUserUrl");

		FrameworkLogger.logStep("getLogoutUrl -> End");

		return result;
	}

	protected String getLogoutUrl(String url) {
		FrameworkLogger.logStep("getLogoutUrl -> End");

		String result = apiUrls.get("baseURL") + serverConfig.get(url);

		FrameworkLogger.logStep("getLogoutUrl -> End");

		return result;
	}

	/**
	 * Method to create logout api body
	 * 
	 * @throws IOException
	 */
	protected void createLogoutBody(String deviceKey) throws IOException {
		FrameworkLogger.logStep("createLogoutBody -> Start");

		String path = System.getProperty("user.dir") + "/resources/logoutTestData/logoutBody.js";
		File file = new File(path);
		logoutJSONBody = JsonPath.parse(file).jsonString();
		logoutJSONBody = setJsonData(LogoutUserConstants.getDeviceKeyOneJsonPath(), deviceKey, logoutJSONBody);

		FrameworkLogger.logStep("createLogoutBody -> End");
	}

	protected String createLogoutBody() throws IOException, ParseException {
		FrameworkLogger.logStep("createLogoutBody -> Start");

		String logoutJsonBody = "{\"revokeAll\": \"N\",\"forceLogout\":\"Y\",\"devices\": []}";

		//Added support for logout from web
		if(serverConfig.get("deviceType").equalsIgnoreCase("W")){
		addDeviceIdForWeb();
		}
			Map<String, Map<String, String>> multiDeviceRepositoryMapLocal=null;
			FrameworkLogger.logStep("-----------------Email:" + apiUrls.get("Email"));
		//	multiDeviceRepositoryMapLocal=multiUserRepositoryMap.get(apiUrls.get("Email"));
			if(multiDeviceRepositoryMapLocal==null){
				FrameworkLogger.logStep("-----------------multiDeviceRepositoryMapLocal is NULL:");
			}
			FrameworkLogger.logStep("-----------------Device value:" + multiDeviceRepositoryMapLocal.get(serverConfig.get("deviceKey")));
		//	FrameworkLogger.logStep("-----------------Device value:" + multiUserRepositoryMap.get(serverConfig.get("deviceKey")));
	
					multiDeviceRepositoryMapLocal.get(serverConfig.get("deviceKey"));

		//////////////////
		Set<String> deviceSet = multiDeviceRepositoryMapLocal.keySet();
		//Set<String> deviceSet = multiUserRepositoryMap.keySet();

		FrameworkLogger.logStep("deviceSet -> ");
		FrameworkLogger.logStep(deviceSet.toString());

		JSONArray listAllRecords = new JSONArray();
		int i = -1;
		for (String strOneDevice : deviceSet) {
			i++;
			Object oneRecord = createOneLogoutRecord(strOneDevice);

			listAllRecords.add(oneRecord);
		}

		JSONParser parser = new JSONParser();
		Object objAllRecords = parser.parse(logoutJsonBody);
		JSONObject jsonObjectAllRecords = (JSONObject) objAllRecords;
		jsonObjectAllRecords.put("devices", listAllRecords);

		FrameworkLogger.logStep("createLogoutBody:-> End");
		return jsonObjectAllRecords.toJSONString();

	}
	
	protected String createLogoutBody(Map<String, String> multiDeviceRepositoryMapLocal) throws IOException, ParseException {
		FrameworkLogger.logStep("createLogoutBody -> Start");

		String logoutJsonBody = "{\"revokeAll\": \"N\",\"forceLogout\":\"Y\",\"devices\": []}";

		//Added support for logout from web
		if(serverConfig.get("deviceType").equalsIgnoreCase("W")){
		addDeviceIdForWeb();
		}
//			Map<String, Map<String, String>> multiDeviceRepositoryMapLocal=null;
//			FrameworkLogger.logStep("-----------------Email:" + apiUrls.get("Email"));
//			multiDeviceRepositoryMapLocal=multiUserRepositoryMap.get(apiUrls.get("Email"));
//			if(multiDeviceRepositoryMapLocal==null){
//				FrameworkLogger.logStep("-----------------multiDeviceRepositoryMapLocal is NULL:");
//			}
//			FrameworkLogger.logStep("-----------------Device value:" + multiDeviceRepositoryMapLocal.get(serverConfig.get("deviceKey")));
//	
//					multiDeviceRepositoryMapLocal.get(serverConfig.get("deviceKey"));

		//////////////////
		Set<String> deviceSet = multiDeviceRepositoryMapLocal.keySet();

		FrameworkLogger.logStep("deviceSet -> ");
		FrameworkLogger.logStep(deviceSet.toString());

		JSONArray listAllRecords = new JSONArray();
		int i = -1;
		for (String strOneDevice : deviceSet) {
			i++;
			Object oneRecord = createOneLogoutRecord(strOneDevice);

			listAllRecords.add(oneRecord);
		}

		JSONParser parser = new JSONParser();
		Object objAllRecords = parser.parse(logoutJsonBody);
		JSONObject jsonObjectAllRecords = (JSONObject) objAllRecords;
		jsonObjectAllRecords.put("devices", listAllRecords);

		FrameworkLogger.logStep("createLogoutBody:-> End");
		return jsonObjectAllRecords.toJSONString();

	}
	

	protected Object createOneLogoutRecord(String strDeviceId) throws ParseException {
		FrameworkLogger.logStep("createOneLogoutRecord:-> Start");
		String oneDummyContact = "{\"deviceKey\": \"dummy value\"}";

		JSONParser parser = new JSONParser();
		Object objOneDummyRecord = parser.parse(oneDummyContact);
		JSONObject jsonObjectOneDummyRecord = (JSONObject) objOneDummyRecord;
		jsonObjectOneDummyRecord.put("deviceKey", strDeviceId);

		FrameworkLogger.logStep("createOneLogoutRecord:-> End");
		return jsonObjectOneDummyRecord;
	}

	/**
	 * Method to get Logout Api Response
	 * 
	 * @return
	 * @throws IOException
	 * @throws ParseException
	 */
	// public static ValidatableResponse logoutUser() throws IOException {
	public ValidatableResponse logoutUser() throws IOException, ParseException {
		FrameworkLogger.logStep("logoutUser -> Start");

		ValidatableResponse response = null;

		createLogoutBody(serverConfig.get("deviceKey"));
		response = triggerLogoutApi();

		FrameworkLogger.logStep("logoutUser -> End");

		return response;
	}

	public ValidatableResponse logoutUser(String apiUrl) throws IOException, ParseException {
		FrameworkLogger.logStep("logoutUser -> Start");

		ValidatableResponse response = null;

		createLogoutBody(serverConfig.get("deviceKey"));
		response = triggerLogoutApi(apiUrl);

		FrameworkLogger.logStep("logoutUser -> End");

		return response;
	}

	/**
	 * Method to logout a user with default header.
	 * 
	 * @return
	 * @throws IOException
	 * @throws ParseException
	 */
	public static ValidatableResponse logoutUserWithDefaultHeader() throws IOException, ParseException {
		FrameworkLogger.logStep("logoutUserWithDefaultHeader -> Start");

		LogoutBaseScript apiObj = new LogoutBaseScript();

		ValidatableResponse response = null;

		apiObj.createHeader();
		apiObj.createLogoutBody(serverConfig.get("deviceKey"));
		// apiObj.logoutJSONBody=apiObj.createLogoutBody();

		response = apiObj.triggerLogoutApi();

		FrameworkLogger.logStep("logoutUserWithDefaultHeader -> End");

		return response;
	}
	/**
	 * Method to logout a user with default header.
	 * 
	 * @return
	 * @throws IOException
	 * @throws ParseException
	 */
	public static ValidatableResponse logoutUserWithDefaultHeader(String deviceIdKey) throws IOException, ParseException {
		FrameworkLogger.logStep("logoutUserWithDefaultHeader -> Start");

		LogoutBaseScript apiObj = new LogoutBaseScript();

		ValidatableResponse response = null;

		apiObj.createHeader();
		apiObj.createLogoutBody(serverConfig.get(deviceIdKey));
		// apiObj.logoutJSONBody=apiObj.createLogoutBody();

		response = apiObj.triggerLogoutApi();

		FrameworkLogger.logStep("logoutUserWithDefaultHeader -> End");

		return response;
	}

	/**
	 * Method to logout a user with default header.
	 * 
	 * @return
	 * @throws IOException
	 * @throws ParseException
	 */
	public static ValidatableResponse logoutUserMultidevice() throws IOException, ParseException {
		FrameworkLogger.logStep("logoutUserMultidevice -> Start");

		LogoutBaseScript apiObj = new LogoutBaseScript();

		ValidatableResponse response = null;

		apiObj.createHeader();
		String deviceKeyLogoutBody=serverConfig.get("deviceKey");
		FrameworkLogger.logStep("deviceKeyLogoutBody:-" + deviceKeyLogoutBody);
		
		 apiObj.createLogoutBody(deviceKeyLogoutBody);
		apiObj.logoutJSONBody = apiObj.createLogoutBody();

		response = apiObj.triggerLogoutApi();

		FrameworkLogger.logStep("logoutUserMultidevice -> End");

		return response;
	}


	/**
     * Method to logout a user with default header.
     * 
     * @return
     * @throws IOException
     * @throws ParseException
     */
   
	public static ValidatableResponse logoutUserMultidevice(String deviceId) throws IOException, ParseException {
        FrameworkLogger.logStep("logoutUserMultidevice -> Start");

        Map<String, String> multiDeviceRepositoryMapLocal=null;
        FrameworkLogger.logStep("***********deviceId:" + deviceId);
        multiDeviceRepositoryMapLocal=multiUserRepositoryMap.get(deviceId);
        FrameworkLogger.logStep("*********:" + multiDeviceRepositoryMapLocal.toString());
        
        //Map<String, String> deviceInfoMap=multiUserRepositoryMap.get(deviceId);
        
        LogoutBaseScript apiObj = new LogoutBaseScript();

        ValidatableResponse response = null;

        apiObj.createHeader(multiDeviceRepositoryMapLocal);

        FrameworkLogger.logStep("deviceKeyLogoutBody:-" + deviceId);
        
        //         apiObj.createLogoutBody(deviceKeyLogoutBody);
        apiObj.createLogoutBody(deviceId);
        
        response = apiObj.triggerLogoutApi();

        FrameworkLogger.logStep("logoutUserMultidevice -> End");

        return response;
    }

	

	/**
	 * Method to Logout for the logged in user.
	 * 
	 * @return
	 * @throws IOException
	 */
	public static ValidatableResponse logoutUser(String userId, String deviceKey, String accessToken)
			throws IOException {
		FrameworkLogger.logStep("logoutUser -> Start");

		LogoutBaseScript apiObj = new LogoutBaseScript();

		apiObj.createHeader();

		apiObj.createLogoutBody(deviceKey);

		ValidatableResponse response = apiObj.triggerLogoutApi();

		FrameworkLogger.logStep("logoutUser -> End");

		return response;
	}

	/**
	 * Method to Trigger the Logout API.
	 * 
	 * @return
	 * @throws IOException
	 */
	// public static ValidatableResponse triggerLogoutApi() throws IOException {
	public ValidatableResponse triggerLogoutApi() throws IOException {
		FrameworkLogger.logStep("triggerLogoutApi -> Start");

		String strApiUrl = getLogoutUrl();
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, logoutJSONBody);

		// Verify the status code.
		int status = response.extract().statusCode();
		int intExpectedHttpCode = ApiResponseCodes.RESPONSECODE204.getValue();

		// set flag.
		if (status == intExpectedHttpCode) {
			// userIsLoggedIn=false;
			FrameworkLogger.logStep("User logged out successfully.");

		}
		FrameworkLogger.logStep("triggerLogoutApi -> End");

		return response;
	}
	
	public ValidatableResponse triggerLogoutApi(String apiUrl) throws IOException {
		FrameworkLogger.logStep("triggerLogoutApi -> Start");

		String strApiUrl = getLogoutUrl(apiUrl);
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, logoutJSONBody);

		// Verify the status code.
		int status = response.extract().statusCode();
		int intExpectedHttpCode = ApiResponseCodes.RESPONSECODE204.getValue();

		// set flag.
		if (status == intExpectedHttpCode) {
			// userIsLoggedIn=false;
			FrameworkLogger.logStep("User logged out successfully.");

		}
		FrameworkLogger.logStep("triggerLogoutApi -> End");

		return response;
	}

	public static void validateErrorsInLogoutApiResponse(ValidatableResponse response, int intExpectedHttpErrorCode,
			String strExpectedResponseErrorCode, String strExpectedError) throws VerificationFailException {
		FrameworkLogger.logStep("validateErrorsInLogoutApiResponse:-> Start");

		// Read the actual error information from Response
		int status = response.extract().statusCode();
		String strActualError = response.extract().path("error");
		// String strActualErrors = response.extract().path("errors[0]");
		String strActualErrorCode = response.extract().path("code");

		// Validating the Actual and Expected error information
		Verify.verifyEquals(strActualError, strExpectedError, "Verifying the error message.");
		// Verify.verifyEquals(strActualErrors, strExpectedError,
		// "Verifying the errors message.");
		Verify.verifyEquals(strActualErrorCode, strExpectedResponseErrorCode,
				"Validating the Expected and Actual error codes.");
		Verify.verifyEquals(status, intExpectedHttpErrorCode,
				"Validating the Expected and Actual 'HTTP Codes for Error'.");

		FrameworkLogger.logStep("validateErrorsInLogoutApiResponse:-> End");
		System.out.println("validateErrorsInLogoutApiResponse:-> End");

	}

	/*
	 * @AfterMethod public void postLogoutOperation() throws IOException{
	 * FrameworkLogger.logStep("postLogoutOperation:-> Start");
	 * 
	 * if(userIsLoggedIn==false){ FrameworkLogger.logStep("Calling login user."
	 * ); // logoutUserWithDefaultHeader(); defaultLogin(); }
	 * FrameworkLogger.logStep("postLogoutOperation:-> End"); }
	 */
	
	
	/*public static ValidatableResponse logoutUserWithHeader1(String deviceIdKey2) throws IOException, ParseException {
		FrameworkLogger.logStep("logoutUserWithHeader -> Start");

		LogoutBaseScript apiObj = new LogoutBaseScript();

		ValidatableResponse response = null;

	//	apiObj.createHeader();
		Map<String, String>HeaderMap=apiObj.initializeHeader1();
		apiObj.createLogoutBody(deviceIdKey2);
		// apiObj.logoutJSONBody=apiObj.createLogoutBody();

		response = apiObj.triggerLogoutApi1(HeaderMap);

		FrameworkLogger.logStep("logoutUserWithDefaultHeader -> End");

		return response;
	}*/
	
	public ValidatableResponse triggerLogoutApi1(Map<String, String>HeaderMap) throws IOException {
		FrameworkLogger.logStep("triggerLogoutApi -> Start");

		String strApiUrl = getLogoutUrl();
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl, HeaderMap, logoutJSONBody);

		// Verify the status code.
		int status = response.extract().statusCode();
		int intExpectedHttpCode = ApiResponseCodes.RESPONSECODE204.getValue();

		// set flag.
		if (status == intExpectedHttpCode) {
			// userIsLoggedIn=false;
			FrameworkLogger.logStep("User logged out successfully.");

		}
		FrameworkLogger.logStep("triggerLogoutApi -> End");

		return response;
	}
	
	/*public static ValidatableResponse logoutUserWithHeader2(String deviceIdKey3) throws IOException, ParseException {
		FrameworkLogger.logStep("logoutUserWithHeader -> Start");

		LogoutBaseScript apiObj = new LogoutBaseScript();

		ValidatableResponse response = null;

	//	apiObj.createHeader();
		Map<String, String>HeaderMap2=apiObj.initializeHeader2();
		apiObj.createLogoutBody(deviceIdKey3);
		// apiObj.logoutJSONBody=apiObj.createLogoutBody();

		response = apiObj.triggerLogoutApi2(HeaderMap2);

		FrameworkLogger.logStep("logoutUserWithDefaultHeader -> End");

		return response;
	}*/
	
	public ValidatableResponse triggerLogoutApi2(Map<String, String>HeaderMap2) throws IOException {
		FrameworkLogger.logStep("triggerLogoutApi -> Start");

		String strApiUrl = getLogoutUrl();
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl, HeaderMap2, logoutJSONBody);

		// Verify the status code.
		int status = response.extract().statusCode();
		int intExpectedHttpCode = ApiResponseCodes.RESPONSECODE204.getValue();

		// set flag.
		if (status == intExpectedHttpCode) {
			// userIsLoggedIn=false;
			FrameworkLogger.logStep("User logged out successfully.");

		}
		FrameworkLogger.logStep("triggerLogoutApi -> End");

		return response;
	}
}
