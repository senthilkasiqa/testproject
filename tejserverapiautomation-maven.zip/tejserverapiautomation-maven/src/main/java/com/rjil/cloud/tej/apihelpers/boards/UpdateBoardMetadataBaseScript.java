/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boards;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;

/**
 * @author Prateek
 *
 */
public class UpdateBoardMetadataBaseScript extends BaseTestScript{

	
	
	protected static final String apiName = "UpdateBoardMetadata";
	protected static String updateBoardMetaDataJsonBody;
	//String boardJsonBody=null;
	public static String boardKey;
	
	public UpdateBoardMetadataBaseScript() {
		globalApiName = apiName;
	}
	
	protected Map<String, String> createHeader() {
		headerMap = initializeHeader();
		return headerMap;
	}
	
	protected String updateBoardMetaDataUrl() {
		FrameworkLogger.logStep("updateBoardMetaDataUrl: Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get("updateBoardMetadataUrl");
		FrameworkLogger.logStep("updateBoardMetaDataUrl: End");
		return url;
	}
	
	protected String updateBoardMetaDataUrl(String urlValue) {
		FrameworkLogger.logStep("updateBoardMetaDataUrl: Start");
		String url = apiUrls.get("boardUrl") + urlValue;
		FrameworkLogger.logStep("updateBoardMetaDataUrl: End");
		return url;
	}
	
	protected String setUpdateBoardMetadataJsonBody(String jsonName) throws IOException{
		FrameworkLogger.logStep("setUpdateBoardMetadataJsonBody: Start");
		// load json file
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/"+jsonName+"";
		File file = new File(path);
		updateBoardMetaDataJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setUpdateBoardMetadataJsonBody: End");
		return updateBoardMetaDataJsonBody;
	}


	protected ValidatableResponse triggerPostApiUpdateBoardMetadata() throws IOException {

		FrameworkLogger.logStep("triggerPostApiUpdateBoardMetadata: Start");
        String strApiUrl=updateBoardMetaDataUrl();
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, updateBoardMetaDataJsonBody);
		FrameworkLogger.logStep("triggerPostApiUpdateBoardMetadata: End");
		return response;
	}
	
	
	protected ValidatableResponse triggerPostApiUpdateBoardMetadata(Map<String, String> headerMap) throws IOException {

		FrameworkLogger.logStep("triggerPostApiUpdateBoardMetadata: Start");
		String strApiUrl=updateBoardMetaDataUrl();
		// headerMap=createHeader(headerMap);
		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, createHeader(headerMap), updateBoardMetaDataJsonBody);
		FrameworkLogger.logStep("triggerPostApiUpdateBoardMetadata: End");

		return response;
	}
	

	public static ValidatableResponse updateBoardMetaDataServiceMethod(String opertaionName,String objectKey, String boardKey,String jsonName) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("updateBoardMetaDataServiceMethod: Start");
		
		UpdateBoardMetadataBaseScript updateBoardMetadataBaseScript = new UpdateBoardMetadataBaseScript();
		updateBoardMetadataBaseScript.createHeader();
		updateBoardMetaDataJsonBody = updateBoardMetadataBaseScript.setUpdateBoardMetadataJsonBody(jsonName);
		updateBoardMetaDataJsonBody = setJsonData(NewBoardConstants.getOperationName(0), opertaionName, updateBoardMetaDataJsonBody);
		updateBoardMetaDataJsonBody = setJsonData(NewBoardConstants.getBoardKey(0), boardKey, updateBoardMetaDataJsonBody);
		updateBoardMetaDataJsonBody = setJsonData(NewBoardConstants.getObjectKey(0), objectKey, updateBoardMetaDataJsonBody);
		ValidatableResponse response = updateBoardMetadataBaseScript.triggerPostApiUpdateBoardMetadata();
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Update Board Metadata Status");
		FrameworkLogger.logStep("updateBoardMetaDataServiceMethod: End");
		return response;
	}
	
	public static ValidatableResponse updateBoardMetaDataServiceMethod(String newFileName,String opertaionName,String objectKey, String boardKey,String jsonName) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("updateBoardMetaDataServiceMethod: Start");
		
		UpdateBoardMetadataBaseScript updateBoardMetadataBaseScript = new UpdateBoardMetadataBaseScript();
		updateBoardMetadataBaseScript.createHeader();
		updateBoardMetaDataJsonBody = updateBoardMetadataBaseScript.setUpdateBoardMetadataJsonBody(jsonName);
		updateBoardMetaDataJsonBody = setJsonData(NewBoardConstants.getOperationName(0), opertaionName, updateBoardMetaDataJsonBody);
		updateBoardMetaDataJsonBody = setJsonData(NewBoardConstants.getBoardKey(0), boardKey, updateBoardMetaDataJsonBody);
		updateBoardMetaDataJsonBody = setJsonData(NewBoardConstants.getObjectKey(0), objectKey, updateBoardMetaDataJsonBody);
		updateBoardMetaDataJsonBody  = setJsonData(NewBoardConstants.getObjectName(0), newFileName, updateBoardMetaDataJsonBody);
		ValidatableResponse response = updateBoardMetadataBaseScript.triggerPostApiUpdateBoardMetadata();
		//int statusCode = response.extract().statusCode();
		//Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("updateBoardMetaDataServiceMethod: End");
		return response;
	}
	
	public static ValidatableResponse updateBoardMetaDataServiceMethod(Map<String, String> headerMap,String opertaionName,String objectKey, String boardKey,String jsonName) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("updateBoardMetaDataServiceMethod: Start");
		
		UpdateBoardMetadataBaseScript updateBoardMetadataBaseScript = new UpdateBoardMetadataBaseScript();
		//headerMap=updateBoardMetadataBaseScript.createHeader(headerMap);
		updateBoardMetaDataJsonBody = updateBoardMetadataBaseScript.setUpdateBoardMetadataJsonBody(jsonName);
		updateBoardMetaDataJsonBody = setJsonData(NewBoardConstants.getOperationName(0), opertaionName, updateBoardMetaDataJsonBody);
		updateBoardMetaDataJsonBody = setJsonData(NewBoardConstants.getBoardKey(0), boardKey, updateBoardMetaDataJsonBody);
		updateBoardMetaDataJsonBody = setJsonData(NewBoardConstants.getObjectKey(0), objectKey, updateBoardMetaDataJsonBody);
		ValidatableResponse response = updateBoardMetadataBaseScript.triggerPostApiUpdateBoardMetadata(headerMap);
		//int statusCode = response.extract().statusCode();
		//Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("updateBoardMetaDataServiceMethod: End");
		return response;
	}
	
	/*public static ValidatableResponse updateBoardCoverPicServiceMethod(Map<String, String> headerMap1, String objectKey, String boardKey) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("repositoryFileUploadToBoardServiceMethod: Start");
		

		UpdateBoardMetadataBaseScript updateBoardMetadataBaseScript = new UpdateBoardMetadataBaseScript();
		updateBoardMetadataBaseScript.createHeader();
		updateBoardMetaDataJsonBody = updateBoardMetadataBaseScript.setUpdateBoardMetadataJsonBody();
		//updateBoardMetaDataJsonBody = setJsonData(NewBoardConstants.getBoardCoverPicObjectKey(), objectKey, updateBoardMetaDataJsonBody);
		ValidatableResponse response = updateBoardMetadataBaseScript.triggerPostApiUpdateBoardMetadata()
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("updateBoardCoverPicServiceMethod: End");
		return response;
	}*/

}
