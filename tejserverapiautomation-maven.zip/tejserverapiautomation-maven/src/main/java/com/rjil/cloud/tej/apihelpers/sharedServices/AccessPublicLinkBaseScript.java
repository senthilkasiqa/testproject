/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.sharedServices;

import static com.jayway.restassured.RestAssured.given;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 *
 */
public class AccessPublicLinkBaseScript extends BaseTestScript {

	protected static final String apiName = "AccessPublicLink";

	// protected Map<String, String> headerMap = null;
	
	public AccessPublicLinkBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * In order to construct the header parameters for each test, we would call
	 * a createHeader method. This method would initialize a hashmap that would
	 * contain a key-value pair ( header parameters and its corresponding value)
	 *
	 * UserId Authorization
	 *
	 * The method would then put header parameters needed for each test case.
	 * Once the header parameters are available, we would call the API method to
	 * get response. The idea behing using a hashmap is that we would need only
	 * 3 methods in the middle layer base script to run all our test cases
	 * namely
	 */

	/*
	 * // created a Hashmap to save all the headers. protected void
	 * createHeader() { FrameworkLogger.logStep("createHeader:-> Start");
	 * headerMap = new HashMap<>();
	 * headerMap.put(HeaderParameters.CONTENTTYPE.getValue(),
	 * "application/json"); headerMap.put(HeaderParameters.XUSERID.getValue(),
	 * userId);
	 * 
	 * headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
	 * 
	 * // Add 'X-Api-Key' in header for the API. addXapiHeaderKey(headerMap);
	 * 
	 * System.out.println("Headere==========>"+headerMap);
	 * 
	 * FrameworkLogger.logStep("createHeader:-> End"); }
	 */

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Remove device key from header for this API.
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * get a complete url for 'Access a public link API'
	 * 
	 * @return
	 */
	protected String getAccessPublicLinkUrl() {
		FrameworkLogger.logStep("getAccessPublicLinkUrl : Start");
		String aplURL = apiUrls.get("URL") + serverConfig.get("accessPublicLinkUrl").replace("{shareKey}",
				repositoryMap.get(RepositoryParameterEnum.SHAREKEY.getValue()));
		
		String strXapiKeyValue=apiUrls.get("xApiKeyValue");
		String shardKey=repositoryMap.get(RepositoryParameterEnum.SHARDKEY.getValue());
		  FrameworkLogger.logStep("aplURL : - > "+ aplURL + "; strXapiKeyValue : - > "+ strXapiKeyValue + "; shardKey : - > " + shardKey);
		String accessLinkUrl = aplURL.replace("{shardKey}", repositoryMap.get(RepositoryParameterEnum.SHARDKEY.getValue())).replace("{apiKey}", apiUrls.get("xApiKeyValue"));
		FrameworkLogger.logStep("AccessPublicLinkUrl=========>" + accessLinkUrl);
		FrameworkLogger.logStep("getAccessPublicLinkUrl : End");
		return accessLinkUrl;
	}

	/**
	 * get a url for 'Access a public link API' for negative scenarios
	 * 
	 * @return
	 */
	protected String getAccessPublicLinkUrl(String shareKey) {
		FrameworkLogger.logStep("getAccessPublicLinkUrl : Start");
		String aplURL = apiUrls.get("URL") + serverConfig.get("accessPublicLinkUrl").replace("{shareKey}", shareKey);
		String accessLinkUrl = aplURL.replace("{shardKey}", shardKey).replace("{apiKey}", apiUrls.get("xApiKeyValue"));
		FrameworkLogger.logStep("getAccessPublicLinkUrl : End");
		return accessLinkUrl;
	}


	/**
	 * Method to get Access a public link Api
	 *
	 * @return create a public link validatable response
	 */
	protected ValidatableResponse triggerGetApiAccessPublicLink() throws IOException {

		FrameworkLogger.logStep("triggerGetApiAccessPublicLink : Start");
		String apiUrl=getAccessPublicLinkUrl();
		ValidatableResponse response=triggerGetApi(apiUrl, headerMap,true);
		FrameworkLogger.logStep("triggerGetApiAccessPublicLink : End");
		return response;
	}

	/**
	 * Method to get Access a public link Api for negative test
	 *
	 * @return create a public link validatable response
	 */
	protected ValidatableResponse triggerGetApiAccessPublicLink(String shareKey) throws IOException {

		FrameworkLogger.logStep("triggerGetApiAccessPublicLink : Start");
		String apiUrl=getAccessPublicLinkUrl(shareKey);
		ValidatableResponse response=triggerGetApi(apiUrl, headerMap,true);
		FrameworkLogger.logStep("triggerGetApiAccessPublicLink : End");
		return response;
	}

}
