package com.rjil.cloud.tej.apihelpers.nms;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.Validatable;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.BoardConstants;
import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apiconstants.NmsUpdateMetadataConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.fileupload.UploadBaseScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.BoardParameters;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek Jain
 * 
 * Base class for Update Metadata Version 1 Base Script
 *
 */
public class UpdateMetadataV1BaseScriptForFileFolder extends BaseTestScript {

	protected static String updateMetadataV1JsonBody;
	protected static final String apiName = "UpdateMetadataV1";
	CreateFolderBaseScript cf = new CreateFolderBaseScript();
    ValidatableResponse createFolderResponse;
    HashMap valuesMap = new HashMap();
	
    public UpdateMetadataV1BaseScriptForFileFolder(){
    	globalApiName=apiName;
    }
    
    /**Method to get response from Create Folder API
     * @return
     * @throws IOException
     */
   /* public ValidatableResponse getCreateFolderResponse() throws IOException
    {
    	cf.createHeader();
    	return cf.getCreateFolderResponse();
    } */
    
    
    /**Get the values from response of create a folder API
     * and put it in a hashmap
     * @return
     * @throws IOException
     * @throws InterruptedException 
     * @throws VerificationFailException 
     */
    @BeforeTest
    public HashMap getResponseValueFromCreateFolderApi() throws IOException, InterruptedException, VerificationFailException
    {
    	//createFolderResponse = CreateFolderBaseScript.createFolderServiceMethod();
    	String fileName="RunAppDownload.jpg";
    	createFolderResponse=UploadBaseScript.getUploadFileServiceMethodResponse(fileName);
    	valuesMap.put("createdDate", createFolderResponse.extract().path("createdDate"));
    	valuesMap.put("lastUpdatedDate", createFolderResponse.extract().path("lastUpdatedDate"));
    	valuesMap.put("status",createFolderResponse.extract().path("status"));
    	valuesMap.put("objectKey",createFolderResponse.extract().path("objectKey"));
    	valuesMap.put("sourceName",createFolderResponse.extract().path("sourceName"));
    	valuesMap.put("parentObjectKey",createFolderResponse.extract().path("parentObjectKey"));
    	valuesMap.put("objectName",createFolderResponse.extract().path("objectName"));
    	valuesMap.put("isHidden",createFolderResponse.extract().path("isHidden"));
    	valuesMap.put("isLocked",createFolderResponse.extract().path("isLocked"));
    	valuesMap.put("isReadonly",createFolderResponse.extract().path("isReadonly"));
    	valuesMap.put("isPinned",createFolderResponse.extract().path("isPinned"));
    	valuesMap.put("parentObjectKey",createFolderResponse.extract().path("parentObjectKey"));
    	valuesMap.put("version",createFolderResponse.extract().path("version"));
		return valuesMap;
   }
  
    /**method to create a positive request body for 'Update metadata API"
     * by replacing all values from the valueMap
     * @return
     */
    protected String updateJsonForUpdateMetadataApi()
    {
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getStatus(0),valuesMap.get("status"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getObjectKey(0),valuesMap.get("objectKey"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getSourceName(0),valuesMap.get("sourceName"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getParentObjectKey(0),valuesMap.get("parentObjectKey"), updateMetadataV1JsonBody);
    	//updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getObjectName(0),System.currentTimeMillis()+".doc", updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getObjectName(0),valuesMap.get("objectName"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsHidden(0),valuesMap.get("isHidden"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsLocked(0),valuesMap.get("isLocked"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsReadonly(0),valuesMap.get("isReadonly"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsPinned(0),valuesMap.get("isPinned"), updateMetadataV1JsonBody);
    //	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getSourceFolder(),valuesMap.get("sourceFolder"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getVersion(0),valuesMap.get("version"), updateMetadataV1JsonBody);
    //	updateMetadataJSONBody = setJsonData(NmsConstants.getVersion(),valuesMap.get("operationName"), updateMetadataJSONBody);
    	
    	////////////////////////
    	
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getStatus(1),valuesMap.get("status"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getObjectKey(1),valuesMap.get("objectKey"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getSourceName(1),valuesMap.get("sourceName"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getParentObjectKey(1),valuesMap.get("parentObjectKey"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getObjectName(1),System.currentTimeMillis(), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsHidden(1),valuesMap.get("isHidden"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsLocked(1),valuesMap.get("isLocked"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsReadonly(1),valuesMap.get("isReadonly"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsPinned(1),valuesMap.get("isPinned"), updateMetadataV1JsonBody);
    //	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getSourceFolder(),valuesMap.get("sourceFolder"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getVersion(1),valuesMap.get("version"), updateMetadataV1JsonBody);
   
    	//////////////////////
    	
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getStatus(2),valuesMap.get("status"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getObjectKey(2),valuesMap.get("objectKey"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getSourceName(2),valuesMap.get("sourceName"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getParentObjectKey(2),valuesMap.get("parentObjectKey"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getObjectName(2),System.currentTimeMillis(), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsHidden(2),valuesMap.get("isHidden"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsLocked(2),valuesMap.get("isLocked"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsReadonly(2),valuesMap.get("isReadonly"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsPinned(2),valuesMap.get("isPinned"), updateMetadataV1JsonBody);
    //	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getSourceFolder(),valuesMap.get("sourceFolder"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getVersion(2),valuesMap.get("version"), updateMetadataV1JsonBody);
   
    	////////////////////////
    	
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getStatus(3),valuesMap.get("status"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getObjectKey(3),valuesMap.get("objectKey"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getSourceName(3),valuesMap.get("sourceName"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getParentObjectKey(3),valuesMap.get("parentObjectKey"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getObjectName(3),System.currentTimeMillis(), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsHidden(3),valuesMap.get("isHidden"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsLocked(3),valuesMap.get("isLocked"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsReadonly(3),valuesMap.get("isReadonly"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getIsPinned(3),valuesMap.get("isPinned"), updateMetadataV1JsonBody);
    //	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getSourceFolder(),valuesMap.get("sourceFolder"), updateMetadataV1JsonBody);
    	updateMetadataV1JsonBody = setJsonData(NmsUpdateMetadataConstants.getVersion(3),valuesMap.get("version"), updateMetadataV1JsonBody);
   
    	return updateMetadataV1JsonBody;

    }
 //   updateMetadataJSONBody = setJsonData(NMSConstants.getStatus(),status, updateMetadataJSONBody);
    
//protected static Map<String, String> headerMap = null;
	
	// created a Hashmap to save all the headers.
/*	protected void createHeader() {
		headerMap=new HashMap<>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");

		// add x-api header key
		addXapiHeaderKey(headerMap);
	}
*/
    
    /**get a complete url for 'Update Metadata API'
     * @return
     */
  //  protected String getUpdateMetadataURL() {
  //      return apiUrls.get("baseURL") + serverConfig.get("updateMetadataURL");
  //  }
    
    /**get a complete url for 'Update Metadata API'
	 * @return
	 */
	protected static String getUpdateMetadataV1Url() {
		FrameworkLogger.logStep("getUpdateMetadataV1Url: Start");
		return getUpdateMetadataV1Url(serverConfig.get("updateMetadataV1Url"));
	//	return apiUrls.get("baseURL") + serverConfig.get("getTrashMetadataURL");
	}
	
	/**get a complete url for 'Update Metadata API'
	 * @return
	 */
	protected static String getUpdateMetadataV1Url(String urlValue) {
		FrameworkLogger.logStep("getUpdateMetadataV1Url: Start");
		return (apiUrls.get("baseURL") + urlValue);
	}
  
    protected String setUpdateMetadataV1JsonBody() throws IOException {
        //load json file
    	FrameworkLogger.logStep("setUpdateMetadataV1JsonBody: Start");
        String path = System.getProperty("user.dir") + "/resources/nmsTestData/updateMetadataBodyV1.js";
        File file = new File(path);
        updateMetadataV1JsonBody = JsonPath.parse(file).jsonString();
        updateMetadataV1JsonBody = updateJsonForUpdateMetadataApi();
        FrameworkLogger.logStep("setUpdateMetadataV1JsonBody: End");
       return updateMetadataV1JsonBody;
    }
    
    protected String setUpdateMetadataV1JsonBodyForMultipleObjects() throws IOException {
        //load json file
    	FrameworkLogger.logStep("setUpdateMetadataV1JsonBodyForMultipleObjects: Start");
        String path = System.getProperty("user.dir") + "/resources/nmsTestData/updateMetadataBodyV1WithMultipleObjects.js";
        File file = new File(path);
        updateMetadataV1JsonBody = JsonPath.parse(file).jsonString();
        updateMetadataV1JsonBody = updateJsonForUpdateMetadataApi();
        FrameworkLogger.logStep("setUpdateMetadataV1JsonBodyForMultipleObjects: End");
       return updateMetadataV1JsonBody;
    }
    
    protected String setUpdateMetadataV1JsonBodyForMultipleObjects1() throws IOException {
        //load json file
    	FrameworkLogger.logStep("setUpdateMetadataV1JsonBodyForMultipleObjects1: Start");
        String path = System.getProperty("user.dir") + "/resources/nmsTestData/updateMetadataBodyV1WithMultipleObjects2.js";
        File file = new File(path);
        updateMetadataV1JsonBody = JsonPath.parse(file).jsonString();
        updateMetadataV1JsonBody = updateJsonForUpdateMetadataApi();
        FrameworkLogger.logStep("setUpdateMetadataV1JsonBodyForMultipleObjects2: Start");
       return updateMetadataV1JsonBody;
    }
    
   
    /**
     * Method to get Update Metadata Response
     *
     * @return Update Metadata validatable response
     */
    
    protected ValidatableResponse triggerPutApiUpdateMetadataV1(String updateMetadataJsonBody) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiUpdateMetadataV1: Start");
 
		String strApiUrl=getUpdateMetadataV1Url();
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApiUpdateMetadataV1(updateMetadataJsonBody,serverConfig.get("updateMetadataV1Url"));
		
		FrameworkLogger.logStep("triggerPutApiUpdateMetadataV1: End");

    	return response;
    }
    	
	/**
	 * Method to get getTrashMetadata Response
	 * @return getTrashMetadata validatable response
	 */
    
	protected ValidatableResponse triggerPutApiUpdateMetadataV1(String updateMetadataJsonBody, String urlValue) throws IOException {
		FrameworkLogger.logStep("triggerPutApiUpdateMetadataV1: Start");	
		String strApiUrl=getUpdateMetadataV1Url(urlValue);
		
		//Call method to trigger GET API.
	
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,updateMetadataJsonBody);
		FrameworkLogger.logStep("triggerPutApiUpdateMetadataV1: End");
		return response;

	}
    
}
