package com.rjil.cloud.tej.apihelpers.boards;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class CopyFileFromAnotherBoardBaseScript extends BaseTestScript{

	protected static final String apiName = "CopyFileFromAnotherBoard";
	protected static String copyFileFromAnotherBoardJsonBody;
	//String boardJsonBody=null;
	public static String boardKey;
	
	protected String copyFileFromAnotherBoardURL(String newBoardKey) {
		FrameworkLogger.logStep("CopyFileFromAnotherBoardURL: Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get("copyFileFromAnotherBoardUrl").replace("{newBoardKey}", newBoardKey);
		FrameworkLogger.logStep("CopyFileFromAnotherBoardURL: End");
		return url;
	}
	
	protected String copyFileFromAnotherBoardURL(String newBoardKey, String urlValue) {
		FrameworkLogger.logStep("copyFileFromAnotherBoardURL: Start");
		String url = apiUrls.get("boardUrl") + urlValue;
		FrameworkLogger.logStep("copyFileFromAnotherBoardURL: End");
		return url;
	}
	

	protected String setCopyFileFromAnotherBoardJsonBody() throws IOException{
		
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/copyFileToAnotherBoardBody.js";
		File file = new File(path);
		copyFileFromAnotherBoardJsonBody= JsonPath.parse(file).jsonString();
		return copyFileFromAnotherBoardJsonBody;
	}

	
	
	protected ValidatableResponse triggerPostApiCopyFileFromAnotherBoard(String newBoardKey) throws IOException {

		FrameworkLogger.logStep("triggerPostApiCopyFileFromAnotherBoard: Start");

		String strApiUrl=copyFileFromAnotherBoardURL(newBoardKey);

		//boardJsonBody=setCreateBoardJsonBody();
		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, copyFileFromAnotherBoardJsonBody);

		FrameworkLogger.logStep("triggerPostApiCopyFileFromAnotherBoard: BoardKey== :-> "+ boardKey);

		return response;
	}
	
	protected ValidatableResponse triggerPostApiCopyFileFromAnotherBoard( Map<String, String> headerMap, String newBoardKey) throws IOException {

		FrameworkLogger.logStep("triggerPostApiCopyFileFromAnotherBoard: Start");

		
		// get url for create metadata for folder API
		String strApiUrl=copyFileFromAnotherBoardURL(newBoardKey);

		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, createHeader(headerMap), copyFileFromAnotherBoardJsonBody);

		FrameworkLogger.logStep("triggerPostApiCopyFileFromAnotherBoard: BoardKey== :-> "+ boardKey);

		return response;
	}
	

	protected ValidatableResponse triggerPostApiCopyFileFromAnotherBoard(String urlValue, String newBoardKey) throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreateBoard: Start");

		// get url for create metadata for folder API
		String strApiUrl=copyFileFromAnotherBoardURL(urlValue);

		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, copyFileFromAnotherBoardJsonBody);

		FrameworkLogger.logStep("triggerPostApiCreateBoard: BoardKey== :-> "+ boardKey);

		return response;
	}
	

	public static ValidatableResponse copyFileFromAnotherBoardServiceMethod(String newBoardKey, String sourceBoardKey , String sourceObjectKey) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("copyFileFromAnotherBoardServiceMethod: Start");
		
		CopyFileFromAnotherBoardBaseScript copy = new CopyFileFromAnotherBoardBaseScript();
		copy.createHeader();
		copyFileFromAnotherBoardJsonBody = copy.setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), sourceBoardKey, copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), sourceObjectKey, copyFileFromAnotherBoardJsonBody);
		
		ValidatableResponse response = copy.triggerPostApiCopyFileFromAnotherBoard(newBoardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("copyFileFromAnotherBoardServiceMethod: End");
		return response;
	}
	
	
	public static ValidatableResponse copyFileFromAnotherBoardServiceMethod(Map<String, String> headerMap1, String newBoardKey, String sourceBoardKey , String sourceObjectKey) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("copyFileFromAnotherBoardServiceMethod: Start");
		
		CopyFileFromAnotherBoardBaseScript copy = new CopyFileFromAnotherBoardBaseScript();
		copy.createHeader();
    	copyFileFromAnotherBoardJsonBody = copy.setCopyFileFromAnotherBoardJsonBody();	
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), sourceBoardKey, copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), sourceObjectKey, copyFileFromAnotherBoardJsonBody);
		
		ValidatableResponse response = copy.triggerPostApiCopyFileFromAnotherBoard(newBoardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("copyFileFromAnotherBoardServiceMethod: End");
		return response;
	}
}
