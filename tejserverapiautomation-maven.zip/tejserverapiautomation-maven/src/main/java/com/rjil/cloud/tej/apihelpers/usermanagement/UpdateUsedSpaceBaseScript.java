/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.usermanagement;

import java.io.File;
import java.io.IOException;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

/**
 * @author Prateek
 * 
 * Base class for Update used space api
 *
 */
public class UpdateUsedSpaceBaseScript extends BaseTestScript{

	protected String updateUsedSpaceJsonBody;
	protected static final String apiName = "UpdatdeUsedSpace";
	
	public UpdateUsedSpaceBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * Method for Creating update auto backup settings Url
	 * 
	 * @return
	 */
	protected String getUpdateUsedSpaceUrl() {
		FrameworkLogger.logStep("getUpdateUsedSpaceUrl:-> Start");
		String url = apiUrls.get("baseURL") + serverConfig.get("updateAutoBackupSettingsUrl");

		FrameworkLogger.logStep("getUpdateUsedSpaceUrl:-> End");
		return url;
	}
	
	protected String getUpdateUsedSpaceUrl(String url) {
		FrameworkLogger.logStep("getUpdateUsedSpaceUrl:-> Start");
		String apiUrl = apiUrls.get("baseURL") + serverConfig.get(url);

		FrameworkLogger.logStep("getUpdateUsedSpaceUrl:-> End");
		return apiUrl;
	}

	/**
	 * Method for Creating update Auto Backup Settings body
	 * 
	 * @return
	 */

	protected String setUpdateUsedSpaceJsonBody() throws IOException {
		FrameworkLogger.logStep("setUpdateUsedSpaceJsonBody:-> Start");
		String path = System.getProperty("user.dir")
				+ "/resources/userManagementTestData/updateUsedSpaceJsonBody.js";
		File file = new File(path);
		updateUsedSpaceJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setUpdateUsedSpaceJsonBody:-> End");
		return updateUsedSpaceJsonBody;
	}

	/**
	 * Method to get the response after triggering update auto backup settings
	 * Api
	 * 
	 * @return
	 * @throws IOException
	 */
	protected ValidatableResponse triggerPutApiUpdateUsedSpace() throws IOException {

		FrameworkLogger.logStep("triggerPutApiUpdateUsedSpace:-> Start");

		// get url for autobackup settings url
		String strApiUrl = getUpdateUsedSpaceUrl();

		// get response from update auto backup setings api
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, updateUsedSpaceJsonBody);

		FrameworkLogger.logStep("triggerPutApiUpdateUsedSpace:-> End");
		return response;
	}
	
	protected ValidatableResponse triggerPutApiUpdateUsedSpace(String apiUrl) throws IOException {

		FrameworkLogger.logStep("triggerPutApiUpdateUsedSpace:-> Start");

		// get url for store autobackup settings url
		String strApiUrl = getUpdateUsedSpaceUrl(apiUrl);

		// get response from store auto backup settings api
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, updateUsedSpaceJsonBody);

		FrameworkLogger.logStep("triggerPutApiUpdateUsedSpace:-> End");
		return response;
	}
}
