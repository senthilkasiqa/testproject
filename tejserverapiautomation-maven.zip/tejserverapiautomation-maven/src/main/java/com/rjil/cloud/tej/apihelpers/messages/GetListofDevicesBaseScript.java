package com.rjil.cloud.tej.apihelpers.messages;

import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

public class GetListofDevicesBaseScript extends BaseTestScript{

	 protected static final String apiName="GetListOfAllDevices";
    /**
     * @author Sanjeevanee Kanase
     * <p>
     * It creates the url for API 
     */
    private String getListofDevicesForMessagesUrl() {
		FrameworkLogger.logStep("getListofDevicesForMessagesUrl:-> Start");

		String apiUrl=apiUrls.get("baseMessagesURL") + serverConfig.get("getListofDevicesForMessagesUrl");
		FrameworkLogger.logStep("getListofDevicesForMessagesUrl:-> End");
		return apiUrl;
    }
    
    /**
     * @return validatable response for getListofDevicesForMessages
     * @author 
     * <p>
     * Call the API and return the Response
     */
    
    protected ValidatableResponse triggerGetApigetListofDevicesForMessages() {
		FrameworkLogger.logStep("getListofDevicesForMessages:-> Start");
        // setContactBackupJsonBody();
		
		String strApiUrl=getListofDevicesForMessagesUrl();
		
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
		
		FrameworkLogger.logStep("getListofDevicesForMessages:-> End");
		return response;
    }
}
