package com.rjil.cloud.tej.apihelpers.contacts;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
public class CabBaseScript extends BaseTestScript {
	protected static final String moduleName = "Contacts";
	protected static final String apiName = "GetCab";
	
	public CabBaseScript(){
		globalApiName=apiName;
	}
	// Overload the method.
	protected Map<String, String> createHeader() {

	headerMap = initializeHeader();
		// get data for last two days.
		headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), Utils.getTime(-1)); 
	//	headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), "2013-01-10 11:11:11.000000"); 
		// Chunk size is 100 byte
	headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "100"); 
	//	headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "10"); 
		headerMap.put(HeaderParameters.ONLYACTIVE.getValue(), "True"); // Only
																		// active
																		// records.
		return headerMap;
	}
	// Overload the method.
	protected Map<String, String> createHeader(Map<String, String> deviceInfo) {
		headerMap = initializeHeader(deviceInfo);
		headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), Utils.getTime(-1)); // get
																					// data
																					// for
																					// last
																					// two
																					// days.
		headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "100"); // Chunk
																		// size
																		// is
																		// 100
																		// byte
		headerMap.put(HeaderParameters.ONLYACTIVE.getValue(), "True"); // Only
																		// active
																		// records.
		return headerMap;
	}
	/**
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         It creates the url for API
	 */
	private String getCabURL() {
		return apiUrls.get("baseContactURL") + serverConfig.get("cabURL");
	}
	/**
	 * @return validatable response for Contact Backup
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the Backup API and return the Response
	 */
	protected ValidatableResponse triggerGetApiCab() {
		FrameworkLogger.logStep("triggerGetApiCab:-> String");
		// setContactBackupJsonBody();
		String strApiUrl = getCabURL();
		headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "100"); 
		headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), Utils.getTime(-1));
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		Utils.addRequestResponseToLogger();
		FrameworkLogger.logStep("triggerGetApiCab:-> End");
		return response;
	}
	
	//triggerGetApiCabForNext();
	protected ValidatableResponse triggerGetApiCabForNext() {
		FrameworkLogger.logStep("triggerGetApiCab:-> String");
		// setContactBackupJsonBody();
		String strApiUrl =getCabURL();
		FrameworkLogger.logStep("strApiUrl==="+strApiUrl);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		//Utils.addRequestResponseToLogger();
		FrameworkLogger.logStep("triggerGetApiCab:-> End");
		return response;
	}
	
	/**
	 * @return validatable response for Contact Backup
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the Backup API and return the Response
	 */
	protected ValidatableResponse triggerGetApiCab(String url) {
		FrameworkLogger.logStep("triggerGetApiCab:-> String");
		// setContactBackupJsonBody();
		ValidatableResponse response = triggerGetApi(url, headerMap);
		FrameworkLogger.logStep("triggerGetApiCab:-> End");
		return response;
	}
	
	
	protected String getUrlCabForNext(String nextPageDate) {
		FrameworkLogger.logStep("triggerGetApiCab:-> String");
		// setContactBackupJsonBody();
		String url = getCabURL()+"?nextPageDate="+nextPageDate;
		return url;
	}
	// This method accepts the response and returns the list of contacts not
	// matching with deviceId.
	public static List<String> getContactListNotForDeviceIdFromCabApiResponse(ValidatableResponse response,
			String deviceId, int numberOfContacts) {
		FrameworkLogger.logStep("getContactListNotForDeviceIdFromCabApiResponse:-> Start");
		// String deviceId=serverConfig.get("deviceKey");
		List<String> contactList = new ArrayList<>();
		int size = -1;
		size = getSizeOfContactsInCabApiResponse(response);
		for (int i = 0; i < size; i++) {
			if (contactList.size() == numberOfContacts)
				break;
			String strDeviceIdInResponse = response.extract().path("contacts[" + i + "].device_id_list");
			FrameworkLogger
					.logStep("Comparing device_id_list= " + strDeviceIdInResponse + "; with deviceId=" + deviceId);
			if (!strDeviceIdInResponse.contains(deviceId)) {
				FrameworkLogger.logStep("Contact is for OTHER device: " + strDeviceIdInResponse);
				String strContactIdInResponse = response.extract().path("contacts[" + i + "].contactid");
				contactList.add(strContactIdInResponse);
			} else {
				FrameworkLogger.logStep("Contact is for SAME device: " + strDeviceIdInResponse);
			}
		}
		FrameworkLogger.logStep("getContactListNotForDeviceIdFromCabApiResponse:-> End");
		return contactList;
	}
	/**
	 * @return validatable response for CAB
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the Backup API and return the Response
	 * @throws VerificationFailException
	 */
	public static ValidatableResponse getCabForDays(int numberOfPrevDays) throws VerificationFailException {
		FrameworkLogger.logStep("getCabForDays:-> Start");
		// Create an object of the CAB api.
		CabBaseScript cabBaseObj = new CabBaseScript();
		// We can change the time in header from here.
		cabBaseObj.createHeader();
		cabBaseObj.headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), Utils.getMidnightTime(-numberOfPrevDays)); // get
																														// data
																														// for
																														// last
																														// specified
																														// days.
		// Call the API to call Cab API.
		ValidatableResponse response = cabBaseObj.triggerGetApiCab();
		// Get and verify the status code.
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status of CAB API");
		FrameworkLogger.logStep("getCabForDays:-> End");
		return response;
	}
	/**
	 * @return validatable response for CAB
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the Backup API and return the Response
	 * @throws VerificationFailException
	 */
	public static ValidatableResponse getCabForDays(int numberOfPrevDays, String strChunkSize, String strOnlyActive)
			throws VerificationFailException {
		FrameworkLogger.logStep("getCabForDays:-> Start");
		// Create an object of the CAB api.
		CabBaseScript cabBaseObj = new CabBaseScript();
		// We can change the time in header from here.
		cabBaseObj.createHeader();
		cabBaseObj.headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), Utils.getMidnightTime(-numberOfPrevDays)); // get
																														// data
																														// for
																														// last
																														// specified
																														// days.
		cabBaseObj.headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), strChunkSize); // Chunk
																						// size
																						// in
																						// byte
		cabBaseObj.headerMap.put(HeaderParameters.ONLYACTIVE.getValue(), strOnlyActive); // Only
																							// active(true)/inactive(false)
																							// records.
		// Call the API to call Cab API.
		ValidatableResponse response = cabBaseObj.triggerGetApiCab();
		// Get and verify the status code.
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status of CAB API");
		FrameworkLogger.logStep("getCabForDays:-> End");
		return response;
	}
	/**
	 * @return validatable response for CAB
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the CAB API and return the Response for specified Date with
	 * @throws VerificationFailException
	 */
	public static ValidatableResponse getCabForDate(Map<String, String> deviceInfoMap, String startingDate)
			throws VerificationFailException {
		FrameworkLogger.logStep("getCabForDate:-> Start");
		// CabBaseScript cabBaseObj=new CabBaseScript();
		ValidatableResponse response = getCabForDateActiveInactiveRecords(deviceInfoMap, startingDate, "True");
		FrameworkLogger.logStep("getCabForDate:-> End");
		return response;
	}
	// This method will get Active/Inactive data based on given parameter.
	public static ValidatableResponse getCabForDateActiveInactiveRecords(Map<String, String> deviceInfoMap,
			String startingDate, String strActiveInactive) throws VerificationFailException {
		FrameworkLogger.logStep("getCabForDateActiveInactiveRecords:-> Start");
		// Create an object of the CAB api.
		CabBaseScript cabBaseObj = new CabBaseScript();
		// We can change the time in header from here.
		cabBaseObj.createHeader(deviceInfoMap);
		cabBaseObj.headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), startingDate); // get
																							// data
																							// from
																							// specified
																							// date.
		cabBaseObj.headerMap.put(HeaderParameters.ONLYACTIVE.getValue(), strActiveInactive); // Only
																								// active
																								// records.
		// Call the API to call Cab API.
		ValidatableResponse response = cabBaseObj.triggerGetApiCab();
		// Get and verify the status code.
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status of CAB API");
		FrameworkLogger.logStep("getCabForDateActiveInactiveRecords:-> End");
		return response;
	}
	/**
	 * @return validatable response for CAB
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the CAB API and return the Response for specified Date
	 * @throws VerificationFailException
	 */
	public static ValidatableResponse getCabForDate(String startingDate, String strChunkSize, String strOnlyActive)
			throws VerificationFailException {
		FrameworkLogger.logStep("getCabForDate:-> Start");
		// Create an object of the CAB api.
		CabBaseScript cabBaseObj = new CabBaseScript();
		// We can change the time in header from here.
		cabBaseObj.createHeader();
		cabBaseObj.headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), startingDate); // get
																							// data
																							// from
																							// specified
																							// date.
		cabBaseObj.headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), strChunkSize); // Chunk
																						// size
																						// in
																						// byte
		cabBaseObj.headerMap.put(HeaderParameters.ONLYACTIVE.getValue(), strOnlyActive); // Only
																							// active(true)/inactive(false)
																							// records.
		// Call the API to call Cab API.
		ValidatableResponse response = cabBaseObj.triggerGetApiCab();
		// Get and verify the status code.
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status of CAB API");
		FrameworkLogger.logStep("getCabForDate:-> End");
		return response;
	}
	// This method accepts the response and returns the number of Contacts in
	// CAB response.
	public static int getSizeOfContactsInCabApiResponse(ValidatableResponse response) {
		FrameworkLogger.logStep("getSizeOfContactsInCabApiResponse:-> Start");
		int size = -1;
		ArrayList<String> list = response.extract().path("contacts");
		size = list.size();
		FrameworkLogger.logStep("getSizeOfContactsInCabApiResponse:-> End");
		return size;
	}
	// This method accepts the response, number of contacts and returns the list
	// of contacts and its info.
	public static List<String[]> getContactInfoFromCabApiResponse(ValidatableResponse response) {
		FrameworkLogger.logStep("getContactInfoFromCabApiResponse:-> Start");
		String deviceId = serverConfig.get("deviceKey");
		int numberOfContacts = -1;
		List<String[]> infoList = new ArrayList<>();
		infoList = getSomeContactInfoFromCabApiResponseForDevice(response, deviceId, numberOfContacts);
		FrameworkLogger.logStep("getContactInfoFromCabApiResponse:-> End");
		return infoList;
	}
	// This method accepts the response, number of contacts and returns the list
	// of contacts and its info.
	public static List<String[]> getContactInfoFromCabApiResponse(ValidatableResponse response, int numberOfContacts) {
		FrameworkLogger.logStep("getContactInfoFromCabApiResponse:-> Start");
		String deviceId = serverConfig.get("deviceKey");
		List<String[]> infoList = new ArrayList<>();
		infoList = getSomeContactInfoFromCabApiResponseForDevice(response, deviceId, numberOfContacts);
		FrameworkLogger.logStep("getContactInfoFromCabApiResponse:-> End");
		return infoList;
	}
	// This method accepts the response, deviceId and returns the list of
	// contacts and its info matching with device Id.
	public static List<String[]> getSomeContactInfoFromCabApiResponseForDevice(ValidatableResponse response,
			String deviceId, int numberOfContacts) {
		FrameworkLogger.logStep("getSomeContactInfoFromCabApiResponseForDevice:-> Start");
		// String deviceId=serverConfig.get("deviceKey");
		List<String[]> infoList = new ArrayList<>();
		int size = -1;
		size = getSizeOfContactsInCabApiResponse(response);
		for (int i = 0; i < size; i++) {
			if (numberOfContacts < 0) {
				// Nothing to check.
			} else {
				if (infoList.size() == numberOfContacts)
					break;
			}
			String strDeviceIdInResponse = response.extract().path("contacts[" + i + "].device_id_list");
			FrameworkLogger
					.logStep("Comparing device_id_list= " + strDeviceIdInResponse + "; with deviceId=" + deviceId);
			if (strDeviceIdInResponse.contains(deviceId)) {
				FrameworkLogger.logStep("Contact is for SAME device: " + strDeviceIdInResponse);
				String strContactIdInResponse = response.extract().path("contacts[" + i + "].contactid");
				String strVcardInResponse = response.extract().path("contacts[" + i + "].jcard");
				String strContactInfo[] = { strContactIdInResponse, strVcardInResponse };
				infoList.add(strContactInfo);
			} else {
				FrameworkLogger.logStep("Contact is for OTHER device: " + strDeviceIdInResponse);
			}
		}
		FrameworkLogger.logStep("getSomeContactInfoFromCabApiResponseForDevice:-> End");
		return infoList;
	}
	// This method accepts the response, deviceId and returns the list of
	// contacts and its info matching with device Id.
	public static List<String[]> getSomeContactInfoFromCabApiResponseContactIdVcard(ValidatableResponse response,
			int numberOfContacts) {
		FrameworkLogger.logStep("getSomeContactInfoFromCabApiResponseContactIdVcard:-> Start");
		// String deviceId=serverConfig.get("deviceKey");
		List<String[]> infoList = new ArrayList<>();
		int size = -1;
		size = getSizeOfContactsInCabApiResponse(response);
		for (int i = 0; i < size; i++) {
			if (numberOfContacts < 0) {
				// Nothing to check.
			} else {
				if (infoList.size() == numberOfContacts)
					break;
			}
			String strContactIdInResponse = response.extract().path("contacts[" + i + "].contactid");
			String strVcardInResponse = null;
			try {
				strVcardInResponse = response.extract().path("contacts[" + i + "].jcard");
			} catch (Exception e) {
				strVcardInResponse = "Vcard not found";
				FrameworkLogger.logStep("Vcard not found for contactId:-> " + strContactIdInResponse);
			}
			String strContactInfo[] = { strContactIdInResponse, strVcardInResponse };
			infoList.add(strContactInfo);
		}
		FrameworkLogger.logStep("getSomeContactInfoFromCabApiResponseContactIdVcard:-> End");
		return infoList;
	}
	// This method accepts the response and returns the list of contactIds.
	public static List<String> getSomeContactInfoFromCabApiResponseContactIdOnly(ValidatableResponse response,
			int numberOfContacts) {
		FrameworkLogger.logStep("getSomeContactInfoFromCabApiResponseContactIdOnly:-> Start");
		// String deviceId=serverConfig.get("deviceKey");
		List<String> infoList = new ArrayList<>();
		int size = -1;
		size = getSizeOfContactsInCabApiResponse(response);
		for (int i = 0; i < size; i++) {
			if (numberOfContacts < 0) {
				// Nothing to check.
			} else {
				if (infoList.size() == numberOfContacts)
					break;
			}
			String strContactIdInResponse = response.extract().path("contacts[" + i + "].contactid");
			infoList.add(strContactIdInResponse);
		}
		FrameworkLogger.logStep("getSomeContactInfoFromCabApiResponseContactIdOnly:-> End");
		return infoList;
	}
	// This method accepts the response, contactInfo, deviceId and after
	// validation returns true/false.
	public static boolean verifyContactInfoInCabApiResponse(ValidatableResponse response, String contactId,
			String strVcard, String deviceId) {
		FrameworkLogger.logStep("verifyContactInfoInCabApiResponse:-> Start");
		boolean result = false;
		// String deviceId=serverConfig.get("deviceKey");
		List<String[]> infoList = new ArrayList<>();
		int size = -1;
		// Get contact info from CAB response.
		List<String[]> contactIdVcardList = getSomeContactInfoFromCabApiResponseForDevice(response, deviceId, -1);
		size = contactIdVcardList.size();
		FrameworkLogger.logStep("size of list: " + size);
		for (String[] contactIdVcardStrArr : contactIdVcardList) {
			if (contactIdVcardStrArr[0].equalsIgnoreCase(contactId)) {
				FrameworkLogger.logStep("ContactId found : " + contactId);
				FrameworkLogger.logStep("Comparing both VCard : " + contactIdVcardStrArr[1] + " with : " + strVcard);
				if (contactIdVcardStrArr[1].equalsIgnoreCase(strVcard)) {
					FrameworkLogger.logStep("ContactVcard matched");
					return true;
				}
			}
		}
		FrameworkLogger.logStep("verifyContactInfoInCabApiResponse:-> End");
		return result;
	}
	// This method accepts the response, contactInfo, deviceId and after
	// validation returns true/false.
	public static boolean verifyContactInfoInCabApiResponse(ValidatableResponse response, String contactId) {
		FrameworkLogger.logStep("verifyContactInfoInCabApiResponse:-> Start");
		boolean result = false;
		int size = -1;
		// Get contact info from CAB response.
		List<String> contactIdList = getSomeContactInfoFromCabApiResponseContactIdOnly(response, -1);
		size = contactIdList.size();
		FrameworkLogger.logStep("size of list: " + size);
		// Check contact Id is present in CabResponse or not.
		result = contactIdList.contains(contactId);
		FrameworkLogger.logStep("verifyContactInfoInCabApiResponse:-> End");
		return result;
	}
	// This method accepts the response, contactInfo, deviceId and after
	// validation returns true/false.
	public static boolean verifyContactInfoInCabApiResponse(ValidatableResponse response, String contactId,
			String strVcard) {
		FrameworkLogger.logStep("verifyContactInfoInCabApiResponse:-> Start");
		boolean result = false;
		// Get contact info from CAB response.
		List<String[]> contactIdVcardList = getSomeContactInfoFromCabApiResponseContactIdVcard(response, -1);
		// Check contact Id and Vcard is present in CabResponse or not.
		for (String[] contactIdVcardFromResponse : contactIdVcardList) {
			FrameworkLogger.logStep("Comparing, ContactId from Response:- " + contactIdVcardFromResponse[0]
					+ " With received contactId:-> " + contactId);
			if (contactIdVcardFromResponse[0].equalsIgnoreCase(contactId)) {
				FrameworkLogger.logStep("ContactId Found; Now comparing Vcard:- " + contactIdVcardFromResponse[1]
						+ " With received Vcard:-> " + strVcard);
				if (contactIdVcardFromResponse[1].equalsIgnoreCase(strVcard)) {
					FrameworkLogger.logStep("Vcard also matched.");
					return true;
				}
			}
		}
		FrameworkLogger.logStep("verifyContactInfoInCabApiResponse:-> End");
		return result;
	}
	// Search the given contact Id in response and return the index.
	public static int searchSerGuidAndGetIndexValue(ValidatableResponse response, String serGuid) throws IOException {
		FrameworkLogger.logStep("searchSerGuidAndGetIndexValue:-> Start");
		int contactidIndex = -1;
		int sizeOfContactsArray = response.extract().jsonPath().getList("contacts").size();
		for (int i = 0; i < sizeOfContactsArray; i++) {
			String contactid = response.extract().path("contacts[" + i + "].contactid");
			FrameworkLogger.logStep(i + "-> contactid:->" + contactid + ",comparing with serGuid: " + serGuid);
			if (contactid.equalsIgnoreCase(serGuid)) {
				FrameworkLogger.logStep("FOUND");
				contactidIndex = i;
				break;
			}
		}
		FrameworkLogger.logStep("searchSerGuidAndGetIndexValue:-> End");
		return contactidIndex;
	}
	// This method accepts the response, contactId and searches the contact id in response and returns the index
	public static int getIndexOfContactIdInCabApiResponse(ValidatableResponse response, String contactId) {
		FrameworkLogger.logStep("getIndexOfContactIdInCabApiResponse:-> Start");
		int indexToReturn=-1;
		int size = getSizeOfContactsInCabApiResponse(response);
		FrameworkLogger.logStep("Number of contacts in CAB response : " + size);
		for(int i=0; i< size; i++){
			String strContactIdInResponse = response.extract().path("contacts[" + i + "].contactid");
			FrameworkLogger.logStep("Comparing : contactId: " + contactId + " with strContactIdInResponse: " + strContactIdInResponse);
			if(contactId.equalsIgnoreCase(strContactIdInResponse)){
				indexToReturn=i;
				FrameworkLogger.logStep("Searching contactId found.");
				break;
			}
		}
//		
		FrameworkLogger.logStep("getIndexOfContactIdInCabApiResponse:-> End");
		return indexToReturn;
	}
	
	
       public static int getOccuranceOfContactInCab(String cond, String contactid)
       {
    	   int count = 0;
    	   
    	   String nextPageDate ="2014-01-01 17:03:37.187376";
    	   WhileLoop:
    	   while(!(nextPageDate.contains(cond)))
    	   {   CabBaseScript cab = new CabBaseScript();
    		   System.out.println("Value of nextPageDate======"+nextPageDate);
    		   cab.createHeader();
    		   cab.headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), nextPageDate); 
    		   cab.headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "10");
    		 
    		//   ValidatableResponse response = cab.triggerGetApiCabForNext("2014-01-01 17:03:37.187376");
    		   ValidatableResponse response = cab.triggerGetApiCabForNext();
    		   
    		   int indexToReturn=-1;
    		   int size = getSizeOfContactsInCabApiResponse(response);
    		   FrameworkLogger.logStep("Number of contacts in CAB response : " + size);
    		   for(int i=0; i< size; i++)
    		   {
    			   String strContactIdInResponse = response.extract().path("contacts[" + i + "].contactid");
    			   FrameworkLogger.logStep("Comparing : contactId: " + contactid + " with strContactIdInResponse: " + strContactIdInResponse);
    			   if(contactid.equalsIgnoreCase(strContactIdInResponse))
    			   {
    				   FrameworkLogger.logStep("Contact matching here**************************************");
    				   indexToReturn=i;
    				   count++;
    				   FrameworkLogger.logStep("NOW WE GOT FIRST COUNT ===============:-> " + count);
    				   break WhileLoop;
    			   }
    			  
    		   }	
    		   
    		   nextPageDate = response.extract().path("next");
    		   FrameworkLogger.logStep("NEXTPAGEURL===============:-> " + nextPageDate);
    		   String completeUrlInCab[]=nextPageDate.trim().split("\\?");
    	        FrameworkLogger.logStep("URL - completeUrlInCab[0]:-> " + completeUrlInCab[0]);
    			 nextPageDate=(nextPageDate.trim().split("="))[1];
    			 FrameworkLogger.logStep("Match not found so we are here***************************************");
    	     //   FrameworkLogger.logStep("datePartFromCabUrl:-> " + datePartFromCabUrl);
    	     //   cab.headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), datePartFromCabUrl); 
    		//   response = cab.triggerGetApiCabForNext();
    			
    	   }
    	   return count;
       }
       public static ValidatableResponse getCabWithHashForDate(String startingDate) throws VerificationFailException {
   		FrameworkLogger.logStep("getCabForDate:-> Start");
   		// Get 1st deviceId.
   		String strDeviceId1 = serverConfig.get("deviceKey");
   		ValidatableResponse response = getCabForDateActiveInactiveRecordsWithHash(deviceOwnerInfo,
   				startingDate, "True");
   		FrameworkLogger.logStep("getCabForDate:-> End");
   		return response;
   	}
    // This method will get Active/Inactive data based on given parameter.
   	public static ValidatableResponse getCabForDateActiveInactiveRecordsWithHash(Map<String, String> deviceInfoMap,
   			String startingDate, String strActiveInactive) throws VerificationFailException {
   		FrameworkLogger.logStep("getCabForDateActiveInactiveRecords:-> Start");
   		// Create an object of the CAB api.
   		CabBaseScript cabBaseObj = new CabBaseScript();
   		// We can change the time in header from here.
   		cabBaseObj.createHeader(deviceInfoMap);
   		cabBaseObj.headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), startingDate); // get
   																							// data
   																							// from
   																							// specified
   																							// date.
   		cabBaseObj.headerMap.put(HeaderParameters.ONLYACTIVE.getValue(), strActiveInactive); // Only
   		cabBaseObj.headerMap.put(HeaderParameters.XAPPVERSION.getValue(), "1.0");											// active
   																								// records.
   		// Call the API to call Cab API.
   		ValidatableResponse response = cabBaseObj.triggerGetApiCab();
   		// Get and verify the status code.
   		int status = response.extract().statusCode();
   		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status of CAB API");
   		FrameworkLogger.logStep("getCabForDateActiveInactiveRecords:-> End");
   		return response;
   	}
   	
   	/**
	 * @return validatable response for CAB
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the CAB API and return the Response for specified Date
	 * @throws VerificationFailException
	 */
	public static ValidatableResponse getCabForDate(String startingDate) throws VerificationFailException {
		FrameworkLogger.logStep("getCabForDate:-> Start");
	//	multiUserRepositoryMap= new HashMap<String,Map<String,Map<String,String>>>();
		// Get 1st deviceId.
		String strDeviceId1=deviceOwnerInfo.get("deviceKey");
	
		ValidatableResponse response = getCabForDateActiveInactiveRecords(deviceOwnerInfo,
				startingDate, "True");
		FrameworkLogger.logStep("getCabForDate:-> End");
		return response;
	}
	// This method will get Active/Inactive data based on given parameter.
	public static ValidatableResponse getCabForDateActiveInactiveRecords(String startingDate, String strActiveInactive)
			throws VerificationFailException {
		FrameworkLogger.logStep("getCabForDateActiveInactiveRecords:-> Start");
		String strDeviceId1 = serverConfig.get("deviceKey");
		// Call the method with HeaderMap.
		ValidatableResponse response = getCabForDateActiveInactiveRecords(deviceOwnerInfo,
				startingDate, strActiveInactive);
		FrameworkLogger.logStep("getCabForDateActiveInactiveRecords:-> End");
		return response;
	}
}