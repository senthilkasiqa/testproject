package com.rjil.cloud.tej.apihelpers.boards;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class BoardsDeltaSyncBaseScript extends BaseTestScript{

	protected static final String apiName = "BoardsDeltaSync";

	protected String getBoardsDeltaSyncURL() {
		FrameworkLogger.logStep("getBoardsDeltaSyncURL:-> Start");
		return apiUrls.get("boardUrl") + serverConfig.get("boardsDeltaSyncUrl");
	}

	protected String getBoardsDeltaSyncURL(String url,String page,String limit) {
		FrameworkLogger.logStep(" getBoardsDeltaSyncURL:-> Start");
		//return apiUrls.get("boardUrl") + url;
		String replaceUrl= apiUrls.get("boardUrl") + serverConfig.get(url);
		String boardDeltaSyncUrl=replaceUrl.replace("{page}", page).replace("{limit}", limit);
		return boardDeltaSyncUrl;
	}

	protected Map<String, String> createHeader(String ifModifiedSince) {
		FrameworkLogger.logStep("createHeader:-> Start");

		headerMap=initializeHeader();
		headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), ifModifiedSince);
		FrameworkLogger.logStep("createHeader:-> End");
		return headerMap;
	}

	protected Map<String, String> createHeader(String ifModifiedSince, Map <String, String>device1Info) {
		FrameworkLogger.logStep("createHeader:-> Start");

		headerMap=initializeHeader(device1Info);
		headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), ifModifiedSince);
		FrameworkLogger.logStep("createHeader:-> End");
		return headerMap;
	}


	protected ValidatableResponse triggerGetBoardsDeltaSync() throws IOException {
		FrameworkLogger.logStep("triggerGetBoardsDeltaSync:-> Start");
		String strApiUrl = getBoardsDeltaSyncURL();
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetBoardsDeltaSync:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetBoardsDeltaSync(String url,String page,String limit) throws IOException {
		FrameworkLogger.logStep("triggerGetBoardsDeltaSync:-> Start");
		String strApiUrl = getBoardsDeltaSyncURL(url,page,limit);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetBoardsDeltaSync:-> End");
		return response;
	}

	public static ValidatableResponse getBoardsDeltaSyncService(String ifModifiedSince)
	{
		BoardsDeltaSyncBaseScript boardsDeltaSync = new BoardsDeltaSyncBaseScript();
		boardsDeltaSync.createHeader(ifModifiedSince);
		String strApiUrl = boardsDeltaSync.getBoardsDeltaSyncURL();
		ValidatableResponse response =boardsDeltaSync.triggerGetApi(strApiUrl, boardsDeltaSync.headerMap);
		return response;
	}
	
	public static ValidatableResponse getBoardsDeltaSyncService(String ifModifiedSince, Map <String, String>device1Info)
	{
		BoardsDeltaSyncBaseScript boardsDeltaSync = new BoardsDeltaSyncBaseScript();
		boardsDeltaSync.createHeader(ifModifiedSince, device1Info);
		String strApiUrl = boardsDeltaSync.getBoardsDeltaSyncURL();
		ValidatableResponse response = boardsDeltaSync.triggerGetApi(strApiUrl, boardsDeltaSync.headerMap);
		return response;
	}


}
