/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.download;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 * 
 * Base class for Bulk downlaod Api
 *
 */
public class BulkDownloadBaseScript extends BaseTestScript{

    public static String bulkDownloadJsonBody;
    protected static final String apiName = "BulkDownload";
//    protected static Map<String, String> headerMap = null;
    
    public BulkDownloadBaseScript(){
    	globalApiName=apiName;
    }
	
 // Overload the method.
 		public Map<String, String> createHeader() {
 			FrameworkLogger.logStep("createHeader -> Start");

 			headerMap = initializeHeader();

 		    	//Remove device key from header for this API.
 			//headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
 			if(serverConfig.get("deviceType").equalsIgnoreCase("W")){
 				headerMap.put("X-Device-Type", serverConfig.get("deviceType"));
 			}

 			FrameworkLogger.logStep("createHeader -> End");
 			return headerMap;
 		}

    
    /**get a complete url for 'Update Notification API' negative test cases
     * @return
     */
    public String getBulkDownloadUrl(String url) {
    //	FrameworkLogger.logStep("getBulkDownloadUrl: Start");
     //   String apiUrl= apiUrls.get("baseURL") + serverConfig.get(url);
        FrameworkLogger.logStep("getBulkDownloadUrl: Start");
		String bulkDownloadUrl = apiUrls.get("downloadPublicIp")
				+ serverConfig.get(url);
		//String sharedFileDownloadUrl = apiUrl2.replace("{shardKey}", shardKey);
		FrameworkLogger.logStep("sharedFileDownloadUrl=======>" + bulkDownloadUrl);
		FrameworkLogger.logStep("getBulkDownloadUrl: End");
		return bulkDownloadUrl;
   
    }
    
    public String setBulkDownloadJsonBody() throws IOException {
        //load json file
    	//createHeader();
    	FrameworkLogger.logStep("setUpdateNotificationJsonBody: Start");
        String path = System.getProperty("user.dir") + "/resources/downloadTestData/bulkDownloadBody.js";
        File file = new File(path);
        bulkDownloadJsonBody = JsonPath.parse(file).jsonString();
        FrameworkLogger.logStep("setUpdateNotificationJsonBody: End");
       return bulkDownloadJsonBody;
    }
    
   
    
    /**
     * Method to get Update Notification Response for negative test
     * @return Update Notification validatable response
     */
    public ValidatableResponse triggerPostApiBulkDownloadApiResponse(String url) throws IOException {
    	
    	FrameworkLogger.logStep("triggerPostApiBulkDownloadApiResponse: Start");     
		String strApiUrl=getBulkDownloadUrl(url);
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPostApi(strApiUrl,headerMap,bulkDownloadJsonBody);
		
		String zipUrl=response.extract().path("zipUrl");
		repositoryMap.put(RepositoryParameterEnum.ZIPURL.getValue(), zipUrl);

		FrameworkLogger.logStep("triggerPostApiBulkDownloadApiResponse: End");
    	return response;
    }
    
    public static void bulkDownloadApiServiceMethod(String url) throws IOException{
    	BulkDownloadBaseScript bulkDownloadBaseScript = new BulkDownloadBaseScript();
    	bulkDownloadBaseScript.createHeader();
    	bulkDownloadBaseScript.setBulkDownloadJsonBody();
    	bulkDownloadBaseScript.triggerPostApiBulkDownloadApiResponse(url);
    }

}
