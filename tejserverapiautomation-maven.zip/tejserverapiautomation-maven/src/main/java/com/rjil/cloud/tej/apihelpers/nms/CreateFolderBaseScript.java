package com.rjil.cloud.tej.apihelpers.nms;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.enums.NmsParameters;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

import static com.jayway.restassured.RestAssured.given;

public class CreateFolderBaseScript extends BaseTestScript {

	protected static final String apiName = "CreateFolder";
	protected static String folderJsonBody;
	protected static String folderName = "folder_";
//	protected Map<String, String> headerMap = null;
	public static int max = 9999;
	public static int min = 100;
	public static String folderKey;
	
	public CreateFolderBaseScript(){
		globalApiName=apiName;
	}

/*	protected void createHeader() {
		FrameworkLogger.logStep("createHeader:-> Start");
		headerMap = new HashMap<>();

		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");
		addXapiHeaderKey(headerMap);

		FrameworkLogger.logStep("createHeader:-> End");

	}
*/
	/**
	 * get url for Create Folder
	 * 
	 * @return url String
	 */
	protected String getCreateFolderURL() {
		FrameworkLogger.logStep("getCreateFolderURL: Start");
		String url = apiUrls.get("baseURL") + serverConfig.get("createFolderURL");
		FrameworkLogger.logStep("getCreateFolderURL: End");
		return url;
	}
	
	protected String getCreateFolderURL(String url) {
		FrameworkLogger.logStep("getCreateFolderURL: Start");
		String endUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		FrameworkLogger.logStep("getCreateFolderURL: End");
		return endUrl;
	}

	/**
	 * set Json Body for Create Folder API
	 * 
	 * @throws IOException
	 * @throws InterruptedException 
	 */
	protected String setCreateFolderJsonBody() throws IOException{
		String objectName = folderName + Utils.getUniqueId();
		// load json file
		String path = System.getProperty("user.dir") + "/resources/createFolderTestData/createFolderBody.js";
		File file = new File(path);
		folderJsonBody = JsonPath.parse(file).jsonString();
		folderJsonBody = setJsonData(NmsConstants.getObjectName(), objectName, folderJsonBody);
		folderJsonBody = setJsonData(NmsConstants.getParentObjectKey(), rootFolderKey, folderJsonBody);
		return folderJsonBody;
	}

	/**
	 * Method to get Create Folder Response
	 *
	 * @return validatable response
	 * @throws IOException
	 */
	protected ValidatableResponse triggerPostApiCreateFolder() throws IOException {

		// setCreateFolderJsonBody();
		FrameworkLogger.logStep("triggerPostApiCreateFolder: Start");

		// get url for create metadata for folder API
				String strApiUrl=getCreateFolderURL();

		// get response from create a Folder API
				ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, folderJsonBody);

		folderKey = response.extract().path("objectKey");
		repositoryMap.put(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue(), folderKey);

		FrameworkLogger.logStep("triggerPostApiCreateFolder: End with Folder's objectKey :-> "+ folderKey);

		return response;
	}
	
	protected ValidatableResponse triggerPostApiCreateFolder(String url) throws IOException {

		// setCreateFolderJsonBody();
		FrameworkLogger.logStep("triggerPostApiCreateFolder: Start");

		// get url for create metadata for folder API
				String strApiUrl=getCreateFolderURL(url);

		// get response from create a Folder API
				ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, folderJsonBody);

		folderKey = response.extract().path("objectKey");
		repositoryMap.put(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue(), folderKey);
		FrameworkLogger.logStep("triggerPostApiCreateFolder: End");

		return response;
	}

	public static ValidatableResponse createFolderServiceMethod() throws IOException {
		FrameworkLogger.logStep("createFolderServiceMethod: Start");
		CreateFolderBaseScript folderBaseScript = new CreateFolderBaseScript();

		folderBaseScript.createHeader();

		folderBaseScript.setCreateFolderJsonBody();

		ValidatableResponse response = folderBaseScript.triggerPostApiCreateFolder();

		FrameworkLogger.logStep("createFolderServiceMethod: End");

		return response;

		// String objectKey=response.extract().path("objectKey");
		// repositoryMap.put(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue(),
		// objectKey);

	}
	
}
