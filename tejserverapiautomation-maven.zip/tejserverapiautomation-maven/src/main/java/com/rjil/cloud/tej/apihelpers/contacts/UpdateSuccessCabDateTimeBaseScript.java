package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.UpdateSuccessCabDateTimeConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.util.HashMap;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;
/**
 * @author Chandrashekhar Singh
 * 
 * Base script for Update Success Cab Date Time.
 * */

public class UpdateSuccessCabDateTimeBaseScript extends BaseTestScript {
    protected static final String apiName="UpdateSuccessCabDateTimeAPI";
    protected  String jsonBody;
    public UpdateSuccessCabDateTimeBaseScript(){
  		globalApiName=apiName;
  	}
       /**
     * @author Chandrashekhar Singh
     * <p>
     * It creates the url for API
     */
    protected String getUpdateSuccessCabDateTimeUrl() {
        return apiUrls.get("baseContactURL") + serverConfig.get("updateSuccessCabDateTimeUrl");
    }

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It loads the default JSON body.
     */

    protected void loadJsonFile(){
		FrameworkLogger.logStep("loadJsonFile:-> Start");
        //load json file
		String filePath="/resources/updateSuccessCabDateTimeTestData/updateSuccessCabDateTimeJsonBody.js";
		jsonBody=loadJsonFile(filePath);

		FrameworkLogger.logStep("loadJsonFile:-> End");
    }
    
    /**
     * @author Chandrashekhar Singh
     * <p>
     * It will set the value on provided json path
     */
    protected void setJsonBody(String jsonPath, String value) {
		FrameworkLogger.logStep("setJsonBody:-> Start");
        jsonBody = setJsonData(jsonPath, value, jsonBody);

		FrameworkLogger.logStep("setJsonBody:-> End");
    }


    /**
     * @return validatable response for API
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    protected ValidatableResponse triggerPutApiUpdateSuccessCabDateTime() {
		FrameworkLogger.logStep("triggerPutApiUpdateSuccessCabDateTime:-> Start");

//		triggerPutApi ContactBackup
		String strApiUrl=getUpdateSuccessCabDateTimeUrl();
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,jsonBody);

      FrameworkLogger.logStep("triggerPutApiUpdateSuccessCabDateTime:-> End");

        return response;
    }

    /**
     * @author Chandrashekhar Singh
     * @return validatable response for API
     * <p>
     * Call the method to update the date.
     */
	public static ValidatableResponse updateSuccessCabDateTimeServiceMethod(String successCabDateTime)
			throws InterruptedException, VerificationFailException {
		FrameworkLogger.logStep("updateSuccessCabDateTimeServiceMethod -> Start");
		
		//Create object of the API base class.
		UpdateSuccessCabDateTimeBaseScript apiObj=new UpdateSuccessCabDateTimeBaseScript();
		// Load the sample JSON file.
		apiObj.loadJsonFile();
		// Create the header of API.
		apiObj.createHeader();

		//get the today's date.
//		String successCabDateTime=Utils.getTime();
		// Set the cabViewTime in JSON.
		apiObj.setJsonBody(UpdateSuccessCabDateTimeConstants.getCabViewTimeJsonPath(),
				successCabDateTime);
		// Trigger the API and get the response.
		ValidatableResponse response = apiObj.triggerPutApiUpdateSuccessCabDateTime();

		// Get and verify the status code.
		int status = response.extract().statusCode();
		Verify.verifyEquals(status,
				ApiResponseCodes.RESPONSECODE200.getValue(),
				"Verify Success Status");

		FrameworkLogger.logStep("updateSuccessCabDateTimeServiceMethod -> End");
		
		return response;
	}

}
