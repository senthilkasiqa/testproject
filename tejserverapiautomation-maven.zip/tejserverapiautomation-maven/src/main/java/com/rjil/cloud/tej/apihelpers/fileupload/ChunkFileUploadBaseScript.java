/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.fileupload;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.security.MessageDigest;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import com.jayway.jsonpath.JsonPath;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;

/**
 * @author Prateek
 * 
 *         Base class for Chunk file upload API
 *
 */
public class ChunkFileUploadBaseScript extends BaseTestScript {

	protected static final String apiName = "ChunkFileUpload";
	private String file;
	private String chunksize;
	private String chunknumber;
	private String url;
	private String header;
	private int responseCode;
	private String response;
	protected static String jsonResponse = null;
	protected static CloseableHttpResponse response1 = null;
	HttpPut http = new HttpPut();
	
	public ChunkFileUploadBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * 
	 * Method to get url for chunk file upload api
	 * 
	 * @param transactionId
	 * @return
	 */

	protected String getChunkFileUploadURL(String transactionId) {
		FrameworkLogger.logStep("getChunkFileUploadURL: Start");
		/**
		 * The SIT url for upload is different compared to other environments
		 * So, we need to add this check
		 */
		String chunkUrl = apiUrls.get("uploadIp") + serverConfig.get("chunkUploadUrl") + "?uploadId=" + transactionId;
		FrameworkLogger.logStep("chunkUploadUrl=========>" + chunkUrl);
		FrameworkLogger.logStep("getChunkFileUploadURL: End");
		return chunkUrl;
	}

	/**
	 * Create header for chunk file upload api
	 * 
	 * @param hash
	 * @param offsetValue
	 * @return
	 */
	protected HttpPut createHeadersForCHunkUpload(String hash, int offsetValue) {

		FrameworkLogger.logStep("createHeadersForCHunkUpload: Start");
		http.addHeader("Content-MD5", hash);
		
		http.addHeader("Content-Type", "application/octet-stream");
		http.addHeader("X-Offset", Integer.toString(offsetValue));
		http.addHeader("X-User-Id", userId);
		http.addHeader("Accept-Language", "en");
		http.addHeader("X-Device-Key", "089B1EE6-6E2B-4501-B705-28393F0C9BF5");
		String xApiKeyValue = apiUrls.get("xApiKeyValue");
		http.addHeader("X-App-Secret", getAppSecretValue());
		http.addHeader("X-Api-Key", xApiKeyValue);
		http.addHeader("Authorization", accessToken);
		FrameworkLogger.logStep("createHeadersForCHunkUpload: End");
		return http;
	}
	
	protected HttpPut createHeadersForCHunkUploadForBoard(String userId,String hash, int offsetValue,String accessToken,String deviceKey) {

		FrameworkLogger.logStep("createHeadersForCHunkUpload: Start");
		http.addHeader("Content-MD5", hash);
		http.addHeader("Content-Type", "application/octet-stream");
		http.addHeader("X-Offset", Integer.toString(offsetValue));
		http.addHeader("X-User-Id", userId);
		http.addHeader("Accept-Language", "en");
		http.addHeader("X-Device-Key", deviceKey);
		String xApiKeyValue = apiUrls.get("xApiKeyValue");
		http.addHeader("X-App-Secret", getAppSecretValue());
		http.addHeader("X-Api-Key", xApiKeyValue);
		http.addHeader("Authorization", accessToken);
		FrameworkLogger.logStep("createHeadersForCHunkUpload: End");
		return http;
	}

	/**
	 * 
	 * Method to get chunk file upload response
	 * 
	 * @param transactionId
	 * @param offsetValue
	 */

	public void triggerPutApiUploadChunkFile(String transactionId, int offsetValue) {

		FrameworkLogger.logStep("triggerPutApiUploadChunkFile: start");
		File file1 = new File(getFile());
		FrameworkLogger.logStep(getFile());
		long length = file1.length();
		FrameworkLogger.logStep("length of file" + length);
		try {
			int chunkSize = (Integer.parseInt(getChunksize()));
			FrameworkLogger.logStep("ChunkSize:" + chunkSize);
			int chunkNumber = Integer.parseInt(getChunknumber());
			int endChunk = chunkNumber * chunkSize;
			if (offsetValue + chunkSize == length) {
				endChunk = (int) length;
			}
			FrameworkLogger.logStep("End CHunk:" + endChunk);
			int startChunk = endChunk - chunkSize;
			FrameworkLogger.logStep("Start Chunk:" + startChunk);
			
			RandomAccessFile file = new RandomAccessFile(getFile(), "r");
			file.seek(startChunk);
			byte[] mBytes = null;
			mBytes = new byte[chunkSize];
			
			file.read(mBytes);
			file.close();
			String hash;
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(mBytes, 0, mBytes.length);
			hash = String.format("%032x", new BigInteger(1, md.digest()));
			FrameworkLogger.logStep("Hash:" + hash);
			String uri = getChunkFileUploadURL(transactionId);
			FrameworkLogger.logStep("URL:" + uri);
			http = new HttpPut(uri);
			createHeadersForCHunkUpload(hash, offsetValue);
			http.setEntity(new ByteArrayEntity(mBytes));
			// CloseableHttpResponse response = null;
			CloseableHttpClient httpClient = HttpClients.createDefault();
			response1 = httpClient.execute(http);
			FrameworkLogger.logStep("Response" + response1.toString());
			setResponseCode(response1.getStatusLine().getStatusCode());
			FrameworkLogger.logStep("Code:" + response1.getStatusLine().getStatusCode());
			BufferedReader reader;
			String json = null;
			reader = new BufferedReader(new InputStreamReader(response1.getEntity().getContent(), "UTF-8"));
			json = reader.readLine();

			FrameworkLogger.logStep("Response-" + json);
			
			setResponse(json);

			FrameworkLogger.logStep("triggerPutApiUploadChunkFile: End");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	/**
	 * 
	 * Method to get chunk file upload response
	 * 
	 * @param transactionId
	 * @param offsetValue
	 */

	public void triggerPutApiUploadChunkFileForBoard(String userId,String transactionId, int offsetValue,String accessToken,String deviceKey) {

		FrameworkLogger.logStep("triggerPutApiUploadChunkFile: start");
		File file1 = new File(getFile());
		FrameworkLogger.logStep(getFile());
		long length = file1.length();
		FrameworkLogger.logStep("length of file" + length);
		try {
			int chunkSize = (Integer.parseInt(getChunksize()));
			FrameworkLogger.logStep("ChunkSize:" + chunkSize);
			int chunkNumber = Integer.parseInt(getChunknumber());
			int endChunk = chunkNumber * chunkSize;
			if (offsetValue + chunkSize == length) {
				endChunk = (int) length;
			}
			FrameworkLogger.logStep("End CHunk:" + endChunk);
			int startChunk = endChunk - chunkSize;
			FrameworkLogger.logStep("Start Chunk:" + startChunk);
			
			RandomAccessFile file = new RandomAccessFile(getFile(), "r");
			file.seek(startChunk);
			byte[] mBytes = null;
			mBytes = new byte[chunkSize];
			
			file.read(mBytes);
			file.close();
			String hash;
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(mBytes, 0, mBytes.length);
			hash = String.format("%032x", new BigInteger(1, md.digest()));
			FrameworkLogger.logStep("Hash:" + hash);
			String uri = getChunkFileUploadURL(transactionId);
			FrameworkLogger.logStep("URL:" + uri);
			http = new HttpPut(uri);
			createHeadersForCHunkUploadForBoard(userId,hash,offsetValue,accessToken,deviceKey);
			http.setEntity(new ByteArrayEntity(mBytes));
			// CloseableHttpResponse response = null;
			CloseableHttpClient httpClient = HttpClients.createDefault();
			response1 = httpClient.execute(http);
			FrameworkLogger.logStep("Response" + response1.toString());
			setResponseCode(response1.getStatusLine().getStatusCode());
			FrameworkLogger.logStep("Code:" + response1.getStatusLine().getStatusCode());
			BufferedReader reader;
			String json = null;
			reader = new BufferedReader(new InputStreamReader(response1.getEntity().getContent(), "UTF-8"));
			json = reader.readLine();

			FrameworkLogger.logStep("Response-" + json);
			
			setResponse(json);

			FrameworkLogger.logStep("triggerPutApiUploadChunkFile: End");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * Function to fetch the offset value
	 * @param fileName
	 * @param transactionId
	 * @param chunkSizeValue
	 * @param offsetValue
	 */
	public void uploadFileHelper(String fileName, String transactionId, String chunkSizeValue, int offsetValue) {
		
		FrameworkLogger.logStep("uploadFileHelper: Start");
		int offset = offsetValue;
		boolean lastChunk = false;
		String chunkSize = chunkSizeValue;
		String path = System.getProperty("user.dir") + "/resources/uploadTestData/" + fileName;
		File file = new File(path);
		
		setFile(System.getProperty("user.dir") + "/resources/uploadTestData/" + fileName);
		
		int fileLength = (int) file.length();
		FrameworkLogger.logStep("FileLengthNew:"+fileLength);
		int chunkNumber = 1;
		chunkLoop: for (int i = offset; i <= (fileLength - offset);) {
			if ((fileLength - offset) < Integer.parseInt(chunkSize)&&offset>0) {
				chunkSize = Integer.toString(fileLength - offset);
				lastChunk = true;
			}

			
			setChunksize(chunkSize);
			setChunknumber(Integer.toString(chunkNumber));
			triggerPutApiUploadChunkFile(transactionId, offset);
			jsonResponse = getResponse();
			FrameworkLogger.logStep("JSONRESPONSE====>" + jsonResponse);
			int responsecode = response1.getStatusLine().getStatusCode();
			FrameworkLogger.logStep("Code:" + responsecode);
			
			if (lastChunk) {
				FrameworkLogger.logStep("lastChunk" + lastChunk);
				break chunkLoop;
			
			} else if (responsecode != ApiResponseCodes.RESPONSECODE200.getValue()
					&& responsecode != ApiResponseCodes.RESPONSECODE201.getValue()) {
				FrameworkLogger.logStep("NEGATIVE TEST CASES");
				break chunkLoop;
			} else {
				offset = JsonPath.read(jsonResponse, "$.offset");
			}
			FrameworkLogger.logStep("Offset:" + offset);
			FrameworkLogger.logStep("uploadFileHelper: End");
			chunkNumber++;
		}
	}
	
	/**
	 * Function to fetch the offset value
	 * @param fileName
	 * @param transactionId
	 * @param chunkSizeValue
	 * @param offsetValue
	 */
	public void uploadFileHelperForBoard(String fileName, String transactionId, String chunkSizeValue, int offsetValue,String userId,String accessToken,String deviceKey) {
		
		FrameworkLogger.logStep("uploadFileHelper: Start");
		int offset = offsetValue;
		boolean lastChunk = false;
		String chunkSize = chunkSizeValue;
		String path = System.getProperty("user.dir") + "/resources/uploadTestData/" + fileName;
		File file = new File(path);
		
		setFile(System.getProperty("user.dir") + "/resources/uploadTestData/" + fileName);
		
		int fileLength = (int) file.length();
		FrameworkLogger.logStep("FileLengthNew:"+fileLength);
		int chunkNumber = 1;
		chunkLoop: for (int i = offset; i <= (fileLength - offset);) {
			if ((fileLength - offset) < Integer.parseInt(chunkSize)&&offset>0) {
				chunkSize = Integer.toString(fileLength - offset);
				lastChunk = true;
			}

			
			setChunksize(chunkSize);
			setChunknumber(Integer.toString(chunkNumber));
			FrameworkLogger.logStep("UserId:"+userId);
			FrameworkLogger.logStep("AccessToken:"+accessToken);
			FrameworkLogger.logStep("deviceKey:"+deviceKey);
			triggerPutApiUploadChunkFileForBoard(userId,transactionId,offset,accessToken,deviceKey);
			jsonResponse = getResponse();
			FrameworkLogger.logStep("JSONRESPONSE====>" + jsonResponse);
			int responsecode = response1.getStatusLine().getStatusCode();
			FrameworkLogger.logStep("Code:" + responsecode);
			
			if (lastChunk) {
				FrameworkLogger.logStep("lastChunk" + lastChunk);
				break chunkLoop;
			
			} else if (responsecode != ApiResponseCodes.RESPONSECODE200.getValue()
					&& responsecode != ApiResponseCodes.RESPONSECODE201.getValue()) {
				FrameworkLogger.logStep("NEGATIVE TEST CASES");
				break chunkLoop;
			} else {
				offset = JsonPath.read(jsonResponse, "$.offset");
			}
			FrameworkLogger.logStep("Offset:" + offset);
			FrameworkLogger.logStep("uploadFileHelper: End");
			chunkNumber++;
		}
	}
	

	public int ResponseCode() {
		FrameworkLogger.logStep(Integer.toString(getResponseCode()));
		return getResponseCode();
	}

	public String Response() {
		FrameworkLogger.logStep(getResponse());
		return getResponse();
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String getChunksize() {
		return chunksize;
	}

	public void setChunksize(String chunksize) {
		this.chunksize = chunksize;
	}

	public String getChunknumber() {
		return chunknumber;
	}

	public void setChunknumber(String chunknumber) {
		this.chunknumber = chunknumber;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int i) {
		this.responseCode = i;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
}
