package com.rjil.cloud.tej.enums;

/**
 * @author: Chandra
 * 
 * Header Parameter Enum
 * This is for all API's header.
 */

public enum HeaderParameters {
	
    CONTENTTYPE("Content-Type"),
    XUSERID("X-User-Id"),
    XDEVICEKEY("X-Device-Key"),
    AUTHORIZATION("Authorization"),
	ACCEPTLANGUAGE("Accept-Language"),
	XAPIKEY("X-Api-Key"),
	XAPPSECRET("X-App-Secret"),
	IFMODIFIEDSINCE("If-Modified-Since"),

    NEXTPAGEDATE("nextPageDate"),
    XCHUNKSIZE("X-Chunk-Size"),
    ONLYACTIVE("onlyActive"),
    SORT("sort"),
	XOFFSET("X-Offset"),
	XSHARDKEY("X-Shard-Key"),
	XAPPVERSION("X-App-Version"),
    XDEVICENAME("X-Device-Name"),
	LIMIT("limit"),
	/////MAILCHAMP///
	//XCODE("xCode"),
	XCODE("X-Offline-Code"),
	XMCSACCESSTOKEN("Authorization"),
	XSUBSCRIPTIONTYPE("Subscription-Type"),
	XSUBSCRIPTIONKEY("Subscription-Key"),
	XEMAILID("X-Email-Id"),
	XModifiedAfter("X-Modified-After"),
	XLastBackupTime("X-Last-Backup-Time"),
	XDeviceList("X-Device-List"),
	FromDateTimeStamp("fromDateTimeStamp");

    public String value;

    HeaderParameters(String value) {
        this.value = value;

    }

    public String getValue() {
        return value;
    }
}

