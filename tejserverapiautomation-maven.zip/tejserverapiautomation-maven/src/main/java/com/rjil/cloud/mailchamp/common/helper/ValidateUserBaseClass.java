package com.rjil.cloud.mailchamp.common.helper;



public class ValidateUserBaseClass extends MailChampBaseTestScript {
	
	protected String getValidateUserUrl() {
		String baseUrl = getValueFromEnvConfig("baseURL");
		String subUrl = getValueFromProjectConfig("validateUserURL");	
		return baseUrl + subUrl;
		}
}