package com.rjil.cloud.tej.apihelpers.nms;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class CopyMetadataBaseScript extends BaseTestScript{
	/**
	 * @author Sanjeevanee.Kanase
	 *class for having methods - for creating headers, get url for calling copy metadata url, and getting response for api
	 */

	    protected  String copyMetadataJSONBody;
//		protected  Map<String, String> headerMap = null;
		protected static final String apiName = "CopyMetadata";
		
		public CopyMetadataBaseScript(){
			globalApiName=apiName;
		}

	// created a Hashmap to save all the headers.
/*	protected  void createHeader() {

		FrameworkLogger.logStep("createHeader:-> Start");
		headerMap=new HashMap<>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");

		//Add 'X-Api-Key' in header for the API.
		addXapiHeaderKey(headerMap);

		FrameworkLogger.logStep("createHeader:-> End");
	}
*/
	/**get a complete url for 'copy Metadata API'
	 * @return
	 */
/*	protected String CopyMetadataURL() {
		
		FrameworkLogger.logStep("getCopyMetadataURL -> Start");
		return apiUrls.get("baseURL") + serverConfig.get("copyMetadataURL");
		
	}
*/
	/**get a complete url for 'Copy Metadata API'
	 * @return
	 */
	protected String copyMetadataURL() {
		FrameworkLogger.logStep("copyMetadataURL: Start");
		return copyMetadataURL(serverConfig.get("copyMetadataURL"));
	//	return apiUrls.get("baseURL") + serverConfig.get("getTrashMetadataURL");
	}
	
	/**get a complete url for 'Copy Metadata API'
	 * @return
	 */
	protected String copyMetadataURL(String urlValue) {
		FrameworkLogger.logStep("copyMetadataURL: Start");
		return (apiUrls.get("baseURL") + urlValue);
	}
	/**
	 * Method to get copyMetadata Response
	 * @return copyMetadata validatable response
	 */
	
    // Set the jsonBody for TrashMetadata API
    protected String setCopyMetadataJsonBody() throws IOException {
        //load json file
    	FrameworkLogger.logStep("setCopyMetadataJsonBody -> Start");
        String path = System.getProperty("user.dir") + "/resources/nmsTestData/copyMetadataBody.js";
        File file = new File(path);
        copyMetadataJSONBody = JsonPath.parse(file).jsonString();
        FrameworkLogger.logStep("setCopyMetadataJsonBody -> End");
       return  copyMetadataJSONBody;
    }
    
 /*   // call the copy metedata api and return the response
	protected ValidatableResponse getCopyMetadataAPIResponse() throws IOException {
		FrameworkLogger.logStep("getCopyMetadataAPIResponse -> Start");
		ValidatableResponse response = given().body(copyMetadataJSONBody)
				.headers(headerMap)
				.log().all()
				.when()
				.put(getCopyMetadataURL())
				.then();
		response.log().all();
		Utils.addRequestResponseToLogger();
		
		
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(CopyMetadataURL(),headerMap,copyMetadataJSONBody);

		FrameworkLogger.logStep("getCopyMetadataAPIResponse -> End");
		return response;

	}
	*/

	/**
	 * Method to get getTrashMetadata Response
	 * @return getTrashMetadata validatable response
	 */
	protected ValidatableResponse triggerPutApiCopyMetadata(String copyMetadataJSONBody) throws IOException {
		FrameworkLogger.logStep("triggerPutApiCopyMetadata: Start");
/*		ValidatableResponse response = given()
				.headers(headerMap)
				.log().all()
				.when()
				.get(getTrashMetatadataURL())
				.then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/		
		
//		String strApiUrl=getTrashMetatadataURL();
		//Call method to trigger GET API.
		
		
		ValidatableResponse response = triggerPutApiCopyMetadata(copyMetadataJSONBody,serverConfig.get("copyMetadataURL"));
		
		FrameworkLogger.logStep("triggerPutApiCopyMetadata: End");
		return response;

	}
	
	/**
	 * Method to get getTrashMetadata Response
	 * @return getTrashMetadata validatable response
	 */
	protected ValidatableResponse triggerPutApiCopyMetadata(String trashMetadataJSONBody, String urlValue) throws IOException {
		FrameworkLogger.logStep("triggerPutApiCopyMetadata: Start");
/*		ValidatableResponse response = given()
				.headers(headerMap)
				.log().all()
				.when()
				.get(getTrashMetatadataURL())
				.then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/		
		String strApiUrl=copyMetadataURL(urlValue);
		
		//Call method to trigger GET API.
	
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,trashMetadataJSONBody);
		FrameworkLogger.logStep("triggerPutApiCopyMetadata: End");
		return response;

	}

}
