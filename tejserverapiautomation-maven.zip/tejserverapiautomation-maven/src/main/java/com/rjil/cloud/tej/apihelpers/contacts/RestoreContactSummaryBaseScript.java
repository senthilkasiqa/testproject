package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;

public class RestoreContactSummaryBaseScript extends BaseTestScript {
    protected static final String apiName="RestoreContactSummary";
    
   
    public RestoreContactSummaryBaseScript(){
  		globalApiName=apiName;
  	}
    /**
     * @author Chandrashekhar Singh
     * <p>
     * It creates the url for API
     */
    private String getRestoreContactSummaryUrl() {
        return apiUrls.get("baseContactURL") + serverConfig.get("restoreContactSummaryUrl");
    }


    /**
     * @return validatable response for API
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    protected ValidatableResponse triggerGetApiRestoreContactSummary() {
		FrameworkLogger.logStep("triggerGetApiRestoreContactSummary:-> String");
        // setContactBackupJsonBody();
		
		String strApiUrl=getRestoreContactSummaryUrl();
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
		
		FrameworkLogger.logStep("triggerGetApiRestoreContactSummary:-> End");
		return response;
    }

    
      
	   //Service method to trigger RestoreContactSummaryApi.
		public static ValidatableResponse triggerRestoreContactSummaryApiServiceMethod() throws org.json.simple.parser.ParseException, VerificationFailException, ParseException, IOException {
			FrameworkLogger.logStep("triggerRestoreContactSummaryApiServiceMethod:-> Start");

			String strDeviceId1=deviceOwnerInfo.get("deviceKey");
			//Calling the method with deviceMap.
			ValidatableResponse response = triggerRestoreContactSummaryApiServiceMethod(deviceOwnerInfo);
			
	/*		RestoreContactSummaryBaseScript apiObj=new RestoreContactSummaryBaseScript();
			//Create header for API.
			apiObj.createHeader();

//	      Call the API to get the response.
	        ValidatableResponse response = apiObj.triggerGetApiRestoreContactSummary();

//	        Get and verify the status code.
	        int status = response.extract().statusCode();
	        Verify.verifyEquals(status,ApiResponseCodes.RESPONSECODE200.getValue(),"Verify Success Status");
	*/
	        FrameworkLogger.logStep("triggerRestoreContactSummaryApiServiceMethod:-> End");
	        return response;
	    }

	    //Service method to trigger RestoreContactSummaryApi.
		public static ValidatableResponse triggerRestoreContactSummaryApiServiceMethod(Map<String, String>deviceInfoMap) throws org.json.simple.parser.ParseException, VerificationFailException, ParseException, IOException {
			FrameworkLogger.logStep("triggerRestoreContactSummaryApiServiceMethod:-> Start");

			RestoreContactSummaryBaseScript apiObj=new RestoreContactSummaryBaseScript();
			//Create header for API.
			apiObj.createHeader(deviceInfoMap);

//	      Call the API to get the response.
	        ValidatableResponse response = apiObj.triggerGetApiRestoreContactSummary();

//	        Get and verify the status code.
	        int status = response.extract().statusCode();
	        Verify.verifyEquals(status,ApiResponseCodes.RESPONSECODE200.getValue(),"Verify Success Status");

	        FrameworkLogger.logStep("triggerRestoreContactSummaryApiServiceMethod:-> End");
	        return response;
	    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	// This method accepts the response and returns the size of Restore Contact summary list.
	public static int getSizeOfRestoreContactSummaryApiResponse(ValidatableResponse response){
        FrameworkLogger.logStep("getSizeOfRestoreContactSummaryApiResponse:-> Start");

		int size=-1;
		ArrayList<String> list=response.extract().path("restoreSummary");
		size= list.size();

        FrameworkLogger.logStep("getSizeOfRestoreContactSummaryApiResponse:-> End");
        
		return size;
	}
	// This method accepts the response and returns the list of snapshotid and count for device.
	public static List<String[]> getRestoreContactSummaryInfoFromApiResponse(ValidatableResponse response, String deviceId){
        FrameworkLogger.logStep("getRestoreContactSummaryInfoFromApiResponse:-> Start");

        List<String[]> info=new ArrayList<>();

        int size=-1;
		size= getSizeOfRestoreContactSummaryApiResponse(response);

		for(int i=0; i<size; i++){
			ArrayList<String> listOfRestoreContactSummaryForDevice=response.extract().path("restoreSummary["+i+"].devices");
			
			
			
			int sizeOfRestoreContactSummaryForDevice=listOfRestoreContactSummaryForDevice.size();
			 FrameworkLogger.logStep("sizeOfRestoreContactSummaryForDevice:-> Start"+sizeOfRestoreContactSummaryForDevice);
			for(int j=0; j<sizeOfRestoreContactSummaryForDevice; j++){
				String deviceKey=response.extract().path("restoreSummary["+i+"].devices["+j+"].deviceKey");
				FrameworkLogger.logStep("deviceKey:-> Start" +deviceKey);
				
				if(deviceId.equalsIgnoreCase(deviceKey)){
					FrameworkLogger.logStep("vALUE OF I"+i);
					FrameworkLogger.logStep("vALUE OF J"+j);
					FrameworkLogger.logStep("SNAPSHOTID="+response.extract().path("restoreSummary["+i+"].snapshotid"));
					FrameworkLogger.logStep("COUNT=:->"+response.extract().path("restoreSummary["+i+"].devices["+j+"].count"));
					String summaryInfoForDevice[]={
							response.extract().path("restoreSummary["+i+"].snapshotid"),
							response.extract().path("restoreSummary["+i+"].devices["+j+"].count").toString()
							
					};
					info.add(summaryInfoForDevice);
					FrameworkLogger.logStep("summaryInfoForDevice1:-> Start"+summaryInfoForDevice[0]);
					FrameworkLogger.logStep("summaryInfoForDevice2:-> Start"+summaryInfoForDevice[1]);
				}
			}
		}
        FrameworkLogger.logStep("getRestoreContactSummaryInfoFromApiResponse:-> End");
		return info;
	}

	// This method accepts the response and date; returns the list of deviceKey and count for the date.
	public static Map<String, String> getRestoreContactSummaryInfoFromApiResponseForDate(ValidatableResponse response, String strDate){
        FrameworkLogger.logStep("getRestoreContactSummaryInfoFromApiResponseForDate:-> Start");

        Map<String, String> deviceMap=new HashMap<String, String>();

        int size=-1;
		size= getSizeOfRestoreContactSummaryApiResponse(response);
        FrameworkLogger.logStep("Size of Restore Summary : -> "+ size);

		for(int i=0; i<size; i++){
			String strLastBackupTime =response.extract().path("restoreSummary["+i+"].lastBackupTime");
			if(strLastBackupTime.trim().startsWith(strDate)){
		        FrameworkLogger.logStep("Restore Summary found for date : -> "+ strLastBackupTime);

				ArrayList<String> deviceInfoForDate=response.extract().path("restoreSummary["+i+"].devices");
				int sizeOfDeviceInfoForDate=deviceInfoForDate.size();
		        FrameworkLogger.logStep("Size of DeviceInfoForDate Restore Summary : -> "+ sizeOfDeviceInfoForDate);

				for(int j=0; j<sizeOfDeviceInfoForDate; j++){
					String strDeviceKey=response.extract().path("restoreSummary["+i+"].devices["+j+"].deviceKey");
					String strCount=response.extract().path("restoreSummary["+i+"].devices["+j+"].count").toString();
					deviceMap.put(strDeviceKey, strCount);
					
			        FrameworkLogger.logStep("DeviceInfoForDate added into map : -> "+ strDeviceKey + " ; < - > " + strCount);
				}
				
				String strTotalCount=response.extract().path("restoreSummary["+i+"].count").toString();
				String strSnapshotid=response.extract().path("restoreSummary["+i+"].snapshotid");
				deviceMap.put("lastBackupTime", strLastBackupTime);
				deviceMap.put("count", strTotalCount);
				deviceMap.put("snapshotid", strSnapshotid);

				FrameworkLogger.logStep("Breaking the for loop with i="+i);
				break;
			}
		}
        FrameworkLogger.logStep("getRestoreContactSummaryInfoFromApiResponseForDate:-> End");
		return deviceMap;
	}

	// This method accepts the response ; returns the list of deviceKey and count for the LAST date.
	public static Map<String, String> getRestoreContactSummaryInfoFromApiResponseForLastDate(
			ValidatableResponse response) {
		FrameworkLogger
				.logStep("getRestoreContactSummaryInfoFromApiResponseForLastDate:-> Start");

		Map<String, String> snapshotInfoMap = new HashMap<String, String>();

		String strLatestDate=getRestoreContactSummaryLatestDate(response);

		snapshotInfoMap=getRestoreContactSummaryInfoFromApiResponseForDate(response, strLatestDate);

		FrameworkLogger
				.logStep("getRestoreContactSummaryInfoFromApiResponseForLastDate:-> End");
		return snapshotInfoMap;
	}

	// This method accepts the response ; returns the list of deviceKey and count for the LAST date.
	public static String getRestoreContactSummaryLatestDate(
			ValidatableResponse response) {
		FrameworkLogger
				.logStep("getRestoreContactSummaryLatestDate:-> Start");

		int size = -1;
		size = getSizeOfRestoreContactSummaryApiResponse(response);
		int indexOfLatestSnapshot=(size - 1);
		FrameworkLogger.logStep("Size of Restore Summary : -> " + size);

		List<String> listDates=new ArrayList<String>();
		/////////////////////
		for(int i=0; i< size; i++){
			String strLastUpdatedDate = response.extract().path(
					"restoreSummary[" + i + "].lastBackupTime");
			listDates.add(strLastUpdatedDate);
			
		}
		
		//Sorting the list of dates
		Collections.sort(listDates);
		String strFirstDate=listDates.get(0);
		String strLatestDate=listDates.get(indexOfLatestSnapshot);
		
		FrameworkLogger.logStep("First date in snapshot: -> " + strFirstDate);
		FrameworkLogger.logStep( "Last date in snapshot: -> " + strLatestDate);
		
		//////////////////////
		
		FrameworkLogger
				.logStep("getRestoreContactSummaryLatestDate:-> End");
		return strLatestDate;
	}

}
