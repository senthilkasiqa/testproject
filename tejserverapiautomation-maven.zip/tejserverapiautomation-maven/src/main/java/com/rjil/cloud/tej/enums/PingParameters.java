package com.rjil.cloud.tej.enums;

/**
 * Created by bharat on 25/08/16.
 */
public enum PingParameters {

    XUSERID("X-User-Id"),
    AUTHORIZATION("Authorization");

    public String value;

    PingParameters(String value) {
        this.value = value;

    }

    public String getValue() {
        return value;
    }
}
