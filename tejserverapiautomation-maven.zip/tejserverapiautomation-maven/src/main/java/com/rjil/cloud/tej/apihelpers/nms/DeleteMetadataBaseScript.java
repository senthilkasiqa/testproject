package com.rjil.cloud.tej.apihelpers.nms;

import java.io.File;
import java.io.IOException;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * 
 * @author Prateek
 *
 *         Base class for Delete metatdata API
 */

public class DeleteMetadataBaseScript extends BaseTestScript {
	protected String deleteMetadataJSONBody;
	protected static final String apiName = "DeleteMetaData";

	public DeleteMetadataBaseScript(){
		globalApiName=apiName;
	}
	/**
	 * get a complete url for 'Delete metadata API'
	 * 
	 * @return
	 */
	protected String getDeleteMetadataURL() {
		FrameworkLogger.logStep("getDeleteMetadataURL:-> Start");
		String url = getDeleteMetadataURL("deleteMetadatURL");
		FrameworkLogger.logStep("getDeleteMetadataURL:-> End");
		return url;
	}

	protected String getDeleteMetadataURL(String url) {
		FrameworkLogger.logStep("getDeleteMetadataURL:-> Start");
		String apiUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		FrameworkLogger.logStep("getDeleteMetadataURL:-> End");
		return apiUrl;
	}

	protected String getDeleteMetadataURL1(String urlValue) {
		FrameworkLogger.logStep("getDeleteMetadataURL1:-> Start");
		String apiUrl = apiUrls.get("baseURL") + urlValue;
		FrameworkLogger.logStep("getDeleteMetadataURL1:-> End");
		return apiUrl;
	}

	// Set the jsonBody for TrashMetadata API
	protected String setDeleteMetadataJsonBody() throws IOException {
		// load json file
		String path = System.getProperty("user.dir") + "/resources/nmsTestData/deleteMetadataBody.js";
		File file = new File(path);
		deleteMetadataJSONBody = JsonPath.parse(file).jsonString();
		return deleteMetadataJSONBody;
	}

	/**
	 * Method to get deleteMetadata Response
	 * 
	 * @return trashMetadata validatable response
	 */
	protected ValidatableResponse getDeleteMetadataAPIResponse() throws IOException {
		FrameworkLogger.logStep("getDeleteMetadataAPIResponse:-> Start");
		String strApiUrl = getDeleteMetadataURL();

		// ValidatableResponse response = triggerPutApi(getDeleteMetadataURL(),
		// headerMap, deleteMetadataJSONBody);
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, deleteMetadataJSONBody);
		//ValidatableResponse response = triggerPutApi(getDeleteMetadataURL(), headerMap, deleteMetadataJSONBody);
		//ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, deleteMetadataJSONBody);
		//ValidatableResponse response = getDeleteMetadataAPIResponse("deleteMetadatURL");

		FrameworkLogger.logStep("getDeleteMetadataAPIResponse:-> End");
		return response;
	}

	protected ValidatableResponse getDeleteMetadataAPIResponse(String apiUrl) throws IOException {
		FrameworkLogger.logStep("getDeleteMetadataAPIResponse:-> Start");
		String strApiUrl = getDeleteMetadataURL(apiUrl);
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, deleteMetadataJSONBody);
		FrameworkLogger.logStep("getDeleteMetadataAPIResponse:-> End");
		return response;
	}

	protected ValidatableResponse triggerPutApiDeleteMetadata(String deleteMetadataJSONBody, String urlValue)
			throws IOException {
		FrameworkLogger.logStep("triggerPutApitrashMetadata: Start");

		String strApiUrl = getDeleteMetadataURL1(urlValue);

		// Call method to trigger GET API.

		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, deleteMetadataJSONBody);
		FrameworkLogger.logStep("triggerPutApitrashMetadata: End");
		return response;

	}

	protected ValidatableResponse getDeleteMetadataAPIResponse1(String deleteMetadataJSONBody) throws IOException {
		FrameworkLogger.logStep("getDeleteMetadataAPIResponse1: Start");

		ValidatableResponse response = triggerPutApiDeleteMetadata(deleteMetadataJSONBody,
				serverConfig.get("deleteMetadatURL"));

		FrameworkLogger.logStep("getDeleteMetadataAPIResponse1: End");
		return response;

	}

	public static ValidatableResponse deleteMetadataForFileServiceMethod()
			throws IOException, VerificationFailException {
		FrameworkLogger.logStep("deleteMetadataForFileServiceMethod : Start");

		DeleteMetadataBaseScript deleteApiObject = new DeleteMetadataBaseScript();

		deleteApiObject.createHeader();
		
		deleteApiObject.setDeleteMetadataJsonBody();
		
		deleteApiObject.deleteMetadataJSONBody = setJsonData(NmsConstants.getObjectKey(0),
				repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue()),
				deleteApiObject.deleteMetadataJSONBody);
		
		ValidatableResponse response = deleteApiObject
				.getDeleteMetadataAPIResponse1(deleteApiObject.deleteMetadataJSONBody);

		FrameworkLogger.logStep("deleteMetadataForFileServiceMethod : End");
		
		return response;
	}
	
	public static ValidatableResponse deleteMetadataForFileServiceMethod(String objectKey)
			throws IOException, VerificationFailException {
		FrameworkLogger.logStep("deleteMetadataForFileServiceMethod : Start");

		//Step 1: trash the respective objectKey
		
		TrashMetadataBaseScript.trashMetadataForFileServiceMethod(objectKey);
		
		//Step 2: Now delete the trashed objectKey
		
		DeleteMetadataBaseScript deleteApiObject = new DeleteMetadataBaseScript();

		deleteApiObject.createHeader();
		deleteApiObject.setDeleteMetadataJsonBody();
		deleteApiObject.deleteMetadataJSONBody = setJsonData(NmsConstants.getObjectKey(0), objectKey, deleteApiObject.deleteMetadataJSONBody);
		
		ValidatableResponse response = deleteApiObject.getDeleteMetadataAPIResponse1(deleteApiObject.deleteMetadataJSONBody);

		FrameworkLogger.logStep("deleteMetadataForFileServiceMethod : End");
		
		return response;
	}
}