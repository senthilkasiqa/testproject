/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boardsharedservices;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.SharedServicesConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author User
 *
 */
public class SendEmailNotificationOfPublicLinkUrlBaseScript extends BaseTestScript{
	
	protected static final String apiName= "SendEmailNotificationofAccessPublicLink";
	protected  String createSendEmailNotifictaionOfPublicLinkUrlBody;

	
//	 protected  Map<String,String> headerMap = null;
	
	public SendEmailNotificationOfPublicLinkUrlBaseScript(){
		globalApiName=apiName;
	}

	    /**In order to construct the header parameters for each test, we would call a createHeader method.
	     * This method would initialize a hashmap that would contain a key-value pair ( header parameters and its corresponding value)
	     *
	     * UserId
	     * Authorization
	     *
	     * The method would then put header parameters needed for each test case.
	     * Once the header parameters are available, we would call the API method to get response.
	     * The idea behing using a hashmap is that we would need only 3 methods in the middle layer base script to run
	     * all our test cases namely*/

/*	    protected  void createHeader(){
	    	headerMap = new HashMap<>();
	        headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
	        headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
	        headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
	        addXapiHeaderKey(headerMap);
	        System.out.println("Headers=========>"+headerMap);
	        
	        
	    }
*/	

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

	    	//Remove device key from header for this API.
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * 
	 * Construct the final Download request. 
	 * Need to add object key in the url by fetching object key from the Upload Response 
	 * 
	 */

	protected String getSendEmailNotificationOfPublicLinkUrl() {
		FrameworkLogger.logStep("getSendEmailNotificationOfPublicLinkUrl : Start");
		String url = apiUrls.get("baseURL") + serverConfig.get("sendEmailNotificationOfPublicLinkUrl");
		FrameworkLogger.logStep("getSendEmailNotificationOfPublicLinkUrl : End");
		return url;

	}
	
	/**
	 * 
	 * Construct the final Download request. 
	 * Need to add object key in the url by fetching object key from the Upload Response 
	 * 
	 */

	protected String getSendEmailNotificationOfPublicLinkUrl(String urlKey) {
		FrameworkLogger.logStep("getSendEmailNotificationOfPublicLinkUrl : Start");
		String url = apiUrls.get("baseURL") + serverConfig.get(urlKey);
		FrameworkLogger.logStep("getSendEmailNotificationOfPublicLinkUrl : End");
		return url;

	}
	
	/**
	 * Create body of send email notification public link api
	 * @throws IOException
	 */
	protected String setSendEmailNotificationOfPublicLinkUrlJsonBody() throws IOException {
		
		FrameworkLogger.logStep("setSendEmailNotificationOfPublicLinkUrlJsonBody : Start");
		// load json file
		String path = System.getProperty("user.dir") + "/resources/sharedServicesTestData/sendEmailNotificationOfPublicUrlBody.js";
		File file = new File(path);
		createSendEmailNotifictaionOfPublicLinkUrlBody = JsonPath.parse(file).jsonString();
		createSendEmailNotifictaionOfPublicLinkUrlBody=setJsonData(SharedServicesConstants.getShareURL(), repositoryMap.get(RepositoryParameterEnum.SHAREURL.getValue()), createSendEmailNotifictaionOfPublicLinkUrlBody);
		createSendEmailNotifictaionOfPublicLinkUrlBody=setJsonData(SharedServicesConstants.getShareKey(), repositoryMap.get(RepositoryParameterEnum.SHAREKEY.getValue()), createSendEmailNotifictaionOfPublicLinkUrlBody);
		createSendEmailNotifictaionOfPublicLinkUrlBody=setJsonData(SharedServicesConstants.getRecipientEmailId(), serverConfig.get("emailId"), createSendEmailNotifictaionOfPublicLinkUrlBody);
		FrameworkLogger.logStep("setSendEmailNotificationOfPublicLinkUrlJsonBody : End");
		return createSendEmailNotifictaionOfPublicLinkUrlBody;
	}
	
	/**
	 * Method to get Send email notification of public link  Response
	 *
	 * @return create a public link validatable response
	 */
	protected  ValidatableResponse triggerPostApiSendEmailNotificationOfPublicLink() throws IOException {

		FrameworkLogger.logStep("triggerPostApiSendEmailNotificationOfPublicLink: Start");
		
		String apiUrl=getSendEmailNotificationOfPublicLinkUrl();
		
		ValidatableResponse response=triggerPostApi(apiUrl, headerMap, createSendEmailNotifictaionOfPublicLinkUrlBody);

		FrameworkLogger.logStep("triggerPostApiSendEmailNotificationOfPublicLink: End");
		return response;
	}
	
	/**
	 * Method to get Send email notification of public link  Response
	 *
	 * @return create a public link validatable response
	 */
	protected  ValidatableResponse triggerPostApiSendEmailNotificationOfPublicLink(String urlKey) throws IOException {

		FrameworkLogger.logStep("triggerPostApiSendEmailNotificationOfPublicLink: Start");
		
		String apiUrl=getSendEmailNotificationOfPublicLinkUrl(urlKey);
		
		ValidatableResponse response=triggerPostApi(apiUrl, headerMap, createSendEmailNotifictaionOfPublicLinkUrlBody);
		
		FrameworkLogger.logStep("triggerPostApiSendEmailNotificationOfPublicLink: End");
		
		
		return response;
	}

	
}
