package com.rjil.cloud.tej.apiconstants;

/**
 * NMS API Constants
 */

public class NmsConstants {

	public static String getParentObjectKey() {
		return "$.parentObjectKey";
	}

	public static String getObjectName() {
		return "$.objectName";
	}

	public static String getSourceName() {
		return "$.sourceName";
	}

	public static String getParentObjectKey1() {
		return "$.objects[0].parentObjectKey";
	}

	public static String getObjectName1() {
		return "$.objects[0].objectName";
	}

	public static String getSourceName1() {
		return "$.objects[0].sourceName";
	}

	public static String getStatus() {
		return "$.objects[0].status";
	}

	public static String getObjectKey() {
		return "$.objects[0].objectKey";
	}
	
	public static String getObjectKeyInvalid(){
    	return "$.objectKey";
    }

	public static String getIsHidden() {
		return "$.objects[0].isHidden";
	}

	public static String getIsLocked() {
		return "$.objects[0].isLocked";
	}

	public static String getIsReadonly() {
		return "$.objects[0].isReadonly";
	}

	public static String getIsPinned() {
		return "$.objects[0].isPinned";
	}

	public static String getSourceFolder() {
		return "$.objects[0].sourceFolder";
	}

	public static String getVersion() {
		return "$.objects[0].version";
	}

	public static String getObjectKey(int index) {
		return "$.objectKeys[" + index + "]";
	}

	public static String getRootFolderKey() {
		return "$.destinationObjectKey";
	}
	
	public static String getOperationName() {
		return "$.objects[0].operationName";
	}

	

}
