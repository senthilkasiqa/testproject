package com.rjil.cloud.tej.apihelpers.newBoard;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

public class BoardsFeedBaseScript extends BaseTestScript{

	protected static final String apiName = "BoardsFeed";

	protected String getBoardsFeedURL() {
		FrameworkLogger.logStep(" getBoardsFeedURL:-> Start");
		return apiUrls.get("boardUrl") + serverConfig.get("boardsFeedUrl");
		//return "http://board.dev-jiocloud.com:8080"+serverConfig.get("boardsFeedUrl");
	}

	protected String getBoardsFeedURL(String url) {
		FrameworkLogger.logStep(" getBoardCategoriesURL:-> Start");
		return apiUrls.get("boardUrl") + url;
	}

	protected ValidatableResponse triggerGetgetBoardsFeed() throws IOException {
		FrameworkLogger.logStep("triggerGetgetBoardsFeed:-> Start");
		String strApiUrl = getBoardsFeedURL();
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetgetBoardsFeed:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetgetBoardsFeed(Map<String, String> headerMap1) throws IOException {
		FrameworkLogger.logStep("triggerGetgetBoardsFeed:-> Start");
		String strApiUrl = getBoardsFeedURL();
		Map<String, String> headerMap = createHeader(headerMap1);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetgetBoardsFeed:-> End");
		return response;
	}
	protected ValidatableResponse triggerGetgetBoardsFeed(String url) throws IOException {
		FrameworkLogger.logStep("triggerGetgetBoardsFeed:-> Start");
		String strApiUrl = getBoardsFeedURL(url);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetgetBoardsFeed:-> End");
		return response;
	}
	

	public static ValidatableResponse getGetBoardsFeedService()
	{
		BoardsFeedBaseScript boardsFeed = new BoardsFeedBaseScript();
		boardsFeed.createHeader();
		String strApiUrl = boardsFeed.getBoardsFeedURL();
		ValidatableResponse response =boardsFeed.triggerGetApi(strApiUrl, boardsFeed.headerMap);
		return response;
	}
	
	public static int getBoardIndexFromResponse(ValidatableResponse response, String boardKey) throws IOException
	{
		FrameworkLogger.logStep("getBoardIndexFromResponse: Start");
		int boardIndex = -1;
		int  sizeOfOjectArray =	response.extract().jsonPath().getList("boards").size();
		FrameworkLogger.logStep("ArraySize:"+sizeOfOjectArray);
		for(int i=0;i<sizeOfOjectArray;i++)
		{
			String boardKeyInResponse = response.extract().path("boards["+i+"].boardKey");
			if (boardKey.equalsIgnoreCase(boardKeyInResponse))
			{
				 boardIndex = i;
				  break;
			}
		
		}
		FrameworkLogger.logStep("getBoardIndexFromResponse: End");
		return boardIndex;
	}

}
