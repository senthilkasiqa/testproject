package com.rjil.cloud.tej.apihelpers.invitationservices;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.BoardInviteConstants;
import com.rjil.cloud.tej.apihelpers.boards.BoardsBaseScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.BoardInviteParameters;
import com.rjil.cloud.tej.enums.BoardParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * 
 * @author Prateek
 * 
 *         Date 8/8/2016
 * 
 *         Class for creating board invite request
 */

public class BoardInviteBaseScript extends BoardsBaseScript {
//	protected static String boardInviteJSONBody;
	protected String boardInviteJSONBody;
//	public static String boardKey;
//	public static String inviteCode;
	public String inviteCode;

	/**
	 * Method for creating Send Board Invite URL
	 * 
	 * @return
	 */
	public String getBoardSendInviteURL() {
        FrameworkLogger.logStep("getBoardSendInviteURL:-> Start");

//		return apiUrls.get("baseURL") + apiUrls.get("sendInviteURL").replace("{boardKey}", boardKey);

		String result=apiUrls.get("baseURL") + serverConfig.get("sendInviteURL").replace("{boardKey}", repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue()));

		FrameworkLogger.logStep("getBoardSendInviteURL:-> End");

		return result;
	}

	/**
	 * Method for creating Accept Invite URL
	 * 
	 * @return
	 */
	public String getBoardAcceptInviteURL() {
		return apiUrls.get("baseURL") + serverConfig.get("acceptInviteURL").replace("{inviteCode}", inviteCode);
	}

	/**
	 * Method for creating Send Board Invite JSON Body
	 * 
	 * @throws IOException
	 */
//	protected static void setBoardInviteJsonBody() throws IOException {
	protected void setBoardInviteJsonBody() throws IOException {
        FrameworkLogger.logStep("setBoardInviteJsonBody:-> Start");

		// load json file
		String path = System.getProperty("user.dir") + "/resources/boardInviteTestData/sendInviteBody.js";
		File file = new File(path);
		boardInviteJSONBody = JsonPath.parse(file).jsonString();
		boardInviteJSONBody = setJsonData(BoardInviteConstants.getUserContact(), apiUrls.get("userContactEmail"),
				boardInviteJSONBody);

        FrameworkLogger.logStep("setBoardInviteJsonBody:-> End");
	}

	/**
	 * 
	 * Method to get Send Board Invite Response
	 *
	 * @return board validatable response
	 */
	public static ValidatableResponse getBoardInviteAPIResponse() throws IOException {
        FrameworkLogger.logStep("getBoardInviteAPIResponse:-> Start");

		BoardInviteBaseScript apiObj=new BoardInviteBaseScript();
		apiObj.setBoardInviteJsonBody();
		apiObj.createHeader();
		ValidatableResponse response = apiObj.triggerPostApi(apiObj.getBoardSendInviteURL(), apiObj.headerMap,apiObj.boardInviteJSONBody);

		/*		ValidatableResponse response = given().body(boardInviteJSONBody)
				.header("Content-Type", "application/json")
				.header(BoardInviteParameters.XUSERID.getValue(), userId)
				.header(BoardInviteParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"))
				.header(BoardInviteParameters.AUTHORIZATION.getValue(), accessToken)
				.header(BoardInviteParameters.ACCEPTLANGUAGE.getValue(), "en").log().all().when()
				.post(getBoardSendInviteURL()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/

		FrameworkLogger.logStep("getBoardInviteAPIResponse:-> End");

		return response;
	}

	/**
	 * Method to get Accept Board Invite response
	 * 
	 * @return
	 */
	public static ValidatableResponse getAcceptBoardInviteAPIResponse() {
		FrameworkLogger.logStep("getAcceptBoardInviteAPIResponse:-> Start");
		
/*		ValidatableResponse response = given().header("Content-Type", "application/json")
				.header(BoardInviteParameters.XUSERID.getValue(), userId)
				.header(BoardInviteParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"))
				.header(BoardInviteParameters.AUTHORIZATION.getValue(), accessToken)
				.header(BoardInviteParameters.ACCEPTLANGUAGE.getValue(), "en").log().all().when()
				.put(getBoardAcceptInviteURL()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/
		BoardInviteBaseScript apiObj=new BoardInviteBaseScript();
		apiObj.createHeader();
		ValidatableResponse response = apiObj.triggerPutApi(apiObj.getBoardAcceptInviteURL(), apiObj.headerMap);

		FrameworkLogger.logStep("getAcceptBoardInviteAPIResponse:-> End");
		return response;
	}

	/**
	 * Method to get Invite code
	 *
	 * @return invite code
	 */
	public static String getInviteCode(ValidatableResponse response) {
		return response.extract().path("inviteCode");
	}
}
