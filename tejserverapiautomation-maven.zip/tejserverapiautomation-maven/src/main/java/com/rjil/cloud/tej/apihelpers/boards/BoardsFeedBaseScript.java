package com.rjil.cloud.tej.apihelpers.boards;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

public class BoardsFeedBaseScript extends BaseTestScript {

	protected static final String apiName = "BoardsFeed";

	protected String getBoardsFeedURL() {
		FrameworkLogger.logStep(" getBoardsFeedURL:-> Start");
		return apiUrls.get("boardUrl") + serverConfig.get("boardsFeedUrl");
		// return
		// "http://board.dev-jiocloud.com:8080"+serverConfig.get("boardsFeedUrl");
	}

	protected String getBoardsFeedURL(String url, String page, String limit) {
		FrameworkLogger.logStep(" getBoardCategoriesURL:-> Start");
		String replaceUrl = apiUrls.get("boardUrl") + serverConfig.get(url);
		String boardFeedUrl = replaceUrl.replace("{page}", page).replace("{limit}", limit);
		return boardFeedUrl;
	}

	protected ValidatableResponse triggerGetgetBoardsFeed() throws IOException {
		FrameworkLogger.logStep("triggerGetgetBoardsFeed:-> Start");
		String strApiUrl = getBoardsFeedURL();
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetgetBoardsFeed:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetgetBoardsFeed(Map<String, String> headerMap1) throws IOException {
		FrameworkLogger.logStep("triggerGetgetBoardsFeed:-> Start");
		String strApiUrl = getBoardsFeedURL();
		Map<String, String> headerMap = createHeader(headerMap1);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetgetBoardsFeed:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetgetBoardsFeed(String url, String page, String limit) throws IOException {
		FrameworkLogger.logStep("triggerGetgetBoardsFeed:-> Start");
		String strApiUrl = getBoardsFeedURL(url, page, limit);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetgetBoardsFeed:-> End");
		return response;
	}

	public static ValidatableResponse getGetBoardsFeedService() {
		BoardsFeedBaseScript boardsFeed = new BoardsFeedBaseScript();
		boardsFeed.createHeader();
		String strApiUrl = boardsFeed.getBoardsFeedURL();
		ValidatableResponse response = boardsFeed.triggerGetApi(strApiUrl, boardsFeed.headerMap);
		return response;
	}

	public static ValidatableResponse getGetBoardsFeedService(Map<String, String> headerMap) throws IOException {
		BoardsFeedBaseScript boardsFeed = new BoardsFeedBaseScript();
		boardsFeed.headerMap = boardsFeed.createHeader(headerMap);
		String strApiUrl = boardsFeed.getBoardsFeedURL();
		ValidatableResponse response = boardsFeed.triggerGetApi(strApiUrl, boardsFeed.headerMap);
		return response;
	}

	public static int getBoardIndexFromResponse(ValidatableResponse response, String boardKey) throws IOException {
		FrameworkLogger.logStep("getBoardIndexFromResponse: Start");
		int boardIndex = -1;
		int sizeOfOjectArray = response.extract().jsonPath().getList("boards").size();
		FrameworkLogger.logStep("ArraySize:" + sizeOfOjectArray);
		for (int i = 0; i < sizeOfOjectArray; i++) {
			String boardKeyInResponse = response.extract().path("boards[" + i + "].boardKey");
			if (boardKey.equalsIgnoreCase(boardKeyInResponse)) {
				FrameworkLogger.logStep("Board Index:"+boardIndex);
				boardIndex = i;
				break;
			}
		}
		FrameworkLogger.logStep("getBoardIndexFromResponse: End");
		return boardIndex;
	}

	public static void getAllBoardKeysAndUnjoinBoard() throws IOException {
		FrameworkLogger.logStep("getAllBoardKeysAndUnjoinBoard :-> Start");
		ValidatableResponse boardFeedResponse = BoardsFeedBaseScript.getGetBoardsFeedServiceWithLimit("boardsFeedUrlWithPageAndLimit","0","1000");
		try {
			int sizeOfOjectArray = boardFeedResponse.extract().jsonPath().getList("boards").size();
			List boardKeyList = new ArrayList();

			for (int i = 0; i < sizeOfOjectArray; i++) {
				boardKeyList.add(boardFeedResponse.extract().path("boards[" + i + "].boardKey"));
			}

			for (int i = 0; i < sizeOfOjectArray; i++) {
				String boardKey = (String) boardKeyList.get(i);
				com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript.leaveBoardService(boardKey);
			}
		} catch (Exception ex) {
			FrameworkLogger.logStep("No Boards found Boards Feed Response");
		}
		FrameworkLogger.logStep("getAllBoardKeysAndUnjoinBoard() :-> End");
	}

	public static void getAllBoardKeysAndUnjoinBoardByContributor(Map<String, String> deviceContributorInfoTemp)
			throws IOException {
		FrameworkLogger.logStep("getAllBoardKeysAndUnjoinBoardByContributor :-> Start");
		ValidatableResponse boardFeedContributorResponse = BoardsFeedBaseScript
				.getGetBoardsFeedService(deviceContributorInfoTemp);
		int sizeOfOjectArray = boardFeedContributorResponse.extract().jsonPath().getList("boards").size();
		List contributorBoardKeyList = new ArrayList();

		for (int i = 0; i < sizeOfOjectArray; i++) {
			contributorBoardKeyList.add(boardFeedContributorResponse.extract().path("boards[" + i + "].boardKey"));
		}

		for (int i = 0; i < sizeOfOjectArray; i++) {
			String boardKey = (String) contributorBoardKeyList.get(i);
			LeaveBoardBaseScript.leaveBoardService(boardKey, deviceContributorInfoTemp);
		}

		FrameworkLogger.logStep("getAllBoardKeysAndUnjoinBoardByContributor() :-> End");
	}
	
	public static ValidatableResponse getGetBoardsFeedServiceWithLimit(String url, String page, String limit) {
		BoardsFeedBaseScript boardsFeed = new BoardsFeedBaseScript();
		boardsFeed.createHeader();
		String strApiUrl = boardsFeed.getBoardsFeedURL(url, page, limit);
		ValidatableResponse response = boardsFeed.triggerGetApi(strApiUrl, boardsFeed.headerMap);
		return response;
	}

}
