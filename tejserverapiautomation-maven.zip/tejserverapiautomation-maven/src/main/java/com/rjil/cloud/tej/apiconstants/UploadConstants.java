package com.rjil.cloud.tej.apiconstants;

/**
 * 
 * @author Prateek
 * 
 * Upload File API Constant class
 */

public class UploadConstants {

	public static String getName() {
		return "$.name";
	}

	public static String getSize() {
		return "$.size";
	}

	public static String getHash() {
		return "$.hash";
	}

	public static String getDescription() {
		return "$.description";
	}
	
	public static String getFolderKey() {
		return "$.folderKey";
	}
	
	public static String getSourceFolder() {
		return "$.sourceFolder";
	}
	
	public static String getIsProfilePic() {
		return "$.isProfilePic";
	}

	public static String getIsAutoUpload() {
		return "$.isAutoUpload";
	}
	
	public static String getIsContactPhoto() {
		return "$.isContactPhoto";
	}
	
	public static String getLatitude() {
		return "$.location.latitude";
	}
	
	public static String getLongitude() {
		return "$.location.longitude";
	}
	
	public static String getAltitude() {
		return "$.location.altitude";
	}
	
	public static String getKeywords() {
		return "$.keywords.[0]";
	}
	
	public static String getKeywordsField() {
		return "$.keywords";
	}

	public static String getHidden() {
		return "$.hidden";
	}

	public static String getBoardKey() {
		return "$.boardKey";
	}
	
	public static String getBoardCoverPic() {
		return "$.isBoardCoverPic";
	}

	public static String getFileCreatedDate() {
		return "$.fileCreatedDate";
	}
	

}
