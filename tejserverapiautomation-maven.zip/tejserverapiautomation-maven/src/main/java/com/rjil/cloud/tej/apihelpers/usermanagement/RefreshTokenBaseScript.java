/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.usermanagement;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.poi.hssf.record.RefreshAllRecord;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author Prateek
 *
 *Base class for refresh access token Api
 */
public class RefreshTokenBaseScript extends BaseTestScript{

	protected static final String apiName = "RefreshToken";
//	protected Map<String, String> headerMap = null;
	protected String refreshTokenJsonBody=null;
	
	public RefreshTokenBaseScript(){
		globalApiName=apiName;
	}
	
	// Overload the method.
		protected Map<String, String> createHeader() {
			FrameworkLogger.logStep("createHeader -> Start");

			headerMap = initializeHeader();

			headerMap.put("lb-cookie", "3");
		   //Remove Authorization and accept langauage from header for this API.
			headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());
			headerMap.remove(HeaderParameters.ACCEPTLANGUAGE.getValue());
			FrameworkLogger.logStep("createHeader -> End");
			return headerMap;
		}
		
		/**
		 * 
		 * Method to get refresh token api url
		 * 
		 * URL=http://{envUrl}/account/token/refresh
		 * 
		 */
		protected String getRefreshTokenUrl(String url) {
			FrameworkLogger.logStep("getRefreshTokenUrl: Start");
			String getRefreshTokenUrl = apiUrls.get("publicBaseURL") + serverConfig.get(url);
			FrameworkLogger.logStep("getSetUserProfilePicUrl:" + getRefreshTokenUrl);
			FrameworkLogger.logStep("getRefreshTokenUrl: End");
			return getRefreshTokenUrl;

		}
		
		/**
		 * Method to create refresh token json body
		 * 
		 * @return
		 * @throws IOException
		 */
		protected String loadRefreshTokenJsonBody() throws IOException {
			FrameworkLogger.logStep("loadRefreshTokenJsonBody: Start");
			// load json file
			String path = System.getProperty("user.dir") + "/resources/userManagementTestData/refreshTokenBody.js";
			File file = new File(path);
			refreshTokenJsonBody = JsonPath.parse(file).jsonString();
			FrameworkLogger.logStep("loadRefreshTokenJsonBody: End");
			return refreshTokenJsonBody;
		}
		
		/**
		 * Method to get refresh token api Response
		 * 
		 * @return trashMetadata validatable response
		 */
		protected ValidatableResponse triggerPutApiRefreshToken(String url) throws IOException {

			FrameworkLogger.logStep("triggerPutApiRefreshToken: Start");

			String strApiUrl = getRefreshTokenUrl(url);
			// Call method to trigger PUT API.
			ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, refreshTokenJsonBody);

			FrameworkLogger.logStep("triggerPutApiRefreshToken: End");

			return response;
		}
}
