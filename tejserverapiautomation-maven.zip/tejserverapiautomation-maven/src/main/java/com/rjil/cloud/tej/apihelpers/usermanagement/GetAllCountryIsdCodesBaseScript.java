package com.rjil.cloud.tej.apihelpers.usermanagement;

import java.io.IOException;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

/**
 * 
 * @author Ashwini.Abhyankar
 *
 *         Base Class for Get All Country Isd Codes Api
 */

public class GetAllCountryIsdCodesBaseScript extends BaseTestScript {
	protected static final String apiName = "GetAllCountryISDCodes";
	
	public GetAllCountryIsdCodesBaseScript(){
		globalApiName=apiName;
	}
	/**
	 * Method for Creating Get All country isd codes Url
	 * @return
	 */
	
	protected String getGetAllCountryIsdCodesUrl() {
		FrameworkLogger.logStep("getGetAllCountryIsdCodesUrl:-> Start");
		//String url = getGetAllCountryIsdCodesUrl(serverConfig.get("getAllCountryIsdCodesUrl"));
		String url = apiUrls.get("baseURL") + serverConfig.get("getAllCountryIsdCodesUrl");

		FrameworkLogger.logStep("getGetAllCountryIsdCodesUrl:-> End");
		return url;
	}
	
	protected String getGetAllCountryIsdCodesUrl(String url) {
		FrameworkLogger.logStep("getGetAllCountryIsdCodesUrl:-> Start");
		String apiUrl = apiUrls.get("baseURL") + serverConfig.get(url);

		FrameworkLogger.logStep("getGetAllCountryIsdCodesUrl:-> End");
		return apiUrl;
	}
	
	/**
	 * Method to get the response after triggering Get All Country Isd Codes Api
	 * @return
	 * @throws IOException
	 */
	protected ValidatableResponse triggerGetApiGetAllCountryIsdCodes() throws IOException {

		FrameworkLogger.logStep("triggerGetApiGetAllCountryIsdCodes:-> Start");
		
		//ValidatableResponse response =triggerGetApiGetAllCountryIsdCodes(serverConfig.get("getAllCountryIsdCodesUrl"));

		// get url for autoback settings url
		String strApiUrl = getGetAllCountryIsdCodesUrl();

		// get response from create a public link API
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);

		FrameworkLogger.logStep("triggerGetApiGetAllCountryIsdCodes:-> End");
		return response;
	}
	
	/**
	 * Method to get the response after triggering Get All Country Isd Codes Api
	 * @return
	 * @throws IOException
	 */
	
	protected ValidatableResponse triggerGetApiGetAllCountryIsdCodes(String apiUrl) throws IOException {

		FrameworkLogger.logStep("triggerGetApiGetAllCountryIsdCodes:-> Start");

		// get url for autoback settings url
		String strApiUrl = getGetAllCountryIsdCodesUrl(apiUrl);

		// get response from create a public link API
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);

		FrameworkLogger.logStep("triggerGetApiGetAllCountryIsdCodes:-> End");
		return response;
	}
	
}