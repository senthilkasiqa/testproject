package com.rjil.cloud.tej.apihelpers.boardsharedservices;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.SharedServicesConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boards.RepositoryFileUploadToBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.fileupload.UploadBaseScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Sanjeevanee.Kanase Class to create a public link - for uploaded file
 */
public class CreateBoardFilePublicLinkBaseScript extends BaseTestScript {

	protected String createBoardFilePublicLinkJsonBody;
	protected static final String apiName = "CreateBoardFilePublicLink";
	
	public CreateBoardFilePublicLinkBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * get a complete url for 'create a public link API'
	 * 
	 * @return
	 */

	protected String getCreateBoardFilePublicLinkUrl() {

		FrameworkLogger.logStep("getCreateBoardFilePublicLinkUrl:-> Start");

		return apiUrls.get("boardUrl") + serverConfig.get("createBoardFilePublicLinkUrl");

	}

	protected String getCreateBoardFilePublicLinkUrl(String urlKey) {
		FrameworkLogger.logStep("getCreateBoardFilePublicLinkUrl with parameter :-> Start");

		return apiUrls.get("boardUrl") + serverConfig.get(urlKey);

	}

	protected String setCreateBoardFilePublicLinkJsonBody(String jsonBody) throws IOException {
		// load json file
		// createHeader();
		FrameworkLogger.logStep("setCreateBoardFilePublicLinkJsonBody:-> Start");
		String path = System.getProperty("user.dir") + "/resources/boardSharedServicesTestData/"+jsonBody+"";
		File file = new File(path);
		createBoardFilePublicLinkJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setCreateBoardFilePublicLinkJsonBody:-> End");
		return createBoardFilePublicLinkJsonBody;
	}

	/**
	 * Method to get create a public link Response
	 *
	 * @return create a public link validatable response
	 */

	protected ValidatableResponse triggerPostApiCreateBoardFilePublicLink() throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreateBoardFilePublicLink:-> Start");

		// get url for create a public link API
		String strApiUrl = getCreateBoardFilePublicLinkUrl();

		// get response from create a public link API
		ValidatableResponse response = triggerPostApi(strApiUrl, headerMap, createBoardFilePublicLinkJsonBody);

		FrameworkLogger.logStep("triggerPostApiCreatePublicLink:-> End");
		return response;
	}

	protected ValidatableResponse triggerPostApiCreateBoardFilePublicLink(String urlKey) throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreatePublicLink with parameter :-> Start");

		String strApiUrl = getCreateBoardFilePublicLinkUrl(urlKey);

		// get response from create a public link API
		ValidatableResponse response = triggerPostApi(strApiUrl, headerMap, createBoardFilePublicLinkJsonBody);

		FrameworkLogger.logStep("triggerPostApiCreatePublicLink with parameter :-> End");
		return response;
	}

	/**
	 * 
	 * @author Prateek
	 * 
	 *         Method to fetch key from create a public link response
	 */

	public static void getShareKeyAndShardKey(ValidatableResponse response) {

		FrameworkLogger.logStep("getShareKey :-> Start");
		String shareUrl = response.extract().path("shareURL");
		repositoryMap.put(RepositoryParameterEnum.SHAREURL.getValue(), shareUrl);

			// Get ShardKey from ShareUrl
		String shardKey = shareUrl.substring(shareUrl.length() - 2);
		FrameworkLogger.logStep("ShardKey========:" + shardKey);
		repositoryMap.put(RepositoryParameterEnum.SHARDKEY.getValue(), shardKey);

		// Pattern.compile("\\w{16}") Regex for fetching sharekey from url
		Pattern pattern = Pattern.compile("\\w{16}");
		Matcher matcher = pattern.matcher(shareUrl);
		if (matcher.find()) {

			String shareKey = matcher.group(0);
			System.out.println("ShareKey========:" + shareKey);
			repositoryMap.put(RepositoryParameterEnum.SHAREKEY.getValue(), shareKey);
		}
		FrameworkLogger.logStep("getShareKey :-> End");
	}

	public static String getShareKey(ValidatableResponse response) {

		FrameworkLogger.logStep("getShareKey :-> Start");
		String shareUrl = response.extract().path("shareURL");
		repositoryMap.put(RepositoryParameterEnum.SHAREURL.getValue(), shareUrl);

	//	 "shareURL": "http://sit-www.tejdrive.com/s?t=7d5f294aee294b4b89ae56"
		String shareKey = shareUrl.split("=")[1];
		
		FrameworkLogger.logStep("getShareKey :-> End"+shareKey);

		FrameworkLogger.logStep("getShareKey :-> End");
		return shareKey;
	}

	/**
	 * 
	 * Auth Api Response Service method for utilization in other test cases
	 * 
	 * @param fileName
	 * @throws VerificationFailException
	 * @throws IOException
	 * @throws InterruptedException
	 */

	public static ValidatableResponse getCreateBoardFilePublicLinkApiResponseServiceMethod(String fileName, String boardKey)
			throws VerificationFailException, IOException, InterruptedException {

		FrameworkLogger.logStep("getCreateBoardFilePublicLinkApiResponseServiceMethod:-> Start");

		ValidatableResponse uploadResponse = UploadBaseScript.getUploadFileToBoardServiceMethod(fileName, boardKey);
		 String objectKey = uploadResponse.extract().path("objectKey");
		 repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(),
				 objectKey);
		CreateBoardFilePublicLinkBaseScript apiObject = new CreateBoardFilePublicLinkBaseScript();
		// Create header for passing in request
		apiObject.createHeader();

		apiObject.setCreateBoardFilePublicLinkJsonBody("createBoardFilePublicLinkBody.js");

		// update the object key of uploaded file from repositoryMap
		apiObject.createBoardFilePublicLinkJsonBody = apiObject.setJsonData(SharedServicesConstants.getObjectKey(),
				objectKey, apiObject.createBoardFilePublicLinkJsonBody);
		apiObject.createBoardFilePublicLinkJsonBody = apiObject.setJsonData(SharedServicesConstants.getBoardKey(),
				boardKey, apiObject.createBoardFilePublicLinkJsonBody);
		
		ValidatableResponse response = apiObject.triggerPostApiCreateBoardFilePublicLink();
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Create Board File Public Link Status");
		FrameworkLogger.logStep("getCreateBoardFilePublicLinkApiResponseServiceMethod:-> End");
		return response;
		
	}
	
	
	
	
	
	public static void getCreateBoardFilePublicLinkApiResponseServiceMethodForPagination(List <String> fileName, String boardKey)
			throws VerificationFailException, IOException, InterruptedException {

		FrameworkLogger.logStep("getCreateBoardFilePublicLinkApiResponseServiceMethodForPagination:-> Start");

		for(int i=0;i<11;i++)
		{
		ValidatableResponse uploadResponse = UploadBaseScript.getUploadFileToBoardServiceMethod(fileName.get(i), boardKey);
		 String objectKey = uploadResponse.extract().path( "objectKey");
		 repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(),
				 objectKey);
		CreateBoardFilePublicLinkBaseScript apiObject = new CreateBoardFilePublicLinkBaseScript();
		// Create header for passing in request
		apiObject.createHeader();

		apiObject.setCreateBoardFilePublicLinkJsonBody("createBoardFilePublicLinkBody.js");

		// update the object key of uploaded file from repositoryMap
		apiObject.createBoardFilePublicLinkJsonBody = apiObject.setJsonData(SharedServicesConstants.getObjectKey(),
				objectKey, apiObject.createBoardFilePublicLinkJsonBody);
		apiObject.createBoardFilePublicLinkJsonBody = apiObject.setJsonData(SharedServicesConstants.getBoardKey(),
				boardKey, apiObject.createBoardFilePublicLinkJsonBody);
		
		ValidatableResponse response = apiObject.triggerPostApiCreateBoardFilePublicLink();
		//shareKey getShareKey(response);
	
		FrameworkLogger.logStep("getCreateBoardFilePublicLinkApiResponseServiceMethodForPagination:-> End");
		}
		
	}
	
	
	public static ValidatableResponse getCreateBoardFilePublicLinkApiResponseServiceMethod(String fileName, String boardKey, Map<String, String>headerMap)
			throws VerificationFailException, IOException, InterruptedException {

		FrameworkLogger.logStep("getCreateBoardFilePublicLinkApiResponseServiceMethod:-> Start");

		ValidatableResponse uploadResponse = UploadBaseScript.getUploadFileToBoardServiceMethod(fileName, boardKey);
		 String objectKey = uploadResponse.extract().path( "objectKey");
		 repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(),
				 objectKey);
		CreateBoardFilePublicLinkBaseScript apiObject = new CreateBoardFilePublicLinkBaseScript();
		// Create header for passing in request
		apiObject.createHeader(headerMap);

		apiObject.setCreateBoardFilePublicLinkJsonBody("createBoardFilePublicLinkBody.js");

		// update the object key of uploaded file from repositoryMap
		apiObject.createBoardFilePublicLinkJsonBody = apiObject.setJsonData(SharedServicesConstants.getObjectKey(),
				objectKey, apiObject.createBoardFilePublicLinkJsonBody);
		apiObject.createBoardFilePublicLinkJsonBody = apiObject.setJsonData(SharedServicesConstants.getBoardKey(),
				boardKey, apiObject.createBoardFilePublicLinkJsonBody);
		
		ValidatableResponse response = apiObject.triggerPostApiCreateBoardFilePublicLink();
	//	getShareKeyAndShardKey(response);
		FrameworkLogger.logStep("getCreateBoardFilePublicLinkApiResponseServiceMethod:-> End");
		return response;
		
	}
	
}