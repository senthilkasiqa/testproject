/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boards;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;

/**
 * @author User
 *
 */
public class DownloadBoardCoverPicBaseScript extends BaseTestScript{

	protected static final String apiName = "DownloadBoardCoverPic";

	// protected Map<String, String> headerMap = null;

	public DownloadBoardCoverPicBaseScript() {
		globalApiName = apiName;
	}

	protected ValidatableResponse triggerGetApiDownloadBoardCoverPic(String url) {

		ValidatableResponse response = triggerGetApi(url);

		return response;
	
}
}
