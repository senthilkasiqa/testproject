package com.rjil.cloud.tej.apihelpers.nms;

import java.io.File;
import java.io.IOException;
import org.testng.Assert;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * 
 * 
 * @author Prateek
 * 
 * Base class for Restore Metadata Api
 *
 */

public class RestoreMetadataBaseScript extends BaseTestScript {
	protected static final String apiName = "RestoreMetadata";
	protected String restoreMetadataJSONBody;

	public RestoreMetadataBaseScript(){
		globalApiName=apiName;
	}
	/**
	 * get a complete url for 'Restore metadata API'
	 * 
	 * @return
	 */
	protected String getRestoreMetadataURL() {
		FrameworkLogger.logStep("getRestoreMetadataURL: Start");
		String url = apiUrls.get("baseURL") + serverConfig.get("restoreMetadataUrl");
		FrameworkLogger.logStep("getRestoreMetadataURL: End");
		return url;
	}

	/**
	 * get a complete url for "restore metadata api with invalid data"
	 */
		
	protected String getRestoreMetadataURL(String url) {
		FrameworkLogger.logStep("getRestoreMetadataURL: Start");
		String apiUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		FrameworkLogger.logStep("getRestoreMetadataURL: End");
		return apiUrl;
	}

	// Set the jsonBody for RestoreMetadata API
	protected String setRestoreMetadataJsonBody() throws IOException {
		// load json file
		FrameworkLogger.logStep("setRestoreMetadataJsonBody: Start");
		String path = System.getProperty("user.dir") + "/resources/nmsTestData/restoreMetadataBody.js";
		File file = new File(path);
		restoreMetadataJSONBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setRestoreMetadataJsonBody: End");
		return restoreMetadataJSONBody;
	}

	/**
	 * Method to get Restore Metadata API Response
	 * 
	 * @return
	 * @throws IOException
	 */
	protected ValidatableResponse getRestoreMetadataAPIResponse() throws IOException {
		// setTrashMetadataJsonBody();
		FrameworkLogger.logStep("getRestoreMetadataAPIResponse: Start");

		String strApiUrl = getRestoreMetadataURL();
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, restoreMetadataJSONBody);

		FrameworkLogger.logStep("getRestoreMetadataAPIResponse: End");
		return response;
	}

	/**
	 * Method to get Restore metadata api response for invalid cases
	 * 
	 */

	protected ValidatableResponse getRestoreMetadataAPIResponse(String apiUrl) throws IOException {
		// setTrashMetadataJsonBody();
		FrameworkLogger.logStep("getRestoreMetadataAPIResponse: Start");

		String strApiUrl = getRestoreMetadataURL(apiUrl);
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, restoreMetadataJSONBody);

		FrameworkLogger.logStep("getRestoreMetadataAPIResponse: End");
		return response;
	}

	public static void extractAndVerifyRestoreMetadataResponse(ValidatableResponse response) throws VerificationFailException {
		String status = response.extract().path("objects[0].status");
		boolean isHidden = response.extract().path("objects[0].isHidden");
		boolean isLocked = response.extract().path("objects[0].isLocked");
		//boolean isPinned = response.extract().path("objects[0].isPinned");
		//boolean iLiked = response.extract().path("objects[0].iLiked");
		boolean isReadonly = response.extract().path("objects[0].isReadonly");

		Verify.verifyEquals(status, "A");
		Verify.verifyEquals(isHidden, false);
		Verify.verifyEquals(isLocked, false);
		//Assert.assertEquals(isPinned, false);
		//Assert.assertEquals(iLiked, false);
		Verify.verifyEquals(isReadonly, false);

	}

	 
	public  ValidatableResponse getRestoreMetadataAPIService() throws IOException {
		// setTrashMetadataJsonBody();
		FrameworkLogger.logStep("getRestoreMetadataAPIResponse: Start");
		createHeader();
		String strApiUrl = getRestoreMetadataURL();
		// Call method to trigger PUT API.
		setRestoreMetadataJsonBody();
		// Update Json body for restore metadata api
		restoreMetadataJSONBody = setJsonData(NmsConstants.getObjectKey(0),
						repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue()), restoreMetadataJSONBody);
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, restoreMetadataJSONBody);

		FrameworkLogger.logStep("getRestoreMetadataAPIResponse: End");
		return response;
	}
}
