/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.usermanagement;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author Prateek
 * 
 *         Base class for Set User Profile Pic Api
 *
 */
public class SetUserProfilePicBaseScript extends BaseTestScript {

	protected static final String apiName = "SetUserProfilePic";

	protected String setUserProfilePicJsonBody = null;
	
	public SetUserProfilePicBaseScript(){
		globalApiName=apiName;
	}

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Remove device key from header for this API.
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * 
	 * Method to get set user profile pic url
	 * 
	 * URL=http://{envUrl}/security/users/profile/photo
	 * 
	 */
	protected String getSetUserProfilePicUrl() {
		FrameworkLogger.logStep("getSetUserProfilePicUrl: Start");
		String url = apiUrls.get("baseURL") + serverConfig.get("setUserProfilePicUrl");
		FrameworkLogger.logStep("getSetUserProfilePicUrl:" + url);
		FrameworkLogger.logStep("getSetUserProfilePicUrl:End");
		return url;

	}
	
	protected String getSetUserProfilePicUrl(String url) {
		FrameworkLogger.logStep("getSetUserProfilePicUrl: Start");
		String apiUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		FrameworkLogger.logStep("getSetUserProfilePicUrl:End");
		return apiUrl;

	}

	/**
	 * Method to create set user profile pic json body
	 * 
	 * @return
	 * @throws IOException
	 */
	protected String setUserProfilePicJsonBody() throws IOException {
		FrameworkLogger.logStep("setUserProfilePicJsonBody: Start");
		// load json file
		String path = System.getProperty("user.dir") + "/resources/userManagementTestData/setUserProfilePic.js";
		File file = new File(path);
		setUserProfilePicJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setUserProfilePicJsonBody: End");
		return setUserProfilePicJsonBody;
	}

	/**
	 * Method to get set user profile pic api Response
	 * 
	 * @return trashMetadata validatable response
	 */
	protected ValidatableResponse triggerPutApiSetUserProfilePic() throws IOException {

		FrameworkLogger.logStep("triggerPutApiSetUserProfilePic: Start");

		String strApiUrl = getSetUserProfilePicUrl();
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, setUserProfilePicJsonBody);

		FrameworkLogger.logStep("triggerPutApiSetUserProfilePic: End");

		return response;
	}
	
	protected ValidatableResponse triggerPutApiSetUserProfilePic(String apiUrl) throws IOException {

		FrameworkLogger.logStep("triggerPutApiSetUserProfilePic: Start");

		String strApiUrl = getSetUserProfilePicUrl(apiUrl);
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, setUserProfilePicJsonBody);

		FrameworkLogger.logStep("triggerPutApiSetUserProfilePic: End");

		return response;
	}

}
