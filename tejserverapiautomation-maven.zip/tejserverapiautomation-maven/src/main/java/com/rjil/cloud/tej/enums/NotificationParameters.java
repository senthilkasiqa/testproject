package com.rjil.cloud.tej.enums;

public enum NotificationParameters {
	
	NOTIFICATIONS("notifications"),
	NOTIFICATIONID("notificationId"), 
	STATUS("status");

	public String value;

	NotificationParameters(String value) {
		this.value = value;

	}

	public String getValue() {
		return value;
	}
}
