package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;
/**
 * @author Chandrashekhar Singh
 * 
 * Base script for Merge Suggestions API.
 * */

public class MergeSuggestionsBaseScript extends BaseTestScript {
    
	protected static final String apiName="MergeSuggestions";
	
	public MergeSuggestionsBaseScript(){
  		globalApiName=apiName;
  	}

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It creates the url for API
     */
    protected String getMergeSuggestionsUrl(String dedupeID) {
		String methodName="getMergeSuggestionsUrl";
		FrameworkLogger.logStep(methodName+" -> Start");
		
		String result=apiUrls.get("baseContactURL") + serverConfig.get("mergeSuggestionsURL").replace("{dedupeid}", dedupeID);
		
		FrameworkLogger.logStep(methodName+" -> End");
		
        return result;
    }


    /**
     * @return validatable response for Merge Suggestions
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    protected ValidatableResponse triggerGetApiMergeSuggestions(String dedupeID) {
		FrameworkLogger.logStep("triggerGetApiMergeSuggestions -> Start");
		
		//Get the URL of the API.
		String strApiUrl=getMergeSuggestionsUrl(dedupeID);
//		ValidatableResponse response =triggerAPI(apiUrl);
		
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);

		FrameworkLogger.logStep("triggerGetApiMergeSuggestions -> End");

        return response;
    }

    // This method take MergeSuggestions response as input and returns the Map of all contacts' VCard.
    public static Map<String, String> getContactVcardFromMergeSuggestions(ValidatableResponse response){
        FrameworkLogger.logStep("getContactVcardFromMergeSuggestions -> Start");
        
		Map<String, String> contactVcard=new HashMap<String, String>();

		//Number of contacts in the response.
		int size=getNumberOfContactsInMergeSuggestions(response);
		
		String strContactId=null;
		String strContactVcard=null;
		
		for (int i = 0; i < size; i++) {
			strContactId = response.extract().path(
					"mergeSuggestion.duplicateContacts["+ i +"].contactId");
			strContactVcard = response.extract().path(
					"mergeSuggestion.duplicateContacts[0].vcard");
			contactVcard.put(strContactId, strContactVcard);
		}
		
        FrameworkLogger.logStep("getContactVcardFromMergeSuggestions -> End");

		return contactVcard;
    }
    
    // It returns the number of contacts in the response.
    public static int getNumberOfContactsInMergeSuggestions(ValidatableResponse response){
        FrameworkLogger.logStep("getNumberOfContactsInMergeSuggestions -> Start");

		List<String> strMergeSuggestionsContactsList=response.extract().path("mergeSuggestion.duplicateContacts");
		int size=strMergeSuggestionsContactsList.size();
		
        FrameworkLogger.logStep("getNumberOfContactsInMergeSuggestions -> End");
		return size;
    }

    // Service method to hit the MergeSuggestions API.
    public static ValidatableResponse triggerMergeSuggestionsApiServiceMethod(String dedupeID) throws VerificationFailException{
    	
        FrameworkLogger.logStep("triggerMergeSuggestionsApiServiceMethod -> Start");

        MergeSuggestionsBaseScript apiObj=new MergeSuggestionsBaseScript();
        // Creating header with default values.
		apiObj.createHeader();

        FrameworkLogger.logStep("Hitting the Merge Suggestions API");

        ValidatableResponse responseMergeSuggestions = apiObj.triggerGetApiMergeSuggestions(dedupeID);
		
//		int mergeSuggestionsStatusCode=responseMergeSuggestions.extract().statusCode();
		
		//Verifying HTTP status code of Merge Suggestions.
//		Verify.verifyEquals(mergeSuggestionsStatusCode, ApiResponseCodes.RESPONSECODE200.getValue());
		
        FrameworkLogger.logStep("triggerMergeSuggestionsApiServiceMethod -> End");
        return responseMergeSuggestions;

    }

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It creates the url for API
     */
    protected String getMergeSuggestionsUrlForInvalidUrl(String strInvalidUrlKey) {
		String methodName="getMergeSuggestionsUrlForInvalidUrl";
		FrameworkLogger.logStep(methodName+" -> Start");
		
		String result=apiUrls.get("baseURL") + serverConfig.get(strInvalidUrlKey);
		
		FrameworkLogger.logStep(methodName+" -> End");
		
        return result;
    }


    /**
     * @return validatable response for Merge Suggestions for Invalid Url
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    protected ValidatableResponse triggerGetApiMergeSuggestionsForInvalidUrl(String strInvalidUrlKey) {
		FrameworkLogger.logStep("triggerGetApiMergeSuggestionsForInvalidUrl -> Start");
		
		//Get the URL of the API.
		String strApiUrl=getMergeSuggestionsUrlForInvalidUrl(strInvalidUrlKey);
		
		//Call method to trigger API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);

		FrameworkLogger.logStep("triggerGetApiMergeSuggestionsForInvalidUrl -> End");

        return response;
    }

    // Service method to hit the MergeSuggestions API for Invalid Url.
    public static ValidatableResponse triggerMergeSuggestionsApiServiceMethodForInvalidUrl(String strInvalidUrl) throws VerificationFailException{
    	
        FrameworkLogger.logStep("triggerMergeSuggestionsApiServiceMethodForInvalidUrl -> Start");

        MergeSuggestionsBaseScript apiObj=new MergeSuggestionsBaseScript();
        // Creating header with default values.
		apiObj.createHeader();

        FrameworkLogger.logStep("Hitting the Merge Suggestions API");

        ValidatableResponse responseMergeSuggestions = apiObj.triggerGetApiMergeSuggestionsForInvalidUrl(strInvalidUrl);
		
//		int mergeSuggestionsStatusCode=responseMergeSuggestions.extract().statusCode();
		
		//Verifying HTTP status code of Merge Suggestions.
//		Verify.verifyEquals(mergeSuggestionsStatusCode, ApiResponseCodes.RESPONSECODE200.getValue());
		
        FrameworkLogger.logStep("triggerMergeSuggestionsApiServiceMethodForInvalidUrl -> End");
        return responseMergeSuggestions;

    }
    
    public int getIndexOfSerGuidFromMergeSuggestionsResponse(ValidatableResponse responseMergeSuggestions, 	String SerGuid)
    
    {
    	int isSerGuidMatchingIndex = -1;
    	int size = responseMergeSuggestions.extract().jsonPath().getList("mergeSuggestion.duplicateContacts").size();
    	List<String> objList = new ArrayList <String>();  
    //	for (int i =0; i<size;i++)
    //	{
	objList = responseMergeSuggestions.extract().jsonPath().get("mergeSuggestion.duplicateContacts.contactId");
    //	}
    	
	String First= objList.get(0);
	String Second= objList.get(1);
	String Third= objList.get(2);
	
	System.out.println("FIRST**************************="+First);
	System.out.println("Second**************************="+Second);
	System.out.println("Third***********************="+Third);
	
	
		for (String actualObjectKeyValue : objList) {
			FrameworkLogger.logStep("Comparing strObjectKeyValue:-> " + SerGuid
					+ " With actualObjectKeyValue:-> " + actualObjectKeyValue);
			if (actualObjectKeyValue.equalsIgnoreCase(SerGuid)) {
				isSerGuidMatchingIndex = objList.indexOf(actualObjectKeyValue);
				break;
			}
		}
		FrameworkLogger.logStep("getIndexIfObjectKeyPresentInResponse:-> end");
		FrameworkLogger.logStep("index of uploaded file in response=" + isSerGuidMatchingIndex);
		return isSerGuidMatchingIndex;
		

    }
    
    
}
