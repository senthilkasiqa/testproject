package com.rjil.cloud.tej.apihelpers.nms;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;

import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class EmptyAllTrashBaseScript extends BaseTestScript {

	protected static final String apiName = "EmptyAllTrash";
	
	public EmptyAllTrashBaseScript(){
		globalApiName=apiName;
	}
//	protected Map<String, String> headerMap = null;

	// created a Hashmap to save all the headers.
/*	protected void createHeader() {

		FrameworkLogger.logStep("createHeader:-> Start");
		headerMap = new HashMap<>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");

		// Add 'X-Api-Key' in header for the API.
		addXapiHeaderKey(headerMap);

		FrameworkLogger.logStep("createHeader:-> End");
	}
*/
	/**
	 * get a complete url for 'Empty All Trash API'
	 * 
	 * @return
	 */
	protected String getEmptyAllTrashUrl() {
		FrameworkLogger.logStep("getEmptyAllTrashUrl: Start");
		//String url=apiUrls.get("baseURL") + serverConfig.get("emptyAllTrashUrl");
		String url=getEmptyAllTrashUrl("emptyAllTrashUrl");
		FrameworkLogger.logStep("getEmptyAllTrashUrl: End");
		return url;
	}
	
	/**
	 * get a complete url for 'Empty All Trash API' for negative test
	 * 
	 * @return
	 */
	protected String getEmptyAllTrashUrl(String url) {
		FrameworkLogger.logStep("getEmptyAllTrashUrl: Start");
		String apiUrl=apiUrls.get("baseURL") + serverConfig.get(url);
		FrameworkLogger.logStep("getEmptyAllTrashUrl: End");
		return apiUrl;
	}

	/**
	 * Method to get empty all trash Response
	 * 
	 * 
	 */
	protected ValidatableResponse getEmptyAllTrashApiResponse() throws IOException {
		FrameworkLogger.logStep("getEmptyAllTrashApiResponse: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().put(getEmptyAllTrashUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/		
		String strApiUrl=getEmptyAllTrashUrl();
		//Call method to trigger PUT API.
		//ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		ValidatableResponse response= getEmptyAllTrashApiResponse("emptyAllTrashUrl");
		
		FrameworkLogger.logStep("getEmptyAllTrashApiResponse: End");
		return response;
	}
	
	/**
	 * Method to get empty all trash Response for negative test
	 * 
	 * 
	 */
	protected ValidatableResponse getEmptyAllTrashApiResponse(String url) throws IOException {
		FrameworkLogger.logStep("getEmptyAllTrashApiResponse: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().put(getEmptyAllTrashUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/		
		String strApiUrl=getEmptyAllTrashUrl(url);
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);

		FrameworkLogger.logStep("getEmptyAllTrashApiResponse: End");
		return response;
	}

	/**
	 * Get Empty All Trash Response
	 * 
	 * @param response
	 * @throws VerificationFailException 
	 */

	public static void extractAndVerifyEmptyAllTrashResponse(ValidatableResponse response) throws VerificationFailException {
		FrameworkLogger.logStep("extractAndAssertEmptyAllTrashResponse:Start");
		
		String status = response.extract().path("objects[0].status");
		boolean isHidden = response.extract().path("objects[0].isHidden");
		boolean isLocked = response.extract().path("objects[0].isLocked");
		/*boolean isPinned = response.extract().path("objects[0].isPinned");
		boolean iLiked = response.extract().path("objects[0].iLiked");*/
		boolean isReadonly = response.extract().path("objects[0].isReadonly");

		Verify.verifyEquals(status, "D");
		Verify.verifyEquals(isHidden, false);
		Verify.verifyEquals(isLocked, false);
		/*Assert.assertEquals(isPinned, false);
		Assert.assertEquals(iLiked, false);*/
		Verify.verifyEquals(isReadonly, false);

		FrameworkLogger.logStep("extractAndAssertEmptyAllTrashResponse:End");
	}

	/**
	 * Empty all trash api service method
	 * 
	 * @throws IOException
	 */
	public static ValidatableResponse emptyAllTrashServiceMethod() throws IOException {
		FrameworkLogger.logStep("emptyAllTrashServiceMethod: Start");
		EmptyAllTrashBaseScript baseScript = new EmptyAllTrashBaseScript();
		baseScript.createHeader();
		ValidatableResponse response = baseScript.getEmptyAllTrashApiResponse();
		FrameworkLogger.logStep("emptyAllTrashServiceMethod: End");
		return response;
	}
	
	public static int getIndexIfObjectKeyPresentInResponse(ValidatableResponse response, String strObjectKeyValue)
			throws IOException {
		FrameworkLogger.logStep("getIndexIfObjectKeyPresentInResponse:-> start; strObjectKeyValue:-> " + strObjectKeyValue);
		int isObjectKeyMatchingIndex = -1;

		int sizeOfOjectArray = response.extract().jsonPath().getList("objects").size();
		FrameworkLogger.logStep("sizeOfOjectArray:-> " + sizeOfOjectArray);
		for (int i = 0; i < sizeOfOjectArray; i++) {
			String actualObjectKeyValue = response.extract().path("objects[" + i + "].objectKey");

			FrameworkLogger.logStep("Comparing strObjectKeyValue:-> " + strObjectKeyValue
					+ " With actualObjectKeyValue:-> " + actualObjectKeyValue);

			if (actualObjectKeyValue.equalsIgnoreCase(strObjectKeyValue)) {
				isObjectKeyMatchingIndex = i;
				FrameworkLogger.logStep("ObjectKeyValue matched.");
				break;
			}
		}
		FrameworkLogger.logStep("getIndexIfObjectKeyPresentInResponse:-> end");
		System.out.println("index of uploaded file in response="+isObjectKeyMatchingIndex);
		return isObjectKeyMatchingIndex;
		
	}
}
