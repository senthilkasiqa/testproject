package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.util.HashMap;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;
/**
 * @author Chandrashekhar Singh
 * 
 * Base script for Update Success Restore Date Time.
 * */

public class UpdateSuccessRestoreDateTimeBaseScript extends BaseTestScript {
    protected static final String apiName="UpdateSuccessRestoreDateTimeAPI";
    protected  String jsonBody;
    
    public UpdateSuccessRestoreDateTimeBaseScript(){
  		globalApiName=apiName;
  	}
    /**
     * @author Chandrashekhar Singh
     * <p>
     * It creates the url for API
     */
    protected String getUpdateSuccessRestoreDateTimeUrl() {
        return apiUrls.get("baseContactURL") + serverConfig.get("updateSuccessRestoreDateTimeUrl");
    }

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It loads the default JSON body.
     */

    protected void loadJsonFile(){
		FrameworkLogger.logStep("loadJsonFile:-> Start");
        //load json file
		String filePath="/resources/updateSuccessRestoreDateTimeTestData/updateSuccessRestoreDateTimeJsonBody.js";
		jsonBody=loadJsonFile(filePath);

		FrameworkLogger.logStep("loadJsonFile:-> End");
    }
    
    /**
     * @author Chandrashekhar Singh
     * <p>
     * It will set the value on provided json path
     */
    protected void setRestoreDateTimeInJsonBody(String strDateTime) {
		FrameworkLogger.logStep("setRestoreDateTimeInJsonBody:-> Start");
        jsonBody=jsonBody.replace("$restoreDateTime$", strDateTime);

		FrameworkLogger.logStep("setRestoreDateTimeInJsonBody:-> End");
    }


    /**
     * @return validatable response for API
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    protected ValidatableResponse triggerPutApiUpdateSuccessRestoreDateTime() {
		FrameworkLogger.logStep("triggerPutApiUpdateSuccessRestoreDateTime:-> Start");

//		triggerPutApi
		String strApiUrl=getUpdateSuccessRestoreDateTimeUrl();
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,jsonBody);

        FrameworkLogger.logStep("triggerPutApiUpdateSuccessRestoreDateTime:-> End");

        return response;
    }

    /**
     * @author Chandrashekhar Singh
     * @return validatable response for API
     * <p>
     * Call the method to update the date.
     */
	public static ValidatableResponse updateSuccessRestoreDateTimeServiceMethod(String restoreDate)
			throws InterruptedException, VerificationFailException {
		FrameworkLogger.logStep("updateSuccessRestoreDateTimeServiceMethod -> Start");
		
		//Create object of the API base class.
		UpdateSuccessRestoreDateTimeBaseScript apiObj=new UpdateSuccessRestoreDateTimeBaseScript();
		
		// Load the sample JSON file.
		apiObj.loadJsonFile();
		// Create the header of API.
		apiObj.createHeader();

		//get the today's date.
//		String restoreDate=Utils.getTime();
		// Set the RestoreViewTime in JSON.
		apiObj.setRestoreDateTimeInJsonBody(restoreDate);

		// Trigger the API and get the response.
		ValidatableResponse response = apiObj.triggerPutApiUpdateSuccessRestoreDateTime();

		// Get and verify the status code.
		int status = response.extract().statusCode();
		Verify.verifyEquals(status,
				ApiResponseCodes.RESPONSECODE200.getValue(),
				"Verify Success Status");

		FrameworkLogger.logStep("updateSuccessRestoreDateTimeServiceMethod -> End");
		
		return response;
		
	}
}
