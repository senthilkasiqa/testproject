/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boards;

import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author User
 *
 */
public class DownloadBoardFileBaseScript extends BaseTestScript{

	protected static final String apiName = "DownloadBoardCoverPic";

	// protected Map<String, String> headerMap = null;

	public DownloadBoardFileBaseScript() {
		globalApiName = apiName;
	}
	
	protected Map<String,String> createHeader() {
		FrameworkLogger.logStep("createHeader:-> Start");

		headerMap=initializeHeader();
		//headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), ifModifiedSince);
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		FrameworkLogger.logStep("createHeader:-> End");
		return headerMap;
	}

	protected ValidatableResponse triggerGetApiDownloadBoardFile(String url) {

		ValidatableResponse response = triggerGetApi(url,headerMap);

		return response;
	
}
}
