package com.rjil.cloud.tej.apihelpers.boards;
import static com.jayway.restassured.RestAssured.given;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.simple.JSONObject;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class GetBoardCategoriesBaseScript extends BaseTestScript{

	protected static final String apiName = "GetBoardCategories";
	
		protected String getBoardCategoriesURL() {
		FrameworkLogger.logStep(" getBoardCategoriesURL:-> Start");
		return apiUrls.get("boardUrl") + serverConfig.get("getBoardCategoriesUrl");
		//return "http://board.dev-jiocloud.com:8080"+serverConfig.get("getBoardCategoriesUrl");
	}
		
	protected String getBoardCategoriesURL(String url) {
			FrameworkLogger.logStep(" getBoardCategoriesURL:-> Start");
			return apiUrls.get("boardUrl") + url;
		}
	
	protected ValidatableResponse triggerGetgetBoardCategory() throws IOException {
		FrameworkLogger.logStep("triggerGetBoardCategory:-> Start");
		String strApiUrl = getBoardCategoriesURL();
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetBoardCategory:-> End");
		return response;
	}
	
	protected ValidatableResponse triggerGetgetBoardCategory(String url) throws IOException {
		FrameworkLogger.logStep("triggerGetBoardCategory:-> Start");
		String strApiUrl = getBoardCategoriesURL(url);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetBoardCategory:-> End");
		return response;
	}
	
	public static ValidatableResponse getGetBoardCategoryService()
	{
		GetBoardCategoriesBaseScript boardCategory = new GetBoardCategoriesBaseScript();
		boardCategory.createHeader();
		String strApiUrl = boardCategory.getBoardCategoriesURL();
		ValidatableResponse response =boardCategory.triggerGetApi(strApiUrl, boardCategory.headerMap);
    	return response;
	}
	
	
}