package com.rjil.cloud.tej.apihelpers.nms;

import static com.jayway.restassured.RestAssured.given;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;

import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.NmsParameters;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Prateek
 * 
 *         Base class for delta sync api
 *
 */
public class DeltaSyncBaseScript extends BaseTestScript {

	protected static final String apiName = "DeltaSync";
	protected static final int MILLIS_IN_ONE_MINUTE = 10;
//	protected Map<String, String> headerMap = null;
	
	public DeltaSyncBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * Create Header Parameters to be passed for the API request
	 */

/*	protected void createHeader() {
		headerMap = new HashMap<>();
		headerMap.put("Content-Type", "application/json");
		headerMap.put(NmsParameters.XUSERID.getValue(), userId);
		headerMap.put(NmsParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(NmsParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(NmsParameters.ACCEPTLANGUAGE.getValue(), "en");
		headerMap.put(NmsParameters.IFMODIFIEDSINCE.getValue(),
				Utils.getTimePriorCurrentTime(MILLIS_IN_ONE_MINUTE).toString());

		// Add X-api header key
		addXapiHeaderKey(headerMap);

	}
*/

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Add additional header parameters.
		headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(),
				Utils.getTimePriorCurrentTime(MILLIS_IN_ONE_MINUTE).toString());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * get url for NMS Delta Sync
	 * 
	 * @return url String
	 */

	protected String getDeltaSyncUrl() {
		FrameworkLogger.logStep("getDeltaSyncURL: Start");
		//String url = apiUrls.get("baseURL") + serverConfig.get("deltaSyncUrl");
		String url=getDeltaSyncUrl("deltaSyncUrl");
		FrameworkLogger.logStep("getDeltaSyncURL: End");
		return url;
	}
	
	/**
	 * get url for NMS Delta Sync for negative scenarios
	 * 
	 * @return url String
	 */

	protected String getDeltaSyncUrl(String url) {
		FrameworkLogger.logStep("getDeltaSyncURL: Start");
		String deltaSyncApiUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		FrameworkLogger.logStep("getDeltaSyncURL: End");
		return deltaSyncApiUrl;
	}
	
	/**
	 * get url for NMS Delta Sync for negative scenarios with limit parameter
	 * 
	 * @return url String
	 */

	protected String getDeltaSyncUrl(String url,String limit) {
		FrameworkLogger.logStep("getDeltaSyncURL: Start");
		//String deltaSyncApiUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		String deltaSyncApiUrl=getDeltaSyncUrl(url).replace("{limit}", limit);
		FrameworkLogger.logStep("getDeltaSyncURL: End");
		return deltaSyncApiUrl;
	}
	
	/**
	 * get url for NMS Delta Sync for negative scenarios with page parameter
	 * 
	 * @return url String
	 */

	protected String getDeltaSyncWithPageInUrl(String url,String page) {
		FrameworkLogger.logStep("getDeltaSyncURL: Start");
		//String deltaSyncApiUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		String deltaSyncApiUrl=getDeltaSyncUrl(url).replace("{page}", page);
		FrameworkLogger.logStep("getDeltaSyncURL: End");
		return deltaSyncApiUrl;
	}

	/**
	 * Method to get NMS Delta Sync Response
	 *
	 * @return Login validatable response
	 */
	protected ValidatableResponse getDeltaSyncApiResponse() {

		FrameworkLogger.logStep("getDeltaSyncApiResponse: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().get(getDeltaSyncUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/

		//Call method to trigger GET API.
		//ValidatableResponse response = triggerGetApi(getDeltaSyncUrl(),headerMap);
		
		ValidatableResponse response=getDeltaSyncApiResponse("deltaSyncUrl");

		FrameworkLogger.logStep("getDeltaSyncApiResponse: End");
		return response;
	}
	

	/**
	 * Method to get NMS Delta Sync Response
	 *
	 * @return Login validatable response
	 */
	protected ValidatableResponse getDeltaSyncApiResponse(String apiUrl) {

		FrameworkLogger.logStep("getDeltaSyncApiResponse: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().get(getDeltaSyncUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/
		
		String url=getDeltaSyncUrl(apiUrl);
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(url,headerMap);

		FrameworkLogger.logStep("getDeltaSyncApiResponse: End");
		return response;
	}
	
	/**
	 * Method to get NMS Delta Sync Response with limit in url
	 *
	 * @return Login validatable response
	 */
	protected ValidatableResponse getDeltaSyncApiResponse(String apiUrl, String limit) {

		FrameworkLogger.logStep("getDeltaSyncApiResponse: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().get(getDeltaSyncUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/
		
		String url=getDeltaSyncUrl(apiUrl,limit);
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(url,headerMap);

		FrameworkLogger.logStep("getDeltaSyncApiResponse: End");
		return response;
	}
	

	/**
	 * Method to get NMS Delta Sync Response with limit in url
	 *
	 * @return Login validatable response
	 */
	protected ValidatableResponse getDeltaSyncApiResponseWithPageInUrl(String apiUrl, String page) {

		FrameworkLogger.logStep("getDeltaSyncApiResponse: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().get(getDeltaSyncUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/
		
		String url=getDeltaSyncWithPageInUrl(apiUrl,page);
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(url,headerMap);

		FrameworkLogger.logStep("getDeltaSyncApiResponse: End");
		return response;
	}
	protected int getIndexIfObjectKeyPresentInResponse(ValidatableResponse response, String strObjectKeyValue)
			throws IOException {
		FrameworkLogger.logStep("getIndexIfObjectKeyPresentInResponse:-> start; strObjectKeyValue:-> " + strObjectKeyValue);
		int isObjectKeyMatchingIndex = -1;

		int sizeOfOjectArray = response.extract().jsonPath().getList("objects").size();
		FrameworkLogger.logStep("sizeOfOjectArray:-> " + sizeOfOjectArray);
		for (int i = 0; i < sizeOfOjectArray; i++) {
			String actualObjectKeyValue = response.extract().path("objects[" + i + "].objectKey");

			FrameworkLogger.logStep("Comparing strObjectKeyValue:-> " + strObjectKeyValue
					+ " With actualObjectKeyValue:-> " + actualObjectKeyValue);

			if (actualObjectKeyValue.equalsIgnoreCase(strObjectKeyValue)) {
				isObjectKeyMatchingIndex = i;
				FrameworkLogger.logStep("ObjectKeyValue matched.");
				break;
			}
		}
		FrameworkLogger.logStep("getIndexIfObjectKeyPresentInResponse:-> end");
		System.out.println("index of file uploaded="+isObjectKeyMatchingIndex);
		return isObjectKeyMatchingIndex;
		
	}
	

	/**
	 * Method to get NMS Delta Sync Response
	 *
	 * @return Login validatable response
	 */
	public ValidatableResponse getDeltaSyncApiService() {

		FrameworkLogger.logStep("getDeltaSyncApiService: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().get(getDeltaSyncUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/
		createHeader();
		//Call method to trigger GET API.
		//ValidatableResponse response = triggerGetApi(getDeltaSyncUrl(),headerMap);
		
		ValidatableResponse response=getDeltaSyncApiResponse("deltaSyncUrl");

		FrameworkLogger.logStep("getDeltaSyncApiService: End");
		return response;
	}
}
