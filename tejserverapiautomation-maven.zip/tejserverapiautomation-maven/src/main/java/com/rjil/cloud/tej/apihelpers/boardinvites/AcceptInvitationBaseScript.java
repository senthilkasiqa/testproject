package com.rjil.cloud.tej.apihelpers.boardinvites;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.nms.CreateFolderBaseScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.MultiDeviceRepositoryParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class AcceptInvitationBaseScript extends BaseTestScript{

	protected static final String apiName = "AcceptInvitationAPI";
	
	protected String acceptInvitationURL(String invitationCode) {
		FrameworkLogger.logStep("acceptInvitationURL: Start");
		FrameworkLogger.logStep("invitationCode: Start" + invitationCode);
		
		String url=apiUrls.get("boardInviteUrl") + serverConfig.get("acceptInvitationUrl").replace("{invitationCode}", invitationCode);
		return url;
	}
	
	
	protected String acceptInvitationURL(String urlValue, String invitationCode) {
		FrameworkLogger.logStep("acceptInvitationURL: Start");
		return (apiUrls.get("boardInviteUrl") + urlValue);
	}
  
    
    protected ValidatableResponse triggerPutApiAcceptInvitation(String invitationCode) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiAcceptInvitation: Start");
    	FrameworkLogger.logStep("invitationCode: Start" + invitationCode);
 
		String strApiUrl=acceptInvitationURL(invitationCode);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiAcceptInvitation: End");

    	return response;
    	
    }
    
    protected ValidatableResponse triggerPutApiAcceptInvitation(String urlValue, String invitationCode) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiAcceptInvitation: Start");
 
		String strApiUrl=acceptInvitationURL(urlValue, invitationCode);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiAcceptInvitation: End");

    	return response;
    	
    }
    
    //overloading triggerPutApiAcceptInvitation to device info of second user
    protected ValidatableResponse triggerPutApiAcceptInvitation(String urlValue, String invitationCode, Map<String,String>headerMap1 ) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiAcceptInvitation: Start");
 
		String strApiUrl=acceptInvitationURL(urlValue, invitationCode);
		Map<String,String> headerMap = createHeader(headerMap1);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiAcceptInvitation: End");

    	return response;
    	
    }
    protected ValidatableResponse triggerPutApiAcceptInvitation(String invitationCode, Map<String,String>headerMap1 ) throws IOException {
    	FrameworkLogger.logStep("triggerPutApiAcceptInvitation: Start");
		String strApiUrl=acceptInvitationURL(invitationCode);
		Map<String,String> headerMap = createHeader(headerMap1);
		//headerMap = createHeader(headerMap1);
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerPutApiAcceptInvitation: End");

    	return response;
    	
    }
    
    public static ValidatableResponse acceptInvitationService(String invitationCode, Map<String,String> deviceInfoMap ) throws IOException
    {
    	AcceptInvitationBaseScript accept = new AcceptInvitationBaseScript();
    	//Map<String,String> headerMap = accept.createHeader(deviceInfoMap);
    	FrameworkLogger.logStep("acceptInvitationService" + invitationCode);
    	ValidatableResponse response = accept.triggerPutApiAcceptInvitation(invitationCode,deviceInfoMap);
    	return response;
    	
    	
    }
    public static ValidatableResponse acceptInvitationService(String invitationCode) throws IOException
    {  
    	AcceptInvitationBaseScript accept = new AcceptInvitationBaseScript();
    	accept.createHeader();
    	ValidatableResponse response = accept.triggerPutApiAcceptInvitation(invitationCode);
    	return response;
    	
    }
    

}
