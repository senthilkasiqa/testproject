package com.rjil.cloud.tej.utility;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

/**
 * @author Sanjeevanee.Kanase
 *class with a method - updateInputFile (method used to append current time at the end of file)
 */
public class CommonUtilityMethods {
	/**method to update the file to be uploaded each time when execution happens.
	 * @param fileName - file to be uploaded and updated 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static void updateInputFile(String fileName) throws IOException, InterruptedException
	{
		String filePath = System.getProperty("user.dir") + "/resources/uploadTestData/"+fileName;

		File file = new File(filePath);

		FileWriter fileWriter = new FileWriter(file,true);

		BufferedWriter bufferFileWriter  = new BufferedWriter(fileWriter);

		fileWriter.append("Apending data to existing file:"+System.currentTimeMillis());

		fileWriter.flush();
		
		FrameworkLogger.logStep("FilePATH After Appending==============>"+filePath);

		Utils.fileCheckSum(filePath);

		bufferFileWriter.close();
	}

	public static JSONArray addJsonObject(String requestJSONBody, int arraySize) throws ParseException
	{
		JSONArray jsonArray = null;
		JSONParser parser=new JSONParser();
		Object objRequestBody =parser.parse(requestJSONBody);
		JSONObject jsonObjectRequestBody=(JSONObject)objRequestBody;
		for (int i=0;i<arraySize;i++)
		{
		JSONObject jsonObject = new JSONObject();
		jsonArray = (JSONArray) jsonObjectRequestBody.get("objects");
		jsonObject.put("objectKey", "$objectKey_value");
		jsonArray.add(i, jsonObject);
	    }
		return jsonArray;
	}
	
	/**
	 * Method to update the file 
	 * @param fileName
	 * @throws IOException
	 * @throws InterruptedException
	 */

		public static void updateFile(String fileName) throws IOException, InterruptedException {
			String path = System.getProperty("user.dir") + "/resources/uploadTestData/"+fileName;
		//	File f = new File("/Users/jenkins/Documents/Automation/VID_20161128_122508.mp4");
			File f = new File(path);
			FrameworkLogger.logStep("file length:->" + f.length());
			int length = (int) f.length();
			int newSize = length - 1;
			FrameworkLogger.logStep("file length:->" + newSize);
			
			byte[] buffer = new byte[newSize];
			File newFile = null;
			BufferedInputStream bis = new BufferedInputStream(new FileInputStream(f));
			String name = f.getName();

			int tmp = 0;
			while ((tmp = bis.read(buffer)) > 0) {
				// write each chunk of data into separate file with different number
				// in name
				newFile = new File(f.getParent(), name);
				FileOutputStream out = new FileOutputStream(newFile);
				out.write(buffer, 0, tmp);// tmp is chunk size
			}
			String hash = fileCheckSum(newFile.getAbsolutePath());
			FrameworkLogger.logStep("new file name:->" + newFile.getName());
			FrameworkLogger.logStep("new file size:->" + newFile.length());
			FrameworkLogger.logStep("hash of new file:->" + hash);

		}


	    public static String fileCheckSum(String fileInput){
	   	 
	    	//fileInput = System.getProperty("user.dir") + "/resources/uploadTestData/download.jpg";
	    	InputStream input = null;
			byte[] mdbytes = null;
			try {
				input = new FileInputStream(fileInput);
				long length = ((FileInputStream) input).getChannel().size();
				FrameworkLogger.logStep(Long.toString(length));
				MessageDigest md = MessageDigest.getInstance("MD5");
				byte[] dataBytes = new byte[1024];
				int nread;
				int totalRead = 0;
				while ((nread = input.read(dataBytes)) != -1) {
					md.update(dataBytes, 0, nread);
					totalRead += nread;
					if (totalRead >= length) {
						break;
					}
				}
				mdbytes = md.digest();
				input.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException ex) {
				ex.printStackTrace();
			} catch (NoSuchAlgorithmException ex) {
				ex.printStackTrace();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			String hashValue = String.format("%032x", new BigInteger(1, mdbytes));
			return hashValue;
		}

	}


