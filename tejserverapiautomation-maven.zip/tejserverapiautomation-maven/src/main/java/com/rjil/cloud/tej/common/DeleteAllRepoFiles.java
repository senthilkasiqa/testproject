package com.rjil.cloud.tej.common;

import java.io.IOException;
import java.util.List;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.nms.DeleteMetadataBaseScript;
import com.rjil.cloud.tej.apihelpers.nms.GetMetadataBaseScript;

public class DeleteAllRepoFiles {

	public static void deleteAllRepoFiles()
	{
		ValidatableResponse getMetadataResponse = null;
		try {
			getMetadataResponse = GetMetadataBaseScript.getMetadataServiceMethod();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		List<String> objList = getMetadataResponse.extract().jsonPath().get("objects.objectKey");
		for(int i=0; i<objList.size();i++)
		{
			try {if(!objList.get(i).equalsIgnoreCase(BaseTestScript.rootFolderKey))
			{
				DeleteMetadataBaseScript.deleteMetadataForFileServiceMethod(objList.get(i));
			}
			} catch (IOException e) {
				
				e.printStackTrace();
			} catch (VerificationFailException e) {
				
				e.printStackTrace();
			}
			System.out.println("DELETED FOR OBJECTKEY = "+objList.get(i));
		}
	}
}
