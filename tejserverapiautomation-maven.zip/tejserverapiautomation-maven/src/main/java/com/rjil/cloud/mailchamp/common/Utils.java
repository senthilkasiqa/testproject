package com.rjil.cloud.mailchamp.common;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class Utils {

   /**
    * Method to get Properties Map from property file
    *
    * @return : Property Map
    */
   public static Map<String, String> getServerConfigMAP() {

       try {
           String path = System.getProperty("user.dir") + "/resources/ProjectConfig.properties";
           File config = new File(path);
           FileInputStream input;
           input = new FileInputStream(config.getAbsolutePath());
           Properties prop = new Properties();
           prop.load(input);
           Map<String, String> properties = new HashMap<String, String>();
           for (Object key : prop.keySet()) {
               properties.put(key.toString(), prop.getProperty(key.toString()));
           }
           input.close();
           return properties;

       } catch (Exception e) {
           e.printStackTrace();
       }
       return null;
   }

   /**
    * Method to get Properties Map
    *
    * @param server Execution Server
    * @return Property Map
    */
   public static Map<String, String> getPropertyMAP(String server) {

       try {
           String path = System.getProperty("user.dir") + "/resources/serverInfo/" + server + "/config.properties";
           File config = new File(path);
           FileInputStream input;
           input = new FileInputStream(config.getAbsolutePath());
           Properties prop = new Properties();
           prop.load(input);
           Map<String, String> properties = new HashMap<String, String>();
           for (Object key : prop.keySet()) {
               properties.put(key.toString(), prop.getProperty(key.toString()));
           }
           input.close();
           return properties;
       } catch (Exception e) {
           e.printStackTrace();
       }
       return null;
          }
   
   public static Map<String, String> getTempConfigPropertyMAP(String server) {

       try {
           String path = System.getProperty("user.dir") + "/resources/serverInfo/" + server + "/tempConfig.properties";
           File config = new File(path);
           FileInputStream input;
           input = new FileInputStream(config.getAbsolutePath());
           Properties prop = new Properties();
           prop.load(input);
           Map<String, String> properties = new HashMap<String, String>();
           for (Object key : prop.keySet()) {
               properties.put(key.toString(), prop.getProperty(key.toString()));
           }
           input.close();
           return properties;
       } catch (Exception e) {
           e.printStackTrace();
       }
       return null;
          }
   
 //Keep in Utils.java file
   public static void saveProperties(File file, Properties p)throws IOException
   {
           FileOutputStream fr=new FileOutputStream(file);
           p.store(fr,"Properties");
           fr.close();
           System.out.println("saving properties");
   }

   public static void savePropertiesTempConfig(String server, Properties p)throws IOException
   {
    String path = System.getProperty("user.dir") + "/resources/serverInfo/" + server + "/tempConfig.properties";
   	File file=new File(path);
   	saveProperties(file, p);
   }

}
