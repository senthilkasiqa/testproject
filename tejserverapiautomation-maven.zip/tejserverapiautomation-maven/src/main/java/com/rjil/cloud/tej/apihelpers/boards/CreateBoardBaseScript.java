package com.rjil.cloud.tej.apihelpers.boards;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class CreateBoardBaseScript extends BaseTestScript{

	protected static final String apiName = "CreateBoardApi";
	protected static String boardJsonBody;
	//String boardJsonBody=null;
	public static String boardKey;
	
	protected String getCreateBoardURL() {
		FrameworkLogger.logStep("getCreateFolderURL: Start");
		//String url = apiUrls.get("baseURL") + serverConfig.get("createBoardUrl");
		String url = apiUrls.get("boardUrl") + serverConfig.get("createBoardUrl");
		FrameworkLogger.logStep("getCreateFolderURL: End");
		return url;
	}
	
	protected String getCreateBoardURL(String urlValue) {
		FrameworkLogger.logStep("getCreateFolderURL: Start");
		String url = apiUrls.get("boardUrl") + urlValue;
		FrameworkLogger.logStep("getCreateFolderURL: End");
		return url;
	}
	

	protected String setCreateBoardJsonBody() throws IOException{
		//String boardName = "Board___"+Utils.getUniqueId();
		// load json file
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/createBoardBody.js";
		File file = new File(path);
		boardJsonBody = JsonPath.parse(file).jsonString();
		return boardJsonBody;
	}

	
	
	protected ValidatableResponse triggerPostApiCreateBoard() throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreateBoard: Start");

		// get url for create metadata for folder API
		String strApiUrl=getCreateBoardURL();

		//boardJsonBody=setCreateBoardJsonBody();
		// get response from create a Folder API
		
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, boardJsonBody);

		String boardKey = response.extract().path("boardKey");
		repositoryMap.put(RepositoryParameterEnum.BOARDKEY.getValue(), boardKey);

		FrameworkLogger.logStep("triggerPostApiCreateBoard: BoardKey== :-> "+ boardKey);

		return response;
	}
	
	protected ValidatableResponse triggerPostApiCreateBoard( Map<String, String> headerMap) throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreateBoard: Start");

		
		// get url for create metadata for folder API
		String strApiUrl=getCreateBoardURL();

		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, createHeader(headerMap), boardJsonBody);

		String boardKey = response.extract().path("boardKey");
		repositoryMap.put(RepositoryParameterEnum.BOARDKEY.getValue(), boardKey);

		FrameworkLogger.logStep("triggerPostApiCreateBoard: BoardKey== :-> "+ boardKey);

		return response;
	}
	

	protected ValidatableResponse triggerPostApiCreateBoard(String urlValue) throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreateBoard: Start");

		// get url for create metadata for folder API
		String strApiUrl=getCreateBoardURL(urlValue);

		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, boardJsonBody);

		FrameworkLogger.logStep("triggerPostApiCreateBoard: BoardKey== :-> "+ boardKey);

		return response;
	}
	

	public static ValidatableResponse createBoardServiceMethod(String boardName) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("createBoardServiceMethod: Start");
		
		CreateBoardBaseScript boardBaseScript = new CreateBoardBaseScript();
		boardBaseScript.createHeader();
		boardJsonBody = boardBaseScript.setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = boardBaseScript.triggerPostApiCreateBoard();
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Create Board Status");
		FrameworkLogger.logStep("createBoardServiceMethod: End");
		return response;
	}
	
	public static ValidatableResponse createBoardServiceMethod(Map<String, String> headerMap1,String boardName) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("createBoardServiceMethod: Start");
		CreateBoardBaseScript boardBaseScript = new CreateBoardBaseScript();
		boardJsonBody = boardBaseScript.setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = boardBaseScript.triggerPostApiCreateBoard(headerMap1);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Create Board Status");
		FrameworkLogger.logStep("createBoardServiceMethod: End");
		return response;
	}
	
}
