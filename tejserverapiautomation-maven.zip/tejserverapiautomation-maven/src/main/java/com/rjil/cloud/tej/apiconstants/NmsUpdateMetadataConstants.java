/**
 * 
 */
package com.rjil.cloud.tej.apiconstants;

import com.rjil.cloud.tej.common.logging.FrameworkLogger;

/**
 * @author Prateek
 * 
 * NMS constants for update metadata api
 *
 */
public class NmsUpdateMetadataConstants {

	public static String getOperation(int index) {
		return "$.objects[" + index + "].operation";
	}

	public static String getcorrelationId(int index) {
		return "$.objects[" + index + "].correlationId";
	}

	public static String getCreatedDate(int index) {
		return "$.objects[" + index + "].object.createdDate";
	}

	public static String getStatus(int index) {
		return "$.objects[" + index + "].object.status";
	}
	
	public static String getParentObjectKey(int index) {
		return "$.objects[" + index + "].object.parentObjectKey";
	}
	
	public static String getParentObjectType(int index) {
		FrameworkLogger.logStep("INDEX==========="+index);
		return "$.objects[" + index + "].object.parentObjectType";
	}
	
	public static String getObjectKey(int index) {
		return "$.objects[" + index + "].object.objectKey";
	}
	
	public static String getObjectType(int index) {
		return "$.objects[" + index + "].object.objectType";
	}
	
	public static String getObjectName(int index) {
		return "$.objects[" + index + "].object.objectName";
	}
	
	public static String getMimeType(int index) {
		return "$.objects[" + index + "].object.mimeType";
	}
	
	public static String getMimeSubType(int index) {
		return "$.objects[" + index + "].object.mimeSubType";
	}
	
	public static String getSizeInBytes(int index) {
		return "$.objects[" + index + "].object.sizeInBytes";
	}
	
	public static String getIsHidden(int index) {
		return "$.objects[" + index + "].object.isHidden";
	}
	
	public static String getIsLocked(int index) {
		return "$.objects[" + index + "].object.isLocked";
	}
	
	public static String getIsReadonly(int index) {
		return "$.objects[" + index + "].object.isReadonly";
	}
	
	public static String getIsPinned(int index) {
		return "$.objects[" + index + "].object.isPinned";
	}
	
	public static String getVersion(int index) {
		return "$.objects[" + index + "].object.version";
	}
	
	public static String getSourceId(int index) {
		return "$.objects[" + index + "].object.sourceId";
	}

	public static String getSourceName(int index) {
		return "$.objects[" + index + "].object.sourceName";
	}
	
	public static String getLastModifiedDate(int index) {
		return "$.objects[" + index + "].object.lastModifiedDate";
	}
	
	public static String getLastAccessedDate(int index) {
		return "$.objects[" + index + "].object.lastAccessedDate";
	}
	
	public static String getUrl(int index) {
		return "$.objects[" + index + "].object.url";
	}

	public static String getHash(int index) {
		return "$.objects[" + index + "].object.hash";
	}
	
	//////////////////////////////////////////
/*	public static String getOperation1() {
		return "$.objects[1].operation";
	}

	public static String getcorrelationId1() {
		return "$.objects[1].correlationId";
	}

	public static String getCreatedDate1() {
		return "$.objects[1].object.createdDate";
	}

	public static String getStatus1() {
		return "$.objects[1].object.status";
	}
	
	public static String getParentObjectKey1() {
		return "$.objects[1].object.parentObjectKey";
	}
	
	public static String getParentObjectType1() {
		return "$.objects[1].object.parentObjectType";
	}
	
	public static String getObjectKey1() {
		return "$.objects[1].object.objectKey";
	}
	
	public static String getObjectType1() {
		return "$.objects[1].object.objectType";
	}
	
	public static String getObjectName1() {
		return "$.objects[1].object.objectName";
	}
	
	public static String getMimeType1() {
		return "$.objects[1].object.mimeType";
	}
	
	public static String getMimeSubType1() {
		return "$.objects[1].object.mimeSubType";
	}
	
	public static String getSizeInBytes1() {
		return "$.objects[1].object.sizeInBytes";
	}
	
	public static String getIsHidden1() {
		return "$.objects[1].object.isHidden";
	}
	
	public static String getIsLocked1() {
		return "$.objects[1].object.isLocked";
	}
	
	public static String getIsReadonly1() {
		return "$.objects[1].object.isReadonly";
	}
	
	public static String getIsPinned1() {
		return "$.objects[1].object.isPinned";
	}
	
	public static String getVersion1() {
		return "$.objects[1].object.version";
	}
	
	public static String getSourceId1() {
		return "$.objects[1].object.sourceId";
	}

	public static String getSourceName1() {
		return "$.objects[1].object.sourceName";
	}
	
	public static String getLastModifiedDate1() {
		return "$.objects[1].object.lastModifiedDate";
	}
	
	public static String getLastAccessedDate1() {
		return "$.objects[1].object.lastAccessedDate";
	}
	
	public static String getUrl1() {
		return "$.objects[1].object.url";
	}

	public static String getHash1() {
		return "$.objects[1].object.hash";
	}
	*/
	
}
