package com.rjil.cloud.tej.apihelpers.contacts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class CabWebBaseScript extends BaseTestScript{

	protected static final String moduleName = "Contacts";
	protected static final String apiName = "GetCab";

	public CabWebBaseScript(){
		globalApiName=apiName;
	}
	// Overload the method.
	protected Map<String, String> createHeader() {

		headerMap = initializeHeader();

		// get data for last two days.
		headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), Utils.getTime(-1)); 
		// Chunk size is 100 byte
		headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "100");
		headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "100");
		headerMap.put(HeaderParameters.ONLYACTIVE.getValue(), "True"); 
		headerMap.put(HeaderParameters.XOFFSET.getValue(), "0"); // Only
																		// active
																		// records.
		return headerMap;
	}

	

	/**
	 * @author Sanjeevanee Kanase
	 *         <p>
	 *         It creates the url for API
	 */
	private String getCabWebURL() {
		FrameworkLogger.logStep("getCabWebURL:-> Start");
		return apiUrls.get("baseContactURL") + serverConfig.get("cabWebURL");
		
	}

	/**
	 * @return validatable response for Contact Backup
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the Backup API and return the Response
	 */
	protected ValidatableResponse triggerGetApiforWebCab() {
		FrameworkLogger.logStep("triggerGetApiforWebCab:-> String");
		// setContactBackupJsonBody();
		String strApiUrl = getCabWebURL();
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		Utils.addRequestResponseToLogger();

		FrameworkLogger.logStep("triggerGetApiforWebCab:-> End");
		return response;
	}

}
