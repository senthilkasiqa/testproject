package com.rjil.cloud.tej.apihelpers.boardsharedservices;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class BoardInviteImageUrlBaseScript extends BaseTestScript{
	
	protected static final String apiName = "BoardInviteImageUrl";
	
	public BoardInviteImageUrlBaseScript(){
		globalApiName=apiName;
	}

	
	protected String getBoardInviteImageUrlUrl(String inviteKey) {

		FrameworkLogger.logStep("getBoardInviteImageUrlUrl:-> Start");
		String aplURL = apiUrls.get("boardUrl") + serverConfig.get("BoardInviteImageUrl").replace("{inviteKey}",
				inviteKey);
		FrameworkLogger.logStep("getShareImageUrl : End");
		return aplURL;
	}
	

	
	/**
	 * Method to get the response after triggering Get All Shared Image Url
	 * API
	 */
	protected ValidatableResponse triggerGetApiBoardInviteImageUrlUrl(String inviteKey) throws IOException {
		FrameworkLogger.logStep("triggerGetApiBoardInviteImageUrlUrl:-> Start");
		String strApiUrl = getBoardInviteImageUrlUrl(inviteKey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiBoardInviteImageUrlUrl:-> End");
		return response;
	}

	/**
	 * Method to get the response after triggering Get All Shared Image Url
	 * API
	 */
	protected ValidatableResponse triggerGetApiBoardInviteImageUrlUrlByContributor(Map<String, String>headerMap, String inviteKey) throws IOException {
		FrameworkLogger.logStep("triggerGetApiBoardInviteImageUrlUrl:-> Start");
		headerMap = createHeader(headerMap);
		String strApiUrl = getBoardInviteImageUrlUrl(inviteKey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiBoardInviteImageUrlUrl:-> End");
		return response;
	}

	}

