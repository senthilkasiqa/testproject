/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.download;

import static com.jayway.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 *
 *Base class for Shared File Transcode and Download Api
 */
public class SharedImageTranscodeAndDownloadBaseScript extends BaseTestScript{

protected static final String apiName= "SharedFileTranscodeAndDownloadApi";

	public SharedImageTranscodeAndDownloadBaseScript(){
		globalApiName=apiName;
	}
	
//	protected  Map<String,String> headerMap = null;

	    /**In order to construct the header parameters for each test, we would call a createHeader method.
	     * This method would initialize a hashmap that would contain a key-value pair ( header parameters and its corresponding value)
	     *
	     * UserId
	     * Authorization
	     *
	     * The method would then put header parameters needed for each test case.
	     * Once the header parameters are available, we would call the API method to get response.
	     * The idea behing using a hashmap is that we would need only 3 methods in the middle layer base script to run
	     * all our test cases namely*/

/*	    protected void createHeader(){
	    	FrameworkLogger.logStep("createHeader -> Start");
	    	headerMap = new HashMap<>();
	        headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
	        headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
	        addXapiHeaderKey(headerMap);
	        FrameworkLogger.logStep("createHeader -> End");
	    }
*/	

// Overload the method.
protected Map<String, String> createHeader() {
	FrameworkLogger.logStep("createHeader -> Start");

	headerMap = initializeHeader();

	// Remove from header for this API.
	headerMap.remove(HeaderParameters.XUSERID.getValue());
	headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());

	FrameworkLogger.logStep("createHeader -> End");
	return headerMap;
}

/**
	 * 
	 * Construct the Shared Image Transcode and Download request. 
	 * Need to add object key in the url by fetching object key from the Upload Response 
	 * 
	 */

	protected String getSharedImageTranscodeAndDownloadUrl(String url,String objectKey,String shareKey,String shardKey,String size) {

		FrameworkLogger.logStep("getSharedImageTranscodeAndDownloadUrl: Start");
		String createUrlForImageAndTransCodeApi = apiUrls.get("downloadPublicIp") + serverConfig.get(url).replace("{objectKey}", objectKey);
		String replaceShardKey=createUrlForImageAndTransCodeApi.replace("{shareKey}", shareKey);
		String sharedFileTranscodeAndDownloadUrl=replaceShardKey.replace("{shardKey}", shardKey).replace("{size}", size);
		FrameworkLogger.logStep("sharedFileTranscodeAndDownloadUrl=======>"+sharedFileTranscodeAndDownloadUrl);
		FrameworkLogger.logStep("getSharedImageTranscodeAndDownloadUrl: End");
		return sharedFileTranscodeAndDownloadUrl;
		}
		

	
	/**
	 * Method to get Shared Image Transcode and Download Response
	 */
	protected ValidatableResponse getSharedImageTranscodeAndDownloadResponse(String url,String objectKey,String shareKey,String shardKey,String size) {
		
		FrameworkLogger.logStep("getSharedFileTranscodeAndDownloadResponse-> Start");
//		ValidatableResponse response = given().headers(headerMap).when().get(getSharedImageTranscodeAndDownloadUrl(objectKey)).then();
//		response.log().all();

		ValidatableResponse response = triggerGetApi(getSharedImageTranscodeAndDownloadUrl(url,objectKey,shareKey,shardKey,size), headerMap);

		/***
		 * Add the request fired to the logger file for reference purpose
		 */
//		Utils.addRequestResponseToLogger();

		
		FrameworkLogger.logStep("getSharedFileTranscodeAndDownloadResponse-> End");
		/**
		 * Return back the response to the test method
		 */
		
		return response;

	}
	
}
