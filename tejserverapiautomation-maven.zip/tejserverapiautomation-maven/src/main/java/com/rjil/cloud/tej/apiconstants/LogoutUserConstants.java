package com.rjil.cloud.tej.apiconstants;

/**
 * Logout User API, JSON path Constants
 * 
 */

public class LogoutUserConstants {

    public static String getRevokeAllJsonPath() {
        return "$.revokeAll";
    }

    public static String getDevicesJsonPath() {
        return "$.devices";
    }

    public static String getDeviceKeyOneJsonPath() {
        return "$.devices[0].deviceKey";
    }

}
