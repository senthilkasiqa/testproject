package com.rjil.cloud.tej.apihelpers.contacts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class FeaturePhoneCabBaseScript extends BaseTestScript{

	protected static final String moduleName = "Contacts";
	protected static final String apiName = "FeaturePhoneGetCab";
	
	public FeaturePhoneCabBaseScript(){
		globalApiName=apiName;
	}
	
	
	protected Map<String, String> createHeader() {

	headerMap = initializeHeader();
		
	headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), Utils.getTime(-1)); 
	headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "100"); 
	headerMap.put(HeaderParameters.ONLYACTIVE.getValue(), "True"); 
		return headerMap;
	}
	
	
	
	private String getFeaturePhoneCabURL() 
	{
		return apiUrls.get("baseContactURL") + serverConfig.get("getFeaturePhoneCabURL");
	}
	
	
	protected ValidatableResponse triggerGetApiFeaturePhoneCab() {
		
		FrameworkLogger.logStep("triggerGetApiFeaturePhoneCab:-> String");
		String strApiUrl = getFeaturePhoneCabURL();
		headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "100"); 
		headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), Utils.getTime(-1));
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		Utils.addRequestResponseToLogger();
		FrameworkLogger.logStep("triggerGetApiFeaturePhoneCab:-> End");
		return response;
		
	}
	

	protected ValidatableResponse triggerGetApiFeaturePhoneCab(String url) {
		FrameworkLogger.logStep("triggerGetApiFeaturePhoneCab:-> String");
		// setContactBackupJsonBody();
		FrameworkLogger.logStep("Nextlink:->*************************"+url);
		
		ValidatableResponse response = triggerGetApi(url, headerMap);
		FrameworkLogger.logStep("triggerGetApiCab:-> End");
		return response;
	}
	
	public static String verifyContactInCab(ValidatableResponse featurePhoneCabResponse, String serverGuid)
	{
		int i;
		String nextLink1;
		int index = -1;
		String nextLink = null;
		while(index ==-1)
		{
		nextLink1 = featurePhoneCabResponse.extract().path("next");
		//"http://sit-apis.tejdrive.com/amiko/cab/allcontacts/featurephone?nextPageDate=2017-07-24 14:01:34.389616"
		 
		   FrameworkLogger.logStep("NEXTPAGEURL===============:-> " + nextLink1);
		   String completeUrlInCab[]=nextLink1.trim().split("\\?");
	        FrameworkLogger.logStep("URL - completeUrlInCab[0]:-> " + completeUrlInCab[0]);
	       String nextLink2=(nextLink1.trim().split("="))[1];
	        nextLink = (nextLink1.trim().split("="))[0];
	        
		int  noOfContactInCurrentPage = featurePhoneCabResponse.extract().jsonPath().getList("contacts").size();
		
		for(i=0;i<noOfContactInCurrentPage;i++)
		{
			String contactId = featurePhoneCabResponse.extract().path("contacts["+i+"].contactid");
			if(contactId.equalsIgnoreCase(serverGuid))
			{
				
				index = i;
				break;
			}
			
		}
		
		FeaturePhoneCabBaseScript cab = new FeaturePhoneCabBaseScript();
		
		FrameworkLogger.logStep("Nextlink:->*************************"+nextLink);
		featurePhoneCabResponse = cab.triggerGetApiFeaturePhoneCab(nextLink);
		}
	return index+""+nextLink;
	}

}
