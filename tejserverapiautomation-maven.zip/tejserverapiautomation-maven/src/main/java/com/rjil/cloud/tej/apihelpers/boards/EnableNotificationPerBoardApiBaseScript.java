/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boards;

import java.io.IOException;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 *
 */
public class EnableNotificationPerBoardApiBaseScript extends BaseTestScript{

	protected static final String apiName="EnableNotificationPerBoard";
	
	protected String getEnableNotificationPerBoardUrl(String boardKey) {
		FrameworkLogger.logStep("getEnableNotificationPerBoardUrl: Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get("enableNotificationPerBoardUrl").replace("{boardKey}", boardKey);
		FrameworkLogger.logStep("getEnableNotificationPerBoardUrl: End");
		return url;
	}
	
	protected String getEnableNotificationPerBoardInvalidUrl(String apiUrl) {
		FrameworkLogger.logStep("getEnableNotificationPerBoardUrl: Start");
		String url = apiUrls.get("boardUrl") + apiUrl;
		FrameworkLogger.logStep("getEnableNotificationPerBoardUrl: End");
		return url;
	}
	
	protected ValidatableResponse triggerPutApiEnableNotificationPerBoard(String boardKey) throws IOException {

		FrameworkLogger.logStep("triggerPutApiEnableNotificationPerBoard: Start");

		String strApiUrl=getEnableNotificationPerBoardUrl(boardKey);

		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap);

		FrameworkLogger.logStep("triggerPutApiEnableNotificationPerBoard: End");

		return response;
	}
	
	protected ValidatableResponse triggerPutApiEnableNotificationPerBoardForNegativeTest(String apiUrl) throws IOException {

		FrameworkLogger.logStep("triggerPutApiEnableNotificationPerBoardForNegativeTest: Start");

		String strApiUrl=getEnableNotificationPerBoardInvalidUrl(apiUrl);

		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap);

		FrameworkLogger.logStep("triggerPutApiEnableNotificationPerBoardForNegativeTest: End");

		return response;
	}
	
}
