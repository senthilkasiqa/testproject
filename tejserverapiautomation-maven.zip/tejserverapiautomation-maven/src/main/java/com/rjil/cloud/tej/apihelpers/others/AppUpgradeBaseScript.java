/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.others;

import static com.jayway.restassured.RestAssured.given;

import java.io.IOException;
import java.util.Map;

import org.testng.Assert;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.PingParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 */
public class AppUpgradeBaseScript extends BaseTestScript {

	public static String actualLatestAppVersion;
	public static String actualLowestSupportedVersion;
	public static String actualDownloadURL;
	protected static final String apiName="AppUpgrade";
	
	public AppUpgradeBaseScript(){
		globalApiName=apiName;
	}
	
	public void defaultLogin() throws IOException {
		//empty login
	}
	
	 //Overload the method.
    protected Map<String, String> createHeader() {
    	FrameworkLogger.logStep("createHeader: Start");
    	headerMap=initializeHeader();
    	//Remove device key from header for this API.
    	headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
    	headerMap.remove(HeaderParameters.XAPIKEY.getValue());
    	headerMap.remove(HeaderParameters.XUSERID.getValue());
    	headerMap.remove(HeaderParameters.ACCEPTLANGUAGE.getValue());
    	headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());
    	FrameworkLogger.logStep("createHeader: End");
    	return headerMap;
    }

	/**
	 * 
	 * Construct the final App Upgrade request. String that needs to be appended
	 * to the base url is passed directly from the test itself
	 * 
	 */

	public static String getAppUpgradeUrl(String os) {
		
		FrameworkLogger.logStep("getAppUpgradeUrl: Start");

		String url = apiUrls.get("URL") + serverConfig.get("appUpgradeURL").replace("{os}", os);
		
		FrameworkLogger.logStep("URL:"+url);
		
		FrameworkLogger.logStep("getAppUpgradeUrl: End");
		return url;

	}

	/**
	 * Method to get App Upgrade Response
	 */
	protected  ValidatableResponse triggerGetApiAppUpgrade(String os){
//	protected ValidatableResponse getAppUpgradeResponse(String os) {

		FrameworkLogger.logStep("getAppUpgradeResponse: Start");
		
		ValidatableResponse response = triggerGetApi(getAppUpgradeUrl(os), headerMap);
		//ValidatableResponse response = given().contentType(ContentType.JSON).when().get(getAppUpgradeUrl(os)).then();
		//response.log().all();

		/***
		 * Add the request fired to the logger file for reference purpose
		 */
		Utils.addRequestResponseToLogger();

		
//		String strApiUrl=getAppUpgradeUrl(os);
		//Call method to trigger GET API.
//		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);

		/**
		 * Return back the response to the test method
		 */
		FrameworkLogger.logStep("getAppUpgradeResponse: End");
		return response;

	}
	
	
	public void extractAppUpgradeInformationFromResponse(ValidatableResponse response){
		//Extract latest app version from response json
				actualLatestAppVersion = response.extract().path("latestAppVersion");

				//Extract lowest app version from response json
				actualLowestSupportedVersion = response.extract().path("lowestSupportedVersion");

				//Extract download url from  response json
				actualDownloadURL = response.extract().path("downloadURL");
	}
	/**
	 * 
	 * Methhod for asserting the values of app upgrade api response
	 * @param latestAppVersion
	 * @param lowestSupportedVersion
	 * @param downloadURL
	 * @throws VerificationFailException
	 */
	public void assertAppUpgradeApiResponse(String latestAppVersion, String lowestSupportedVersion, String downloadURL)
			throws VerificationFailException {
		
		/**
		// Need to assert whether we are getting the correct values in the
		// response

		// Execute below Scripts when there is an App Upgrade Release

		// Assert app version
		
		Assert.assertEquals(actualLatestAppVersion.trim(), latestAppVersion);

		// Assert lowest supported version
		Assert.assertEquals(actualLowestSupportedVersion.trim(), lowestSupportedVersion);

		// Assert download url
		Assert.assertEquals(actualDownloadURL, downloadURL);
*/
	}
}
