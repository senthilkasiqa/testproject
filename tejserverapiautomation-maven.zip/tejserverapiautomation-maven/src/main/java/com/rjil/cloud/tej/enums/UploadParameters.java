package com.rjil.cloud.tej.enums;

public enum UploadParameters {

		XUSERID("X-User-Id"),
		AUTHORIZATION("Authorization"),
	    XDEVICEKEY("X-Device-Key"),
	    FOLDERKEY("folderKey"),
	    SOURCEFOLDER("sourceFolder"),
	    ISPROFILEPIC("isProfilePic"),
	    ISAUTOUPLOAD("isAutoUpload"),
	    LATITUDE("latitude"),
	    LONGITUDE("longitude"),
    	ALTITUDE("altitude"),
	    KEYWORDS("keywords"),
	    HIDDEN("hidden");
	    public String value;

	    UploadParameters(String value) {
	        this.value = value;
	    }
	    
	    public String getValue() {
	        return value;
	    }
}
