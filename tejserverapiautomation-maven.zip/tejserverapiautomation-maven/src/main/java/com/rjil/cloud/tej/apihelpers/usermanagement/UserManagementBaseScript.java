package com.rjil.cloud.tej.apihelpers.usermanagement;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.BoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.enums.BoardParameters;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class UserManagementBaseScript extends BaseTestScript{

	protected static String addIdamUserJSONBody;
//	protected static Map<String, String> headerMap = null;
	
	// created a Hashmap to save all the headers.
/*	protected void createHeader() {
		headerMap=new HashMap<>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");

		// Add X-API Header Key
		addXapiHeaderKey(headerMap);

	}
*/
	//method to get url for addIdamUser API
//	public static String getAddIdamUserURL() {
	public String getAddIdamUserURL() {
		return apiUrls.get("baseURL") + serverConfig.get("addIdamUserURL");
	}

	//method to get url for deleteIdamUser API
//	public static String getDeleteIdamUserURL() {
	public String getDeleteIdamUserURL() {
		return apiUrls.get("baseURL") + serverConfig.get("deleteIdamUserURL");
	}

	//method to set the request body for addIdamUser API
//	protected static String setAddIdamUserJsonBody() throws IOException {
	protected String setAddIdamUserJsonBody() throws IOException {

		String path = System.getProperty("user.dir") + "/resources/userManagementTestData/addIdamUser.js";
		File file = new File(path);
		addIdamUserJSONBody = JsonPath.parse(file).jsonString();
		return addIdamUserJSONBody;
	}

	//method to get the response of addIdamUser Api 
//	public static ValidatableResponse getAddIdamUserAPIResponse() throws IOException {
	public ValidatableResponse getAddIdamUserAPIResponse() throws IOException {
		
/*		ValidatableResponse response = given().body(addIdamUserJSONBody)
				.headers((headerMap))
				.log().all()
				.when()
				.post(getAddIdamUserURL())
				.then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/
		String strApiUrl=getAddIdamUserURL();
		//Call method to trigger POST API.
    	ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, addIdamUserJSONBody);

		return response;
	}

	//method to get the response of deleteIdamUser Api 
//	public static ValidatableResponse getDeleteIdamUserAPIResponse() throws IOException {
	public ValidatableResponse getDeleteIdamUserAPIResponse() throws IOException {

/*		ValidatableResponse response = given()
				.headers((headerMap))
				.log().all()
				.when()
				.delete(getDeleteIdamUserURL())
				.then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/
		String strApiUrl=getDeleteIdamUserURL();
		//Call method to trigger DELETE API.
    	ValidatableResponse response=triggerDeleteApi(strApiUrl, headerMap);

		return response;
	}
}
