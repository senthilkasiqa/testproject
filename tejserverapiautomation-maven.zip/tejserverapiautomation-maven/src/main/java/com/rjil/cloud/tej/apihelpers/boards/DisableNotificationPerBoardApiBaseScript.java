/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boards;

import java.io.IOException;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

/**
 * @author Prateek
 * 
 * Base class for Disable Notification Per Board Api Base Script
 *
 */
public class DisableNotificationPerBoardApiBaseScript extends BaseTestScript{

protected static final String apiName="DisableNotificationPerBoard";

public DisableNotificationPerBoardApiBaseScript(){
	globalApiName=apiName;
}
	
	protected String getDisableNotificationPerBoardUrl(String boardKey) {
		FrameworkLogger.logStep("getDisableNotificationPerBoardUrl: Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get("disableNotificationPerBoardUrl").replace("{boardKey}", boardKey);
		FrameworkLogger.logStep("getDisableNotificationPerBoardUrl: End");
		return url;
	}
	
	protected String getDisableNotificationPerBoardInvalidUrl(String apiUrl) {
		FrameworkLogger.logStep("getDisableNotificationPerBoardInvalidUrl: Start");
		String url = apiUrls.get("boardUrl") + apiUrl;
		FrameworkLogger.logStep("getDisableNotificationPerBoardInvalidUrl: End");
		return url;
	}
	
	protected ValidatableResponse triggerPutApiDisableNotificationPerBoard(String boardKey) throws IOException {

		FrameworkLogger.logStep("triggerPutApiDisableNotificationPerBoard: Start");

		String strApiUrl=getDisableNotificationPerBoardUrl(boardKey);

		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap);

		FrameworkLogger.logStep("triggerPutApiDisableNotificationPerBoard: End");

		return response;
	}
	
	protected ValidatableResponse triggerPutApiDisableNotificationPerBoardForNegativeTest(String apiUrl) throws IOException {

		FrameworkLogger.logStep("triggerPutApiDisableNotificationPerBoardForNegativeTest: Start");

		String strApiUrl=getDisableNotificationPerBoardInvalidUrl(apiUrl);

		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap);

		FrameworkLogger.logStep("triggerPutApiDisableNotificationPerBoardForNegativeTest: End");

		return response;
	}
}
