package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;

/**
 * @author Chandrashekhar Singh.
 * 4.2.9.2	To get date time of last successful backup executed on given device id. 
 * */

public class LastBackupSuccessDateTimeForDeviceBaseScript extends BaseTestScript {
    protected static final String moduleName="Contacts";
    protected static final String apiName="LastBackupSuccessDateTimeForDevice";
    
    public LastBackupSuccessDateTimeForDeviceBaseScript(){
  		globalApiName=apiName;
  	}

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It creates the url for API
     */
    private String getLastBackupSuccessDateTimeForDeviceUrl() {
        return apiUrls.get("baseContactURL") + serverConfig.get("lastBackupSuccessDateTimeForDeviceUrl");
    }

    /**
     * @return validatable response for the API
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    protected ValidatableResponse triggerGetApiLastBackupSuccessDateTimeForDevice() {
		FrameworkLogger.logStep("triggerGetApiLastBackupSuccessDateTimeForDevice:-> Start");
        // setContactBackupJsonBody();
		
		String strApiUrl=getLastBackupSuccessDateTimeForDeviceUrl();
		
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);

		FrameworkLogger.logStep("triggerGetApiLastBackupSuccessDateTimeForDevice:-> End");
		return response;
    }

    /**
     * @return validatable response for the API
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
	public static String getLastBackupSuccessDateTimeForDevice() throws org.json.simple.parser.ParseException, VerificationFailException, ParseException, IOException, InterruptedException {
		FrameworkLogger.logStep("getLastBackupSuccessDateTimeForDevice:-> Start");
		
		LastBackupSuccessDateTimeForDeviceBaseScript apiObj=new LastBackupSuccessDateTimeForDeviceBaseScript();
		//Create header for the API.
		apiObj.createHeader();

//      Call the API to call LastBackupSuccessDateTime API.
        ValidatableResponse responseLastBackupSuccessDateTime = apiObj.triggerGetApiLastBackupSuccessDateTimeForDevice();

//        Get and verify the status code.
        int status = responseLastBackupSuccessDateTime.extract().statusCode();
        if(status!=ApiResponseCodes.RESPONSECODE200.getValue()){
        	
    		FrameworkLogger.logStep("Something wrong in fetching LastBackupSuccessDateTimeForDevice"
    				+ "Goint to add a contact to add LastBackupSuccessDateTimeForDevice...");

    		String strUniqueValue=Utils.getUniqueValue();

    		String firstName = "testContactFN_FromLastBackupSuccessDateTimeForDeviceRA_1_" + strUniqueValue;
    		String lastName = "testContactLN_LastBackupSuccessDateTimeForDevice1_" + strUniqueValue;
    		String aditionalName = "testContactAN_LastBackupSuccessDateTimeForDevice1_" + strUniqueValue;
    		String emailID = "testContactEmail_LastBackupSuccessDateTimeForDevice1_" + strUniqueValue+"@test.com";
    		String phoneNumber = "tel:+" + Utils.getUniquePhoneNumber();

    		ValidatableResponse responseBackup=ContactBackupBaseScript.backupAcontact("true", "false", firstName, lastName, aditionalName, phoneNumber, emailID);
        	
//    		Call the API LastBackupSuccessDateTimeForDevice
    		responseLastBackupSuccessDateTime = apiObj.triggerGetApiLastBackupSuccessDateTimeForDevice();
        }

        //Verify the date of the API
        String timeLastBackupSuccessDateTime=responseLastBackupSuccessDateTime.extract().path("timestamp");
        FrameworkLogger.logStep("timeLastBackupSuccessDateTime:-> " + timeLastBackupSuccessDateTime);
        
        FrameworkLogger.logStep("getLastBackupSuccessDateTimeForDevice:-> End");
        return timeLastBackupSuccessDateTime;
    }

}
