package com.rjil.cloud.tej.apihelpers.boardsharedservices;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apiconstants.SharedServicesConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.fileupload.UploadBaseScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class SendBoardPublicUrlBaseScript extends BaseTestScript{
	protected static final String apiName = "SendBoardPublicUrl";
	protected String sendBoardPublicURLJsonBody;
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		//Remove from header for this API.
	 //   headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
	 //   headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());
	  //  headerMap.remove(HeaderParameters.XAPIKEY.getValue());

	   	FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	
	protected String SendBoardPublicURL() {
		FrameworkLogger.logStep("SendBoardPublicURL: Start");
		String url=apiUrls.get("boardUrl") + serverConfig.get("SendBoardPublicUrl");
		return url;
	}
	
	protected String setSendBoardPublicURLJsonBody(String jsonBody) throws IOException {
		// load json file
		// createHeader();
		FrameworkLogger.logStep("setSendBoardPublicURLJsonBody:-> Start");
		String path = System.getProperty("user.dir") + "/resources/boardSharedServicesTestData/"+jsonBody+"";
		File file = new File(path);
		sendBoardPublicURLJsonBody = JsonPath.parse(file).jsonString();
		
		FrameworkLogger.logStep("sendBoardPublicURLJsonBody:-> End");
		return sendBoardPublicURLJsonBody;
	}
	
	
	protected ValidatableResponse triggerPostApiSendBoardPublicURL() throws IOException {

		FrameworkLogger.logStep("triggerPostApiSendBoardPublicURL:-> Start");

		// get url for create a public link API
		String strApiUrl = SendBoardPublicURL();

		// get response from create a public link API
		ValidatableResponse response = triggerPostApi(strApiUrl, headerMap, sendBoardPublicURLJsonBody);

		FrameworkLogger.logStep("triggerPostApiSendBoardPublicURL:-> End");
		return response;
	}

	
	
	public static ValidatableResponse getSendBoardPublicURLApiResponseServiceMethod()
			throws VerificationFailException, IOException, InterruptedException {

		FrameworkLogger.logStep("getSendBoardPublicURLApiResponseServiceMethod:-> Start");

		
		SendBoardPublicUrlBaseScript sendBoardUrl = new SendBoardPublicUrlBaseScript();
		// Create header for passing in request
		sendBoardUrl.createHeader();

		sendBoardUrl.setSendBoardPublicURLJsonBody("sendBoardPublicURLJsonBody.js");
		ValidatableResponse response = sendBoardUrl.triggerPostApiSendBoardPublicURL();
	//	getShareKeyAndShardKey(response);
		FrameworkLogger.logStep("getSendBoardPublicURLApiResponseServiceMethod:-> End");
		return response;
		
	}
	
}
