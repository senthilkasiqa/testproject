package com.rjil.cloud.tej.apihelpers.contacts;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.ContactBackupConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ApiSuccessResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class FeaturePhoneContactBackupBaseScript extends BaseTestScript {
	
    protected  String featurePhoneContactBackupJSONBody;
    protected  String profilePicUploadJSONBody;
    protected  String profilePicDeleteJSONBody;
    protected static final String apiName="ContactBackup";
    protected String vcard=null;
    protected String strOneContact=null;
   
   
    public FeaturePhoneContactBackupBaseScript() {
    	
        globalApiName=apiName;
    	
		FrameworkLogger.logStep("FeaturePhoneContactBackupBaseScript:-> Start");
            //load json file
		
        loadJsonFile();
		FrameworkLogger.logStep("FeaturePhoneContactBackupBaseScript:-> End");
    }
  
    
    public String loadJsonFile(){
		FrameworkLogger.logStep("loadJsonFile:-> Start");
      
		String filePath="/resources/contactBackupTestData/featurePhoneContactBackupBody.js";

    	
    	featurePhoneContactBackupJSONBody=loadJsonFile(filePath);
    	String strUniqueValue=Utils.getUniqueId();
    	featurePhoneContactBackupJSONBody=setfeaturePhoneContactBackupJSONBody(ContactBackupConstants.getActTranIdJsonPath(), "111"+strUniqueValue);
		FrameworkLogger.logStep("loadJsonFile:-> End");
		return featurePhoneContactBackupJSONBody;
    }
    
    
    public String loadJsonDeleteFile(){
		FrameworkLogger.logStep("loadJsonDeleteFile:-> Start");
      
		String filePath="/resources/contactBackupTestData/featurePhoneContactDeleteBody.js";

    	
    	featurePhoneContactBackupJSONBody=loadJsonFile(filePath);
    	String strUniqueValue=Utils.getUniqueId();
    	featurePhoneContactBackupJSONBody=setfeaturePhoneContactBackupJSONBody(ContactBackupConstants.getActTranIdJsonPath(), "111"+strUniqueValue);
		FrameworkLogger.logStep("loadJsonDeleteFile:-> End");
		return featurePhoneContactBackupJSONBody;
    }
    
    
    public String loadJsonUpdateFile(){
		FrameworkLogger.logStep("loadJsonUpdateFile:-> Start");
      
		String filePath="/resources/contactBackupTestData/featurePhoneContactUpdateBody.js";
    	featurePhoneContactBackupJSONBody=loadJsonFile(filePath);
    	String strUniqueValue=Utils.getUniqueId();
    	featurePhoneContactBackupJSONBody=setfeaturePhoneContactBackupJSONBody(ContactBackupConstants.getActTranIdJsonPath(), "111"+strUniqueValue);
		FrameworkLogger.logStep("loadJsonUpdateFile:-> End");
		
		return featurePhoneContactBackupJSONBody;
    }
    
    private String getFeaturePhoneContactBackupUrl() {
		FrameworkLogger.logStep("getFeaturePhoneContactBackupUrl:-> Start");
        return apiUrls.get("baseContactURL") + serverConfig.get("featurePhoneContactBackupURL");
    }
    
   
    public String setfeaturePhoneContactBackupJSONBody(String jsonPath, Object value) {
		FrameworkLogger.logStep("setfeaturePhoneContactBackupJSONBody:-> Start");
        featurePhoneContactBackupJSONBody = setJsonData(jsonPath, value, featurePhoneContactBackupJSONBody);
		FrameworkLogger.logStep("setfeaturePhoneContactBackupJSONBody:-> End");
		return featurePhoneContactBackupJSONBody;
    }
    
   
    protected void addElementInfeaturePhoneContactBackupJSONBody(String jsonPath, Object value) {
		FrameworkLogger.logStep("addElementInfeaturePhoneContactBackupJSONBody:-> Start");
        featurePhoneContactBackupJSONBody = addJsonData(jsonPath, value, featurePhoneContactBackupJSONBody);
		FrameworkLogger.logStep("addElementInfeaturePhoneContactBackupJSONBody:-> End");
    }
   
    
    public ValidatableResponse triggerPostApiFeaturePhoneContactBackup() {
		FrameworkLogger.logStep("triggerPostApiFeaturePhoneContactBackup:-> Start");
        
    	String strApiUrl=getFeaturePhoneContactBackupUrl();
    	String strUniqueValue=Utils.getUniqueValue();
		setfeaturePhoneContactBackupJSONBody(ContactBackupConstants.getActTranIdJsonPath(), "111"+strUniqueValue);
		
    	ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, featurePhoneContactBackupJSONBody);
    	FrameworkLogger.logStep("triggerPostApiFeaturePhoneContactBackup:-> End");
        return response;
    }
    
    public static ValidatableResponse triggerPostApiFeaturePhoneContactBackupService(String Id, String Name, String Surname, String Tel, String Email) {
  		FrameworkLogger.logStep("triggerPostApiFeaturePhoneContactBackup:-> Start");
          
  		FeaturePhoneContactBackupBaseScript contactBackup = new FeaturePhoneContactBackupBaseScript();
      	String strApiUrl=contactBackup.getFeaturePhoneContactBackupUrl();
      	String strUniqueValue=Utils.getUniqueValue();
      	contactBackup.setfeaturePhoneContactBackupJSONBody(ContactBackupConstants.getActTranIdJsonPath(), "111"+strUniqueValue);
      	contactBackup.featurePhoneContactBackupJSONBody = contactBackup.setJsonData(ContactBackupConstants.getFeaturePhoneIdJsonPath(), Id, contactBackup.featurePhoneContactBackupJSONBody);
      	contactBackup.featurePhoneContactBackupJSONBody = contactBackup.setJsonData(ContactBackupConstants.getFirstNameJsonPath(), Name, contactBackup.featurePhoneContactBackupJSONBody);
      	contactBackup.featurePhoneContactBackupJSONBody = contactBackup.setJsonData(ContactBackupConstants.getFamilyNameJsonPath(), Surname, contactBackup.featurePhoneContactBackupJSONBody);
      	contactBackup.featurePhoneContactBackupJSONBody = contactBackup.setJsonData(ContactBackupConstants.getFeaturePhoneTelephoneJsonPath(), Tel,contactBackup.featurePhoneContactBackupJSONBody);
      	contactBackup.featurePhoneContactBackupJSONBody = contactBackup.setJsonData(ContactBackupConstants.getFeaturePhoneEmailJsonPath(), Email, contactBackup.featurePhoneContactBackupJSONBody);
  	
      	ValidatableResponse response = contactBackup.triggerPostApi(strApiUrl, headerMap, contactBackup.featurePhoneContactBackupJSONBody);
     
      	FrameworkLogger.logStep("triggerPostApiFeaturePhoneContactBackup:-> End");
          return response;
      }
		 
}
