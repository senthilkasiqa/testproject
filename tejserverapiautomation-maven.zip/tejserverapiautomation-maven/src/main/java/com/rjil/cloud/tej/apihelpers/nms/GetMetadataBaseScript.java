package com.rjil.cloud.tej.apihelpers.nms;

import static com.jayway.restassured.RestAssured.given;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.simple.JSONObject;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class GetMetadataBaseScript extends BaseTestScript {

	protected static final String apiName = "GetMetadata";
	public static Map<String, String> headerMap1;
	public GetMetadataBaseScript() {
		globalApiName = apiName;
	}

	/**
	 * @author Sanjeevanee.Kanase class for having methods - for creating
	 *         headers, get url for calling get metadata url, and getting
	 *         response for api
	 */
	/**
	 * get a complete url for 'get Metadata API'
	 * 
	 * @return
	 */
	
	protected void createHeaderForNextLink() {
		headerMap1 = initializeHeader();
	}
	protected String getMetatadataURL() {
		FrameworkLogger.logStep(" getMetatadataURL:-> Start");
		// return apiUrls.get("baseURL") + serverConfig.get("getMetadataURL");
		return getMetatadataURL("getMetadataURL");
	}

	protected String getMetatadataURL(String url) {
		FrameworkLogger.logStep(" getMetatadataURL:-> Start");
		return apiUrls.get("baseURL") + serverConfig.get(url);
	}

	protected String getMetatadataURL1(String url, String limit) {
		FrameworkLogger.logStep(" getMetatadataURL:-> Start");
		String apiUrl = getMetatadataURL(url).replace("{limit}", limit);
		System.out.println("URL-------------------=" + apiUrl);
		return apiUrl;
	}

	protected String getMetatadataURL(String url, String limit, String filtercode) {
		FrameworkLogger.logStep(" getMetatadataURL:-> Start");
		String apiUrl = getMetatadataURL(url).replace("{limit}", limit).replace("{filtercode}", filtercode);
		return apiUrl;
	}

	protected String getMetatadataURLWithFolderKey(String url, String limit, String folderkey) {
		FrameworkLogger.logStep(" getMetatadataURL:-> Start");
		String apiUrl = getMetatadataURL(url).replace("{limit}", limit).replace("{folderkey}", folderkey);
		return apiUrl;
	}

	protected String getMetatadataURL(String url, String folderkey) {
		FrameworkLogger.logStep(" getMetatadataURL:-> Start");
		String apiUrl = getMetatadataURL(url).replace("{folderkey}", folderkey);
		return apiUrl;
	}

	/**
	 * Method to get getMetadata Response
	 * 
	 * @return getmetadata validatable response
	 */
	protected ValidatableResponse triggerGetApiGetMetadata() throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetMetadata:-> Start");
		/*
		 * String strApiUrl = getMetatadataURL();
		 * 
		 * ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		 */
		ValidatableResponse response = triggerGetApiGetMetadata("getMetadataURL");
		FrameworkLogger.logStep("triggerGetApiGetMetadata:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetApiGetMetadata(String urlKey) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetMetadata:-> Start");
		String strApiUrl = getMetatadataURL(urlKey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetMetadata:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetApiGetMetadata(String apiUrl, String limit, String filtercode)
			throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetMetadata:-> Start");
		String strApiUrl = getMetatadataURL(apiUrl, limit, filtercode);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetMetadata:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetApiGetMetadataForFolderKey(String apiUrl, String limit, String folderkey)
			throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetMetadataForFolderKey:-> Start");
		String strApiUrl = getMetatadataURLWithFolderKey(apiUrl, limit, folderkey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetMetadataForFolderKey:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetApiGetMetadataByLimit(String apiUrl, String limit) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetMetadataByLimit:-> Start");
		String strApiUrl = getMetatadataURL1(apiUrl, limit);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetMetadataByLimit:-> End");
		return response;
	}

	protected static ValidatableResponse triggerGetApiGetMetadataForNextPage(String nextPageUrl) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetMetadataForNextPage:-> Start");
		String strApiUrl = apiUrls.get("baseURL") + nextPageUrl;
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetMetadataForNextPage:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetApiGetMetadata(String apiUrl, String folderkey) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetMetadata:-> Start");
		String strApiUrl = getMetatadataURL(apiUrl, folderkey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetMetadata:-> End");
		return response;
	}

	/**
	 * method to check that objectKey of uploaded file (using file upload api)
	 * is present in the response of getMetadata api.
	 * 
	 * @param response
	 *            - response of getMetadata API
	 * @param strObjectKey
	 *            - objectKey of uploaded file
	 * @return boolean value - true: if objectKey of uploaded file is found in
	 *         response of getmetadata api else false
	 * @throws IOException
	 */
	protected boolean isObjectKeyPresentInResponse(ValidatableResponse response, String strObjectKeyValue)
			throws IOException {
		FrameworkLogger.logStep("isObjectKeyPresentInResponse:-> start; strObjectKeyValue:-> " + strObjectKeyValue);
		boolean isObjectKeyMatching = false;
		List<String> objList = response.extract().jsonPath().get("objects.objectKey");
		for (String actualObjectKeyValue : objList) {
			FrameworkLogger.logStep("Comparing strObjectKeyValue:-> " + strObjectKeyValue
					+ " With actualObjectKeyValue:-> " + actualObjectKeyValue);
			if (actualObjectKeyValue.equalsIgnoreCase(strObjectKeyValue)) {
				isObjectKeyMatching = true;
				FrameworkLogger.logStep("ObjectKeyValue matched.");
				break;
			}
		}

		FrameworkLogger.logStep("isObjectKeyPresentInResponse:-> end");
		return isObjectKeyMatching;
	}

	public static int getIndexIfObjectKeyPresentInResponse(ValidatableResponse response, String strObjectKeyValue)
			throws IOException {
		FrameworkLogger
				.logStep("getIndexIfObjectKeyPresentInResponse:-> start; strObjectKeyValue:-> " + strObjectKeyValue);
		int isObjectKeyMatchingIndex = -1;
		boolean isObjectKeyFound = false;
		String nextLink = "";
			List<String> objList = response.extract().jsonPath().get("objects.objectKey");
			for (String actualObjectKeyValue : objList) {
				if (actualObjectKeyValue.equalsIgnoreCase(strObjectKeyValue)) {
					FrameworkLogger.logStep("Object key found:-> " + actualObjectKeyValue);
					isObjectKeyMatchingIndex = objList.indexOf(actualObjectKeyValue);
					break;
				}
			}
		FrameworkLogger.logStep("getIndexIfObjectKeyPresentInResponse:-> end");
		FrameworkLogger.logStep("index of uploaded file in response=" + isObjectKeyMatchingIndex);
		return isObjectKeyMatchingIndex;
	}

	public static ValidatableResponse getMetadataServiceMethod() throws IOException {
		GetMetadataBaseScript getMetadata = new GetMetadataBaseScript();
		headerMap = getMetadata.createHeader();
		return getMetadata.triggerGetApiGetMetadata();

	}
	
	public static ValidatableResponse getResponseIfObjectKeyPresentInResponse(ValidatableResponse response, String strObjectKeyValue)
			throws IOException {
		FrameworkLogger
				.logStep("getIndexIfObjectKeyPresentInResponse:-> start; strObjectKeyValue:-> " + strObjectKeyValue);
		int isObjectKeyMatchingIndex = -1;
		boolean isObjectKeyFound = false;
		String nextLink = "";
		searchLoop:
		do {
			List<String> objList = response.extract().jsonPath().get("objects.objectKey");
			for (String actualObjectKeyValue : objList) {
				if (actualObjectKeyValue.equalsIgnoreCase(strObjectKeyValue)) {
					FrameworkLogger.logStep("Object key found:-> " + actualObjectKeyValue);
					isObjectKeyMatchingIndex = objList.indexOf(actualObjectKeyValue);
					break searchLoop;
				}
			}
			if (isObjectKeyFound == false) {
				nextLink = response.extract().jsonPath().get("nextLink");
				FrameworkLogger.logStep("NextLink url:-> " + nextLink);
				if(nextLink!=null){
					response = triggerGetApiGetMetadataForNextPage(nextLink);
				}
			}
		} while (nextLink!=null);
		FrameworkLogger.logStep("getIndexIfObjectKeyPresentInResponse:-> end");
		FrameworkLogger.logStep("index of uploaded file in response=" + isObjectKeyMatchingIndex);
		return response;
	}
	
}