package com.rjil.cloud.tej.apihelpers.others;

import com.jayway.restassured.filter.log.RequestLoggingFilter;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.PingParameters;

import java.util.HashMap;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;


/**
 * Created by bharat on 25/08/16.
 */
public class PingBaseScript extends BaseTestScript {


//    protected static Map<String,String>headerMap = null;


   /** The following 2 common methods would be used to generate Ping,Manifest and ManifestArray related requests for each micro service
    * and return the response to the tests called
    * in PingTest,Manifest,ManifestArray class*/

    public static String getPingUploadURL(String urlpath){


        if(urlpath.equalsIgnoreCase("pingAccountURL")||urlpath.equalsIgnoreCase("manifestAccountURL")||
                urlpath.equalsIgnoreCase("manifestarrayAccountURL"))
        {

            // for account module, we need to hit the public service url
            return apiUrls.get("URL") + serverConfig.get(urlpath);

        }else if(urlpath.equalsIgnoreCase("manifestarrayUploadURL")){
        	return apiUrls.get("uploadIp") + serverConfig.get(urlpath);
        }else if(urlpath.equalsIgnoreCase("pingUploadURL")){
        	return apiUrls.get("uploadIp") + serverConfig.get(urlpath);
        }else if(urlpath.equalsIgnoreCase("manifestUploadURL")){
        	return apiUrls.get("uploadIp") + serverConfig.get(urlpath);
        }else if(urlpath.equalsIgnoreCase("manifestarrayContactsBackUpURL")){
        	return apiUrls.get("baseContactURL") + serverConfig.get(urlpath);
        }
        else if(urlpath.equalsIgnoreCase("manifestarrayContactsRestoreURL")){
        	return apiUrls.get("baseContactURL") + serverConfig.get(urlpath);
        }
        else if(urlpath.equalsIgnoreCase("manifestarrayContactsCabURL")){
        	return apiUrls.get("baseContactURL") + serverConfig.get(urlpath);
        }
        else if(urlpath.equalsIgnoreCase("manifestarrayContactsMergeURL")){
        	return apiUrls.get("baseContactURL") + serverConfig.get(urlpath);
        }
        else if(urlpath.equalsIgnoreCase("pingContactsBackUpURL")){
        	return apiUrls.get("baseContactURL") + serverConfig.get(urlpath);
        }
        else if(urlpath.equalsIgnoreCase("pingContactsRestoreURL")){
        	return apiUrls.get("baseContactURL") + serverConfig.get(urlpath);
        }
        else if(urlpath.equalsIgnoreCase("pingContactsCabURL")){
        	return apiUrls.get("baseContactURL") + serverConfig.get(urlpath);
        }
        else if(urlpath.equalsIgnoreCase("pingContactsMergeURL")){
        	return apiUrls.get("baseContactURL") + serverConfig.get(urlpath);
        }
        else if(urlpath.equalsIgnoreCase("manifestContactsBackUpURL")){
        	return apiUrls.get("baseContactURL") + serverConfig.get(urlpath);
        }
        else if(urlpath.equalsIgnoreCase("manifestContactsRestoreURL")){
        	return apiUrls.get("baseContactURL") + serverConfig.get(urlpath);
        }
        else if(urlpath.equalsIgnoreCase("manifestContactsCabURL")){
        	return apiUrls.get("baseContactURL") + serverConfig.get(urlpath);
        }
        else if(urlpath.equalsIgnoreCase("manifestContactsMergeURL")){
        	return apiUrls.get("baseContactURL") + serverConfig.get(urlpath);
        }
        /** Construct the final ping request. String that needs to be appended to the base url is passed directly from the test itself*/
        return apiUrls.get("baseURL") + serverConfig.get(urlpath);


    }

    /**
     * Method to create header parameters to be sent in the api request
     */
/*    protected void createHeader(){
        headerMap = new HashMap<>();
        headerMap.put(PingParameters.XUSERID.getValue(),userId);
        headerMap.put(PingParameters.AUTHORIZATION.getValue(),accessToken);

        // Call this method if x-api header key needs to be passed as header parameter
        addXapiHeaderKey(headerMap);

    }
*/

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Remove from header for this API.
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

    public ValidatableResponse getPingResponse(String urlpath){

        /** Pass only the user id and authorization in the header and fire the request and return the response back
         * to the called tests */

/*        ValidatableResponse response = given()

                //TODO: RequestLoggingFilter - Have a look at it
                .headers(headerMap).log().all()
                .when()
                .get(getPingUploadURL(urlpath))
                .then();
        Utils.addRequestResponseToLogger();
*/        
		String strApiUrl=getPingUploadURL(urlpath);
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);

    	return response;


    }



}


