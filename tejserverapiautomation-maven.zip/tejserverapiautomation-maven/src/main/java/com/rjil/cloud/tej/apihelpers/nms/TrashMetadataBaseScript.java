package com.rjil.cloud.tej.apihelpers.nms;

import java.io.File;
import java.io.IOException;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * 
 * @author Prateek
 * 
 *         Base class for Trash Metadata Api
 *
 */

public class TrashMetadataBaseScript extends BaseTestScript {
	protected String trashMetadataJSONBody;
	// protected Map<String, String> headerMap = null;
	protected static final String apiName = "TrashMetadata";
	
	public TrashMetadataBaseScript(){
		globalApiName=apiName;
	}
	// created a Hashmap to save all the headers.
	/*
	 * protected void createHeader() {
	 * 
	 * FrameworkLogger.logStep("createHeader:-> Start"); headerMap = new
	 * HashMap<>(); headerMap.put(HeaderParameters.CONTENTTYPE.getValue(),
	 * "application/json"); headerMap.put(HeaderParameters.XUSERID.getValue(),
	 * userId); headerMap.put(HeaderParameters.XDEVICEKEY.getValue(),
	 * serverConfig.get("deviceKey"));
	 * headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
	 * headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");
	 * 
	 * // Add 'X-Api-Key' in header for the API. addXapiHeaderKey(headerMap);
	 * 
	 * FrameworkLogger.logStep("createHeader:-> End"); }
	 */
	/**
	 * get a complete url for 'Trash metadata API'
	 * 
	 * @return
	 */

	/*
	 * protected String trashMetadataURL() { FrameworkLogger.logStep(
	 * "trashMetadataURL : Start"); String url = apiUrls.get("baseURL") +
	 * serverConfig.get("trashMetadataURL"); FrameworkLogger.logStep(
	 * "trashMetadataURL : End"); return url;
	 * 
	 * }
	 */
	/**
	 * get a complete url for 'Trash Metadata API'
	 * 
	 * @return
	 */
	protected String trashMetatadataURL() {
		FrameworkLogger.logStep("trashMetatadataURL: Start");
		return trashMetatadataURL(serverConfig.get("trashMetadataURL"));
		// return apiUrls.get("baseURL") +
		// serverConfig.get("getTrashMetadataURL");
	}

	/**
	 * get a complete url for 'Trash Metadata API'
	 * 
	 * @return
	 */
	protected String trashMetatadataURL(String urlValue) {
		FrameworkLogger.logStep("trashMetatadataURL: Start");
		String url=(apiUrls.get("baseURL") + urlValue);
		FrameworkLogger.logStep("trashMetatadataURL: Start");
		return url;
	}

	// Set the jsonBody for TrashMetadata API
	protected String setTrashMetadataJsonBody() throws IOException {
		// load json file
		FrameworkLogger.logStep("setTrashMetadataJsonBody : Start");
		String path = System.getProperty("user.dir") + "/resources/nmsTestData/trashMetadataBody.js";
		File file = new File(path);
		trashMetadataJSONBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setTrashMetadataJsonBody : End");
		return trashMetadataJSONBody;
	}

	/**
	 * Method to get trashMetadata Response
	 * 
	 * @return trashMetadata validatable response
	 */
	/*
	 * protected ValidatableResponse trashMetadataAPIResponse() throws
	 * IOException { // setTrashMetadataJsonBody(); FrameworkLogger.logStep(
	 * "trashMetadataAPIResponse : Start"); ValidatableResponse response =
	 * given().body(trashMetadataJSONBody).headers(headerMap).log().all().when()
	 * .put(trashMetadataURL()).then(); response.log().all();
	 * Utils.addRequestResponseToLogger();
	 * 
	 * String strApiUrl=trashMetadataURL(); //Call method to trigger PUT API.
	 * ValidatableResponse response =
	 * triggerPutApi(strApiUrl,headerMap,trashMetadataJSONBody);
	 * 
	 * FrameworkLogger.logStep("trashMetadataAPIResponse : End"); return
	 * response; }
	 */

	/**
	 * Method to get getTrashMetadata Response
	 * 
	 * @return getTrashMetadata validatable response
	 */
	protected ValidatableResponse triggerPutApiTrashMetadata(String trashMetadataJSONBody) throws IOException {
		FrameworkLogger.logStep("triggerPutApitrashMetadata: Start");
		/*
		 * ValidatableResponse response = given() .headers(headerMap)
		 * .log().all() .when() .get(getTrashMetatadataURL()) .then();
		 * response.log().all(); Utils.addRequestResponseToLogger();
		 */

		// String strApiUrl=getTrashMetatadataURL();
		// Call method to trigger GET API.

		ValidatableResponse response = triggerPutApiTrashMetadata(trashMetadataJSONBody,
				serverConfig.get("trashMetadataURL"));

		FrameworkLogger.logStep("triggerPutApitrashMetadata: End");
		return response;

	}

	/**
	 * Method to get getTrashMetadata Response
	 * 
	 * @return getTrashMetadata validatable response
	 */
	protected ValidatableResponse triggerPutApiTrashMetadata(String trashMetadataJSONBody, String urlValue)
			throws IOException {
		FrameworkLogger.logStep("triggerPutApitrashMetadata: Start");
		
		String strApiUrl = trashMetatadataURL(urlValue);

		// Call method to trigger GET API.

		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, trashMetadataJSONBody);
		FrameworkLogger.logStep("triggerPutApitrashMetadata: End");
		return response;

	}

	/**
	 * @author Prateek
	 * 
	 *         Service method for Trash metadata api
	 * 
	 * @throws IOException
	 * @throws VerificationFailException
	 */
	public static ValidatableResponse trashMetadataServiceMethod() throws IOException, VerificationFailException {
		FrameworkLogger.logStep("trashMetadataServiceMethod : Start");
		TrashMetadataBaseScript trashaApiObject = new TrashMetadataBaseScript();
		// Create header parameters needed for trash api request
		trashaApiObject.createHeader();
		trashaApiObject.setTrashMetadataJsonBody();
		// update the object key of uploaded file from repositoryMap
		if (repositoryMap.get(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue()) != null) {
			trashaApiObject.trashMetadataJSONBody = setJsonData(NmsConstants.getObjectKey(0),
					repositoryMap.get(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue()),
					trashaApiObject.trashMetadataJSONBody);
		} else {
			trashaApiObject.trashMetadataJSONBody = setJsonData(NmsConstants.getObjectKey(0),
					repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue()),
					trashaApiObject.trashMetadataJSONBody);
		}
		ValidatableResponse response = trashaApiObject
				.triggerPutApiTrashMetadata(trashaApiObject.trashMetadataJSONBody);
		FrameworkLogger.logStep("trashMetadataServiceMethod : End");
		return response;
	}

	/**
	 * @author Prateek
	 * 
	 *         Service method for Trash metadata api for File object
	 * 
	 * @throws IOException
	 * @throws VerificationFailException
	 */
	
	public static ValidatableResponse trashMetadataForFileServiceMethod()
			throws IOException, VerificationFailException {
		FrameworkLogger.logStep("trashMetadataForFileServiceMethod : Start");
		TrashMetadataBaseScript trashaApiObject = new TrashMetadataBaseScript();
		// Create header parameters needed for trash api request

		trashaApiObject.createHeader();
		trashaApiObject.setTrashMetadataJsonBody();
		// update the object key of uploaded file from repositoryMap

		trashaApiObject.trashMetadataJSONBody = setJsonData(NmsConstants.getObjectKey(0),
				repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue()), trashaApiObject.trashMetadataJSONBody);
		ValidatableResponse response = trashaApiObject
				.triggerPutApiTrashMetadata(trashaApiObject.trashMetadataJSONBody);
		FrameworkLogger.logStep("trashMetadataForFileServiceMethod : End");
		return response;
	}
	
	
	public static ValidatableResponse trashMetadataForFileServiceMethod(String objectKey)
			throws IOException, VerificationFailException {
		FrameworkLogger.logStep("trashMetadataForFileServiceMethod : Start");
		TrashMetadataBaseScript trashaApiObject = new TrashMetadataBaseScript();
		// Create header parameters needed for trash api request

		trashaApiObject.createHeader();
		trashaApiObject.setTrashMetadataJsonBody();
		// update the object key of uploaded file from repositoryMap

		trashaApiObject.trashMetadataJSONBody = setJsonData(NmsConstants.getObjectKey(0), objectKey, trashaApiObject.trashMetadataJSONBody);
		ValidatableResponse response = trashaApiObject.triggerPutApiTrashMetadata(trashaApiObject.trashMetadataJSONBody);
		
		FrameworkLogger.logStep("trashMetadataForFileServiceMethod : End");
		return response;
	}
	
	
}
