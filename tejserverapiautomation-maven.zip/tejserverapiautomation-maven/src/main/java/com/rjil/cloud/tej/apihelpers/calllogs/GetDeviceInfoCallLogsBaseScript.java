package com.rjil.cloud.tej.apihelpers.calllogs;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

public class GetDeviceInfoCallLogsBaseScript extends BaseTestScript {
	protected static final String apiName = "GetDeviceInfoCallLogs";
	
	protected String getDeviceInfoLogsURL() {
		FrameworkLogger.logStep("getDeviceInfoLogsURL: Start");
		String url = apiUrls.get("callLogsBaseUrl")+ serverConfig.get("deviceInfoCallLogsUrl");
		FrameworkLogger.logStep("getDeviceInfoLogsURL: End");
		return url;
	}
	
	/**
	 * Method to get deviceInfoCallLogs Response
	 * 
	 * @return GetDeviceInfoCallLogs validatable response
	 */
	protected ValidatableResponse triggerGetDeviceInfoCallLogs() throws IOException {
		FrameworkLogger.logStep("triggerGetDeviceCallLogs:-> Start");
		ValidatableResponse response = triggerGetApi(getDeviceInfoLogsURL(), headerMap);
		FrameworkLogger.logStep("triggerGetDeviceCallLogs:-> End");
		return response;
	}
	
	
	public static ValidatableResponse getDeviceInfoCallLogsServiceMethod() throws IOException, VerificationFailException {
		FrameworkLogger.logStep("triggerGetDeviceCallLogs:-> Start");
		GetDeviceInfoCallLogsBaseScript baseScript=new GetDeviceInfoCallLogsBaseScript();
		ValidatableResponse response = baseScript.triggerGetDeviceInfoCallLogs();
		FrameworkLogger.logStep("triggerGetDeviceCallLogs:-> End");
		return response;
	}
}
