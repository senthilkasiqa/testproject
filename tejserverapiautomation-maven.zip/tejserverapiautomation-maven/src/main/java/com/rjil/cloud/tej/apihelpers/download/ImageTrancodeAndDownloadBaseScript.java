/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.download;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author Prateek
 * 
 * Base class for Image transcode and download Api
 *
 */
public class ImageTrancodeAndDownloadBaseScript extends BaseTestScript{

	
	protected static final String apiName= "TrancodeDownloadFile";
	
	public ImageTrancodeAndDownloadBaseScript(){
		globalApiName=apiName;
	}
	
//	 protected  Map<String,String> headerMap = null;

	    /**In order to construct the header parameters for each test, we would call a createHeader method.
	     * This method would initialize a hashmap that would contain a key-value pair ( header parameters and its corresponding value)
	     *
	     * UserId
	     * Authorization
	     *
	     * The method would then put header parameters needed for each test case.
	     * Once the header parameters are available, we would call the API method to get response.
	     * The idea behing using a hashmap is that we would need only 3 methods in the middle layer base script to run
	     * all our test cases namely*/

/*	    protected void createHeader(){
	    	headerMap = new HashMap<>();
	        headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
	        headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
	        addXapiHeaderKey(headerMap);
	        
	    }
*/	    

    //Overload the method.
    protected Map<String, String> createHeader() {
	    FrameworkLogger.logStep("createHeader -> Start");
    	
    	headerMap=initializeHeader();

    	//Remove from header for this API.
        headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
    	
	    FrameworkLogger.logStep("createHeader -> End");
    	return headerMap;
    }

	/**
		 * 
		 * Construct the Image transcode and Download request. 
		 * Need to add object key in the url by fetching object key from the Upload Response 
		 * 
		 */
		protected String getImageTranscodeAndDownloadUrl(String objectKey) {
			FrameworkLogger.logStep("getImageTranscodeAndDownloadUrl:Start");
			String url = apiUrls.get("downloadIp") + serverConfig.get("imageTranscodeAndDownloadUrl").replace("{objectKey}", objectKey);
			FrameworkLogger.logStep("url=============>"+url);
			FrameworkLogger.logStep("getImageTranscodeAndDownloadUrl:Start");
			return url;

		}
		
		/**
		 * 
		 * Construct the Image transcode and Download request. 
		 * Need to add object key in the url by fetching object key from the Upload Response 
		 * Replace limit and format 
		 * 
		 */
		protected String getImageTranscodeAndDownloadUrl(String objectKey, String apiUrl,String size, String format) {
			FrameworkLogger.logStep("getImageTranscodeAndDownloadUrl:Start");
			FrameworkLogger.logStep("apis:"+serverConfig.get(apiUrl));
			String url = apiUrls.get("downloadIp") + serverConfig.get(apiUrl).replace("{objectKey}", objectKey).replace("{size}",size).replace("{format}", format);
			FrameworkLogger.logStep("url=============>"+url);
			FrameworkLogger.logStep("getImageTranscodeAndDownloadUrl:Start");
			return url;

		}

		
		/**
		 * Method to get ImageTarnscodeAndDownload File response
		 * 
		 * 
		 */
		
		protected ValidatableResponse triggerGetApiImageTarnscodeAndDownloadResponse(String objectKey){
			FrameworkLogger.logStep("triggerGetApiImageTarnscodeAndDownloadResponse: Start");
//			ValidatableResponse response = given().headers(headerMap).when().get(getImageTranscodeAndDownloadUrl(objectKey)).then();
//			response.log().all();

			ValidatableResponse response = triggerGetApi(getImageTranscodeAndDownloadUrl(objectKey), headerMap);
			/***
			 * Add the request fired to the logger file for reference purpose
			 */
//			Utils.addRequestResponseToLogger();

			FrameworkLogger.logStep("triggerGetApiImageTarnscodeAndDownloadResponse: End");
			/**
			 * Return back the response to the test method
			 */
			return response;
			
		}
		
		/**
		 * Method to get ImageTarnscodeAndDownload File response for negative scenarios
		 * 
		 * 
		 */
		
		protected ValidatableResponse triggerGetApiImageTarnscodeAndDownloadResponse(String objectKey,String url, String size, String format){
			FrameworkLogger.logStep("triggerGetApiImageTarnscodeAndDownloadResponse: Start");
//			ValidatableResponse response = given().headers(headerMap).when().get(getImageTranscodeAndDownloadUrl(objectKey)).then();
//			response.log().all();

			ValidatableResponse response = triggerGetApi(getImageTranscodeAndDownloadUrl(objectKey,url,size,format), headerMap);
			/***
			 * Add the request fired to the logger file for reference purpose
			 */
//			Utils.addRequestResponseToLogger();

			FrameworkLogger.logStep("triggerGetApiImageTarnscodeAndDownloadResponse: End");
			/**
			 * Return back the response to the test method
			 */
			return response;
			
		}
		
}
