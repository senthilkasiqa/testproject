package com.rjil.cloud.tej.common;

import java.util.Random;

public class RandomNumberGenerator {
	

	public static int getRandomNumber()
	{
		Random r = new Random();
		int Low = 5;
		int High = 40;
		int Result = r.nextInt(High-Low) + Low;
		return Result;
	}

	public static int getRandomNumberSmall()
	{
		Random r = new Random();
		int Low = 2;
		int High = 7;
		int Result = r.nextInt(High-Low) + Low;
		return Result;
	}

	public static int getRandomNumber2()
	{
		Random r = new Random();
		int Low = 100;
		int High = 500;
		int Result = r.nextInt(High-Low) + Low;
		return Result;
	}
	
	public static int getRandomNumber3()
	{
		Random r = new Random();
		int Low = 1;
		int High = 10;
		int Result = r.nextInt(High-Low) + Low;
		return Result;
	}
	
	public static String getRandomPhoneNo()
	{
		Random r = new Random();
		int Low = 111111111;
		int High = 999999999;
		int Result = r.nextInt(High-Low) + Low;
		return "+919"+Result;
	}
}
