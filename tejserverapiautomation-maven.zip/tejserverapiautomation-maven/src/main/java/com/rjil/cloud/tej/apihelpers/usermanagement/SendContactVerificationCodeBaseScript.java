/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.usermanagement;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author Prateek
 * 
 *         Base class for Send Contact Verification api
 *
 */
public class SendContactVerificationCodeBaseScript extends BaseTestScript {

	protected static final String apiName = "SendContactVerificationCode";
	// protected Map<String, String> headerMap = null;
	protected String sendContactVerificationJsonBody;
	
	public SendContactVerificationCodeBaseScript(){
		globalApiName=apiName;
	}

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Remove device key from header for this API.
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * 
	 * Method to get Send contact verification code url
	 * 
	 * URL=http://{envUrl}/security/users/contacts/verification
	 * 
	 */
	protected String getSendContactVerificationCodeUrl() {
		FrameworkLogger.logStep("getSendContactVerificationCodeUrl: Start");
		String url = apiUrls.get("baseURL") + serverConfig.get("sendContactVerificationCodeUrl");
		FrameworkLogger.logStep("getSetUserProfilePicUrl:" + url);
		FrameworkLogger.logStep("getSendContactVerificationCodeUrl: End");
		return url;

	}

	protected String getSendContactVerificationCodeUrl(String url) {
		FrameworkLogger.logStep("getSendContactVerificationCodeUrl: Start");
		String apiUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		FrameworkLogger.logStep("getSetUserProfilePicUrl:" + url);
		FrameworkLogger.logStep("getSendContactVerificationCodeUrl: End");
		return apiUrl;

	}

	/**
	 * Method to create set send contact verification code api json body
	 * 
	 * @return
	 * @throws IOException
	 */
	protected String setSendContactVerificationCodeJsonBody() throws IOException {
		FrameworkLogger.logStep("setSendContactVerificationCodeUrlJsonBody: Start");
		// load json file
		String path = System.getProperty("user.dir")
				+ "/resources/userManagementTestData/sendContactVerificationCode.js";
		File file = new File(path);
		sendContactVerificationJsonBody = JsonPath.parse(file).jsonString();

		FrameworkLogger.logStep("setSendContactVerificationCodeUrlJsonBody:" + sendContactVerificationJsonBody);
		FrameworkLogger.logStep("setSendContactVerificationCodeUrlJsonBody: End");
		return sendContactVerificationJsonBody;
	}

	/**
	 * Method to get Send contact verification code api Response
	 * 
	 * 
	 */
	protected ValidatableResponse getSendContactVerificationCodeApiResponse() throws IOException {

		FrameworkLogger.logStep("getSendContactVerificationCodeApiResponse: Start");

		String strApiUrl = getSendContactVerificationCodeUrl();
		// Call method to trigger POST API.
		ValidatableResponse response = triggerPostApi(strApiUrl, headerMap, sendContactVerificationJsonBody);

		FrameworkLogger.logStep("getSendContactVerificationCodeApiResponse: End");

		return response;
	}

	protected ValidatableResponse getSendContactVerificationCodeApiResponse(String apiUrl) throws IOException {

		FrameworkLogger.logStep("getSendContactVerificationCodeApiResponse: Start");

		String strApiUrl = getSendContactVerificationCodeUrl(apiUrl);
		// Call method to trigger POST API.
		ValidatableResponse response = triggerPostApi(strApiUrl, headerMap, sendContactVerificationJsonBody);

		FrameworkLogger.logStep("getSendContactVerificationCodeApiResponse: End");

		return response;
	}

}
