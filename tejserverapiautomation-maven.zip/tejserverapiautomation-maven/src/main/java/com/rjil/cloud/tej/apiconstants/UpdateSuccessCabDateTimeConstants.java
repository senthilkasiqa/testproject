package com.rjil.cloud.tej.apiconstants;

/**
 * UpdateSuccessCabDateTimeConstants JSON paths
 * 
 */

public class UpdateSuccessCabDateTimeConstants {

    public static String getCabViewTimeJsonPath() {
        return "$.cabViewTime";
    }
}
