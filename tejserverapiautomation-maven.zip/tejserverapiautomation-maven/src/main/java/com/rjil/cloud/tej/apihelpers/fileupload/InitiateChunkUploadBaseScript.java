/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.fileupload;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.UploadConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.nms.CreateFolderBaseScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 *
 *Base class for Initiate Chunk Upload Api
 */
public class InitiateChunkUploadBaseScript extends BaseTestScript {
	
	protected static final String apiName="InitaiteChunkUpload";
	public String initiateUploadJSONBody;
	
	public InitiateChunkUploadBaseScript(){
		globalApiName=apiName;
	}
	

	/**
	 * Create header fir Initiate chunk file upload api
	 */
/*	public Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		headerMap.put("Content-Type", "application/json");
		// headerMap.put("Content-Type", "multipart/related;boundary=*****");

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}*/
	
	/**
	 * 
	 * Create Initiate chunk file upload url
	 * @return
	 */

	protected String getInitiateUploadURL() {

		FrameworkLogger.logStep("getInitiateUploadURL: Start");
		/**
		 * The SIT url for upload is different compared to other environments
		 * So, we need to add this check
		 */
		String initiateUrl = apiUrls.get("uploadIp") + serverConfig.get("initiateUploadUrl");
		FrameworkLogger.logStep("InitiateUploadUrl=========>" + initiateUrl);
		return initiateUrl;

	}
	
	/**
	 * Method to set file upload Json Body
	 * 
	 * @throws IOException
	 */
	public String setInitiateUploadJsonBody(String fileName) throws IOException {
		FrameworkLogger.logStep("setInitiateUploadJsonBody: Start");
		String filePath = System.getProperty("user.dir") + "/resources/uploadTestData/" + fileName;
		FrameworkLogger.logStep("FilePATH==============>" + filePath);
		Utils.fileCheckSum(filePath);
		String path = System.getProperty("user.dir") + "/resources/uploadTestData/initiateUploadFileBody.js";
		File file = new File(path);
		//Utils.fileCheckSum(path);
		initiateUploadJSONBody = JsonPath.parse(file).jsonString();
		initiateUploadJSONBody = setJsonData(UploadConstants.getName(), fileName, initiateUploadJSONBody);
		initiateUploadJSONBody = setJsonData(UploadConstants.getSize(), Utils.getLen(), initiateUploadJSONBody);
		initiateUploadJSONBody = setJsonData(UploadConstants.getHash(), Utils.getOutput(), initiateUploadJSONBody);
		if (CreateFolderBaseScript.folderKey != null) {
			initiateUploadJSONBody = JsonPath.parse(initiateUploadJSONBody)
					.put("@", "folderKey", repositoryMap.get(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue()))
					.jsonString();
		}
		FrameworkLogger.logStep("setInitiateUploadJsonBody:" + initiateUploadJSONBody);
		FrameworkLogger.logStep("setInitiateUploadJsonBody: End");
		return initiateUploadJSONBody;
	}

	/**
	 * Method to set file upload Json Body
	 * 
	 * @throws IOException
	 */
	public String setInitiateUploadJsonBodyForBoard(String fileName,String boardKey,boolean boardCoverPic,boolean isProfilePic,boolean isAutoUpload) throws IOException {
		FrameworkLogger.logStep("setInitiateUploadJsonBody: Start");
		String filePath = System.getProperty("user.dir") + "/resources/uploadTestData/" + fileName;
		FrameworkLogger.logStep("FilePATH==============>" + filePath);
		Utils.fileCheckSum(filePath);
		String path = System.getProperty("user.dir") + "/resources/uploadTestData/initiateUploadFileBodyForBoard.js";
		File file = new File(path);
		//Utils.fileCheckSum(path);
		initiateUploadJSONBody = JsonPath.parse(file).jsonString();
		initiateUploadJSONBody = setJsonData(UploadConstants.getName(), fileName, initiateUploadJSONBody);
		initiateUploadJSONBody = setJsonData(UploadConstants.getSize(), Utils.getLen(), initiateUploadJSONBody);
		initiateUploadJSONBody = setJsonData(UploadConstants.getHash(), Utils.getOutput(), initiateUploadJSONBody);
		initiateUploadJSONBody = setJsonData(UploadConstants.getBoardKey(),boardKey, initiateUploadJSONBody);
		initiateUploadJSONBody = setJsonData(UploadConstants.getBoardCoverPic(),boardCoverPic, initiateUploadJSONBody);
		initiateUploadJSONBody = setJsonData(UploadConstants.getIsProfilePic(),isProfilePic, initiateUploadJSONBody);
		initiateUploadJSONBody = setJsonData(UploadConstants.getIsAutoUpload(),isAutoUpload, initiateUploadJSONBody);
		initiateUploadJSONBody=deleteJsonData(initiateUploadJSONBody, UploadConstants.getFolderKey());
		if (CreateFolderBaseScript.folderKey != null) {
			initiateUploadJSONBody = JsonPath.parse(file).jsonString();
			//initiateUploadJSONBody = setJsonData(UploadConstants.getF,isAutoUpload, initiateUploadJSONBody);
			initiateUploadJSONBody = JsonPath.parse(initiateUploadJSONBody)
					.put("@", "folderKey", repositoryMap.get(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue()))
					.jsonString();
			initiateUploadJSONBody = setJsonData(UploadConstants.getIsAutoUpload(),isAutoUpload, initiateUploadJSONBody);
		}
		FrameworkLogger.logStep("setInitiateUploadJsonBody:" + initiateUploadJSONBody);
		FrameworkLogger.logStep("setInitiateUploadJsonBody: End");
		return initiateUploadJSONBody;
	}
	/**
	 * Method to get Initiate Upload Response
	 *
	 * @return Initiate Upload response
	 */
	public ValidatableResponse triggerInitiateUploadFileApi() throws IOException {

		FrameworkLogger.logStep("triggerInitiateUploadFileApi: Start");
		// setUploadJsonBody();
		ValidatableResponse response = triggerPostApi(getInitiateUploadURL(), headerMap, initiateUploadJSONBody);
		//response.log().all();
		//Utils.addRequestResponseToLogger();

		// FrameworkLogger.logStep("Setting ObjectKey...");

		// String strObjectKey = response.extract().path("objectKey");
		// FrameworkLogger.logStep("Upload Object Key========>>" +
		// strObjectKey);
		// repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(),
		// strObjectKey);
		
		String transactionId = response.extract().path("transactionId");
		repositoryMap.put(RepositoryParameterEnum.TRANSACTIONID.getValue(),transactionId);

		FrameworkLogger.logStep("triggerInitiateUploadFileApi: End");
		return response;
	}

	/**
	 * Method to get Initiate Upload Response
	 *
	 * @return Initiate Upload response
	 */
	public void initiateChunkFileUploadServiceMethod(String fileName) throws IOException {

		FrameworkLogger.logStep("initiateChunkFileUploadServiceMethod: Start");
		
		InitiateChunkUploadBaseScript initiateChunkUploadBaseScript= new InitiateChunkUploadBaseScript();
		initiateChunkUploadBaseScript.createHeader();
		initiateChunkUploadBaseScript.setInitiateUploadJsonBody(fileName);
		initiateChunkUploadBaseScript.triggerInitiateUploadFileApi();
		
		FrameworkLogger.logStep("initiateChunkFileUploadServiceMethod: End");
		
	}
	
	/**
	 * Method to get Initiate Upload Response
	 *
	 * @return Initiate Upload response
	 */
	public ValidatableResponse initiateChunkFileUploadServiceMethod(String fileName,String boardKey,boolean boardCoverPic,boolean isProfilePic,boolean isAutoUpload) throws IOException {

		FrameworkLogger.logStep("initiateChunkFileUploadServiceMethod: Start");
		
		InitiateChunkUploadBaseScript initiateChunkUploadBaseScript= new InitiateChunkUploadBaseScript();
		initiateChunkUploadBaseScript.createHeader();
		initiateChunkUploadBaseScript.setInitiateUploadJsonBodyForBoard(fileName,boardKey, boardCoverPic, isProfilePic, isAutoUpload);
		ValidatableResponse response=initiateChunkUploadBaseScript.triggerInitiateUploadFileApi();
		FrameworkLogger.logStep("initiateChunkFileUploadServiceMethod: End");
		return response;
	
		
	}
	
	/**
	 * Method to get Initiate Upload Response
	 *
	 * @return Initiate Upload response
	 */
	public void initiateChunkFileUploadServiceMethod(String fileName,String boardKey,Map<String,String> deviceInfo,boolean boardCoverPic,boolean isProfilePic,boolean isAutoUpload) throws IOException {

		FrameworkLogger.logStep("initiateChunkFileUploadServiceMethod: Start");
		
		InitiateChunkUploadBaseScript initiateChunkUploadBaseScript= new InitiateChunkUploadBaseScript();
		initiateChunkUploadBaseScript.createHeader(deviceInfo);
		initiateChunkUploadBaseScript.setInitiateUploadJsonBodyForBoard(fileName,boardKey, boardCoverPic, isProfilePic, isAutoUpload);
		initiateChunkUploadBaseScript.triggerInitiateUploadFileApi();
		
		FrameworkLogger.logStep("initiateChunkFileUploadServiceMethod: End");
		
	}

}
