package com.rjil.cloud.tej.apihelpers.contacts;

import java.io.IOException;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boards.GetBoardCategoriesBaseScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

public class DeleteCabContactsBaseScript extends BaseTestScript{
	protected static final String apiName = "GetBoardCategories";
	
	protected String deleteCabContactURL() {
	FrameworkLogger.logStep(" deleteCabContactURL:-> Start");
	return apiUrls.get("baseContactURL") + serverConfig.get("deleteCabContactUrl");
	
}
	
protected String deleteCabContactURL(String url) {
		FrameworkLogger.logStep(" deleteCabContactURL:-> Start");
		return apiUrls.get("baseContactURL") + url;
	}

protected ValidatableResponse triggerDeletedeleteCabContact() throws IOException {
	FrameworkLogger.logStep("triggerGetdeleteCabContact:-> Start");
	String strApiUrl = deleteCabContactURL();
	ValidatableResponse response = triggerDeleteApi(strApiUrl, headerMap);
	FrameworkLogger.logStep("triggerGetdeleteCabContact:-> End");
	return response;
}

protected ValidatableResponse triggerDeletedeleteCabContact(String url) throws IOException {
	FrameworkLogger.logStep("triggerGetdeleteCabContact:-> Start");
	String strApiUrl = deleteCabContactURL(url);
	ValidatableResponse response = triggerDeleteApi(strApiUrl, headerMap);
	FrameworkLogger.logStep("triggerGetdeleteCabContact:-> End");
	return response;
}

public static ValidatableResponse deleteCabContactService()
{
	DeleteCabContactsBaseScript deleteAllCabContacts = new DeleteCabContactsBaseScript();
	deleteAllCabContacts.createHeader();
	String strApiUrl = deleteAllCabContacts.deleteCabContactURL();
	ValidatableResponse response =deleteAllCabContacts.triggerGetApi(strApiUrl, deleteAllCabContacts.headerMap);
	return response;
}

	
	
	
	
}
