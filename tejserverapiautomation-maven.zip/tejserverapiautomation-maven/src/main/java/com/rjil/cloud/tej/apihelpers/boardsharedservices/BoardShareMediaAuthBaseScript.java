package com.rjil.cloud.tej.apihelpers.boardsharedservices;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.streaming.AuthRequestApiBaseScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class BoardShareMediaAuthBaseScript extends BaseTestScript{

	
	protected static final String apiName = "BoardShareMediaAuthAPI";

	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		//Remove from header for this API.
	//    headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
	//    headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());
	//    headerMap.remove(HeaderParameters.XAPIKEY.getValue());

	   	FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	
	protected String boardShareMediaAuthURL(String objectKey, String boardKey,String fileKey, String shareKey) {
		FrameworkLogger.logStep("boardMediaAuthURL: Start");
	//	String url = "http://board.sit-jiocloud.com:8080"+ serverConfig.get("boardShareMediaAuthUrl").replace("{objectKey}", objectKey).replace("{boardKey}", boardKey).replace("{shareKey}", shareKey);
		
		String url=apiUrls.get("boardUrl") + serverConfig.get("boardShareMediaAuthUrl").replace("{objectKey}", objectKey).replace("{boardKey}", boardKey).replace("{shareKey}", shareKey);
		String newUrl=url.replace("{fileKey}", fileKey);
		return newUrl;
	}
	

	public  ValidatableResponse getRequestForBoardShareMediaFileResponse(String objectKey, String boardKey,String fileKey,String shareKey) throws VerificationFailException, IOException, InterruptedException {
		
	//	AuthRequestApiBaseScript.getAuthApiResponseServiceMethod(fileName);
		
		BoardShareMediaAuthBaseScript boardMediaAuth = new BoardShareMediaAuthBaseScript();
		headerMap= boardMediaAuth.createHeader();
		String strApiUrl = boardShareMediaAuthURL(objectKey, boardKey,fileKey,shareKey);
		ValidatableResponse response1 = triggerGetApi(strApiUrl,headerMap);
		Thread.sleep(90000);
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
		Thread.sleep(90000);
//		ValidatableResponse response = authRequestApiBaseScript.getAuthRequestApiResponse(objectKey);
//		String strApiUrl=repositoryMap.get(RepositoryParameterEnum.STREAMINGURL.getValue());
		//Call method to trigger GET API.
		String strStreamingUrl = response.extract().asString();
		
		//Read token  from response cookie header
		if(serverConfig.get("deviceType").equalsIgnoreCase("W")){
			String readToken=response.extract().header("Set-Cookie");
			FrameworkLogger.logStep("TOKEN:"+readToken);
			//String value=readToken.split(";")[0];
			try{
			String value=readToken.substring(readToken.indexOf("t=")+2, readToken.indexOf(";"));
			String strStreamingUrl1=strStreamingUrl+"&token="+value;
			FrameworkLogger.logStep("VALUE:"+value);
			repositoryMap.put(RepositoryParameterEnum.STREAMINGURL.getValue(),
					strStreamingUrl1);
			}catch(Exception e){
				FrameworkLogger.logStep("Null pointer exception");
			}
			
	
		}else{
			repositoryMap.put(RepositoryParameterEnum.STREAMINGURL.getValue(),
					strStreamingUrl);
		}


		ValidatableResponse responseDownload = triggerGetApi(strStreamingUrl,headerMap);

		
		/**
		 * Return back the response to the test method
		 */
		return responseDownload;
	}
	
	
	public  ValidatableResponse getRequestForBoardShareMediaFileResponse(Map<String, String> deviceInfo,String objectKey, String boardKey,String fileKey,String shareKey) throws VerificationFailException, IOException, InterruptedException {
		
	//	AuthRequestApiBaseScript.getAuthApiResponseServiceMethod(fileName);
		
		BoardShareMediaAuthBaseScript boardMediaAuth = new BoardShareMediaAuthBaseScript();
		headerMap= boardMediaAuth.createHeader();
		String strApiUrl = boardShareMediaAuthURL(objectKey, boardKey,fileKey,shareKey);
		ValidatableResponse response1 = triggerGetApi(strApiUrl,headerMap);
		Thread.sleep(60000);
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
		Thread.sleep(60000);
//		ValidatableResponse response = authRequestApiBaseScript.getAuthRequestApiResponse(objectKey);
//		String strApiUrl=repositoryMap.get(RepositoryParameterEnum.STREAMINGURL.getValue());
		//Call method to trigger GET API.
		String strStreamingUrl = response.extract().asString();
		
		
		
//		ValidatableResponse response = authRequestApiBaseScript.getAuthRequestApiResponse(objectKey);
//		String strApiUrl=repositoryMap.get(RepositoryParameterEnum.STREAMINGURL.getValue());
		//Call method to trigger GET API.
		
		
		//Read token  from response cookie header
		if(serverConfig.get("deviceType").equalsIgnoreCase("W")){
			String readToken=response.extract().header("Set-Cookie");
			FrameworkLogger.logStep("TOKEN:"+readToken);
			//String value=readToken.split(";")[0];
			try{
			String value=readToken.substring(readToken.indexOf("t=")+2, readToken.indexOf(";"));
			String strStreamingUrl1=strStreamingUrl+"&token="+value;
			FrameworkLogger.logStep("VALUE:"+value);
			repositoryMap.put(RepositoryParameterEnum.STREAMINGURL.getValue(),
					strStreamingUrl1);
			}catch(Exception e){
				FrameworkLogger.logStep("Null pointer exception");
			}
			
	
		}else{
			repositoryMap.put(RepositoryParameterEnum.STREAMINGURL.getValue(),
					strStreamingUrl);
		}

		//Thread.sleep(60000);
		ValidatableResponse responseDownload = triggerGetApi(strStreamingUrl,headerMap);

		
		/**
		 * Return back the response to the test method
		 */
		return responseDownload;
	}
	
	
	public  ValidatableResponse getRequestForBoardShareMediaFileForNegativeResponse(String objectKey, String boardKey,String fileKey, String shareKey) throws VerificationFailException, IOException, InterruptedException {
		
		//	AuthRequestApiBaseScript.getAuthApiResponseServiceMethod(fileName);
			
			BoardShareMediaAuthBaseScript boardMediaAuth = new BoardShareMediaAuthBaseScript();
		//	headerMap= boardMediaAuth.createHeader();
			String strApiUrl = boardShareMediaAuthURL(objectKey, boardKey,fileKey, shareKey);
			ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
			return response;
		

		}
		
	public  ValidatableResponse getRequestForBoardMediaFileForNegativeResponse(Map<String, String> deviceInfo,String objectKey, String boardKey,String fileKey, String shareKey) throws VerificationFailException, IOException, InterruptedException {
		
		//	AuthRequestApiBaseScript.getAuthApiResponseServiceMethod(fileName);
			
			BoardShareMediaAuthBaseScript boardMediaAuth = new BoardShareMediaAuthBaseScript();
			headerMap= boardMediaAuth.createHeader(deviceInfo);
			String strApiUrl = boardShareMediaAuthURL(objectKey, boardKey,fileKey,shareKey);
			ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
			return response;
		

		}
		
}
