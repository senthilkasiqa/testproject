package com.rjil.cloud.tej.apihelpers.nms;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.Validatable;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.BoardConstants;
import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.BoardParameters;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Sanjeevanee.Kanase
 *
 */
public class UpdateMetadataBaseScript extends BaseTestScript {

	protected static String updateMetadataJsonBody;
	protected static final String apiName = "UpdateMetadata";
	CreateFolderBaseScript cf = new CreateFolderBaseScript();
    ValidatableResponse createFolderResponse;
    HashMap valuesMap = new HashMap();
	
    public UpdateMetadataBaseScript(){
    	globalApiName=apiName;
    }
    
    /**Method to get response from Create Folder API
     * @return
     * @throws IOException
     */
   /* public ValidatableResponse getCreateFolderResponse() throws IOException
    {
    	cf.createHeader();
    	return cf.getCreateFolderResponse();
    } */
    
    
    /**Get the values from response of create a folder API
     * and put it in a hashmap
     * @return
     * @throws IOException
     * @throws InterruptedException 
     */
    @BeforeClass
    public HashMap getResponseValueFromCreateFolderAPI() throws IOException, InterruptedException
    {
    	createFolderResponse = CreateFolderBaseScript.createFolderServiceMethod();
    	valuesMap.put("status",createFolderResponse.extract().path("status"));
    	valuesMap.put("objectKey",createFolderResponse.extract().path("objectKey"));
    	valuesMap.put("sourceName",createFolderResponse.extract().path("sourceName"));
    	valuesMap.put("parentObjectKey",createFolderResponse.extract().path("parentObjectKey"));
    	valuesMap.put("objectName",createFolderResponse.extract().path("objectName"));
    	valuesMap.put("isHidden",createFolderResponse.extract().path("isHidden"));
    	valuesMap.put("isLocked",createFolderResponse.extract().path("isLocked"));
    	valuesMap.put("isReadonly",createFolderResponse.extract().path("isReadonly"));
    	valuesMap.put("isPinned",createFolderResponse.extract().path("isPinned"));
    	valuesMap.put("parentObjectKey",createFolderResponse.extract().path("parentObjectKey"));
    	valuesMap.put("version",createFolderResponse.extract().path("version"));
		return valuesMap;
   }
  
    /**method to create a positive request body for 'Update metadata API"
     * by replacing all values from the valueMap
     * @return
     */
    protected String updateJsonForUpdateMetadataAPI()
    {
    	updateMetadataJsonBody = setJsonData(NmsConstants.getStatus(),valuesMap.get("status"), updateMetadataJsonBody);
    	updateMetadataJsonBody = setJsonData(NmsConstants.getObjectKey(),valuesMap.get("objectKey"), updateMetadataJsonBody);
    	updateMetadataJsonBody = setJsonData(NmsConstants.getSourceName1(),valuesMap.get("sourceName"), updateMetadataJsonBody);
    	updateMetadataJsonBody = setJsonData(NmsConstants.getParentObjectKey1(),valuesMap.get("parentObjectKey"), updateMetadataJsonBody);
    	updateMetadataJsonBody = setJsonData(NmsConstants.getObjectName1(),System.currentTimeMillis()+".pot", updateMetadataJsonBody);
    	updateMetadataJsonBody = setJsonData(NmsConstants.getIsHidden(),valuesMap.get("isHidden"), updateMetadataJsonBody);
    	updateMetadataJsonBody = setJsonData(NmsConstants.getIsLocked(),valuesMap.get("isLocked"), updateMetadataJsonBody);
    	updateMetadataJsonBody = setJsonData(NmsConstants.getIsReadonly(),valuesMap.get("isReadonly"), updateMetadataJsonBody);
    	updateMetadataJsonBody = setJsonData(NmsConstants.getIsPinned(),valuesMap.get("isPinned"), updateMetadataJsonBody);
    	updateMetadataJsonBody = setJsonData(NmsConstants.getSourceFolder(),valuesMap.get("sourceFolder"), updateMetadataJsonBody);
    	updateMetadataJsonBody = setJsonData(NmsConstants.getVersion(),valuesMap.get("version"), updateMetadataJsonBody);
    //	updateMetadataJSONBody = setJsonData(NmsConstants.getVersion(),valuesMap.get("operationName"), updateMetadataJSONBody);
    	return updateMetadataJsonBody;

    }
 //   updateMetadataJSONBody = setJsonData(NMSConstants.getStatus(),status, updateMetadataJSONBody);
    
//protected static Map<String, String> headerMap = null;
	
	// created a Hashmap to save all the headers.
/*	protected void createHeader() {
		headerMap=new HashMap<>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");

		// add x-api header key
		addXapiHeaderKey(headerMap);
	}
*/
    
    /**get a complete url for 'Update Metadata API'
     * @return
     */
  //  protected String getUpdateMetadataURL() {
  //      return apiUrls.get("baseURL") + serverConfig.get("updateMetadataURL");
  //  }
    
    /**get a complete url for 'Update Metadata API'
	 * @return
	 */
	protected String getUpdateMetadataURL() {
		FrameworkLogger.logStep("getUpdateMetadataURL: Start");
		return getUpdateMetadataURL(serverConfig.get("updateMetadataURL"));
	//	return apiUrls.get("baseURL") + serverConfig.get("getTrashMetadataURL");
	}
	
	/**get a complete url for 'Update Metadata API'
	 * @return
	 */
	protected String getUpdateMetadataURL(String urlValue) {
		FrameworkLogger.logStep("getUpdateMetadataURL: Start");
		return (apiUrls.get("baseURL") + urlValue);
	}
  
    protected String setUpdateMetadataJsonBody() throws IOException {
        //load json file
  
        String path = System.getProperty("user.dir") + "/resources/nmsTestData/updateMetadataBody.js";
        File file = new File(path);
        updateMetadataJsonBody = JsonPath.parse(file).jsonString();
        updateMetadataJsonBody = updateJsonForUpdateMetadataAPI();
       return updateMetadataJsonBody;
    }
    
   
    /**
     * Method to get Update Metadata Response
     *
     * @return Update Metadata validatable response
     */
    
    protected ValidatableResponse triggerPutApiUpdateMetadata(String updateMetadataJsonBody) throws IOException {
    	FrameworkLogger.logStep("triggerPutApitrashMetadata: Start");
 
		String strApiUrl=getUpdateMetadataURL();
		//Call method to trigger PUT API.
	ValidatableResponse response = triggerPutApiUpdateMetadata(updateMetadataJsonBody,serverConfig.get("updateMetadataURL"));
		
		FrameworkLogger.logStep("triggerPutApitrashMetadata: End");

    	return response;
    }
    	
	/**
	 * Method to get getTrashMetadata Response
	 * @return getTrashMetadata validatable response
	 */
    
	protected ValidatableResponse triggerPutApiUpdateMetadata(String updateMetadataJsonBody, String urlValue) throws IOException {
		FrameworkLogger.logStep("triggerPutApiUpdateMetadata: Start");	
		String strApiUrl=getUpdateMetadataURL(urlValue);
		
		//Call method to trigger GET API.
	
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,updateMetadataJsonBody);
		FrameworkLogger.logStep("triggerPutApiUpdateMetadata: End");
		return response;

	}
	
	
	public static void triggerUpdateMetadataForRename(String fileName) throws IOException
	{
		UpdateMetadataBaseScript rename = new UpdateMetadataBaseScript();
		rename.createHeader();
		rename.setUpdateMetadataJsonBody();
		updateMetadataJsonBody = setJsonData(NmsConstants.getOperationName(), "Rename", updateMetadataJsonBody);
		updateMetadataJsonBody = setJsonData(NmsConstants.getObjectName(),fileName, updateMetadataJsonBody);
        rename.triggerPutApiUpdateMetadata(updateMetadataJsonBody);
	}
    
}
