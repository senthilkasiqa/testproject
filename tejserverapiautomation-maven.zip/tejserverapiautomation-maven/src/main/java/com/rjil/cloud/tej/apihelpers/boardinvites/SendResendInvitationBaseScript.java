package com.rjil.cloud.tej.apihelpers.boardinvites;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class SendResendInvitationBaseScript extends BaseTestScript{

	protected static final String apiName = "sendResendInvitationApi";
	protected static String sendResendInvitationJsonBody;
	protected static String boardKey;
	
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();
		
		//headerMap.put("Content-Type", "multipart/related;boundary=*****");

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	protected String sendResendInvitationURL(String boardKey) {
		FrameworkLogger.logStep("sendResendInvitationURL: Start");
		FrameworkLogger.logStep("sendResendInvitationURL BoardKey*******************: Start"+boardKey);
		String url =( apiUrls.get("boardInviteUrl") + (serverConfig.get("sendResendInvitationUrl"))).replace("boardKey", boardKey);
		FrameworkLogger.logStep("sendResendInvitationURL: End"+url);
		return url;
	}

	
	protected String sendResendInvitationURL(String boardKey, String urlValue) {
		FrameworkLogger.logStep("sendResendInvitationURL: Start");
		String url = apiUrls.get("boardInviteUrl") + urlValue;
		FrameworkLogger.logStep("sendResendInvitationURL: End");
		return url;
	}

	protected String setSendResendInvitationJsonBody() throws IOException{

		// load json file
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/sendResendInvitationBody.js";
		File file = new File(path);
		sendResendInvitationJsonBody = JsonPath.parse(file).jsonString();
		return sendResendInvitationJsonBody;
	}

	protected String setSendResendInvitationJsonBodyForTwoUsers() throws IOException{

		// load json file
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/sendResendInvitationBodyTwoUsers.js";
		File file = new File(path);
		sendResendInvitationJsonBody = JsonPath.parse(file).jsonString();
		return sendResendInvitationJsonBody;
	}

	protected String setSendResendInvitationJsonBodyForGroupInvitation() throws IOException{

		// load json file
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/sendResendGroupInvitationBody.js";
		File file = new File(path);
		sendResendInvitationJsonBody = JsonPath.parse(file).jsonString();
		return sendResendInvitationJsonBody;
	}
	
	protected ValidatableResponse triggerPostApiSendResendInvitation(String boardKey) throws IOException {

		FrameworkLogger.logStep("triggerPostApiSendResendInvitation: Start");

		String strApiUrl=sendResendInvitationURL(boardKey);
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, sendResendInvitationJsonBody);
		FrameworkLogger.logStep("triggerPostApiSendResendInvitation");

		return response;
	}

	protected ValidatableResponse triggerPostApiSendResendInvitation(String boardKey,Map<String, String> headerMap1) throws IOException {

		FrameworkLogger.logStep("triggerPostApiSendResendInvitation: Start");

		String strApiUrl=sendResendInvitationURL(boardKey);
		Map<String,String> headerMap = createHeader(headerMap1);
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, sendResendInvitationJsonBody);
		FrameworkLogger.logStep("triggerPostApiSendResendInvitation");

		return response;
	}

	protected ValidatableResponse triggerPostApiSendResendInvitation(String urlValue, String boardKey) throws IOException {

		FrameworkLogger.logStep("triggerPostApiSendResendInvitation: Start");
		String strApiUrl=sendResendInvitationURL(boardKey, urlValue);
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, sendResendInvitationJsonBody);
		FrameworkLogger.logStep("triggerPostApiSendResendInvitation: End");

		return response;
	}


	public static ValidatableResponse sendResendInvitationServiceMethod(String boardKey, String FirstName, String LastName, String userContact, String userType) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationServiceMethod: Start");
		SendResendInvitationBaseScript sendResendInvite = new SendResendInvitationBaseScript();
		sendResendInvite.createHeader();
		sendResendInvitationJsonBody = sendResendInvite.setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstFirstName(), FirstName, sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstLastName(), LastName, sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserContact(), userContact, sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserType(), userType, sendResendInvitationJsonBody);
		ValidatableResponse response = sendResendInvite.triggerPostApiSendResendInvitation(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Send Invite Status");
		FrameworkLogger.logStep("sendResendInvitationServiceMethod: End");
		return response;
	}

	public static ValidatableResponse sendResendInvitationServiceMethod(String boardKey, String FirstName, String LastName, String userContact, String userType,Map<String, String> headerMap1) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationServiceMethod: Start");
		SendResendInvitationBaseScript sendResendInvite = new SendResendInvitationBaseScript();
		sendResendInvitationJsonBody = sendResendInvite.setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstFirstName(), FirstName, sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstLastName(), LastName, sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserContact(), userContact, sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserType(), userType, sendResendInvitationJsonBody);
		ValidatableResponse response = sendResendInvite.triggerPostApiSendResendInvitation(boardKey,headerMap1);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Send Invite Status");
		FrameworkLogger.logStep("sendResendInvitationServiceMethod: End");
		return response;
	}

	public static ValidatableResponse sendResendGroupInvitationServiceMethod(String boardKey) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendGroupInvitationServiceMethod: Start");
		SendResendInvitationBaseScript sendResendInvite = new SendResendInvitationBaseScript();
		sendResendInvite.createHeader();
		sendResendInvitationJsonBody = sendResendInvite.setSendResendInvitationJsonBodyForGroupInvitation();
		ValidatableResponse response = sendResendInvite.triggerPostApiSendResendInvitation(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Send Group Invite Status");
		FrameworkLogger.logStep("sendResendGroupInvitationServiceMethod: End");
		return response;
	}


	public static ValidatableResponse sendResendInvitationServiceMethod(Map<String, String> device1Info,String boardKey) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationServiceMethod: Start");
		SendResendInvitationBaseScript sendResendInvite = new SendResendInvitationBaseScript();
		sendResendInvite.createHeader(device1Info);
		sendResendInvitationJsonBody = sendResendInvite.setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getSecondUserContact(), "@gmail.com", sendResendInvitationJsonBody);
		ValidatableResponse response = sendResendInvite.triggerPostApiSendResendInvitation(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Send Invite Status");
		FrameworkLogger.logStep("sendResendInvitationServiceMethod: End");
		return response;
	}
	
}
