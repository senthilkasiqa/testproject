/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.streaming;

import static com.jayway.restassured.RestAssured.given;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 *
 * Base class for request for video file api
 */
public class RequestForVideoFileApiBaseScript extends BaseTestScript	{
	
	protected static final String apiNameForVideoFileApi = "RequestForVideoFile";
//	protected  Map<String, String> headerMap = null;
	//public static String masterUrl=null;
	
	public RequestForVideoFileApiBaseScript(){
		globalApiName=apiNameForVideoFileApi;
	}
	
	/**
	 * In order to construct the header parameters for each test, we would call
	 * a createHeader method. This method would initialize a hashmap that would
	 * contain a key-value pair ( header parameters and its corresponding value)
	 *
	 * UserId Authorization
	 *
	 * The method would then put header parameters needed for each test case.
	 * Once the header parameters are available, we would call the API method to
	 * get response. The idea behing using a hashmap is that we would need only
	 * 3 methods in the middle layer base script to run all our test cases
	 * namely
	 */

/*	protected  void createHeader() {
		
		headerMap = new HashMap<>();
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		
		
	}
*/	

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		//Remove from header for this API.
	    headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
	    headerMap.remove(HeaderParameters.AUTHORIZATION.getValue());
	    headerMap.remove(HeaderParameters.XAPIKEY.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * Method for request for video file response
	 * @throws IOException 
	 * @throws VerificationFailException 
	 * @throws InterruptedException 
	 */
	public  ValidatableResponse getRequestForVideoFileResponse(String fileName) throws VerificationFailException, IOException, InterruptedException {
		
		
		RequestForPlaylistFileApiBaseScript.getMPlaylistUrlServiceMethod(fileName);
		
/*		ValidatableResponse response = given().headers(headerMap).when().get(repositoryMap.get(RepositoryParameterEnum.MPLAYlISTURL.getValue()))
				.then();
		response.log().all();

		*//***
		 * Add the request fired to the logger file for reference purpose
		 *//*
		Utils.addRequestResponseToLogger();

*/
		
		String strApiUrl=repositoryMap.get(RepositoryParameterEnum.MPLAYlISTURL.getValue());
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);

		/**
		 * Return back the response to the test method
		 */
		return response;

	}
	
	public  ValidatableResponse getRequestForVideoFileResponseForNegativeTest(String apiUrl) throws VerificationFailException, IOException, InterruptedException {
		
		
		//RequestForPlaylistFileApiBaseScript.getMPlaylistUrlServiceMethod(fileName);
		
/*		ValidatableResponse response = given().headers(headerMap).when().get(repositoryMap.get(RepositoryParameterEnum.MPLAYlISTURL.getValue()))
				.then();
		response.log().all();

		*//***
		 * Add the request fired to the logger file for reference purpose
		 *//*
		Utils.addRequestResponseToLogger();

*/
		
		String strApiUrl=apiUrls.get("streamingRequestForPlaylistFileUrl")+apiUrl;
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);

		/**
		 * Return back the response to the test method
		 */
		return response;

	}
	

}
