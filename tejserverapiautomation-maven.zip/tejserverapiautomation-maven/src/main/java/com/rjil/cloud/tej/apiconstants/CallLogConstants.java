package com.rjil.cloud.tej.apiconstants;

public class CallLogConstants {
			
	public static String getCalllogs() {
		return "$.calllogs";
	}
	
	public static String getDvcCallLogId(int index) {
		return "$.calllogs["+index+"].dvcCallLogId";
	}
	
	public static String getDuration(int index) {
		return "$.calllogs["+index+"].duration";
	}
	
	public static String getName(int index) {
		return "$.calllogs["+index+"].name";
	}
	
	public static String getPhoneNo(int index) {
		return "$.calllogs["+index+"].phoneNo";
	}
	
	public static String getDateTime(int index) {
		return "$.calllogs["+index+"].dateTime";
	}
	
	public static String getType(int index) {
		return "$.calllogs["+index+"].type";
	}
	
}
