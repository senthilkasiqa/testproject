package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

public class LastSuccessRestoreTimeBaseScript extends BaseTestScript {
    protected static final String moduleName="Contacts";
    protected static final String apiName="GetLastSuccessRestoreTime";
    
   
    public LastSuccessRestoreTimeBaseScript(){
  		globalApiName=apiName;
  	}
    /**
     * @author Chandrashekhar Singh
     * <p>
     * It creates the url for API 
     */
    private String getLastSuccessRestoreTimeUrl() {
		FrameworkLogger.logStep("getLastSuccessRestoreTimeUrl:-> Start");

		String apiUrl=apiUrls.get("baseContactURL") + serverConfig.get("lastSuccessRestoreDateTimeUrl");
		FrameworkLogger.logStep("getLastSuccessRestoreTimeUrl:-> End");

		return apiUrl;
    }

    /**
     * @return validatable response for LastSuccessRestoreTime
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    protected ValidatableResponse triggerGetApiLastSuccessRestoreTime() {
		FrameworkLogger.logStep("triggerGetApiLastSuccessRestoreTime:-> Start");
        // setContactBackupJsonBody();
		
		String strApiUrl=getLastSuccessRestoreTimeUrl();
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
		
		FrameworkLogger.logStep("triggerGetApiLastSuccessRestoreTime:-> End");
		return response;
    }
}
