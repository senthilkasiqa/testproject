package com.rjil.cloud.tej.enums;


/**
 * SharedServices Parameters Enum
 */
public enum SharedServicesParameters {
	SHARETYPE("shareType"),
	OBJECTS("objects"),
	OBJECTKEY("objectKey");

	public String value;

	SharedServicesParameters(String value) {
		this.value = value;

	}

	public String getValue() {
		return value;
	}
}
