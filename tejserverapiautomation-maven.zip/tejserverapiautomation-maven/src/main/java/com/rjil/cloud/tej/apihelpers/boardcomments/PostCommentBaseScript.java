package com.rjil.cloud.tej.apihelpers.boardcomments;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;

public class PostCommentBaseScript extends BaseTestScript{
	
	protected static final String apiName = "PostComment";
	protected static String postCommentJsonBody;
	public static String boardKey;
	
	protected String postCommentBaseScriptUrl(String boardKey) {
		FrameworkLogger.logStep("postCommentBaseScriptUrl: Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get("postCommentUrl").replace("{boardKey}", boardKey);
		FrameworkLogger.logStep("postCommentBaseScriptUrl: End");
		return url;
	}
	
	protected String postCommentBaseScriptUrl(String urlValue, String boardKey) {
		FrameworkLogger.logStep("updateBoardCoverPicUrl: Start");
		String url = apiUrls.get("baseURL") + urlValue;
		FrameworkLogger.logStep("postCommentBaseScriptUrl: End");
		return url;
	}
	
	protected String setPostCommentJsonBody() throws IOException{
		FrameworkLogger.logStep("setPostCommentJsonBody: Start");
		// load json file
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/postCommentBody.js";
		File file = new File(path);
		postCommentJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setPostCommentJsonBody: End");
		return postCommentJsonBody;
	}


	protected ValidatableResponse triggerPostApiPostComment(String boardKey) throws IOException {

		FrameworkLogger.logStep("triggerPostApiPostComment: Start");
        String strApiUrl=postCommentBaseScriptUrl(boardKey);
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, postCommentJsonBody);
		FrameworkLogger.logStep("triggerPostApiPostComment: End");
		return response;
	}
	
	
	protected ValidatableResponse triggerPostApiPostComment(String boardKey, Map<String, String> headerMap) throws IOException {

		FrameworkLogger.logStep("triggerPostApiPostComment: Start");
		String strApiUrl=postCommentBaseScriptUrl(boardKey);
		
		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, createHeader(headerMap), postCommentJsonBody);
		FrameworkLogger.logStep("triggerPostApiPostComment: End");

		return response;
	}
	

	public static ValidatableResponse postCommentServiceMethod(String comment, String boardKey) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("postCommentServiceMethod: Start");
		
		PostCommentBaseScript postComment = new PostCommentBaseScript();
		postComment.createHeader();
		postCommentJsonBody = postComment.setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = postComment.triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Post Comment Status");

		//int statusCode = response.extract().statusCode();
		//Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("postCommentServiceMethod: End");
		return response;
	}
	
	public static ValidatableResponse postCommentServiceMethod(Map<String, String> headerMap1, String comment, String boardKey) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("postCommentServiceMethod: Start");
		

		PostCommentBaseScript postComment = new PostCommentBaseScript();
		postComment.createHeader();
		postCommentJsonBody = postComment.setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = postComment.triggerPostApiPostComment(boardKey, headerMap1);

		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Post Comment Status");

		FrameworkLogger.logStep("postCommentServiceMethod: End");
		return response;
	}
	
	public StringBuffer generateString(int size)
	{
		StringBuffer comment = new StringBuffer("C");
		for(int i=1;i<=(size);i++)
		{
			comment=comment.append(1+"");
			
			System.out.println("Now comment="+comment);
		}
		
		return comment;
		
	}

}
