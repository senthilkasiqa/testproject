package com.rjil.cloud.tej.apihelpers.sharedServices;

import java.io.File;
import java.io.IOException;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

/**
 * 
 * @author Ashwini.Abhyankar: Base script for Delete Shared Link Api
 *
 */
public class DeleteSharedLinksBaseScript extends BaseTestScript {

	protected String deleteSharedLinksJsonBody;
	protected static final String apiName = "DeleteSharedLinks";
	
	public DeleteSharedLinksBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * method to create Delete Shared Links Api URL
	 * 
	 * @return
	 */
	protected String deleteSharedLinksUrl() {
		FrameworkLogger.logStep("deleteSharedLinksUrl:-> Start");
		String url = apiUrls.get("baseURL") + serverConfig.get("deleteSharedLinksUrl");
		FrameworkLogger.logStep("deleteSharedLinksUrl:-> End");
		return url;
	}

	/**
	 * Method to create Delete Shared Link API body
	 * 
	 * @return
	 * @throws IOException
	 */
	protected String setDeleteSharedLinksJsonBody() throws IOException {
		FrameworkLogger.logStep("setDeleteSharedLinksJsonBody:-> Start");
		String path = System.getProperty("user.dir") + "/resources/sharedServicesTestData/deleteSharedLinks.js";
		File file = new File(path);
		deleteSharedLinksJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setDeleteSharedLinksJsonBody:-> End");
		return deleteSharedLinksJsonBody;
	}

	/**
	 * Method to get the response after triggering delete shared links api
	 * 
	 * @return
	 * @throws IOException
	 */
	protected ValidatableResponse triggerPutApiDeleteSharedLinks() throws IOException {
		FrameworkLogger.logStep("triggerPutApiDeleteSharedLinks:-> Start");
		String strApiUrl = deleteSharedLinksUrl();
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, deleteSharedLinksJsonBody);
		FrameworkLogger.logStep("triggerPutApiDeleteSharedLinks:-> End");
		return response;
	}
}