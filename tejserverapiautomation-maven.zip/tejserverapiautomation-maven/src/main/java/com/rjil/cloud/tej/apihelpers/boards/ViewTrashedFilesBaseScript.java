/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boards;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author Prateek
 *
 */
public class ViewTrashedFilesBaseScript extends BaseTestScript{

	protected static final String apiName = "ViewTrashedFiles";

	protected ViewTrashedFilesBaseScript() {
		globalApiName = apiName;
	}

	protected Map<String, String> createHeader(String limit,String ifModifiedSince) {
		headerMap = initializeHeader();
		//	headerMap.put(HeaderParameters.XSHARDKEY.getValue(), shardKey);
		//	headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), ifModifiedSince);
		//	headerMap.put(HeaderParameters.LIMIT.getValue(), limit);
		return headerMap;
	}

	protected String getViewTrashedFileUrl(String urlValue) {
		FrameworkLogger.logStep(" getCommentsUrl:-> Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get(urlValue);
		FrameworkLogger.logStep("getCommentsUrl: End");
		return url;
	}

	protected ValidatableResponse triggerGetApiViewTrashedFiles(String urlValue) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetComments:-> Start");
		String strApiUrl = getViewTrashedFileUrl(urlValue);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetComments:-> End");
		return response;
	}
	
	protected ValidatableResponse triggerGetApiViewTrashedFilesForOtherUser(Map<String, String>HeaderMap, String urlValue) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetComments:-> Start");
		headerMap = createHeader(HeaderMap);
		String strApiUrl = getViewTrashedFileUrl(urlValue);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetComments:-> End");
		return response;
	}

	/*protected boolean getSortedResponse(ValidatableResponse trashResponse, ValidatableResponse trashResponseAfterSort) throws IOException {
		List listOfUnsortedTrashFiles = new ArrayList();
		List listOfSortedTrashFiles = new ArrayList();

		int  sizeOfUnsortedArray =	trashResponse.extract().jsonPath().getList("objects").size();
		for(int i=0; i<sizeOfUnsortedArray; i++)
		{
			String objectName=trashResponse.extract().path("objects["+i+"].objectName");
			listOfUnsortedTrashFiles.add(objectName);
		}

		   FrameworkLogger.logStep("Unsorted list from trash response  ================"+listOfUnsortedTrashFiles.toString());

		Collections.sort(listOfUnsortedTrashFiles);

		  FrameworkLogger.logStep("Sorted list after sorting it manually  ================"+listOfUnsortedTrashFiles.toString());



		int  sizeOfSortedArray = trashResponseAfterSort.extract().jsonPath().getList("objects").size();
		for(int i=0; i<sizeOfSortedArray; i++)
		{
			String objectName=trashResponseAfterSort.extract().path("objects["+i+"].objectName");
			listOfSortedTrashFiles.add(objectName);
		}

     FrameworkLogger.logStep("Sorted list through sort trash response  ================"+listOfSortedTrashFiles.toString());

		boolean areListsSame = listOfUnsortedTrashFiles.equals(listOfSortedTrashFiles);
	   FrameworkLogger.logStep("Are arrayList same ================"+areListsSame);
		return areListsSame;

	}
	 */
	
	protected ValidatableResponse triggerGetApiViewSortedTrashedFiles(String urlValue) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetComments:-> Start");
		String url = apiUrls.get("boardUrl") + urlValue;
		ValidatableResponse response = triggerGetApi(url, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetComments:-> End");
		return response;
	}

	protected boolean getSortedResponse(ValidatableResponse trashResponseAfterSort) throws IOException {

		List listOfSortedTrashFiles = new ArrayList();  
		boolean areListsSame = false;
		String nextLink= trashResponseAfterSort.extract().path("nextLink");
		try{
		while((nextLink.contains("page")))
		{
		int  sizeOfSortedArray = trashResponseAfterSort.extract().jsonPath().getList("objects").size();
		for(int i=0; i<sizeOfSortedArray; i++)
		{
			String objectName=trashResponseAfterSort.extract().path("objects["+i+"].objectName");
			listOfSortedTrashFiles.add(objectName);
		}

		List beforeManualalySorted = new ArrayList();
		beforeManualalySorted.addAll(listOfSortedTrashFiles);
		
		List afterManualalySorted = sortList(listOfSortedTrashFiles);

	//	FrameworkLogger.logStep("beforeManualalySorted ***************================"+beforeManualalySorted.toString());
	//	FrameworkLogger.logStep("AfterManualalySorted ***************================"+afterManualalySorted.toString());
		
		Iterator<String> iterateListSortedThroughResposne = beforeManualalySorted.iterator();
		
		Iterator<String> iterateListSortedMnaually = afterManualalySorted.iterator();
		Thread.sleep(5000);
		
		for(int i=0;i<sizeOfSortedArray;i++)
		{
			if((iterateListSortedThroughResposne.next()).equals(iterateListSortedMnaually.next()))
	
			{areListsSame=true;}
			else
			{
				{areListsSame=false;}
				break;
			}
		}
	
		Thread.sleep(10000);
		
		 nextLink= trashResponseAfterSort.extract().path("nextLink");
		
		nextLink = nextLink.replace("sort=+NAME", "sort=%2BNAME");
		
		FrameworkLogger.logStep("nextLink ***************================"+nextLink);
		
		trashResponseAfterSort= triggerGetApiViewSortedTrashedFiles(nextLink);
		
		
		FrameworkLogger.logStep("Are arrayList same ================"+areListsSame);
		//return areListsSame;
		}
		}
		catch(Exception e)
		{
			
			System.out.println("No nextlink found");
		}
		return areListsSame;
	}

	
	protected boolean getSortedResponseDesc(ValidatableResponse trashResponseAfterSort) throws IOException {

		List listOfSortedTrashFiles = new ArrayList();  
		boolean areListsSame = false;
		String nextLink= trashResponseAfterSort.extract().path("nextLink");
		try{
		while((nextLink.contains("page")))
		{
		int  sizeOfSortedArray = trashResponseAfterSort.extract().jsonPath().getList("objects").size();
		for(int i=0; i<sizeOfSortedArray; i++)
		{
			String objectName=trashResponseAfterSort.extract().path("objects["+i+"].objectName");
			listOfSortedTrashFiles.add(objectName);
		}

		List beforeManualalySorted = new ArrayList();
		beforeManualalySorted.addAll(listOfSortedTrashFiles);
		
		List afterManualalySorted_temp = sortList(listOfSortedTrashFiles);
		List afterManualalySorted = sortListDesc(afterManualalySorted_temp);

	//	FrameworkLogger.logStep("beforeManualalySorted ***************================"+beforeManualalySorted.toString());
	//	FrameworkLogger.logStep("AfterManualalySorted ***************================"+afterManualalySorted.toString());
		
		Iterator<String> iterateListSortedThroughResposne = beforeManualalySorted.iterator();
		
		Iterator<String> iterateListSortedMnaually = afterManualalySorted.iterator();
		Thread.sleep(5000);
		
		for(int i=0;i<sizeOfSortedArray;i++)
		{
			if((iterateListSortedThroughResposne.next()).equals(iterateListSortedMnaually.next()))
	
			{areListsSame=true;}
			else
			{
				{areListsSame=false;}
				break;
			}
		}
	
		Thread.sleep(10000);
		
		 nextLink= trashResponseAfterSort.extract().path("nextLink");
		
		nextLink = nextLink.replace("sort=+NAME", "sort=%2DNAME");
		
		FrameworkLogger.logStep("nextLink ***************================"+nextLink);
		
		trashResponseAfterSort= triggerGetApiViewSortedTrashedFiles(nextLink);
		
		
		FrameworkLogger.logStep("Are arrayList same ================"+areListsSame);
		//return areListsSame;
		}
		}
		catch(Exception e)
		{
			
			System.out.println("No nextlink found");
		}
		return areListsSame;
	}

	
	public List sortList(List l)
	{
		Collections.sort(l);
		return l;
	}
	
	public List sortListDesc(List l)
	{
		Collections.reverse(l);
		return l;
	}
	
	
	protected boolean getSortedResponseByTypeInAsce(ValidatableResponse trashResponseAfterSort) throws IOException {

		List listOfSortedTrashFiles = new ArrayList();  
		boolean areListsSame = false;
		String nextLink= trashResponseAfterSort.extract().path("nextLink");
		try{
		while((nextLink.contains("page")))
		{
		int  sizeOfSortedArray = trashResponseAfterSort.extract().jsonPath().getList("objects").size();
		for(int i=0; i<sizeOfSortedArray; i++)
		{
			String objectName=trashResponseAfterSort.extract().path("objects["+i+"].mimeType");
			listOfSortedTrashFiles.add(objectName);
		}

		List beforeManualalySorted = new ArrayList();
		beforeManualalySorted.addAll(listOfSortedTrashFiles);
		
		List afterManualalySorted = sortList(listOfSortedTrashFiles);

		FrameworkLogger.logStep("beforeManualalySorted ***************================"+beforeManualalySorted.toString());
		FrameworkLogger.logStep("AfterManualalySorted ***************================"+afterManualalySorted.toString());
		
		Iterator<String> iterateListSortedThroughResposne = beforeManualalySorted.iterator();
		
		Iterator<String> iterateListSortedMnaually = afterManualalySorted.iterator();
		Thread.sleep(5000);
		
	/*	for(int i=0;i<sizeOfSortedArray;i++)
		{
			if((iterateListSortedThroughResposne.next()).equals(iterateListSortedMnaually.next()))
	
			{areListsSame=true;}
			else
			{
				{areListsSame=false;}
				break;
			}
		}*/
		areListsSame =beforeManualalySorted.equals(afterManualalySorted);
		Thread.sleep(10000);
		
		 nextLink= trashResponseAfterSort.extract().path("nextLink");
		
		nextLink = nextLink.replace("sort=+TYPE", "sort=%2BTYPE");
		
		FrameworkLogger.logStep("nextLink ***************================"+nextLink);
		
		trashResponseAfterSort= triggerGetApiViewSortedTrashedFiles(nextLink);
		
		
		FrameworkLogger.logStep("Are arrayList same ================"+areListsSame);
		//return areListsSame;
		}
		}
		catch(Exception e)
		{
			
			System.out.println("No nextlink found");
		}
		return areListsSame;
	}

	
	
	
	protected boolean getSortedResponseByTypeInDesc(ValidatableResponse trashResponseAfterSort) throws IOException {

		List listOfSortedTrashFiles = new ArrayList();  
		boolean areListsSame = false;
		String nextLink= trashResponseAfterSort.extract().path("nextLink");
		try{
		while((nextLink.contains("page")))
		{
		int  sizeOfSortedArray = trashResponseAfterSort.extract().jsonPath().getList("objects").size();
		for(int i=0; i<sizeOfSortedArray; i++)
		{
			String objectName=trashResponseAfterSort.extract().path("objects["+i+"].mimeType");
			listOfSortedTrashFiles.add(objectName);
		}

		List beforeManualalySorted = new ArrayList();
		beforeManualalySorted.addAll(listOfSortedTrashFiles);
		
		List afterManualalySorted_temp = sortList(listOfSortedTrashFiles);
		List afterManualalySorted = sortListDesc(afterManualalySorted_temp);

		FrameworkLogger.logStep("beforeManualalySorted ***************================"+beforeManualalySorted.toString());
		FrameworkLogger.logStep("AfterManualalySorted ***************================"+afterManualalySorted.toString());
		
		Iterator<String> iterateListSortedThroughResposne = beforeManualalySorted.iterator();
		
		Iterator<String> iterateListSortedMnaually = afterManualalySorted.iterator();
		Thread.sleep(5000);
		
		/*for(int i=0;i<sizeOfSortedArray;i++)
		{
			if((iterateListSortedThroughResposne.next()).equals(iterateListSortedMnaually.next()))
	
			{areListsSame=true;}
			else
			{
				{areListsSame=false;}
				break;
			}
		}*/
		
		areListsSame =beforeManualalySorted.equals(afterManualalySorted);
	
		Thread.sleep(10000);
		
		 nextLink= trashResponseAfterSort.extract().path("nextLink");
		
		 nextLink = nextLink.replace("sort=-TYPE", "sort=%2DTYPE");
		
		FrameworkLogger.logStep("nextLink ***************================"+nextLink);
		
		trashResponseAfterSort= triggerGetApiViewSortedTrashedFiles(nextLink);
		
		
		FrameworkLogger.logStep("Are arrayList same ================"+areListsSame);
		//return areListsSame;
		}
		}
		catch(Exception e)
		{
			
			System.out.println("No nextlink found");
		}
		return areListsSame;
	}
	
	
	
	
	
	protected boolean getSortedResponseByModifiedDateInAsce(ValidatableResponse trashResponseAfterSort) throws IOException {

		List listOfSortedTrashFiles = new ArrayList();  
		boolean areListsSame = false;
		String nextLink= trashResponseAfterSort.extract().path("nextLink");
		FrameworkLogger.logStep("NEXTLINK===="+nextLink);
		try{
		while((nextLink.contains("page")))
		{
			FrameworkLogger.logStep("INSIGHT WHILE");
		int  sizeOfSortedArray = trashResponseAfterSort.extract().jsonPath().getList("objects").size();
		for(int i=0; i<sizeOfSortedArray; i++)
		{
			FrameworkLogger.logStep("INSIGHT FOR");
			long objectName=trashResponseAfterSort.extract().path("objects["+i+"].lastModifiedDate");
			FrameworkLogger.logStep("LAST MODIFIED DATE===="+objectName);
			listOfSortedTrashFiles.add(objectName);
		}

		List beforeManualalySorted = new ArrayList();
		beforeManualalySorted.addAll(listOfSortedTrashFiles);
		
		List afterManualalySorted = sortList(listOfSortedTrashFiles);

		FrameworkLogger.logStep("beforeManualalySorted ***************================"+beforeManualalySorted.toString());
		FrameworkLogger.logStep("AfterManualalySorted ***************================"+afterManualalySorted.toString());
		
		Iterator<String> iterateListSortedThroughResposne = beforeManualalySorted.iterator();
		
		Iterator<String> iterateListSortedMnaually = afterManualalySorted.iterator();
		Thread.sleep(5000);
		
		/*for(int i=0;i<sizeOfSortedArray;i++)
		{
			if((iterateListSortedThroughResposne.next()).equals(iterateListSortedMnaually.next()))
	
			{areListsSame=true;}
			else
			{
				{areListsSame=false;}
				break;
			}
		}*/
		
		areListsSame = beforeManualalySorted.equals(afterManualalySorted);
	
	
		
		 nextLink= trashResponseAfterSort.extract().path("nextLink");
		
		nextLink = nextLink.replace("sort=+MODIFIED_DATE", "sort=%2BMODIFIED_DATE");
		
		FrameworkLogger.logStep("nextLink ***************================"+nextLink);
		
		trashResponseAfterSort= triggerGetApiViewSortedTrashedFiles(nextLink);
		
		
		FrameworkLogger.logStep("Are arrayList same ================"+areListsSame);
		//return areListsSame;
		}
		}
		catch(Exception e)
		{
			
			System.out.println("No nextlink found");
		}
		return areListsSame;
	}

	
	
	
	protected boolean getSortedResponseByMODIFIED_DATEInDesc(ValidatableResponse trashResponseAfterSort) throws IOException {

		List listOfSortedTrashFiles = new ArrayList();  
		boolean areListsSame = false;
		String nextLink= trashResponseAfterSort.extract().path("nextLink");
		try{
		while((nextLink.contains("page")))
		{
		int  sizeOfSortedArray = trashResponseAfterSort.extract().jsonPath().getList("objects").size();
		for(int i=0; i<sizeOfSortedArray; i++)
		{
			long objectName=trashResponseAfterSort.extract().path("objects["+i+"].lastModifiedDate");
			listOfSortedTrashFiles.add(objectName);
		}

		List beforeManualalySorted = new ArrayList();
		beforeManualalySorted.addAll(listOfSortedTrashFiles);
		
		List afterManualalySorted_temp = sortList(listOfSortedTrashFiles);
		List afterManualalySorted = sortListDesc(afterManualalySorted_temp);

	//	FrameworkLogger.logStep("beforeManualalySorted ***************================"+beforeManualalySorted.toString());
	//	FrameworkLogger.logStep("AfterManualalySorted ***************================"+afterManualalySorted.toString());
		
		Iterator<String> iterateListSortedThroughResposne = beforeManualalySorted.iterator();
		
		Iterator<String> iterateListSortedMnaually = afterManualalySorted.iterator();
		Thread.sleep(5000);
		
		/*for(int i=0;i<sizeOfSortedArray;i++)
		{
			if((iterateListSortedThroughResposne.next()).equals(iterateListSortedMnaually.next()))
	
			{areListsSame=true;}
			else
			{
				{areListsSame=false;}
				break;
			}
		}*/
		areListsSame = beforeManualalySorted.equals(afterManualalySorted);
		Thread.sleep(10000);
		
		 nextLink= trashResponseAfterSort.extract().path("nextLink");
		
		 nextLink = nextLink.replace("sort=-MODIFIED_DATE", "sort=%2DMODIFIED_DATE");
		
		FrameworkLogger.logStep("nextLink ***************================"+nextLink);
		
		trashResponseAfterSort= triggerGetApiViewSortedTrashedFiles(nextLink);
		
		
		FrameworkLogger.logStep("Are arrayList same ================"+areListsSame);
		//return areListsSame;
		}
		}
		catch(Exception e)
		{
			
			System.out.println("No nextlink found");
		}
		return areListsSame;
	}
	
	
	protected boolean getSortedResponseBySizeInAsce(ValidatableResponse trashResponseAfterSort) throws IOException {

		List listOfSortedTrashFiles = new ArrayList();  
		boolean areListsSame = false;
		String nextLink= trashResponseAfterSort.extract().path("nextLink");
		FrameworkLogger.logStep("NEXTLINK===="+nextLink);
		try{
		while((nextLink.contains("page")))
		{
			FrameworkLogger.logStep("INSIGHT WHILE");
		int  sizeOfSortedArray = trashResponseAfterSort.extract().jsonPath().getList("objects").size();
		for(int i=0; i<sizeOfSortedArray; i++)
		{
			FrameworkLogger.logStep("INSIGHT FOR");
			Integer objectName=trashResponseAfterSort.extract().path("objects["+i+"].sizeInBytes");
			FrameworkLogger.logStep("SIZE IN BYTES===="+objectName);
			listOfSortedTrashFiles.add(objectName);
		}

		List beforeManualalySorted = new ArrayList();
		beforeManualalySorted.addAll(listOfSortedTrashFiles);
		
		List afterManualalySorted = sortList(listOfSortedTrashFiles);

		FrameworkLogger.logStep("beforeManualalySorted ***************================"+beforeManualalySorted.toString());
		FrameworkLogger.logStep("AfterManualalySorted ***************================"+afterManualalySorted.toString());
		
		Iterator<String> iterateListSortedThroughResposne = beforeManualalySorted.iterator();
		
		Iterator<String> iterateListSortedMnaually = afterManualalySorted.iterator();
		Thread.sleep(5000);
		
		/*for(int i=0;i<sizeOfSortedArray;i++)
		{
			if((iterateListSortedThroughResposne.next()).equals(iterateListSortedMnaually.next()))
	
			{areListsSame=true;}
			else
			{
				{areListsSame=false;}
				break;
			}
		}*/
		
		areListsSame = beforeManualalySorted.equals(afterManualalySorted);
	
	
		
		 nextLink= trashResponseAfterSort.extract().path("nextLink");
		
		nextLink = nextLink.replace("sort=+SIZE", "sort=%2BSIZE");
		
		FrameworkLogger.logStep("nextLink ***************================"+nextLink);
		
		trashResponseAfterSort= triggerGetApiViewSortedTrashedFiles(nextLink);
		
		
		FrameworkLogger.logStep("Are arrayList same ================"+areListsSame);
		//return areListsSame;
		}
		}
		catch(Exception e)
		{
			System.out.println("No nextlink found");
		}
		return areListsSame;
	}

	
	
	
	protected boolean getSortedResponseBySizeDesc(ValidatableResponse trashResponseAfterSort) throws IOException {

		List listOfSortedTrashFiles = new ArrayList();  
		boolean areListsSame = false;
		String nextLink= trashResponseAfterSort.extract().path("nextLink");
		try{
		while((nextLink.contains("page")))
		{
		int  sizeOfSortedArray = trashResponseAfterSort.extract().jsonPath().getList("objects").size();
		for(int i=0; i<sizeOfSortedArray; i++)
		{
			Integer objectName=trashResponseAfterSort.extract().path("objects["+i+"].sizeInBytes");
			listOfSortedTrashFiles.add(objectName);
		}

		List beforeManualalySorted = new ArrayList();
		beforeManualalySorted.addAll(listOfSortedTrashFiles);
		
		List afterManualalySorted_temp = sortList(listOfSortedTrashFiles);
		List afterManualalySorted = sortListDesc(afterManualalySorted_temp);

		FrameworkLogger.logStep("beforeManualalySorted ***************================"+beforeManualalySorted.toString());
		FrameworkLogger.logStep("AfterManualalySorted ***************================"+afterManualalySorted.toString());
		
		Iterator<String> iterateListSortedThroughResposne = beforeManualalySorted.iterator();
		
		Iterator<String> iterateListSortedMnaually = afterManualalySorted.iterator();
		Thread.sleep(5000);
		
		/*for(int i=0;i<sizeOfSortedArray;i++)
		{
			if((iterateListSortedThroughResposne.next()).equals(iterateListSortedMnaually.next()))
	
			{areListsSame=true;}
			else
			{
				{areListsSame=false;}
				break;
			}
		}*/
		areListsSame = beforeManualalySorted.equals(afterManualalySorted);
		Thread.sleep(10000);
		
		 nextLink= trashResponseAfterSort.extract().path("nextLink");
		
		 nextLink = nextLink.replace("sort=-SIZE", "sort=%2DSIZE");
		
		FrameworkLogger.logStep("nextLink ***************================"+nextLink);
		
		trashResponseAfterSort= triggerGetApiViewSortedTrashedFiles(nextLink);
		
		
		FrameworkLogger.logStep("Are arrayList same ================"+areListsSame);
		//return areListsSame;
		}
		}
		catch(Exception e)
		{
			
			System.out.println("No nextlink found");
		}
		return areListsSame;
	}
	
	
	protected boolean getSortedResponseByBoardNameInAsce(ValidatableResponse trashResponseAfterSort) throws IOException {

		List listOfSortedTrashFiles = new ArrayList();  
		boolean areListsSame = false;
		String nextLink= trashResponseAfterSort.extract().path("nextLink");
		FrameworkLogger.logStep("NEXTLINK===="+nextLink);
		try{
		while((nextLink.contains("page")))
		{
			FrameworkLogger.logStep("INSIGHT WHILE");
		int  sizeOfSortedArray = trashResponseAfterSort.extract().jsonPath().getList("objects").size();
		for(int i=0; i<sizeOfSortedArray; i++)
		{
			FrameworkLogger.logStep("INSIGHT FOR");
			String objectName=trashResponseAfterSort.extract().path("objects["+i+"].boardName");
			FrameworkLogger.logStep("SIZE IN BYTES===="+objectName);
			listOfSortedTrashFiles.add(objectName);
		}

		List beforeManualalySorted = new ArrayList();
		beforeManualalySorted.addAll(listOfSortedTrashFiles);
		
		List afterManualalySorted = sortList(listOfSortedTrashFiles);

		FrameworkLogger.logStep("beforeManualalySorted ***************================"+beforeManualalySorted.toString());
		FrameworkLogger.logStep("AfterManualalySorted ***************================"+afterManualalySorted.toString());
		
		Iterator<String> iterateListSortedThroughResposne = beforeManualalySorted.iterator();
		
		Iterator<String> iterateListSortedMnaually = afterManualalySorted.iterator();
		Thread.sleep(5000);
		
		/*for(int i=0;i<sizeOfSortedArray;i++)
		{
			if((iterateListSortedThroughResposne.next()).equals(iterateListSortedMnaually.next()))
	
			{areListsSame=true;}
			else
			{
				{areListsSame=false;}
				break;
			}
		}*/
		
		areListsSame = beforeManualalySorted.equals(afterManualalySorted);
	
	
		
		 nextLink= trashResponseAfterSort.extract().path("nextLink");
		
		nextLink = nextLink.replace("sort=+board_name", "sort=%2Bboard_name");
		
		FrameworkLogger.logStep("nextLink ***************================"+nextLink);
		
		trashResponseAfterSort= triggerGetApiViewSortedTrashedFiles(nextLink);
		
		
		FrameworkLogger.logStep("Are arrayList same ================"+areListsSame);
		//return areListsSame;
		}
		}
		catch(Exception e)
		{
			System.out.println("No nextlink found");
		}
		return areListsSame;
	}

	
	
	
	protected boolean getSortedResponseByBoardNameDesc(ValidatableResponse trashResponseAfterSort) throws IOException {

		List listOfSortedTrashFiles = new ArrayList();  
		boolean areListsSame = false;
		String nextLink= trashResponseAfterSort.extract().path("nextLink");
		try{
		while((nextLink.contains("page")))
		{
		int  sizeOfSortedArray = trashResponseAfterSort.extract().jsonPath().getList("objects").size();
		for(int i=0; i<sizeOfSortedArray; i++)
		{
			String objectName=trashResponseAfterSort.extract().path("objects["+i+"].boardName");
			listOfSortedTrashFiles.add(objectName);
		}

		List beforeManualalySorted = new ArrayList();
		beforeManualalySorted.addAll(listOfSortedTrashFiles);
		
		List afterManualalySorted_temp = sortList(listOfSortedTrashFiles);
		List afterManualalySorted = sortListDesc(afterManualalySorted_temp);

		FrameworkLogger.logStep("beforeManualalySorted ***************================"+beforeManualalySorted.toString());
		FrameworkLogger.logStep("AfterManualalySorted ***************================"+afterManualalySorted.toString());
		
		Iterator<String> iterateListSortedThroughResposne = beforeManualalySorted.iterator();
		
		Iterator<String> iterateListSortedMnaually = afterManualalySorted.iterator();
		Thread.sleep(5000);
		
		/*for(int i=0;i<sizeOfSortedArray;i++)
		{
			if((iterateListSortedThroughResposne.next()).equals(iterateListSortedMnaually.next()))
	
			{areListsSame=true;}
			else
			{
				{areListsSame=false;}
				break;
			}
		}*/
		areListsSame = beforeManualalySorted.equals(afterManualalySorted);
		Thread.sleep(10000);
		
		 nextLink= trashResponseAfterSort.extract().path("nextLink");
		
		 nextLink = nextLink.replace("sort=-board_name", "sort=%2Dboard_name");
		
		FrameworkLogger.logStep("nextLink ***************================"+nextLink);
		
		trashResponseAfterSort= triggerGetApiViewSortedTrashedFiles(nextLink);
		
		
		FrameworkLogger.logStep("Are arrayList same ================"+areListsSame);
		//return areListsSame;
		}
		}
		catch(Exception e)
		{
			
			System.out.println("No nextlink found");
		}
		return areListsSame;
	}
}
