package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.util.HashMap;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;
/**
 * @author Chandrashekhar Singh
 * 
 * Base script for Merge All Duplicate Contacts.
 * */

public class MergeAllMergeSuggestionsOfDuplicateContactsBaseScript extends BaseTestScript {
    protected static final String apiName="MergeAllMergeSuggestionsOfDuplicateContacts";
    
    public MergeAllMergeSuggestionsOfDuplicateContactsBaseScript(){
  		globalApiName=apiName;
  	}

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It creates the url for API
     */
    protected String getMergeAllMergeSuggestionsOfDuplicateContactsUrl() {
        return apiUrls.get("baseContactURL") + serverConfig.get("mergeAllDuplicateContactsURL");
    }


    /**
     * @return validatable response for Merge All Api.
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    protected ValidatableResponse triggerPutApiMergeAllMergeSuggestionsOfDuplicateContacts() {
		FrameworkLogger.logStep("triggerPutApiMergeAllMergeSuggestionsOfDuplicateContacts:-> Start");

		String strApiUrl=getMergeAllMergeSuggestionsOfDuplicateContactsUrl();
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap);
		
        FrameworkLogger.logStep("triggerPutApiMergeAllMergeSuggestionsOfDuplicateContacts:-> End");

        return response;
    }

    /**
     * 
     * @author Chandrashekhar Singh
     * <p>
     * Method to verify the success message in Merge All response.
     * @throws VerificationFailException 
     */
    public static void verifySuccessForMergeAllAPIResponse(ValidatableResponse response) throws VerificationFailException{

        FrameworkLogger.logStep("verifySuccessForMergeAllAPIResponse:-> Start");

    	//Set the expected error information.
		String strExpectedResponseStatus = "SUCCESS";
		String strExpectedResponseCode = "TEJAG0201";
		int strExpectedHttpResponse = ApiResponseCodes.RESPONSECODE200.getValue();
		String strExpectedMessage = "Merging has been started; notification will be sent after completed.";

		//      Get and verify the status code.
		int strActualHttpResponse = response.extract().statusCode();
		String strActualMessage = response.extract().path("message");
		String strActualResponseStatus = response.extract().path("status");
		String strActualCode = response.extract().path("code");
		
		//      Validating the response.
		Verify.verifyEquals(strActualHttpResponse,strExpectedHttpResponse, "Verify Success HTTP Response code for MergeAll.");
		Verify.verifyEquals(strActualResponseStatus,strExpectedResponseStatus, "Verify Success Response Status for MergeAll.");
		Verify.verifyEquals(strActualMessage,strExpectedMessage, "Verify Success Response message for MergeAll.");
		Verify.verifyEquals(strActualCode,strExpectedResponseCode, "Verify Success Response code for MergeAll.");

        FrameworkLogger.logStep("verifySuccessForMergeAllAPIResponse:-> End");
    }

    /**
     * @return validatable response for Merge All Api.
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    public static ValidatableResponse triggerMergeAllMergeSuggestionsOfDuplicateContactsServiceMethod() {
		FrameworkLogger.logStep("triggerMergeAllMergeSuggestionsOfDuplicateContactsServiceMethod:-> Start");
		
		MergeAllMergeSuggestionsOfDuplicateContactsBaseScript apiObj=new MergeAllMergeSuggestionsOfDuplicateContactsBaseScript();
		apiObj.createHeader();
		String strApiUrl=apiObj.getMergeAllMergeSuggestionsOfDuplicateContactsUrl();
		//Call method to trigger PUT API.
		ValidatableResponse response = apiObj.triggerPutApi(strApiUrl,apiObj.headerMap);
		
        FrameworkLogger.logStep("triggerMergeAllMergeSuggestionsOfDuplicateContactsServiceMethod:-> End");

        return response;
    }

}

//Create header for API.
//createHeader();
