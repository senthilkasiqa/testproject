package com.rjil.cloud.tej.apihelpers.usermanagement;

import java.io.File;
import java.io.IOException;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

/**
 * 
 * @author Ashwini.Abhyankar
 *
 *         Base Class for Update auto backup settings
 */

public class UpdateAutoBackupSettingsBaseScript extends BaseTestScript {
	protected String updateAutoBackupSettingsJsonBody;
	protected static final String apiName = "UpdatdeAutoBackupSettings";
	
	public UpdateAutoBackupSettingsBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * Method for Creating update auto backup settings Url
	 * 
	 * @return
	 */
	protected String getUpdateAutoBackupSettingsUrl() {
		FrameworkLogger.logStep("getUpdateAutoBackupSettingsURL:-> Start");
		String url = apiUrls.get("baseURL") + serverConfig.get("updateAutoBackupSettingsUrl");

		FrameworkLogger.logStep("getUpdateAutoBackupSettingsURL:-> End");
		return url;
	}
	
	protected String getUpdateAutoBackupSettingsUrl(String url) {
		FrameworkLogger.logStep("getUpdateAutoBackupSettingsURL:-> Start");
		String apiUrl = apiUrls.get("baseURL") + serverConfig.get(url);

		FrameworkLogger.logStep("getUpdateAutoBackupSettingsURL:-> End");
		return apiUrl;
	}

	/**
	 * Method for Creating update Auto Backup Settings body
	 * 
	 * @return
	 */

	protected String setUpdateAutoBackupSettingsJsonBody() throws IOException {
		FrameworkLogger.logStep("setUpdateAutoBackupSettingsJsonBody:-> Start");
		String path = System.getProperty("user.dir")
				+ "/resources/userManagementTestData/updateAutoBackupSettingsJsonBody.js";
		File file = new File(path);
		updateAutoBackupSettingsJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setUpdateAutoBackupSettingsJsonBody:-> End");
		return updateAutoBackupSettingsJsonBody;
	}

	/**
	 * Method to get the response after triggering update auto backup settings
	 * Api
	 * 
	 * @return
	 * @throws IOException
	 */
	protected ValidatableResponse triggerPutApiUpdateAutoBackupSettings() throws IOException {

		FrameworkLogger.logStep("triggerPutApiUpdateAutoBackupSettings:-> Start");

		// get url for autobackup settings url
		String strApiUrl = getUpdateAutoBackupSettingsUrl();

		// get response from update auto backup setings api
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, updateAutoBackupSettingsJsonBody);

		FrameworkLogger.logStep("triggerPutApiUpdateAutoBackupSettings:-> End");
		return response;
	}
	
	protected ValidatableResponse triggerPutApiUpdateAutoBackupSettings(String apiUrl) throws IOException {

		FrameworkLogger.logStep("triggerPutApiUpdateAutoBackupSettings:-> Start");

		// get url for store autobackup settings url
		String strApiUrl = getUpdateAutoBackupSettingsUrl(apiUrl);

		// get response from store auto backup settings api
		ValidatableResponse response = triggerPutApi(strApiUrl, headerMap, updateAutoBackupSettingsJsonBody);

		FrameworkLogger.logStep("triggerPutApiUpdateAutoBackupSettings:-> End");
		return response;
	}
}
