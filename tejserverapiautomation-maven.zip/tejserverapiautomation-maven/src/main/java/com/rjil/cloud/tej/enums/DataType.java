package com.rjil.cloud.tej.enums;

/**
 * Data type enum
 */
public enum DataType {
    EXCEL,
    JSON,
    XML,
    CSV,
    EMPTY
}
