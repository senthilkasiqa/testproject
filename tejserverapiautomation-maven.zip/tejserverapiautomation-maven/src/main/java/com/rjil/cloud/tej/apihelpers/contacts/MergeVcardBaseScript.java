package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.ContactBackupConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;
/**
 * @author Chandrashekhar Singh
 * 
 * Base script for Merge Suggestions API.
 
4.2.28.2	After get merge suggestions this API will be called. This API will take the master contact id and duplicate contact ids. The JCARD of duplicate ids and master contact id will be merged into JCARD of master contact id. After merging the merged JCARD will be returned in response. 

To create the merged contact, following rules would be followed:
4.2.28.2.1	Name would be taken from the Highest ranked duplicate it is present in. for example if the highest ranked duplicate doesn't have the name then we will take name from the second highest ranked and so on.
4.2.28.2.2	Profile picture would be taken from the highest ranked duplicate having a profile picture.
4.2.28.2.3	For rest of the fields, values will be compared for all the duplicates and
4.2.28.2.3.1	If value for a field is same for 2 or more duplicates than it will be displayed once in the merged contact and the label would be taken from higher ranked duplicate
4.2.28.2.3.2	If different values are present then they will be appended i.e. all of them will be displayed in the merged contact.
4.2.28.2.4	E.g.
-Contact A: mobile: 123, home: 234, other : 456
-Contact A1: other: 123, other: 789
-merged contact: Contact A: mobile:123, home: 234, other: 456, other: 789

Then the same merged contact will be taken backup as merge_add operation.
  

 * */

public class MergeVcardBaseScript extends BaseTestScript {
    protected static final String apiName="MergeSuggestions";
    protected  String mergeVcardJSONBody;
    
    public MergeVcardBaseScript(){
  		globalApiName=apiName;
  	}
  

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It creates the url for API
     */
    protected String getMergeVcardUrl() {
		String methodName="getMergeVcardUrl";
		FrameworkLogger.logStep(methodName+" -> Start");
		
		String result=apiUrls.get("baseContactURL") + serverConfig.get("mergeVcardUrl");
		
		FrameworkLogger.logStep(methodName+" -> End");
		
        return result;
    }

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It loads the default Contact Backup JSON body.
     */

    protected void loadJsonFile(){
        //load json file
		String filePath="/resources/mergeVcardTestData/mergeVcardApiBody.js";
//		String filePath="/resources/contactBackupTestData/contactBackupBody_update.js";
    	
    	mergeVcardJSONBody=loadJsonFile(filePath);

//    	String strUniqueValue=Utils.getUniqueValue();

//		setContactBackupJsonBody(ContactBackupConstants.getActTranIdJsonPath(), new Integer("111"+strUniqueValue));
//		setContactBackupJsonBody(ContactBackupConstants.getActTranIdJsonPath(), "111"+strUniqueValue);
    }

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It will set the value on provided json path
     */
    protected void setMergeVcardJsonBody(String jsonPath, Object value) {
        mergeVcardJSONBody = setJsonData(jsonPath, value, mergeVcardJSONBody);

    }

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It will set the value the duplicate Contact Ids json 
     */
    protected void setDupeContactIdsInMergeVcardJsonBody(String value) {
        mergeVcardJSONBody = mergeVcardJSONBody.replace("$dupContactIds", value);

    }
    /**
     * @return validatable response for Merge Suggestions
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    protected ValidatableResponse triggerPutApiMergeVcard() {
		FrameworkLogger.logStep("triggerPutApiMergeVcard -> Start");
		
		//Get the URL of the API.
		String strApiUrl=getMergeVcardUrl();
		
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,mergeVcardJSONBody);

		FrameworkLogger.logStep("triggerPutApiMergeVcard -> End");

        return response;
    }

}
