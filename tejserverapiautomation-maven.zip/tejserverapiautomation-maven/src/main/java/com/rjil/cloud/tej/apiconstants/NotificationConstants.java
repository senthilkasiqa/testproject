package com.rjil.cloud.tej.apiconstants;

public class NotificationConstants {

	 public static String getNotificationId() {
	        return "$.notifications[0].notificationId";
	    }

	    public static String getStatus() {
	        return "$.notifications[0].status";
	    }
	    
	    public static String getLastUpdatedTime(){
	    	return "$.lastUpdatedTime";
	    }
	    
}
