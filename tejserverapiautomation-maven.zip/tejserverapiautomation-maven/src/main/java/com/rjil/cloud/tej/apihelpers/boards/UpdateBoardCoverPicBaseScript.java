package com.rjil.cloud.tej.apihelpers.boards;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class UpdateBoardCoverPicBaseScript extends BaseTestScript{
	
	protected static final String apiName = "UpdateBoardCoverPic";
	protected static String updateBoardCoverPicJsonBody;
	//String boardJsonBody=null;
	public static String boardKey;
	
	protected UpdateBoardCoverPicBaseScript() {
		globalApiName = apiName;
	}
	protected Map<String, String> createHeader() {
		headerMap = initializeHeader();
		return headerMap;
	}
	
	protected String updateBoardCoverPicUrl(String boardKey) {
		FrameworkLogger.logStep("updateBoardCoverPicUrl: Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get("updateBoardCoverPicUrl").replace("{boardKey}", boardKey);
		FrameworkLogger.logStep("updateBoardCoverPicUrl: End");
		return url;
	}
	
	protected String updateBoardCoverPicUrl(String urlValue, String boardKey) {
		FrameworkLogger.logStep("updateBoardCoverPicUrl: Start");
		String url = apiUrls.get("boardUrl") + urlValue;
		FrameworkLogger.logStep("updateBoardCoverPicUrl: End");
		return url;
	}
	
	protected String setUpdateBoardCoverPicJsonBody() throws IOException{
		FrameworkLogger.logStep("setUpdateBoardCoverPicJsonBody: Start");
		// load json file
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/updateBoardCoverPic.js";
		File file = new File(path);
		updateBoardCoverPicJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setUpdateBoardCoverPicJsonBody: End");
		return updateBoardCoverPicJsonBody;
	}


	protected ValidatableResponse triggerPutApiUpdateBoardCoverPic(String boardKey) throws IOException {

		FrameworkLogger.logStep("triggerPutApiUpdateBoardCoverPic: Start");
        String strApiUrl=updateBoardCoverPicUrl(boardKey);
		ValidatableResponse response=triggerPutApi(strApiUrl, headerMap, updateBoardCoverPicJsonBody);
		FrameworkLogger.logStep("triggerPutApiUpdateBoardCoverPic: End");
		return response;
	}
	
	
	protected ValidatableResponse triggerPutApiUpdateBoardCoverPic(String boardKey, Map<String, String> headerMap) throws IOException {

		FrameworkLogger.logStep("triggerPutApiUpdateBoardCoverPic: Start");
		String strApiUrl=updateBoardCoverPicUrl(boardKey);
		
		// get response from create a Folder API
		ValidatableResponse response=triggerPutApi(strApiUrl, createHeader(headerMap), updateBoardCoverPicJsonBody);
		FrameworkLogger.logStep("triggerPutApiUpdateBoardCoverPic: End");

		return response;
	}
	

	public static ValidatableResponse updateBoardCoverPicServiceMethod(String objectKey, String boardKey) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("updateBoardCoverPicServiceMethod: Start");
		
		UpdateBoardCoverPicBaseScript updateBoardCoverPic = new UpdateBoardCoverPicBaseScript();
		updateBoardCoverPic.createHeader();
		updateBoardCoverPicJsonBody = updateBoardCoverPic.setUpdateBoardCoverPicJsonBody();
		updateBoardCoverPicJsonBody = setJsonData(NewBoardConstants.getBoardCoverPicObjectKey(), objectKey, updateBoardCoverPicJsonBody);
		ValidatableResponse response = updateBoardCoverPic.triggerPutApiUpdateBoardCoverPic(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("updateBoardCoverPicServiceMethod: End");
		return response;
	}
	
	public static ValidatableResponse updateBoardCoverPicServiceMethod(Map<String, String> headerMap1, String objectKey, String boardKey) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("repositoryFileUploadToBoardServiceMethod: Start");
		

		UpdateBoardCoverPicBaseScript updateBoardCoverPic = new UpdateBoardCoverPicBaseScript();
		updateBoardCoverPic.createHeader();
		updateBoardCoverPicJsonBody = updateBoardCoverPic.setUpdateBoardCoverPicJsonBody();
		updateBoardCoverPicJsonBody = setJsonData(NewBoardConstants.getBoardCoverPicObjectKey(), objectKey, updateBoardCoverPicJsonBody);
		ValidatableResponse response = updateBoardCoverPic.triggerPutApiUpdateBoardCoverPic(boardKey, headerMap1);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("updateBoardCoverPicServiceMethod: End");
		return response;
	}

}
