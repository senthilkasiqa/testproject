package com.rjil.cloud.mailchamp.common.helper;

public class SyncDataAndGetSubscriptionBaseClass extends MailChampBaseTestScript {
	
	protected String getSynsDataUrl() {
		String baseUrl = getValueFromEnvConfig("baseURL");
		String subUrl = getValueFromProjectConfig("syncDataURL");	
		return baseUrl + subUrl;
		}

}
