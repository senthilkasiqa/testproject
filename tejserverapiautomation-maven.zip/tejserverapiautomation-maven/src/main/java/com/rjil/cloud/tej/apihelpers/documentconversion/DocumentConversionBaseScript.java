/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.documentconversion;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author Prateek
 * 
 * Base class for Document Conversion Api
 *
 */
public class DocumentConversionBaseScript extends BaseTestScript{

	protected static final String apiName = "DocumentConversion";
	static String filePath;
	// = System.getProperty("user.dir") + "/resources/uploadTestData/"+fileName;
	static File file;
	
	public DocumentConversionBaseScript(){
		globalApiName=apiName;
	}
	
	/**
	 * @author Prateek
	 * 
	 *         Method to get the file name
	 * 
	 */
	protected void getFileName(String fileName) {
		FrameworkLogger.logStep("getFileName: Start");
		// filePath=System.getProperty("user.dir") +
		// "/resources/uploadTestData/download.jpg";
		filePath = System.getProperty("user.dir") + "/resources/documentConversionTestData/" + fileName;
		file = new File(filePath);
		FrameworkLogger.logStep("getFileName: End");
	}
	
	/*protected Map<String, String> createHeader(){
		FrameworkLogger.logStep("createHeader:-> Start");
		  String withXapiKey=apiUrls.get("xApiKeyValue");
		  headerMap.put(HeaderParameters.XAPIKEY.getValue(), withXapiKey);
		  FrameworkLogger.logStep("createHeader:-> End");
		  return headerMap;
	}*/
	
	protected ValidatableResponse triggerGetApiGetDocumentConversion(String apiUrl) throws IOException {	
		FrameworkLogger.logStep("triggerGetApiGetTrashMetadata: Start");
		
		
		ValidatableResponse response = triggerGetApi(apiUrl,createHeader());
		
		FrameworkLogger.logStep("triggerGetApiGetTrashMetadata: End");
		return response;

	}
	
	public  ValidatableResponse documentConversionServiceMethod(String apiUrl){
		FrameworkLogger.logStep("documentConversionServiceMethod: Start");
		
		
		ValidatableResponse response = triggerGetApi(apiUrl,headerMap);
		
		FrameworkLogger.logStep("documentConversionServiceMethod: End");
		return response;
	}
}
