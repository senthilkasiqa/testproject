package com.rjil.cloud.tej.apihelpers.boards;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class RepositoryFileUploadToBoardBaseScript extends BaseTestScript{

	
	protected Map<String, String> createHeader() {
		headerMap = initializeHeader();
	//	headerMap.put(HeaderParameters.XSHARDKEY.getValue(), shardKey);
		return headerMap;
	}
	
	protected static final String apiName = "RepositoryFileUploadToBoard";
	protected static String repositoryFileUploadToBoardJsonBody;
	//String boardJsonBody=null;
	public static String boardKey;
	
	protected String repositoryFileUploadToBoardUrl(String boardKey) {
		FrameworkLogger.logStep("repositoryFileUploadToBoardUrlURL: Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get("repositoryFileUploadToBoardUrl").replace("{boardKey}", boardKey);
		FrameworkLogger.logStep("repositoryFileUploadToBoardUrlURL: End");
		return url;
	}
	
	protected String repositoryFileUploadToBoardUrl(String urlValue, String boardKey) {
		FrameworkLogger.logStep("repositoryFileUploadToBoardUrl: Start");
		String url = apiUrls.get("boardUrl") + urlValue;
		FrameworkLogger.logStep("repositoryFileUploadToBoardUrl: End");
		return url;
	}
	
	protected String setRepositoryFileUploadToBoardJsonBody() throws IOException{
		FrameworkLogger.logStep("setRepositoryFileUploadToBoardJsonBody: Start");
		// load json file
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/repositoryFileUploadToBoad.js";
		File file = new File(path);
		repositoryFileUploadToBoardJsonBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setRepositoryFileUploadToBoardJsonBody: End");
		return repositoryFileUploadToBoardJsonBody;
	}


	protected ValidatableResponse triggerPostApiRepositoryUploadToBoard(String boardKey) throws IOException {

		FrameworkLogger.logStep("triggerPostApiRepositoryUploadToBoard: Start");
        String strApiUrl=repositoryFileUploadToBoardUrl(boardKey);
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, repositoryFileUploadToBoardJsonBody);
		FrameworkLogger.logStep("triggerPostApiRepositoryUploadToBoard: End");
		return response;
	}
	
	
	protected ValidatableResponse triggerPostApiRepositoryUploadToBoard(String boardKey, Map<String, String> headerMap) throws IOException {

		FrameworkLogger.logStep("triggerPostApiRepositoryUploadToBoard: Start");
		String strApiUrl=repositoryFileUploadToBoardUrl(boardKey);

		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, repositoryFileUploadToBoardJsonBody);

		String objectKeyOfFileUploadedToBoardFromRoot = response.extract().path("objectKey");
		repositoryMap.put(RepositoryParameterEnum.OBJECTKEYOFFFILEUPLOADEDTOBOARDFROMROOT.getValue(), objectKeyOfFileUploadedToBoardFromRoot);
		FrameworkLogger.logStep("triggerPostApiRepositoryUploadToBoard: End");

		return response;
	}
	

	protected ValidatableResponse triggerPostApiRepositoryUploadToBoard(String urlValue, String boardKey) throws IOException {

		FrameworkLogger.logStep("triggerPostApiRepositoryUploadToBoard: Start");
		String strApiUrl=repositoryFileUploadToBoardUrl(urlValue, boardKey);

		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, repositoryFileUploadToBoardJsonBody);

		FrameworkLogger.logStep("triggerPostApiRepositoryUploadToBoard: End");
		return response;
	}
	

	public static ValidatableResponse repositoryFileUploadToBoardServiceMethod(String status, String objectKey, String boardKey) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("repositoryFileUploadToBoardServiceMethod: Start");
		
		RepositoryFileUploadToBoardBaseScript repositoryFileUploadToBoard = new RepositoryFileUploadToBoardBaseScript();
		repositoryFileUploadToBoard.createHeader();
		repositoryFileUploadToBoardJsonBody = repositoryFileUploadToBoard.setRepositoryFileUploadToBoardJsonBody();
		repositoryFileUploadToBoardJsonBody = setJsonData(NewBoardConstants.getStatus(), status, repositoryFileUploadToBoardJsonBody);
		repositoryFileUploadToBoardJsonBody = setJsonData(NewBoardConstants.getObjectKeyForRepositoryUploadToBoard(), objectKey, repositoryFileUploadToBoardJsonBody);
		ValidatableResponse response = repositoryFileUploadToBoard.triggerPostApiRepositoryUploadToBoard(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Repository Upload To Board Status");
		FrameworkLogger.logStep("repositoryFileUploadToBoardServiceMethod: End"+response.toString());
		return response;
	}
	
	public static ValidatableResponse repositoryFileUploadToBoardServiceMethod(Map<String, String> headerMap1,String status, String objectKey, String boardKey) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("repositoryFileUploadToBoardServiceMethod: Start");
		
		RepositoryFileUploadToBoardBaseScript repositoryFileUploadToBoard = new RepositoryFileUploadToBoardBaseScript();
		Map<String,String> headerMap = repositoryFileUploadToBoard.createHeader(headerMap1);
		repositoryFileUploadToBoardJsonBody = repositoryFileUploadToBoard.setRepositoryFileUploadToBoardJsonBody();
		repositoryFileUploadToBoardJsonBody = setJsonData(NewBoardConstants.getStatus(), status, repositoryFileUploadToBoardJsonBody);
		repositoryFileUploadToBoardJsonBody = setJsonData(NewBoardConstants.getObjectKeyForRepositoryUploadToBoard(), objectKey, repositoryFileUploadToBoardJsonBody);
		ValidatableResponse response = repositoryFileUploadToBoard.triggerPostApiRepositoryUploadToBoard(boardKey, headerMap);
		int statusCode = response.extract().statusCode();
		//Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("repositoryFileUploadToBoardServiceMethod: End"+response);
		return response;
	}

}
