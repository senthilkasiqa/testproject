package com.rjil.cloud.tej.apihelpers.sharedServices;

import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.SharedServicesConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.fileupload.UploadBaseScript;
import com.rjil.cloud.tej.apihelpers.nms.CreateFolderBaseScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Sanjeevanee.Kanase Class to create a public link - for uploaded file
 */
public class CreatePublicLinkBaseScript extends BaseTestScript {

	protected String createPublicLinkJSONBody;
	protected static final String apiName = "CreatePublicLink";
	public static String objectKey=null;
	public static String objectKey1=null;
	
	public CreatePublicLinkBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * get a complete url for 'create a public link API'
	 * 
	 * @return
	 */

	protected String getCreatePublicLinkURL() {

		FrameworkLogger.logStep("getCreatePublicLinkURL:-> Start");
		return apiUrls.get("baseURL") + serverConfig.get("createAPublicLinkURL");
	}

	protected String getCreatePublicLinkURL(String urlKey) {
		FrameworkLogger.logStep("getCreatePublicLinkURL with parameter :-> Start");
		return apiUrls.get("baseURL") + serverConfig.get(urlKey);
	}

	protected String setCreatePublicLinkJsonBody() throws IOException {
		// load json file
		// createHeader();
		FrameworkLogger.logStep("setCreatePublicLinkJsonBody:-> Start");
		String path = System.getProperty("user.dir") + "/resources/sharedServicesTestData/createAPublicLinkBody.js";
		File file = new File(path);
		createPublicLinkJSONBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setCreatePublicLinkJsonBody:-> End");
		return createPublicLinkJSONBody;
	}
	
	protected String setCreatePublicLinkJsonBodyForTwoObjects() throws IOException {
		// load json file
		// createHeader();
		FrameworkLogger.logStep("setCreatePublicLinkJsonBody:-> Start");
		String path = System.getProperty("user.dir") + "/resources/sharedServicesTestData/createAPublicLinkBodyForTwoObjects.js";
		File file = new File(path);
		createPublicLinkJSONBody = JsonPath.parse(file).jsonString();
		FrameworkLogger.logStep("setCreatePublicLinkJsonBody:-> End");
		return createPublicLinkJSONBody;
	}

	/**
	 * Method to get create a public link Response
	 *
	 * @return create a public link validatable response
	 */

	protected ValidatableResponse triggerPostApiCreatePublicLink() throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreatePublicLink:-> Start");

		// get url for create a public link API
		String strApiUrl = getCreatePublicLinkURL();

		// get response from create a public link API
		ValidatableResponse response = triggerPostApi(strApiUrl, headerMap, createPublicLinkJSONBody);

		FrameworkLogger.logStep("triggerPostApiCreatePublicLink:-> End");
		return response;
	}

	protected ValidatableResponse triggerPostApiCreatePublicLink(String urlKey) throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreatePublicLink with parameter :-> Start");

		String strApiUrl = getCreatePublicLinkURL(urlKey);

		// get response from create a public link API
		ValidatableResponse response = triggerPostApi(strApiUrl, headerMap, createPublicLinkJSONBody);

		FrameworkLogger.logStep("triggerPostApiCreatePublicLink with parameter :-> End");
		return response;
	}

	/**
	 * 
	 * @author Prateek
	 * 
	 *         Method to fetch key from create a public link response
	 */

	public static void getShareKeyAndShardKey(ValidatableResponse response) {

		FrameworkLogger.logStep("getShareKey :-> Start");
		String shareUrl = response.extract().path("shareURL");
		repositoryMap.put(RepositoryParameterEnum.SHAREURL.getValue(), shareUrl);

		// Get ShardKey from ShareUrl
		String shardKey = shareUrl.substring(shareUrl.length() - 2);
		FrameworkLogger.logStep("ShardKey========:" + shardKey);
		repositoryMap.put(RepositoryParameterEnum.SHARDKEY.getValue(), shardKey);

		// Pattern.compile("\\w{16}") Regex for fetching sharekey from url
		Pattern pattern = Pattern.compile("\\w{16}");
		Matcher matcher = pattern.matcher(shareUrl);
		if (matcher.find()) {

			String shareKey = matcher.group(0);
			System.out.println("ShareKey========:" + shareKey);
			repositoryMap.put(RepositoryParameterEnum.SHAREKEY.getValue(), shareKey);
		}
		FrameworkLogger.logStep("getShareKey :-> End");
	}

	/**
	 * 
	 * Auth Api Response Service method for utilization in other test cases
	 * 
	 * @param fileName
	 * @throws VerificationFailException
	 * @throws IOException
	 * @throws InterruptedException
	 */

	public static void getCreatePublicLinkApiResponseServiceMethod(String fileName)
			throws VerificationFailException, IOException, InterruptedException {

		FrameworkLogger.logStep("getCreatePublicLinkApiResponseServiceMethod:-> Start");

		// if
		// (!repositoryMap.containsKey(RepositoryParameterEnum.OBJECTKEY.getValue()))
		// {

		UploadBaseScript.getUploadFileServiceMethod(fileName);

		// }
		// Fecth Object Key from Upload file response
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		CreatePublicLinkBaseScript apiObject = new CreatePublicLinkBaseScript();
		// Create header for passing in request
		apiObject.createHeader();

		apiObject.setCreatePublicLinkJsonBody();

		// update the object key of uploaded file from repositoryMap
		apiObject.createPublicLinkJSONBody = apiObject.setJsonData(SharedServicesConstants.getObjectKey(),
				repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue()), apiObject.createPublicLinkJSONBody);

		ValidatableResponse response = apiObject.triggerPostApiCreatePublicLink();

		getShareKeyAndShardKey(response);
		
		FrameworkLogger.logStep("getCreatePublicLinkApiResponseServiceMethod:-> End");
	}
	
	public static void getCreatePublicLinkApiResponseServiceMethodForTwoObjects(String fileName, String fileName1)
			throws VerificationFailException, IOException, InterruptedException {

		FrameworkLogger.logStep("getCreatePublicLinkApiResponseServiceMethod:-> Start");

		// if
		// (!repositoryMap.containsKey(RepositoryParameterEnum.OBJECTKEY.getValue()))
		// {

		UploadBaseScript.getUploadFileServiceMethod(fileName);

		// }
		// Fecth Object Key from Upload file response
		 objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
		UploadBaseScript.getUploadFileServiceMethod(fileName1);
		
		 objectKey1 = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
		

		CreatePublicLinkBaseScript apiObject = new CreatePublicLinkBaseScript();
		// Create header for passing in request
		apiObject.createHeader();

		apiObject.setCreatePublicLinkJsonBody();

		// update the object key of uploaded file from repositoryMap
		apiObject.createPublicLinkJSONBody = apiObject.setJsonData(SharedServicesConstants.getObjectKey(0),
				objectKey, apiObject.createPublicLinkJSONBody);
		
		apiObject.createPublicLinkJSONBody = apiObject.setJsonData(SharedServicesConstants.getObjectKey(1),
				objectKey1, apiObject.createPublicLinkJSONBody);

		ValidatableResponse response = apiObject.triggerPostApiCreatePublicLink();

		getShareKeyAndShardKey(response);
		
		FrameworkLogger.logStep("getCreatePublicLinkApiResponseServiceMethod:-> End");
	}
	
	public static void getCreatePublicLinkApiResponseServiceMethodForTwoFolderObjects()
			throws VerificationFailException, IOException, InterruptedException {

		FrameworkLogger.logStep("getCreatePublicLinkApiResponseServiceMethod:-> Start");

		// if
		// (!repositoryMap.containsKey(RepositoryParameterEnum.OBJECTKEY.getValue()))
		// {

		//UploadBaseScript.getUploadFileServiceMethod(fileName);

		CreateFolderBaseScript.createFolderServiceMethod();
		// }
		// Fecth Object Key from Upload file response
		 objectKey = repositoryMap.get(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue());
		
		//UploadBaseScript.getUploadFileServiceMethod(fileName1);
		 CreateFolderBaseScript.createFolderServiceMethod();
		
		 objectKey1 = repositoryMap.get(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue());
		
		

		CreatePublicLinkBaseScript apiObject = new CreatePublicLinkBaseScript();
		// Create header for passing in request
		apiObject.createHeader();

		apiObject.setCreatePublicLinkJsonBody();

		// update the object key of uploaded file from repositoryMap
		apiObject.createPublicLinkJSONBody = apiObject.setJsonData(SharedServicesConstants.getObjectKey(0),
				objectKey, apiObject.createPublicLinkJSONBody);
		
		apiObject.createPublicLinkJSONBody = apiObject.setJsonData(SharedServicesConstants.getObjectKey(1),
				objectKey1, apiObject.createPublicLinkJSONBody);

		ValidatableResponse response = apiObject.triggerPostApiCreatePublicLink();

		getShareKeyAndShardKey(response);
		
		FrameworkLogger.logStep("getCreatePublicLinkApiResponseServiceMethod:-> End");
	}
}