/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.download;

import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author Prateek
 * 
 *         Base class for Get bulk download base script
 *
 */
public class GetBulkDownloadBaseScript extends BaseTestScript {

	protected static final String apiName = "GetBulkDownload";

	// protected Map<String, String> headerMap = null;

	public GetBulkDownloadBaseScript() {
		globalApiName = apiName;
	}

	protected ValidatableResponse triggerGetApiGetBulkDownload(String url, boolean value) {

		ValidatableResponse response = triggerGetApi(url, headerMap, value);

		return response;
	}
}
