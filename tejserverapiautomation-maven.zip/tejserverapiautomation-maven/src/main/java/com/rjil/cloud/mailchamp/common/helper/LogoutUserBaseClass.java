package com.rjil.cloud.mailchamp.common.helper;

public class LogoutUserBaseClass extends MailChampBaseTestScript {
	
	protected String getLogoutUserUrl() {
		String baseUrl = getValueFromEnvConfig("baseURL");
		String subUrl = getValueFromProjectConfig("logoutUserURL");	
		return baseUrl + subUrl;
		}

}
