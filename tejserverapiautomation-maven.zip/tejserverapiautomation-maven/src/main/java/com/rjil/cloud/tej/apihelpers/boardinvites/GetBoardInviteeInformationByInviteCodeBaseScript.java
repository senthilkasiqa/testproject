/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boardinvites;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.notifications.NotificationsBaseScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 * 
 * Base class to test Get board and invitee information by invite code
 *
 */
public class GetBoardInviteeInformationByInviteCodeBaseScript extends BaseTestScript{

protected static final String apiName = "GetBoardInviteeInformationByInviteCode";

	
	public GetBoardInviteeInformationByInviteCodeBaseScript(){
		globalApiName=apiName;
	}

	protected String getBoardInviteeInformationByInviteCodeURL(String inviteCode) {
		String url= apiUrls.get("boardInviteUrl") + serverConfig.get("getBoardInviteeInformationByInviteCodeUrl").replace("{inviteCode}", inviteCode);
		return url;
	}
	
	protected ValidatableResponse triggerGetApiGetBoardInviteeMemberInformationByInviteCode(String inviteCode) {
		FrameworkLogger.logStep("triggerGetApiGetBoardInviteeMemberInformationByInviteCode:-> Start");

    	String strApiUrl=getBoardInviteeInformationByInviteCodeURL(inviteCode);
    	ValidatableResponse response=triggerGetApi(strApiUrl, headerMap);
		
    	FrameworkLogger.logStep("triggerGetApiGetBoardInviteeMemberInformationByInviteCode:-> End");
    	
        return response;

	}
	
	protected ValidatableResponse triggerGetApiGetBoardInviteeMemberInformationByInviteCode(String inviteCode,Map<String,String>headerMap1 ) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetBoardInviteeMemberInformationByInviteCode:-> Start");

    	String strApiUrl=getBoardInviteeInformationByInviteCodeURL(inviteCode);
		Map<String,String> headerMap = createHeader(headerMap1);
    	ValidatableResponse response=triggerGetApi(strApiUrl, headerMap);
		
    	FrameworkLogger.logStep("triggerGetApiGetBoardInviteeMemberInformationByInviteCode:-> End");
    	
        return response;

	}
	
	public static ValidatableResponse getBoardInviteeInformationByInvitationCodeServiceMethod(String inviteCode) {
		GetBoardInviteeInformationByInviteCodeBaseScript getBoardInviteeInformationByInviteCodeBaseScript = new GetBoardInviteeInformationByInviteCodeBaseScript();
		getBoardInviteeInformationByInviteCodeBaseScript.createHeader();
		return getBoardInviteeInformationByInviteCodeBaseScript.triggerGetApiGetBoardInviteeMemberInformationByInviteCode(inviteCode);
	}

	
	
	public static List<String> getListKeyValuesFromGetBoardInformationFromInviteCodeResponse(ValidatableResponse response,
			String key) {
		List<String> valueFromResponse = new ArrayList<String>();
		for(int i=0;i<response.extract().jsonPath().getList("boardMembers").size();i++){
			String indexValue = (String) response.extract().jsonPath().get("boardMembers[" + i + "]." + key);
			valueFromResponse.add(indexValue);
		}
		return valueFromResponse;
	}
}
