package com.rjil.cloud.tej.apihelpers.boardsharedservices;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class AccessBoardFileShareLinkBaseScript extends BaseTestScript{

	protected static final String apiName = "AccessBoardFileShareLink";

	protected AccessBoardFileShareLinkBaseScript() {
		globalApiName = apiName;
	}
	
	protected String accessBoardFileShareLinkUrl(String shareKey) {
		FrameworkLogger.logStep("accessBoardFileShareLinkUrl:-> Start");
		

		String url = apiUrls.get("boardUrl") + serverConfig.get("accessBoardFileShareLinkUrl").replace("{shareKey}", shareKey);
		FrameworkLogger.logStep("accessBoardFileShareLinkUrl: End");
		return url;
	}

	
	protected ValidatableResponse triggerAccessBoardFileShareLink(String shareKey) throws IOException {
		FrameworkLogger.logStep("triggerAccessBoardFileShareLink:-> Start");
		String strApiUrl = accessBoardFileShareLinkUrl(shareKey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerAccessBoardFileShareLink:-> End");
		return response;
	}

	protected ValidatableResponse triggerAccessBoardFileShareLink(String shareKey, Map<String, String> headerMap1)
			throws IOException {
		FrameworkLogger.logStep("triggerAccessBoardFileShareLink:-> Start");
		String strApiUrl = accessBoardFileShareLinkUrl(shareKey);
		Map<String, String> headerMap = createHeader(headerMap1);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerAccessBoardFileShareLink:-> End");
		return response;
	}

	
	public static ValidatableResponse accessBoardFileShareLinkService(String shareKey) {
		AccessBoardFileShareLinkBaseScript accessBoardFile = new AccessBoardFileShareLinkBaseScript();
		  Map<String,String> headerMap = accessBoardFile.createHeader();
		  String strApiUrl = accessBoardFile.accessBoardFileShareLinkUrl(shareKey);
		  ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		 // String commentKey=response.extract().path("comments["+index+"].commentKey");
		 // repositoryMap.put(RepositoryParameterEnum.COMMENTKEY.getValue(), commentKey);
		  return response;
		 }
		 
		 public static ValidatableResponse accessBoardFileShareLinkService(String shareKey, Map<String,String> deviceInfo) throws IOException {
		AccessBoardFileShareLinkBaseScript accessBoardFile = new AccessBoardFileShareLinkBaseScript();
		  Map<String,String> headerMap=accessBoardFile.createHeader(deviceInfo);
		  String strApiUrl = accessBoardFile.accessBoardFileShareLinkUrl(shareKey);
		  ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		  return response;
		 }
}
