package com.rjil.cloud.tej.apihelpers.calllogs;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.CallLogConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.RandomNumberGenerator;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class SyncBackupCallLogsBaseScript extends BaseTestScript{

	protected static final String apiName = "SyncBackupCallLogs";
	protected static String syncBackupCallLogsJsonBody;
	
	
	protected String getSyncBackupCallLogsURL()
	{
		FrameworkLogger.logStep("getSyncBackupCallLogsURL: Start");
		String url = apiUrls.get("callLogsBaseUrl")+ serverConfig.get("getsyncBackupCallLogsUrl");
		FrameworkLogger.logStep("getAsyncBackupCallLogsURL: End");
		return url;
	}

	
	
	protected String getSyncBackupCallLogsURL(String urlValue) {
		FrameworkLogger.logStep("getSyncBackupCallLogsURL: Start");
		String url = apiUrls.get("callLogsBaseUrl") + urlValue;
		FrameworkLogger.logStep("getSyncBackupCallLogsURL: End");
		return url;
	}
	

	protected String setSyncBackupCallLogsJsonBody() throws IOException{
		//String boardName = "Board___"+Utils.getUniqueId();
		// load json file
		String path = System.getProperty("user.dir") + "/resources/callLogsTestData/syncBackupCallLogsBody.js";
		File file = new File(path);
		syncBackupCallLogsJsonBody = JsonPath.parse(file).jsonString();
		return syncBackupCallLogsJsonBody;
	}

	protected String setSyncBackupCallLogsInvalidJsonBody() throws IOException{
		//String boardName = "Board___"+Utils.getUniqueId();
		// load json file
		String path = System.getProperty("user.dir") + "/resources/callLogsTestData/asyncBackupCallLogsInvalidBody.js";
		File file = new File(path);
		syncBackupCallLogsJsonBody = JsonPath.parse(file).jsonString();
		return syncBackupCallLogsJsonBody;
	}
	
	protected String setSyncBackupCallLogsValidInvalidJsonBody() throws IOException{
		//String boardName = "Board___"+Utils.getUniqueId();
		// load json file
		String path = System.getProperty("user.dir") + "/resources/callLogsTestData/asyncBackupCallLogsBodyForSomeValidAndSomeInvalid.js";
		File file = new File(path);
		syncBackupCallLogsJsonBody = JsonPath.parse(file).jsonString();
		return syncBackupCallLogsJsonBody;
	}

	
	
	protected ValidatableResponse triggerPostApiSyncBackupCallLogs() throws IOException {

		FrameworkLogger.logStep("triggerPostApiSyncBackupCallLogs: Start");

		// get url for create metadata for folder API
		String strApiUrl=getSyncBackupCallLogsURL();


		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, syncBackupCallLogsJsonBody);
		FrameworkLogger.logStep("triggerPostApiSyncBackupCallLogs:");

		return response;
	}
	
	protected ValidatableResponse triggerPostApiSyncBackupCallLogs( Map<String, String> headerMap) throws IOException {

		FrameworkLogger.logStep("triggerPostApiSyncBackupCallLogs: Start");

		// get url for create metadata for folder API
		String strApiUrl=getSyncBackupCallLogsURL();

		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, createHeader(headerMap), syncBackupCallLogsJsonBody);

		FrameworkLogger.logStep("triggerPostApiSyncBackupCallLogs");

		return response;
	}
	

	protected ValidatableResponse triggerPostApiSyncBackupCallLogs(String urlValue) throws IOException {

		FrameworkLogger.logStep("triggerPostApiSyncBackupCallLogs: Start");

		String strApiUrl=getSyncBackupCallLogsURL(urlValue);
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, syncBackupCallLogsJsonBody);

		FrameworkLogger.logStep("triggerPostApiSyncBackupCallLogs:-> ");

		return response;
	}
	

	public static ValidatableResponse syncBackupCallLogsServiceMethod(String dvcCallLogId, String date, String callLogType) throws IOException, VerificationFailException, ParseException {
		FrameworkLogger.logStep("syncBackupCallLogsServiceMethod: Start");
		
		SyncBackupCallLogsBaseScript syncBackup = new SyncBackupCallLogsBaseScript();
		syncBackup.createHeader();
		syncBackupCallLogsJsonBody = syncBackup.setSyncBackupCallLogsJsonBody();
		//Update the request body of async backup of call log
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getDvcCallLogId(0), dvcCallLogId, syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getDuration(0),36000 , syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getName(0), "Name"+dvcCallLogId, syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getPhoneNo(0),RandomNumberGenerator.getRandomPhoneNo() , syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getDateTime(0), AsyncBackupCallLogsBaseScript.getCallLogDateTime1(date), syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getType(0), callLogType, syncBackupCallLogsJsonBody);

	//	asyncBackupCallLogsJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = syncBackup.triggerPostApiSyncBackupCallLogs();
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Create Board Status");
		FrameworkLogger.logStep("syncBackupCallLogsServiceMethod: End");
		return response;
	}
	
	
	public static ValidatableResponse syncBackupCallLogsServiceMethod(Map<String, String> headerMap1, String dvcCallLogId, String date, String callLogType) throws IOException, VerificationFailException, ParseException {
		FrameworkLogger.logStep("syncBackupCallLogsServiceMethod: Start");
		
		SyncBackupCallLogsBaseScript syncBackup = new SyncBackupCallLogsBaseScript();
		syncBackup.createHeader(headerMap1);
		syncBackupCallLogsJsonBody = syncBackup.setSyncBackupCallLogsJsonBody();
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getDvcCallLogId(0), dvcCallLogId, syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getDuration(0),36000 , syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getName(0), "Name"+dvcCallLogId, syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getPhoneNo(0),RandomNumberGenerator.getRandomPhoneNo() , syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getDateTime(0), AsyncBackupCallLogsBaseScript.getCallLogDateTime1(date), syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getType(0), callLogType, syncBackupCallLogsJsonBody);

		ValidatableResponse response = syncBackup.triggerPostApiSyncBackupCallLogs(headerMap1);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Create Board Status");
		FrameworkLogger.logStep("syncBackupCallLogsServiceMethod: End");
		return response;
	}
	
    public static String getCallLogDateTime(String callLogDate) throws ParseException
    
       {
    	   SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss"); // Month.Day.Year

    	   Date d = formatter.parse(callLogDate);
    	   long timestamp = d.getTime();
    	   System.out.println("Date final date============="+timestamp);
		return timestamp+"";
    	   
       }
    
    
	public static ValidatableResponse syncBackupCallLogsServiceMethodForDifferenceDevices(String deviceKey, String deviceName, String dvcCallLogId, String date, String callLogType) throws IOException, VerificationFailException, ParseException {
		FrameworkLogger.logStep("syncBackupCallLogsServiceMethodForDifferenceDevices: Start");
		
		SyncBackupCallLogsBaseScript syncBackup = new SyncBackupCallLogsBaseScript();
		headerMap = syncBackup.createHeader();
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), deviceKey);
		headerMap.put(HeaderParameters.XDEVICENAME.getValue(), deviceName);
		syncBackupCallLogsJsonBody = syncBackup.setSyncBackupCallLogsJsonBody();
		//Update the request body of async backup of call log
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getDvcCallLogId(0), dvcCallLogId, syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getDuration(0),36000 , syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getName(0), "Name"+dvcCallLogId, syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getPhoneNo(0),RandomNumberGenerator.getRandomPhoneNo() , syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getDateTime(0), AsyncBackupCallLogsBaseScript.getCallLogDateTime1(date), syncBackupCallLogsJsonBody);
		syncBackupCallLogsJsonBody = syncBackup.setJsonData(CallLogConstants.getType(0), callLogType, syncBackupCallLogsJsonBody);

	//	asyncBackupCallLogsJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = syncBackup.triggerPostApiSyncBackupCallLogs();
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Create Board Status");
		FrameworkLogger.logStep("syncBackupCallLogsServiceMethodForDifferenceDevices: End");
		return response;
	}
	
}
