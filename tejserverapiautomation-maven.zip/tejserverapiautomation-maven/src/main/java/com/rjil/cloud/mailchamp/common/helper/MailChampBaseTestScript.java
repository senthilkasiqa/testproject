package com.rjil.cloud.mailchamp.common.helper;

import static com.jayway.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;
import org.testng.annotations.BeforeSuite;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.common.Base64;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;


public class MailChampBaseTestScript {

	private static Map<String, String> serverConfig; // values are coming from
														// ProjectConfi.properties
														// file
	private static Map<String, String> apiInfo; // values are coming from
												// config.properties
	private static String executionServer;

	private String userId = null;
	private String authToken = null;
	public static String authorizationType = "Basic ";


	@BeforeSuite(alwaysRun = true)
	public void preConfigSetUp() {
		System.out.println("preConfigSetUp - - START");
		serverConfig = Utils.getServerConfigMAP();

		System.out.println(serverConfig.get("environment"));
		executionServer = serverConfig != null ? serverConfig.get("environment") : null;

		apiInfo = Utils.getPropertyMAP(executionServer);
		// String userDir = System.getProperty("user.dir");
		System.out.println(apiInfo.get("Email"));
		String doLogin = getValueFromEnvConfig("doLogin");
//		if (!(this instanceof LoginUserBaseClass)) {
		if (doLogin.equalsIgnoreCase("No")){
			Map<String, String> tempConfig = Utils.getTempConfigPropertyMAP(executionServer);
			userId = tempConfig.get("mcsUserId");
			authToken = tempConfig.get("mcsAuthToken");
			FrameworkLogger.logStep("AUTHTOKEN:"+authToken);
			String token = Base64.b64encode(authToken);
			authToken = authorizationType.concat(token);
		}
		else { 
			defaultLogin();
			}
		System.out.println("preConfigSetUp - - END");
	}

	protected void defaultLogin() {
		System.out.println("defaultLogin - - START");
		LoginUserBaseClass obj = new LoginUserBaseClass();
		ValidatableResponse loginResponse = obj.triggerLoginApi();
		userId = loginResponse.extract().path("mcsUserId");
		authToken = loginResponse.extract().path("mcsAuthToken");
		// if this code do not work, then create a login method and put
		// triggelogin code in it and call that method here.
		System.out.println("defaultLogin - - END");
	}

	protected ValidatableResponse triggerPostApi(String UserPostAPI,
			Map<String, String> headerMap /* , String xEmailId */) {
		// Map<String, String> headerMap = createHeaderMap();
		ValidatableResponse response = given().headers(headerMap)
				// contentType(UserInit.GET_ContentType).header("X-Email-Id",
				// xEmailId)
				.log().all().when().post(UserPostAPI).then();
		response.log().all();

		return response;
	}

	protected ValidatableResponse triggerGetApi(String UserAutAPI,
			Map<String, String> headerMap /* String emailID */) {
		// Map<String, String> headerMap = createHeaderMap();

		ValidatableResponse response = given()
				// .contentType(UserInit.GET_ContentType).header("X-Email-Id",
				// emailID)
				.headers(headerMap).log().all().when().get(UserAutAPI).then();
		response.log().all();
		return response;
	}

	protected ValidatableResponse triggerDeleteApi(String UserDelAPI,
			Map<String, String> headerMap/* , String emailID */) {
		ValidatableResponse response = given().headers(headerMap).log().all().when().delete(UserDelAPI).then();
		response.log().all();
		return response;
	}
	
	
	protected ValidatableResponse triggerPutApi(String completeOperationAPI,
			Map<String, String> headerMap) {
		ValidatableResponse response = given().headers(headerMap).log().all().when().put(completeOperationAPI).then();
		response.log().all();
		return response;
	}

	protected Map<String, String> createHeaderMap() {
		System.out.println("create Header from Base");

		Map<String, String> headerMap = initializeHeaderMap();
		return headerMap;

	}
	/*
	 * protected Map<String, String> createHeaderMap(String emailID) {
	 * System.out.println("create Header from Base");
	 * 
	 * Map<String, String> headerMap = initializeHeaderMap(emailID); return
	 * headerMap;
	 * 
	 * }
	 */

	protected Map<String, String> initializeHeaderMap() {
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XAPIKEY.getValue(), getValueFromEnvConfig("xApiKey"));
		// headerMap.put(HeaderParameters.XEMAILID.getValue(), emailID);
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);

		return headerMap;

	}

	protected Map<String, String> initializeHeaderMapForLogin(String xCode) {
		Map<String, String> headerMap = new HashMap<String, String>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XCODE.getValue(), xCode);
		// headerMap.put(HeaderParameters.XCODE.getValue(),getValueFromEnvConfig("xcode"));

		return headerMap;

	}

	public String getValueFromEnvConfig(String key) {
		return (apiInfo.get(key));

	}

	public String getValueFromProjectConfig(String key) {
		return (serverConfig.get(key));

	}

}