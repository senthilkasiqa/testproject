/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.download;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 * 
 * Base class for Shared Bulk download base script
 *
 */
public class SharedBulkDownloadBaseScript extends BaseTestScript{

	 public static String sharedBulkDownloadJsonBody;
	    protected static final String apiName = "SharedBulkDownload";
//	    protected static Map<String, String> headerMap = null;
	    
	    public SharedBulkDownloadBaseScript(){
	    	globalApiName=apiName;
	    }
	    
	 // Overload the method.
		public  Map<String, String> createHeader() {
			FrameworkLogger.logStep("createHeader -> Start");

			headerMap = initializeHeader();

			// Remove from header for this API.
			headerMap.remove(HeaderParameters.XUSERID.getValue());
			headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());

			FrameworkLogger.logStep("createHeader -> End");
			return headerMap;
		}

	    public String getSharedBulkDownloadUrl(String url, String shareKey, String shardKey) {
	    //	FrameworkLogger.logStep("getBulkDownloadUrl: Start");
	     //   String apiUrl= apiUrls.get("baseURL") + serverConfig.get(url);
	        FrameworkLogger.logStep("getSharedBulkDownloadUrl: Start");
			String apiUrl2 = apiUrls.get("downloadPublicIp")
					+ serverConfig.get(url).replace("{shareKey}", shareKey);
			String sharedFileDownloadUrl = apiUrl2.replace("{shardKey}", shardKey);
			FrameworkLogger.logStep("sharedFileDownloadUrl=======>" + sharedFileDownloadUrl);
			FrameworkLogger.logStep("getSharedBulkDownloadUrl: End");
			return sharedFileDownloadUrl;
	   
	    }
	    
	    public String setSharedBulkDownloadJsonBody() throws IOException {
	        //load json file
	    	//createHeader();
	    	FrameworkLogger.logStep("setSharedBulkDownloadJsonBody: Start");
	        String path = System.getProperty("user.dir") + "/resources/downloadTestData/bulkDownloadBody.js";
	        File file = new File(path);
	        sharedBulkDownloadJsonBody = JsonPath.parse(file).jsonString();
	        FrameworkLogger.logStep("setSharedBulkDownloadJsonBody: End");
	       return sharedBulkDownloadJsonBody;
	    }
	    
	    public ValidatableResponse triggerPostApiSharedBulkDownloadApiResponse(String url, String shareKey, String shardKey) throws IOException {
	    	
	    	FrameworkLogger.logStep("triggerPostApiBulkDownloadApiResponse: Start");       
			String strApiUrl=getSharedBulkDownloadUrl(url, shareKey, shardKey);
			//Call method to trigger PUT API.
			ValidatableResponse response = triggerPostApi(strApiUrl,headerMap,sharedBulkDownloadJsonBody);
			
			String zipUrl=response.extract().path("zipUrl");
			repositoryMap.put(RepositoryParameterEnum.ZIPURL.getValue(), zipUrl);

			FrameworkLogger.logStep("triggerPostApiBulkDownloadApiResponse: End");
	    	return response;
	    }
	    
	   
	
}
