/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.usermanagement;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author Prateek
 * 
 * Base class for Get User Profile Api
 *
 */
public class GetUserProfileBaseScript extends BaseTestScript{

	protected static final String apiName = "GetUserProfileApi";
	
	public GetUserProfileBaseScript(){
		globalApiName=apiName;
	}

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Remove device key from header for this API.
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * 
	 * Method to get user profile pic url
	 * 
	 * URL=http://{envUrl}/security/users
	 * 
	 */
	protected String getUserProfileUrl(String url) {
		FrameworkLogger.logStep("getUserProfileUrl: Start");
		String getUserProfileUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		FrameworkLogger.logStep("getUserProfilePicUrl:" + url);
		FrameworkLogger.logStep("getUserProfileUrl: End");
		return getUserProfileUrl;

	}


	/**
	 * Method to get  user profile api Response
	 * 
	 * @return trashMetadata validatable response
	 */
	protected ValidatableResponse triggerGetApiGetUserProfile(String url) throws IOException {

		FrameworkLogger.logStep("triggerGetApiGetUserProfile: Start");

		String strApiUrl = getUserProfileUrl(url);
		// Call method to trigger PUT API.
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);

		FrameworkLogger.logStep("triggerGetApiGetUserProfile: End");

		return response;
	}
	
	
}
