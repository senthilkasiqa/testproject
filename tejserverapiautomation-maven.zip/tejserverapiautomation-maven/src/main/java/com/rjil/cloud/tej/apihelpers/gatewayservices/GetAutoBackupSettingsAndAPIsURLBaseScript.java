package com.rjil.cloud.tej.apihelpers.gatewayservices;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;


/**
 * @author c.singh1
 *
 */
public class GetAutoBackupSettingsAndAPIsURLBaseScript extends BaseTestScript {
    
    protected static final String apiName="GetAutoBackupSettings";
    
    public GetAutoBackupSettingsAndAPIsURLBaseScript(){
    	globalApiName=apiName;
    }
    
 // Overload the method.
 	protected Map<String, String> createHeader() {
 		FrameworkLogger.logStep("createHeader -> Start");

 		headerMap = initializeHeader();

 		// Remove device key from header for this API.
 		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
 		headerMap.remove(HeaderParameters.XAPIKEY.getValue());

 		FrameworkLogger.logStep("createHeader -> End");
 		return headerMap;
 	}

    /**get a complete url for 'Get auto backup settings and APIs URL API'
     * @return
     */
    protected String getAutoBackupSettingsAndAPIsURL() {

        FrameworkLogger.logStep("getAutoBackupSettingsAndAPIsURL:-> Start");

//        return apiUrls.get("baseURL") + apiUrls.get("cabURL");

        String result = apiUrls.get("publicBaseURL") + serverConfig.get("getAutoBackupSettingsAndAPIsURL");

        FrameworkLogger.logStep("getAutoBackupSettingsAndAPIsURL:-> Start");

        return result;


    }
    

   /**
    * Method to get response for Get Auto Backup Settings And APIs URL Api.
    * @return ValidatableResponse
    * @throws IOException
    */
  public  ValidatableResponse getAutoBackupSettingsAndAPIsURLAPIResponse(String strOSName) throws IOException {
      FrameworkLogger.logStep("getAutoBackupSettingsAndAPIsURLAPIResponse:-> Start");

      ValidatableResponse response = given().queryParam("os", strOSName).log().all()
             .headers(headerMap).log().all()
              .when().get(getAutoBackupSettingsAndAPIsURL())
              .then();
      response.log().all();
      Utils.addRequestResponseToLogger();

      FrameworkLogger.logStep("getAutoBackupSettingsAndAPIsURLAPIResponse:-> End");

      return response;
   }
   
  
  
  /**
   * Method to get response for Get Auto Backup Settings And APIs URL Api.
   * @return ValidatableResponse
   * @throws IOException
   */
 public  ValidatableResponse getAutoBackupSettingsAndAPIsURLAPIResponseWithoutOsParam() throws IOException {
     FrameworkLogger.logStep("getAutoBackupSettingsAndAPIsURLAPIResponse:-> Start");

/*     ValidatableResponse response = given().log().all()
//             .headers(headerMap).log().all()
             .when().get(getAutoBackupSettingsAndAPIsURL())
             .then();
     response.log().all();
     Utils.addRequestResponseToLogger();
*/
     
     ValidatableResponse response = triggerGetApi(getAutoBackupSettingsAndAPIsURL());

     FrameworkLogger.logStep("getAutoBackupSettingsAndAPIsURLAPIResponse:-> End");

     return response;
  }

}
