/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.fileupload;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.UploadConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.nms.CreateFolderBaseScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 *
 */
public class AutoUploadBaseScript extends BaseTestScript{

	protected String uploadJSONBody;
	protected String fileName = null;
	protected static final String apiName = "AutoUpload";
	// protected Map<String,String>headerMap = null;
	static String filePath;
	// = System.getProperty("user.dir") + "/resources/uploadTestData/"+fileName;
	static File file;
	// new File(filePath);
	
	public AutoUploadBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to get the file name
	 * 
	 */
	protected void getFileName(String fileName) {
		FrameworkLogger.logStep("getFileName: Start");
		// filePath=System.getProperty("user.dir") +
		// "/resources/uploadTestData/download.jpg";
		filePath = System.getProperty("user.dir") + "/resources/uploadTestData/" + fileName;
		file = new File(filePath);
		FrameworkLogger.logStep("getFileName: End");
	}

	/**
	 * @author Prateek 
	 * Method to get Upload URL for Fie upload
	 * @return url
	 */
	protected String getAutoUploadUrl() {

		FrameworkLogger.logStep("getAutoUploadUrl: Start");
		/**
		 * The SIT url for upload is different compared to other environments
		 * So, we need to add this check
		 */
		/*
		 * if(Objects.equals(executionServer, "SIT")) { return
		 * serverConfig.get("uploadURL");
		 * 
		 * }
		 */
//		String uploadUrl = apiUrls.get("uploadIp") + serverConfig.get("uploadUrl");
		String uploadUrl = getAutoUploadUrl("autoUploadUrl");

		FrameworkLogger.logStep("UploadUrl=========>" + uploadUrl);
		FrameworkLogger.logStep("getAutoUploadUrl: End");
		return uploadUrl;

	}
	
	protected String getAutoUploadUrl(String url) {

		FrameworkLogger.logStep("getAutoUploadUrl: Start");
		/**
		 * The SIT url for upload is different compared to other environments
		 * So, we need to add this check
		 */
		/*
		 * if(Objects.equals(executionServer, "SIT")) { return
		 * serverConfig.get("uploadURL");
		 * 
		 * }
		 */
		String uploadUrl = apiUrls.get("autoUploadIp") + serverConfig.get(url);
		FrameworkLogger.logStep("UploadUrl=========>" + uploadUrl);
		FrameworkLogger.logStep("getAutoUploadUrl: End");
		return uploadUrl;

	}

	/*
	 * protected void createHeader(){ FrameworkLogger.logStep(
	 * "createHeader: Start"); headerMap = new HashMap<>();
	 * headerMap.put("Content-Type", "multipart/related;boundary=*****");
	 * headerMap.put(UploadParameters.XUSERID.getValue(), userId);
	 * headerMap.put(UploadParameters.XDEVICEKEY.getValue(),
	 * serverConfig.get("deviceKey"));
	 * headerMap.put(UploadParameters.AUTHORIZATION.getValue(), accessToken);
	 * 
	 * //Add 'X-Api-Key' in header for the API. addXapiHeaderKey(headerMap);
	 * FrameworkLogger.logStep("createHeader: End");
	 * 
	 * }
	 */
	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		headerMap.put("Content-Type", "multipart/related;boundary=*****");

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * Method to set file upload Json Body
	 * 
	 * @throws IOException
	 */
	protected String setAutoUploadJsonBody(String fileName) throws IOException {
		FrameworkLogger.logStep("setAutoUploadJsonBody: Start");
		FrameworkLogger.logStep("FilePATH==============>" + filePath);
		Utils.fileCheckSum(filePath);
	//	String path = System.getProperty("user.dir") + "/resources/uploadTestData/uploadFileBody.js";
	//	String path = System.getProperty("user.dir") + "/resources/uploadTestData/entireFileUploadBody.js";
		String path = System.getProperty("user.dir") + "/resources/uploadTestData/entireFileUploadBody.js";
		
		File file = new File(path);
		uploadJSONBody = JsonPath.parse(file).jsonString();
		uploadJSONBody=setJsonData(UploadConstants.getName(), fileName, uploadJSONBody);
		uploadJSONBody = setJsonData(UploadConstants.getSize(), Utils.getLen(), uploadJSONBody);
		uploadJSONBody = setJsonData(UploadConstants.getHash(), Utils.getOutput(), uploadJSONBody);
		
		if (CreateFolderBaseScript.folderKey != null) {
			uploadJSONBody = JsonPath.parse(uploadJSONBody)
					.put("@", "folderKey", repositoryMap.get(RepositoryParameterEnum.FOLDEROBJECTKEY.getValue()))
					.jsonString();
		}
		FrameworkLogger.logStep("setUploadJsonBody:"+uploadJSONBody);
		FrameworkLogger.logStep("setAutoUploadJsonBody: End");
		return uploadJSONBody;
	}

	/**
	 * Method to get Upload Response
	 *
	 * @return Upload response
	 */
	protected ValidatableResponse getAutoUploadFileResponse() throws IOException {

		FrameworkLogger.logStep("getUploadFileResponse: Start");
		FrameworkLogger.logStep("Upload request="+uploadJSONBody);
		//setUploadJsonBody();
		ValidatableResponse response = given().multiPart("metadata", uploadJSONBody, "application/json").multiPart(file)
				.headers(headerMap).log().all().when().post(getAutoUploadUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();

		FrameworkLogger.logStep("Setting ObjectKey...");

		/**
		 * This object key derived when a file is uploaded is used in other
		 * tests(Board related). If the file is successfully uploaded, then
		 * valid object key is put into the Repository map and is available for
		 * other tests to retrieve this object key from the respositoryMap If
		 * the file fails to get uploaded, then this object key will have null
		 * value and corresponding tests related to Boards would fail as the
		 * object key used in those tests would be passed as null
		 *
		 */
		String strObjectKey = response.extract().path("objectKey");
		FrameworkLogger.logStep("Upload Object Key========>>" + strObjectKey);
		repositoryMap.put(RepositoryParameterEnum.OBJECTKEY.getValue(), strObjectKey);

		FrameworkLogger.logStep("getUploadFileResponse: End");
		return response;
	}
	
	/**
	 * Method to get Upload Response
	 *
	 * @return Upload response
	 */
	protected ValidatableResponse getAutoUploadFileResponse(String url) throws IOException {

		FrameworkLogger.logStep("getAutoUploadFileResponse: Start");
		//setUploadJsonBody();
		ValidatableResponse response = given().multiPart("metadata", uploadJSONBody, "application/json").multiPart(file)
				.headers(headerMap).log().all().when().post(getAutoUploadUrl(url)).then();
		response.log().all();
		Utils.addRequestResponseToLogger();

		FrameworkLogger.logStep("Setting ObjectKey...");

		/**
		 * This object key derived when a file is uploaded is used in other
		 * tests(Board related). If the file is successfully uploaded, then
		 * valid object key is put into the Repository map and is available for
		 * other tests to retrieve this object key from the respositoryMap If
		 * the file fails to get uploaded, then this object key will have null
		 * value and corresponding tests related to Boards would fail as the
		 * object key used in those tests would be passed as null
		 *
		 */

		FrameworkLogger.logStep("getAutoUploadFileResponse: End");
		return response;
	}
	
	
	/**
	 * 
	 * Service Method for Upload File
	 * 
	 * @param fileName
	 * @throws IOException
	 * @throws VerificationFailException
	 * @throws InterruptedException 
	 */

	public static void getAutoUploadFileServiceMethod(String fileName) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getUploadFileServiceMethod: Start");
		AutoUploadBaseScript apiObject = new AutoUploadBaseScript();
		// fileName="Sample.aac";

		FrameworkLogger.logStep("FileName========>" + fileName);
		apiObject.getFileName(fileName);

		// Create header parameters needed for upload api request
		apiObject.createHeader();
		apiObject.setAutoUploadJsonBody(fileName);
		ValidatableResponse response = apiObject.getAutoUploadFileResponse();
	
		FrameworkLogger.logStep("getUploadFileServiceMethod: End");
		
	}
}
