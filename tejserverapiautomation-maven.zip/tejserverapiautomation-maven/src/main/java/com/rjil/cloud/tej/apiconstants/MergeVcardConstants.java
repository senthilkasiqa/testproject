package com.rjil.cloud.tej.apiconstants;

/**
 * MergeVcard API, JSON path Constants
 * 
 */

public class MergeVcardConstants {

    public static String getMasterIdJsonPath() {
        return "$.masterId";
    }

    public static String getDupContIdsJsonPath() {
        return "$.dupContIds";
    }
}
