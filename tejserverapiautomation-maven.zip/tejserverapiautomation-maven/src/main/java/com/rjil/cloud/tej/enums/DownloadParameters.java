/**
 * 
 */
package com.rjil.cloud.tej.enums;

/**
 * Created By Prateek on 9/8/2016
 *
 */
public enum DownloadParameters {

	    XUSERID("X-User-Id"),
	    AUTHORIZATION("Authorization");

	    public String value;

	    DownloadParameters(String value) {
	        this.value = value;

	    }

	    public String getValue() {
	        return value;
	    }
	}
	

