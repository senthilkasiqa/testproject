package com.rjil.cloud.tej.common;

import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;

import java.io.*;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.TimeZone;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.eclipse.emf.ecore.resource.impl.CryptoCipherImpl;

/**
 * Utils Class for util methods
 */
public class Utils {

	private static String input;
	private static String output;
	private static long len;
	private static String filePath;
	private static File file;

	/**
	 * Method to get Property from file
	 *
	 * @param file
	 *            Property file
	 * @param key
	 *            Property value
	 * @return: Property value
	 */
	public static String getProperty(String file, String key) {

		try {
			file = System.getProperty("user.dir") + "/resources/" + file;
			File config = new File(file);
			FileInputStream input;
			input = new FileInputStream(config.getAbsolutePath());
			Properties prop = new Properties();
			prop.load(input);
			String value = prop.getProperty(key);
			input.close();
			return value;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Method to get Properties Map
	 *
	 * @param server
	 *            Execution Server
	 * @return Property Map
	 */
	public static Map<String, String> getPropertyMAP(String server) {

		try {
			String path = System.getProperty("user.dir") + "/resources/serverURL/" + server + "/config.properties";
			File config = new File(path);
			FileInputStream input;
			input = new FileInputStream(config.getAbsolutePath());
			Properties prop = new Properties();
			prop.load(input);
			Map<String, String> properties = new HashMap<>();
			for (Object key : prop.keySet()) {
				properties.put(key.toString(), prop.getProperty(key.toString()));
			}
			input.close();
			return properties;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Method to get Properties Map from property file
	 *
	 * @return : Property Map
	 */
	public static Map<String, String> getServerConfigMAP() {

		try {
			String path = System.getProperty("user.dir") + "/resources/ProjectConfig.properties";
			File config = new File(path);
			FileInputStream input;
			input = new FileInputStream(config.getAbsolutePath());
			Properties prop = new Properties();
			prop.load(input);
			Map<String, String> properties = new HashMap<>();
			for (Object key : prop.keySet()) {
				properties.put(key.toString(), prop.getProperty(key.toString()));
			}
			input.close();
			return properties;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Method to add request Response to Log file
	 */
	public static void addRequestResponseToLogger() {
		//FrameworkLogger.logStep(getRestAssuredRequestResponse().trim());
		// cleanFile();
	}

	/**
	 * Method to get Restassured Request Response from file
	 *
	 * @return file data in string
	 */
	public static String getRestAssuredRequestResponse() {
		File logFile = new File("./tempLog.txt");
		BufferedReader br = null;
		String allString = "";
		if (logFile.exists()) {
			try {
				String sCurrentLine;
				br = new BufferedReader(new FileReader("./tempLog.txt"));

				while ((sCurrentLine = br.readLine()) != null) {
					allString = allString + sCurrentLine;
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (br != null)
						br.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}

		return allString;

	}

	/**
	 * Method to clear temporary log file
	 */
	public static void cleanFile() {
		File file = new File("./tmp.txt");
		file.delete();
	}

	/**
	 * @author Prateek Method to set pseudo ranodm number
	 */
	public static int setRandomValue(int max, int min) {
		return (int) (Math.random() * ((max - min) + 1)) + min;
	}

	/**
	 * @author Prateek Method to get checksum of file
	 */

	public static void fileCheckSum(String fileInput) {

		// fileInput = System.getProperty("user.dir") +
		// "/resources/uploadTestData/download.jpg";
		InputStream input = null;
		byte[] mdbytes = null;
		try {
			input = new FileInputStream(fileInput);
			long length = ((FileInputStream) input).getChannel().size();
			System.out.println(length);
			setLen(length);
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] dataBytes = new byte[1024];
			int nread;
			int totalRead = 0;
			while ((nread = input.read(dataBytes)) != -1) {
				md.update(dataBytes, 0, nread);
				totalRead += nread;
				if (totalRead >= length) {
					break;
				}
			}
			mdbytes = md.digest();
			input.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (NoSuchAlgorithmException ex) {
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		System.out.println(String.format("%032x", new BigInteger(1, mdbytes)));
		setOutput(String.format("%032x", new BigInteger(1, mdbytes)));

	}

	public static String getInput() {
		return input;
	}

	public static void setInput(String input) {
		Utils.input = input;
	}

	public static String getOutput() {
		return output;
	}

	public static void setOutput(String output) {
		Utils.output = output;
	}

	public static long getLen() {
		return len;
	}

	public static void setLen(long length) {
		Utils.len = length;
	}

	/**
	 * @author c.singh1 Method to get the current date time
	 */
	public static String getTime() {
		Date currDate = new Date();
		SimpleDateFormat frm = new SimpleDateFormat("YYYY-MM-dd hh:mm:ss.SSSSSS");
		return frm.format(currDate);
	}

	/**
	 * @author c.singh1 Method to get the current date time
	 */
	public static String getTime(String format) {
		Date currDate = new Date();
		SimpleDateFormat frm = new SimpleDateFormat(format);
		return frm.format(currDate);
	}

	/**
	 * @author c.singh1 Method to get current date time by adding/subtracting
	 *         the specified days.
	 */
	public static String getTime(int dd) {
		DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd hh:mm:ss.SSSSSS");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DATE, dd);
		return (dateFormat.format(cal.getTime()));
	}

	/**
	 * @author c.singh1 Method to get midnight time by adding/subtracting the
	 *         specified days.
	 */
	public static String getMidnightTime(int dd) {
		DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd hh:mm:ss.SSSSSS");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.set(Calendar.HOUR, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.add(Calendar.DATE, dd);
		return (dateFormat.format(cal.getTime()));
	}

	/**
	 * @author c.singh1 Method to get a unique number through current time.
	 */
	public static String getUniqueValue() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Date currDate = new Date();
		SimpleDateFormat frm = new SimpleDateFormat("YYMMddhhmmss");
		String uniqueID = frm.format(currDate);
		return uniqueID;
	}

	/**
	 * @author c.singh1 Method to get a unique Phone number through current
	 *         time.
	 */
	public static String getUniquePhoneNumber() {
		BaseTestScript.waitForTime(1);
		Date currDate = new Date();
		SimpleDateFormat frm = new SimpleDateFormat("YYMMddhhmmss");
		String uniqueValue = frm.format(currDate);
		String strPhone = uniqueValue.substring(0, 2) + "-" + uniqueValue.substring(2, 5) + "-"
				+ uniqueValue.substring(5, 8) + "-" + uniqueValue.substring(8);
		return strPhone;
	}

	/**
	 * @author c.singh1 Method to get a random number between given two boundary
	 *         limit.
	 */
	public static int getRandomNumber(int min, int max) {
		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}

	/**
	 * 
	 * @author Prateek Method to get time in minutes prior the current time
	 *
	 * @return Long Time
	 */
	public static Long getTimePriorCurrentTime(int intMinutes) {

		Long t = System.currentTimeMillis();
		t = (t - (60 * 10000 * intMinutes));
		return t;
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to get the file name
	 * 
	 */
	public static File getFileName(String fileName) {
		// filePath=System.getProperty("user.dir") +
		// "/resources/uploadTestData/download.jpg";
		filePath = System.getProperty("user.dir") + "/resources/uploadTestData/" + fileName;
		file = new File(filePath);
		return file;

	}

	public static String getUniqueId() {
		try {
			Thread.sleep(1);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}

		Date ndate = new Date();
		/*
		 * SimpleDateFormat date = new SimpleDateFormat("YYYYMMDDhhmmss");
		 * date.setTimeZone(TimeZone.getTimeZone("GMT")); String uniqueID =
		 * date.format(ndate);
		 */

		SimpleDateFormat nft1 = new SimpleDateFormat("YYYYMMDDhhmmssS");
		nft1.setTimeZone(TimeZone.getTimeZone("GMT"));
		String uniqueID = nft1.format(ndate);
		try {
			Thread.sleep(1);
		} catch (Exception e) {
			System.out.println("Thread interruption exception");
		}
		System.out.println(uniqueID);
		return uniqueID;
	}

	public static int getUniqueIntegerId() {
		try {
			Thread.sleep(1);
		} catch (Exception e) {
			System.out.println("Thread interruption exception");
		}
		int uniqueIntegerId = (int) (System.currentTimeMillis() & 0xfffffff);
		return uniqueIntegerId;
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to encrypt password
	 */

	public static String encryptPassword(String password) {
		{
			AesUtil aes = new AesUtil(128, 10000);
			String enCryptSalt = AesUtil.random(128 / 4);

			String encryptedPasswordForWeb = enCryptSalt
					+ aes.encrypt(enCryptSalt, "F27D5C9927726BCEFE7510B1BDD3D137", "cyberSecurityHighAlert", password);
			// String b= aes.decrypt(salt, iv, passphrase, ciphertext)

			// String b = aes.decrypt(enCryptSalt,
			// "F27D5C9927726BCEFE7510B1BDD3D137", "cyberSecurityHighAlert", a);
			FrameworkLogger.logStep("ENCRYPTEDPASSWORD:" + encryptedPasswordForWeb);
			return encryptedPasswordForWeb;
		}
	}

	/**
	 * @author Prateek
	 * 
	 *         Method to call Aws cloud watch listener
	 * 
	 */

	public static void triggerAwsCloudWatchAgent(String apiName, int status) {
		FrameworkLogger.logStep("triggerAwsCloudWatchAgent: Start");
		FrameworkLogger.logStep("/Users/jenkins/Downloads/tejcwmon/bin/tj_cw_api.sh -n JC_API -d API=" + apiName
				+ " -m api_status -a " + status + "");
		try {
			Process p = Runtime.getRuntime().exec("/Users/jenkins/Downloads/tejcwmon/bin/tj_cw_api.sh -n JC_API -d API="
					+ apiName + " -m api_status -a " + status + "");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FrameworkLogger.logStep("triggerAwsCloudWatchAgent: End");
	}

	public static long getFileSize(String fileName) throws IOException {
		InputStream input = null;
		byte[] mdbytes = null;

		input = new FileInputStream(Utils.getFileName(fileName));
		long length = ((FileInputStream) input).getChannel().size();
		// System.out.println(length);
		return length;
	}

	// Keep in Utils.java file
	public static void saveProperties(File file, Properties p) throws IOException {
		FileOutputStream fr = new FileOutputStream(file);
		p.store(fr, "Properties");
		fr.close();
		System.out.println("saving properties");
	}

	public static void savePropertiesTempConfig(String server, Properties p) throws IOException {
		String path = System.getProperty("user.dir") + "/resources/serverInfo/" + server + "/tempConfig.properties";
		File file = new File(path);
		saveProperties(file, p);
	}

	public static Map<String, String> getTempConfigPropertyMAP(String server) {

		try {
			String path = System.getProperty("user.dir") + "/resources/serverURL/" + server + "/tempConfig.properties";
			File config = new File(path);
			FileInputStream input;
			input = new FileInputStream(config.getAbsolutePath());
			Properties prop = new Properties();
			prop.load(input);
			Map<String, String> properties = new HashMap<String, String>();
			for (Object key : prop.keySet()) {
				properties.put(key.toString(), prop.getProperty(key.toString()));
			}
			input.close();
			return properties;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
