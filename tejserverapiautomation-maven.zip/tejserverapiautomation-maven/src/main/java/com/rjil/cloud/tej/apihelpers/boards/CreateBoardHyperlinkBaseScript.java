package com.rjil.cloud.tej.apihelpers.boards;

import java.io.File;
import java.io.IOException;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class CreateBoardHyperlinkBaseScript extends BaseTestScript{
	
	protected static final String apiName = "CreateBoardHyperlinkApi";
//	String boardHyperlinkJsonBody=null;
	protected String boardHyperlinkJsonBody;
	String boardKey=null;
	
	protected String getCreateBoardHyperlinkURL(String boardKey) {
		FrameworkLogger.logStep("getCreateBoardHyperlinkURL: Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get("createBoardHyperlinkUrl").replace("{boardKey}", boardKey);
		FrameworkLogger.logStep("getCreateBoardHyperlinkURL: End");
		return url;
	}
	
	protected String getCreateBoardHyperlinkURL(String urlValue, String boardKey) {
		FrameworkLogger.logStep("getCreateBoardHyperlinkURL: Start");
		String url = (apiUrls.get("boardUrl") + urlValue);
		FrameworkLogger.logStep("getCreateBoardHyperlinkURL: End");
		return url;
	}
	

	protected String setCreateBoardHyperlinkJsonBody(String hyperlink) throws IOException{
		
		// load json file
		String path = System.getProperty("user.dir") + "/resources/newBoardTestData/createBoardHyperlink.js";
		File file = new File(path);
	    boardHyperlinkJsonBody = JsonPath.parse(file).jsonString();
	    boardHyperlinkJsonBody = setJsonData(NewBoardConstants.getHyperlink(), hyperlink, boardHyperlinkJsonBody);
		return boardHyperlinkJsonBody;
	}

	
	protected ValidatableResponse triggerPostApiCreateBoardHyperlink(String boardKey) throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreateBoardHyperlink: Start");
		System.out.println("BoardBoay====+==========================="+boardHyperlinkJsonBody);
		// get url for create metadata for folder API
		String strApiUrl=getCreateBoardHyperlinkURL(boardKey);

		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, boardHyperlinkJsonBody);

		String hyperlinkObjectKey = response.extract().path("objectKey");
		repositoryMap.put(RepositoryParameterEnum.HYPERLINKOBJECTKEY.getValue(), hyperlinkObjectKey);

		FrameworkLogger.logStep("triggerPostApiCreateBoardHyperlink: hyperlinkObjectKey== :-> "+ hyperlinkObjectKey);

		return response;
	}
	

	protected ValidatableResponse triggerPostApiCreateBoardHyperlink(String urlValue, String boardKey ) throws IOException {

		FrameworkLogger.logStep("triggerPostApiCreateBoardHyperlink: Start");

		// get url for create metadata for folder API
		String strApiUrl=getCreateBoardHyperlinkURL(urlValue, boardKey);

		// get response from create a Folder API
		ValidatableResponse response=triggerPostApi(strApiUrl, headerMap, boardHyperlinkJsonBody);

		return response;
	}
	
	public static ValidatableResponse createBoardHyperlinkServiceMethod(String hyperlink, String boardKey) throws IOException {
		FrameworkLogger.logStep("createBoardHyperlinkServiceMethod: Start");
		
		CreateBoardHyperlinkBaseScript hyperlinkBaseScript = new CreateBoardHyperlinkBaseScript();
		hyperlinkBaseScript.createHeader();
		String boardHyperlinkJsonBody = hyperlinkBaseScript.setCreateBoardHyperlinkJsonBody(hyperlink);
		//boardHyperlinkJsonBody = hyperlinkBaseScript.setJsonData(NewBoardConstants.getHyperlink(), hyperlink, boardHyperlinkJsonBody);
		ValidatableResponse response = hyperlinkBaseScript.triggerPostApiCreateBoardHyperlink(boardKey);
		FrameworkLogger.logStep("createBoardHyperlinkServiceMethod: End");
		String hyperlinkObjectKey = response.extract().path("objectKey");
		FrameworkLogger.logStep("HYPERLINK OBJECT===================================="+hyperlinkObjectKey);
		repositoryMap.put(RepositoryParameterEnum.HYPERLINKOBJECTKEY.getValue(), hyperlinkObjectKey);
		return response;
	}
}
