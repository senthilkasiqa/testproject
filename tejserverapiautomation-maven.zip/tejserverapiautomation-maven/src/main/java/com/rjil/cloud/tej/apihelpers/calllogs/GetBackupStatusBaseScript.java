package com.rjil.cloud.tej.apihelpers.calllogs;

import java.io.IOException;
import java.text.ParseException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.CallLogConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.RandomNumberGenerator;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class GetBackupStatusBaseScript extends BaseTestScript{

	 protected static final String apiName="GetBackupStatus";
	    /**
	     * @author Sanjeevanee Kanase
	     * <p>
	     * It creates the url for API 
	     */
	    private String getBackupStatusForCallLogsUrl() {
			FrameworkLogger.logStep("getBackupStatusForCallLogsUrl:-> Start");

			String apiUrl=apiUrls.get("callLogsBaseUrl") + serverConfig.get("getBackupStatusForCallLogsUrl");
			FrameworkLogger.logStep("getBackupStatusForCallLogsUrl:-> End");
			return apiUrl;
	    }
	    
	    /**
	     * @return validatable response for getBackupStatus api
	     * @author 
	     * <p>
	     * Call the API and return the Response
	     */
	    
	    protected ValidatableResponse triggerGetApigetBackupStatusForCallLogs() {
			FrameworkLogger.logStep("triggerGetApigetBackupStatusForCallLogs:-> Start");
	        // setContactBackupJsonBody();
			
			String strApiUrl=getBackupStatusForCallLogsUrl();
			
			//Call method to trigger GET API.
			ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
			
			FrameworkLogger.logStep("triggerGetApigetBackupStatusForCallLogs:-> End");
			return response;
	    }
	    
	    public static ValidatableResponse getBackupStatusForCallLogsServiceMethod(String lastBackupTimeFromAsyncBackup) throws IOException, VerificationFailException, ParseException {
			FrameworkLogger.logStep("getBackupStatusForCallLogsServiceMethod: Start");
			
			GetBackupStatusBaseScript getBackupStatus= new GetBackupStatusBaseScript();
			getBackupStatus.createHeader();
			getBackupStatus.headerMap.put(HeaderParameters.XLastBackupTime.getValue(), lastBackupTimeFromAsyncBackup);
			ValidatableResponse response = getBackupStatus.triggerGetApigetBackupStatusForCallLogs();
			int statusCode = response.extract().statusCode();
			Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Create Board Status");
			FrameworkLogger.logStep("getBackupStatusForCallLogsServiceMethod: End");
			return response;
		}
		
	    
		public static ValidatableResponse getBackupStatusForCallLogsServiceMethod(Map<String, String> headerMap1, String lastBackupTimeFromAsyncBackup) throws IOException, VerificationFailException, ParseException {
			FrameworkLogger.logStep("getBackupStatusForCallLogsServiceMethod: Start");
			
			GetBackupStatusBaseScript getBackupStatus= new GetBackupStatusBaseScript();
			getBackupStatus.createHeader(headerMap1);
			getBackupStatus.headerMap.put(HeaderParameters.XLastBackupTime.getValue(), lastBackupTimeFromAsyncBackup);
			ValidatableResponse response = getBackupStatus.triggerGetApigetBackupStatusForCallLogs();
			int statusCode = response.extract().statusCode();
			Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Create Board Status");
			FrameworkLogger.logStep("getBackupStatusForCallLogsServiceMethod: End");
			return response;
		}
}
