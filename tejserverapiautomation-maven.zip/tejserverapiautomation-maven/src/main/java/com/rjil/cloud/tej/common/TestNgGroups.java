package com.rjil.cloud.tej.common;

/**
 * @author: Chandra
 * 
 * TestNG Groups Class
 * This is for all TestNG tests.
 */

public class TestNgGroups {
	
	public static final String MONITORING_SANITY="Sanity";
	public static final String REGRESSION="Regression";
	public static final String CONTACTS="Contacts";
	public static final String MESSAGES="Messages";
	public static final String NOTIFICATIONS="Notifications";
	public static final String GATEWAY = "Gateway";
	public static final String BOARDS = "Boards";
	public static final String NMSSERVICES = "NMS";
	public static final String UPLOAD = "Upload";
	public static final String USERMANAGEMENT = "UserManagement";
	public static final String OTHERS = "Others";
	public static final String INVITATIONSERVICES = "Invitation";
	public static final String DOWNLOAD = "Download";
	public static final String STREAMING="Streaming"; 
	public static final String SHAREDSERVICES="Shared Service";
	public static final String AMIKOBACKUP="Amiko Backup";
	public static final String AMIKOCAB="Amiko Cab";
	public static final String AMIKODEDUPELISTNER="Amiko Dedupelistener";
	public static final String AMIKOMERGE="Amiko Merge";
	public static final String AMIKORESTORE="Amiko Restore";
	public static final String DOCUMENTCONVERSION="Document Conversion";

	public static final String BOARDCOMMENTS="BOARDCOMMENTS";
	public static final String AMIKOFEATUREPHONEBACKUPCONTACTS="Feature phone backup contacts";
	public static final String LOADTEST="LT Sanity Testing";
	public static final String DEPLOYMENTSANITY = "Sanity Testing";
	public static final String CALLLOGS = "Calllogs";
	public static final String QASANITY = "QASanity";

}

