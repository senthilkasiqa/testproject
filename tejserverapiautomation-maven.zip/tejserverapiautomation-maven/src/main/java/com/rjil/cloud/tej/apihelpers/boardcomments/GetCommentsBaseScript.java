/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boardcomments;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 *
 *	Base class for Get comments base script api
 */
public class GetCommentsBaseScript extends BaseTestScript{

	protected static final String apiName = "GetComments";

	protected GetCommentsBaseScript() {
		globalApiName = apiName;
	}
	
	protected Map<String, String> createHeader(String limit,String ifModifiedSince) {
		headerMap = initializeHeader();
	//	headerMap.put(HeaderParameters.XSHARDKEY.getValue(), shardKey);
		headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), ifModifiedSince);
		headerMap.put(HeaderParameters.LIMIT.getValue(), limit);
		return headerMap;
	}
	
	protected Map<String, String> createHeader(String limit) {
		headerMap = initializeHeader();
	//	headerMap.put(HeaderParameters.XSHARDKEY.getValue(), shardKey);
	//	headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), ifModifiedSince);
		headerMap.put(HeaderParameters.LIMIT.getValue(), limit);
		return headerMap;
	}

	protected String getCommentsUrl( String urlValue,String boardKey) {
		FrameworkLogger.logStep(" getCommentsUrl:-> Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get(urlValue).replace("{boardKey}", boardKey);
		FrameworkLogger.logStep("getCommentsUrl: End");
		return url;
	}

	/*protected String getCommentsUrl(String urlValue, String boardKey) {
		FrameworkLogger.logStep("getCommentsUrl: Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get(urlValue);
		FrameworkLogger.logStep("getCommentsUrl: End");
		return url;
	}*/

	protected ValidatableResponse triggerGetApiGetComments(String boardKey) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetComments:-> Start");
		String strApiUrl = getCommentsUrl("getCommentUrl", boardKey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetComments:-> End");
		return response;
	}

	protected ValidatableResponse triggerGetApiGetComments(String boardKey, Map<String, String> headerMap1)
			throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetComments:-> Start");
		String strApiUrl = getCommentsUrl("getCommentUrl", boardKey);
		Map<String, String> headerMap = createHeader(headerMap1);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetComments:-> End");
		return response;
	}

	
	public static ValidatableResponse getCommentsService(String boardKey, String ifModifiedSince) {
		  GetCommentsBaseScript commentsBaseScript = new GetCommentsBaseScript();
		  Map<String,String> headerMap = commentsBaseScript.createHeader();
		  headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), ifModifiedSince );
		  String strApiUrl = commentsBaseScript.getCommentsUrl("getCommentUrl", boardKey);
		  ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		 // String commentKey=response.extract().path("comments["+index+"].commentKey");
		 // repositoryMap.put(RepositoryParameterEnum.COMMENTKEY.getValue(), commentKey);
		  return response;
		 }
	
	public static ValidatableResponse getCommentsService(String boardKey) {
		  GetCommentsBaseScript commentsBaseScript = new GetCommentsBaseScript();
		  Map<String,String> headerMap = commentsBaseScript.createHeader();
		//  headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), ifModifiedSince );
		  String strApiUrl = commentsBaseScript.getCommentsUrl("getCommentUrl", boardKey);
		  ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		 // String commentKey=response.extract().path("comments["+index+"].commentKey");
		 // repositoryMap.put(RepositoryParameterEnum.COMMENTKEY.getValue(), commentKey);
		  return response;
		 }
		 
		 public static ValidatableResponse getCommentsService(String boardKey, Map<String,String> deviceInfo, String ifModifiedSince) throws IOException {
		  GetCommentsBaseScript commentsBaseScript = new GetCommentsBaseScript();
		  Map<String,String> headerMap=commentsBaseScript.createHeader(deviceInfo);
		  headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), ifModifiedSince );
		  String strApiUrl = commentsBaseScript.getCommentsUrl("getCommentUrl", boardKey);
		  ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		//  String commentKey=response.extract().path("comments["+index+"].commentKey");
		//  repositoryMap.put(RepositoryParameterEnum.COMMENTKEY.getValue(), commentKey);
		  return response;
		 }
	

	
}
