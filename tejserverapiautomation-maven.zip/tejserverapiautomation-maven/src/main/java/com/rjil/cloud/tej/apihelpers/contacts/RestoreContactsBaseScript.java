package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.RestoreContactsConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;

/**
 * @author Chandrashekhar Singh
 * 
 *         Base script for Restore contacts API.
 * */

public class RestoreContactsBaseScript extends BaseTestScript {
	protected static final String apiName = "RestoreContactsAPI";
	protected String jsonBody;
	
	 
    public RestoreContactsBaseScript(){
  		globalApiName=apiName;
  	}
  


	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader:-> Start");

		createHeader("100");
		FrameworkLogger.logStep("createHeader:-> End");
		return headerMap;
	}

	protected Map<String, String> createHeader(String strChunkSize) {
		FrameworkLogger.logStep("createHeader:-> Start");

    	headerMap=initializeHeader();

		// size is 100 byte
		headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), strChunkSize); // Chunk

		FrameworkLogger.logStep("createHeader:-> End");
		return headerMap;
	}

	protected Map<String, String> createHeader(Map<String, String> deviceInfoMap) {
		FrameworkLogger.logStep("createHeader:-> Start");
	//	headerMap = createHeader(deviceOwnerInfo);

		// size is 100 byte
		headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "100000"); // Chunk

		FrameworkLogger.logStep("createHeader:-> End");
		return headerMap;
	}

	/**
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         It creates the url for API
	 */
	protected String getRestoreContactsApiUrl(String strNextPageDate) {
		FrameworkLogger.logStep("getRestoreContactsApiUrl:-> Start");
		String url= getRestoreContactsApiUrlWithUrlKey("restoreContactsApiUrl").replace(
						"{nextPageDate}", strNextPageDate);
		FrameworkLogger.logStep("getRestoreContactsApiUrl:-> End");
		return url;
	}

	/**
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         It loads the default JSON body.
	 */

	private void loadJsonFile() {
		FrameworkLogger.logStep("loadJsonFile:-> Start");
		// load json file
		String filePath = "/resources/restoreContactsTestData/restoreContactsJsonBody.js";
		jsonBody = loadJsonFile(filePath);

		FrameworkLogger.logStep("loadJsonFile:-> End");
	}

	/**
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         It will set the value on provided json path
	 */
	private void setJsonBody(String jsonPath, String value) {
		FrameworkLogger.logStep("setJsonBody:-> Start");
		jsonBody = setJsonData(jsonPath, value, jsonBody);

		FrameworkLogger.logStep("setJsonBody:-> End");
	}

	/**
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         It will set the snapshotId, deviceId in json string.
	 */
	protected void setRestoreContactsInfoInJsonBody(String strSnapshotId,
			String strDeviceId) {
		FrameworkLogger
		.logStep("setRestoreContactsInfoInJsonBody:-> Start");
		// Load the JSON file for API body.
		loadJsonFile();

		// Set snapshotID
		setJsonBody(RestoreContactsConstants.getSnapshotIdJsonPath(),
				strSnapshotId);

		// Set the device ID.
		jsonBody = jsonBody.replace("{deviceId}", strDeviceId);

		FrameworkLogger
		.logStep("setRestoreContactsInfoInJsonBody:-> End");
	}

	/**
	 * @return validatable response for API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the API and return the Response
	 */
	protected ValidatableResponse triggerPutApiRestoreContacts() {
		FrameworkLogger
				.logStep("triggerPutApiRestoreContacts:-> Start");

		String strNextPageDate="1970-10-27 05:30:25.368272";
		//		triggerPutApi ContactBackup
		String strApiUrl=getRestoreContactsApiUrl(strNextPageDate);
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,jsonBody);
		
		FrameworkLogger
				.logStep("triggerPutApiRestoreContacts:-> End");

		return response;
	}

	/**
	 * @return validatable response for API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the API and return the Response
	 */
	protected ValidatableResponse triggerPutApiRestoreContacts(
			String strNextPageDate) {
		FrameworkLogger
				.logStep("triggerPutApiRestoreContacts:-> Start");

//		triggerPutApi ContactBackup
		String strApiUrl=getRestoreContactsApiUrl(strNextPageDate);
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,jsonBody);
		
		FrameworkLogger
				.logStep("triggerPutApiRestoreContacts:-> End");

		return response;
	}

	// This method accepts the response and returns the size of Contact list.
	public static int getSizeOfRestoreContactApiResponse(
			ValidatableResponse response) {
		FrameworkLogger.logStep("getSizeOfRestoreContactApiResponse:-> Start");

		int size = -1;
		ArrayList<String> list = response.extract().path("contacts");
		size = list.size();

		FrameworkLogger.logStep("getSizeOfRestoreContactApiResponse:-> End");

		return size;
	}

	//Service method to hit the RestoreContacts API and returns the response.
	public static ValidatableResponse hitRestoreContactsApiGetResponse(String strDeviceId,
			String date) throws InterruptedException,
			VerificationFailException, ParseException,
			java.text.ParseException, IOException {
		FrameworkLogger
				.logStep("hitRestoreContactsApiGetResponse -> Start");

		RestoreContactsBaseScript apiObj = new RestoreContactsBaseScript();
		ValidatableResponse response=null;
		
		// Get the API response of RestoreContactSummary.
		ValidatableResponse restoreContactSummaryResponse = RestoreContactSummaryBaseScript
				.triggerRestoreContactSummaryApiServiceMethod();

		// Get information (snapshotId, Count) for the device id present in the
		// API response of RestoreContactSummary.
		List<String[]> listOfSummaryInfo = RestoreContactSummaryBaseScript
				.getRestoreContactSummaryInfoFromApiResponse(
						restoreContactSummaryResponse, strDeviceId);

		// Create header for Restore Contacts API.
		apiObj.createHeader();

		// Read one by one the Restore Contact Summary info and call Restore
		// Contacts API.
		int i = -1;
		for (String[] oneSummaryInfo : listOfSummaryInfo) {
			i++;
			FrameworkLogger.logStep("listOfSummaryInfo -> " + i
					+ ": snapshotId- " + oneSummaryInfo[0] + ": count- "
					+ oneSummaryInfo[1]);

			// Set SnapshotId and DeviceId in JSON body for the API
			// Snapshot id is always on '0'th position in array.
			apiObj.setRestoreContactsInfoInJsonBody(oneSummaryInfo[0], strDeviceId); 
			// Call the Restore Contacts API with the Date.
			 response = apiObj.triggerPutApiRestoreContacts(date);
			// Get the status code and validate.
			int status = response.extract().statusCode();
			Verify.verifyEquals(status,
					ApiResponseCodes.RESPONSECODE200.getValue(),
					"Verify Success Status");

		}

		FrameworkLogger.logStep("hitRestoreContactsApiGetResponse -> End");
		return response;
	}

	// Restore contacts service method.
	// It will take input of snapshotId and contacts count and will trigger RestoreContact API.
//	public static ValidatableResponse restoreContactsServiceMethod(String strSnapshotId, String contactCount, String strDeviceId) throws InterruptedException, VerificationFailException, ParseException, java.text.ParseException, IOException  {
	public static ValidatableResponse restoreContactsServiceMethod(String strSnapshotId, String strDeviceId) throws InterruptedException, VerificationFailException, ParseException, java.text.ParseException, IOException  {
		FrameworkLogger.logStep("restoreContactsServiceMethod -> Start");

		String strDeviceId1=deviceOwnerInfo.get("deviceKey");
		//Calling the method with deviceMap.
		ValidatableResponse response = restoreContactsServiceMethod(deviceOwnerInfo, strSnapshotId, strDeviceId);
				
      FrameworkLogger.logStep("restoreContactsServiceMethod -> End");
      return response;
	}
	// Restore contacts service method.
	// It will take input of snapshotId and contacts count and will trigger RestoreContact API.
//	public static ValidatableResponse restoreContactsServiceMethod(Map<String, String>deviceInfoMap,String strSnapshotId, String contactCount, String strDeviceId) throws InterruptedException, VerificationFailException, ParseException, java.text.ParseException, IOException  {
	public static ValidatableResponse restoreContactsServiceMethod(Map<String, String>deviceInfoMap,String strSnapshotId, String strDeviceId) throws InterruptedException, VerificationFailException, ParseException, java.text.ParseException, IOException  {
		FrameworkLogger.logStep("restoreContactsServiceMethod -> Start");

		RestoreContactsBaseScript apiObj=new RestoreContactsBaseScript();
		
		//Create header for Restore Contacts API. 
		apiObj.createHeader(deviceInfoMap);
		
		//Read one by one the Restore Contact Summary info and call Restore Contacts API.
//		String[] oneSummaryInfo=listOfSummaryInfo.get(0);
			FrameworkLogger.logStep("listOfSummaryInfo -> snapshotId- "+strSnapshotId);
			
			//Set SnapshotId and DeviceId in JSON body for the API
			apiObj.setRestoreContactsInfoInJsonBody(strSnapshotId, strDeviceId);	//Snapshot id is always on '0'th position in array.

			//Call the Restore Contacts API with the Date.
			ValidatableResponse response=apiObj.triggerPutApiRestoreContacts();
			//Get the status code and validate.
			int status = response.extract().statusCode();
	      Verify.verifyEquals(status,ApiResponseCodes.RESPONSECODE200.getValue(),"Verify Success Status");
	      
      FrameworkLogger.logStep("restoreContactsServiceMethod -> End");
      return response;
	}

	// Restore contacts service method.
	// It will trigger RestoreContactSummary API and will find the Snapshot info from response and will trigger RestoreContact API.
	public static ValidatableResponse restoreContactsServiceMethod() throws InterruptedException, VerificationFailException, ParseException, java.text.ParseException, IOException  {
		FrameworkLogger.logStep("restoreContactsServiceMethod -> Start");

		//Get the API response of RestoreContactSummary.
		ValidatableResponse restoreContactSummaryResponse=RestoreContactSummaryBaseScript.triggerRestoreContactSummaryApiServiceMethod();
		
		//Get the device id for the loggedin user.
		String strDeviceId=serverConfig.get("deviceKey");
		
		//Get information (snapshotId, Count) for the device id present in the API response of RestoreContactSummary.
		List<String[]> listOfSummaryInfo=RestoreContactSummaryBaseScript.getRestoreContactSummaryInfoFromApiResponse(restoreContactSummaryResponse, strDeviceId);

		String[] oneSummaryInfo=listOfSummaryInfo.get(0);
		
//		ValidatableResponse restoreContactResponse=restoreContactsServiceMethod(oneSummaryInfo[0], oneSummaryInfo[1], strDeviceId);
		ValidatableResponse restoreContactResponse=restoreContactsServiceMethod(oneSummaryInfo[0], strDeviceId);
			      
      FrameworkLogger.logStep("restoreContactsServiceMethod -> End");
      return restoreContactResponse;
	}

	public static ValidatableResponse restoreContactsServiceMethod(Map<String, String>deviceInfoMap, String strSnapshotId, int contactCount, String strDeviceId) throws InterruptedException, VerificationFailException, ParseException, java.text.ParseException, IOException  {
		FrameworkLogger.logStep("restoreContactsServiceMethod -> Start");

		RestoreContactsBaseScript apiObj=new RestoreContactsBaseScript();
		
		//Create header for Restore Contacts API. 
		apiObj.createHeader(deviceInfoMap);
		
		//Read one by one the Restore Contact Summary info and call Restore Contacts API.
//		String[] oneSummaryInfo=listOfSummaryInfo.get(0);
			FrameworkLogger.logStep("listOfSummaryInfo -> snapshotId- "+strSnapshotId+": count- "+contactCount);
			
			//Set SnapshotId and DeviceId in JSON body for the API
			apiObj.setRestoreContactsInfoInJsonBody(strSnapshotId, strDeviceId);	//Snapshot id is always on '0'th position in array.

			//Call the Restore Contacts API with the Date.
			ValidatableResponse response=apiObj.triggerPutApiRestoreContacts("1970-07-01 08:09:00.496484");
			//Get the status code and validate.
			int status = response.extract().statusCode();
	      Verify.verifyEquals(status,ApiResponseCodes.RESPONSECODE200.getValue(),"Verify Success Status");
	      
      FrameworkLogger.logStep("restoreContactsServiceMethod -> End");
      return response;
	}

	/**
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         It gets the url with provided Url Key for API
	 */
	protected String getRestoreContactsApiUrlWithUrlKey(String urlKey) {
		FrameworkLogger.logStep("getRestoreContactsApiUrlWithUrlKey:-> Start");
		String url= apiUrls.get("baseContactURL") + serverConfig.get(urlKey);
		FrameworkLogger.logStep("getRestoreContactsApiUrlWithUrlKey:-> End");
		return url;
	}

	/**
	 * @return validatable response for API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the API by providing urlKey and return the Response
	 */
	protected ValidatableResponse triggerPutApiRestoreContactsWithUrlKey(String urlKey) {
		FrameworkLogger.logStep("triggerPutApiRestoreContactsWithUrlKey:-> Start");

//		triggerPutApi ContactBackup
		String strApiUrl=getRestoreContactsApiUrlWithUrlKey(urlKey);
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,jsonBody);
		
		FrameworkLogger.logStep("triggerPutApiRestoreContactsWithUrlKey:-> End");

		return response;
	}

	/*
	public ValidatableResponse triggerRestoreContactsApiServiceMethod(String strSnapshotId, String strDeviceId){
		FrameworkLogger.logStep("triggerRestoreContactsApiServiceMethod:-> String");
		RestoreContactsBaseScript apiObj=new RestoreContactsBaseScript();
		
		//Create header for Restore Contacts API . 
		apiObj.createHeader();

		//Pass invalid snapshotId in body.
		apiObj.setRestoreContactsInfoInJsonBody(strSnapshotId, strDeviceId);

			//Call the Restore Contacts API.
			//As per discussion with Narendra, this date should be of past 1970.
		ValidatableResponse response=apiObj.triggerPutApiRestoreContacts();

		FrameworkLogger.logStep("triggerRestoreContactsApiServiceMethod:-> End");
		return response;
	}

*/	/**
	 * @return validatable response for API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the API using external provided URL and return the Response
	 */
	protected ValidatableResponse triggerPutApiRestoreContactsUsingProvidedUrl(String strApiUrl) {
		FrameworkLogger
				.logStep("triggerPutApiRestoreContactsUsingProvidedUrl:-> Start");

		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,jsonBody);
		
		FrameworkLogger
				.logStep("triggerPutApiRestoreContactsUsingProvidedUrl:-> End");

		return response;
	}

/*	//Search the given contact Id in response and return the index.
	public static int searchContactIdAndGetIndexValue(ValidatableResponse response, String strContactId) throws IOException
	{
		FrameworkLogger.logStep("searchContactIdAndGetIndexValue:-> Start");
		int contactidIndex = -1;

		int  sizeOfContactsArray =	response.extract().jsonPath().getList("contacts").size();
		for(int i=0;i<sizeOfContactsArray;i++)
		{
			String contactid = response.extract().path("contacts["+i+"].contactid");
			FrameworkLogger.logStep(i+"-> contactid:->"+contactid+",comparing with serGuid: "+serGuid);
			if (contactid.equalsIgnoreCase(serGuid))
			{
				FrameworkLogger.logStep("FOUND");
				contactidIndex=i;
				break;
			}
		}
		FrameworkLogger.logStep("searchContactIdAndGetIndexValue:-> End");
		return contactidIndex;
	}

*/
   /* public static int getOccuranceOfContactForRestore(String cond, String contactid)
    {
 	   int count = 0;
 	   
 	   String nextPageDate ="2014-01-01 17:03:37.187376";
 	   while(!(nextPageDate.contains(cond)))
 	   {   RestoreContactsBaseScript restore = new RestoreContactsBaseScript();
 		   System.out.println("Value of nextPageDate======"+nextPageDate);
 		  restore.createHeader();
 		 restore.headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), nextPageDate); 
 		restore.headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), "10");
 		 
 		//   ValidatableResponse response = cab.triggerGetApiCabForNext("2014-01-01 17:03:37.187376");
 		   ValidatableResponse response = restore.triggerGetApiCabForNext();
 		   
 		   int indexToReturn=-1;
 		   int size = getSizeOfContactsInCabApiResponse(response);
 		   FrameworkLogger.logStep("Number of contacts in CAB response : " + size);
 		   for(int i=0; i< size; i++)
 		   {
 			   String strContactIdInResponse = response.extract().path("contacts[" + i + "].contactid");
 			   FrameworkLogger.logStep("Comparing : contactId: " + contactid + " with strContactIdInResponse: " + strContactIdInResponse);

 			   if(contactid.equalsIgnoreCase(strContactIdInResponse))
 			   {
 				   FrameworkLogger.logStep("Contact matching here**************************************");
 				   indexToReturn=i;
 				   count++;
 				   FrameworkLogger.logStep("NOW WE GOT FIRST COUNT ===============:-> " + count);
 			   }
 			  
 		   }	
 		   
 		   nextPageDate = response.extract().path("next");
 		   FrameworkLogger.logStep("NEXTPAGEURL===============:-> " + nextPageDate);
 		   String completeUrlInCab[]=nextPageDate.trim().split("\\?");
 	        FrameworkLogger.logStep("URL - completeUrlInCab[0]:-> " + completeUrlInCab[0]);
 			 nextPageDate=(nextPageDate.trim().split("="))[1];
 			 FrameworkLogger.logStep("Match not found so we are here***************************************");
 	     //   FrameworkLogger.logStep("datePartFromCabUrl:-> " + datePartFromCabUrl);
 	     //   cab.headerMap.put(HeaderParameters.NEXTPAGEDATE.getValue(), datePartFromCabUrl); 
 		//   response = cab.triggerGetApiCabForNext();
 			
 	   }

 	   return count;
    }*/
}
