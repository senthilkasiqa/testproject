package com.rjil.cloud.tej.apihelpers.boards;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class IndividualBoardInitialSyncBaseScript extends BaseTestScript{

protected static final String apiName = "IndividualBoardInitialSync";
	
	protected String individualBoardInitialSyncURL(String boardKey) {
	FrameworkLogger.logStep(" individualBoardInitialSyncURL:-> Start");
	return apiUrls.get("boardUrl") + serverConfig.get("individualBoardInitialSyncUrl").replace("{boardKey}", boardKey);
}
	
protected String individualBoardInitialSyncURL(String boardKey, String url) {
		FrameworkLogger.logStep(" individualBoardInitialSyncURL:-> Start");
		return apiUrls.get("boardUrl") + serverConfig.get(url).replace("{boardKey}", boardKey);
	}

protected String individualBoardInitialSyncURL(String boardKey, String url,String page,String limit) {
	FrameworkLogger.logStep(" individualBoardInitialSyncURL:-> Start");
	String replaceUrl= apiUrls.get("boardUrl") + serverConfig.get(url).replace("{boardKey}", boardKey);
	String individualBoardInitialSyncUrl=replaceUrl.replace("{page}", page).replace("{limit}", limit);
	return individualBoardInitialSyncUrl;
	//return apiUrls.get("boardUrl") + serverConfig.get(url).replace("{boardKey}", boardKey);
}

protected String individualBoardInitialSyncURLWithNextLink(String nextLink) {
	FrameworkLogger.logStep(" individualBoardInitialSyncURL:-> Start");
	return apiUrls.get("baseURL") + nextLink;
}


protected ValidatableResponse triggerGetIndividualBoardInitialSync(String boardKey) throws IOException {
	FrameworkLogger.logStep("triggerGetIndividualBoardInitialSync:-> Start");
	String strApiUrl = individualBoardInitialSyncURL(boardKey);
	ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
	FrameworkLogger.logStep("triggerGetIndividualBoardInitialSync:-> End");
	return response;
}


protected ValidatableResponse triggerGetIndividualBoardInitialSync(String boardKey, String url) throws IOException {
	FrameworkLogger.logStep("triggerGetIndividualBoardDeltaSync:-> Start");
	String strApiUrl = individualBoardInitialSyncURL(boardKey,url);
	ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
	FrameworkLogger.logStep("triggerGetIndividualBoardInitialSync:-> End");
	return response;
}

protected ValidatableResponse triggerGetIndividualBoardInitialSync(String boardKey, String url,Map<String,String> headerMap1) throws IOException {
	FrameworkLogger.logStep("triggerGetIndividualBoardDeltaSync:-> Start");
	String strApiUrl = individualBoardInitialSyncURL(boardKey,url);
	Map<String,String> headerMap = createHeader(headerMap1);
	ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
	FrameworkLogger.logStep("triggerGetIndividualBoardInitialSync:-> End");
	return response;
}

protected ValidatableResponse triggerGetIndividualBoardInitialSync(String boardKey ,Map<String,String> headerMap1) throws IOException {
	FrameworkLogger.logStep("triggerGetIndividualBoardDeltaSync:-> Start");
	String strApiUrl = individualBoardInitialSyncURL(boardKey);
	Map<String,String> headerMap = createHeader(headerMap1);
	ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
	FrameworkLogger.logStep("triggerGetIndividualBoardInitialSync:-> End");
	return response;
}

protected ValidatableResponse triggerGetIndividualBoardInitialSync(String boardKey, String url,String page,String limit) throws IOException {
	FrameworkLogger.logStep("triggerGetIndividualBoardDeltaSync:-> Start");
	String strApiUrl = individualBoardInitialSyncURL(boardKey,url,page,limit);
	ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
	FrameworkLogger.logStep("triggerGetIndividualBoardInitialSync:-> End");
	return response;
}
public static ValidatableResponse individualBoardInitialSyncService(String boardKey)
{
	FrameworkLogger.logStep("individualBoardInitialSyncService:-> Start");
	IndividualBoardInitialSyncBaseScript individualInitial = new IndividualBoardInitialSyncBaseScript();
	individualInitial.createHeader();
	String strApiUrl = individualInitial.individualBoardInitialSyncURL(boardKey);
	ValidatableResponse response =individualInitial.triggerGetApi(strApiUrl, individualInitial.headerMap);
	FrameworkLogger.logStep("individualBoardInitialSyncService:-> Start");
	return response;
}

public static ValidatableResponse individualBoardInitialSyncService(Map<String, String> deviceInfoMap, String boardKey) throws IOException
{
	FrameworkLogger.logStep("individualBoardInitialSyncService:-> Start");
	IndividualBoardInitialSyncBaseScript individualInitial = new IndividualBoardInitialSyncBaseScript();
	individualInitial.createHeader(deviceInfoMap);
	String strApiUrl = individualInitial.individualBoardInitialSyncURL(boardKey);
	ValidatableResponse response =individualInitial.triggerGetApi(strApiUrl, individualInitial.headerMap);
	FrameworkLogger.logStep("individualBoardInitialSyncService:-> End");
	return response;
}

public static List<String> getListRecentUsersFromIndividualBoardInitialSync(ValidatableResponse response, String key) {
	List<String> valueFromResponse = new ArrayList<String>();
	for (int i = 0; i < response.extract().jsonPath().getList("board.recentUsers").size(); i++) {
		String indexValue = (String) response.extract().jsonPath().get("board.recentUsers[" + i + "]." + key);
		valueFromResponse.add(indexValue);
	}
	return valueFromResponse;
}

public static ValidatableResponse triggetGetNextLink(String nextLink){
	FrameworkLogger.logStep("triggetGetNextLink:-> Start");
	IndividualBoardInitialSyncBaseScript individualInitial = new IndividualBoardInitialSyncBaseScript();
	individualInitial.createHeader();
	String strApiUrl = individualInitial.individualBoardInitialSyncURLWithNextLink(nextLink);
	ValidatableResponse response =individualInitial.triggerGetApi(strApiUrl, individualInitial.headerMap);
	FrameworkLogger.logStep("triggetGetNextLink:-> End");
	return response;
}
}
