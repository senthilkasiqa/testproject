package com.rjil.cloud.tej.apihelpers.messages;

import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class LastMessageBackupDateTimeBaseScript extends BaseTestScript{
	
	    protected static final String apiName="LastMessageBackupDateTime";
	    
	    public LastMessageBackupDateTimeBaseScript(){
	    	globalApiName=apiName;
	    }

	    /**
	     * @author Sanjeevanee Kanase
	     * <p>
	     * It creates the url for API 
	     */
	    private String getLastMessageBackupDateTimeUrl() {
			FrameworkLogger.logStep("getLastMessageBackupDateTimeUrl:-> Start");

			String apiUrl=apiUrls.get("baseMessagesURL") + serverConfig.get("lastMessageBackupDateTimeUrl");
			FrameworkLogger.logStep("getLastMessageBackupDateTimeUrl:-> End");

			return apiUrl;
	    }
	
	    // Overload the method.
	 	protected Map<String, String> createHeader() {
	 		FrameworkLogger.logStep("createHeader -> Start");

	 		headerMap = initializeHeader();
	 	//	headerMap.remove(HeaderParameters.XAPPSECRET.getValue(), getAppSecretValue());
		//	headerMap.remove(HeaderParameters.XAPIKEY.getValue());
	 		FrameworkLogger.logStep("createHeader -> End");
	 		return headerMap;
	 	}
	    /**
	     * @return validatable response for LastMessageBackupTimeDate
	     * @author 
	     * <p>
	     * Call the API and return the Response
	     */
	    protected ValidatableResponse triggerGetApiLastSuccessBackupTime() {
			FrameworkLogger.logStep("triggerGetApiLastSuccessBackupTime:-> Start");
	        // setContactBackupJsonBody();
			
			String strApiUrl=getLastMessageBackupDateTimeUrl();
			
			//Call method to trigger GET API.
			ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
			
			FrameworkLogger.logStep("triggerGetApiLastSuccessBackupTime:-> End");
			return response;
	    }
	    
	    
	    public static ValidatableResponse getLastBackupTimeDateService()
	    {
	    	FrameworkLogger.logStep("getLastBackupTimeDateService:-> Start");
	    	
	    	LastMessageBackupDateTimeBaseScript apiObj=new LastMessageBackupDateTimeBaseScript();
			apiObj.createHeader();
			
			String strApiUrl=apiObj.getLastMessageBackupDateTimeUrl();
	
			//Call method to trigger GET API.
			ValidatableResponse response = apiObj.triggerGetApi(strApiUrl,apiObj.headerMap);
			
			FrameworkLogger.logStep("getLastBackupTimeDateService:-> End");
			return response;
	    }
}
