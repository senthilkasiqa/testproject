package com.rjil.cloud.tej.enums;

public enum MessageBackupParameters {

	    MESSAGES("messages"),
	    DVCMSGID("dvcMsgId"),
	    TEXT("text"),
	    NAME("name"),
	    PHONENO("phoneNo"),
	    CONVID("convId"),
	    DATETIME("dateTime"),
	    MSGTYPE("msgType"),
	    APPTYPE("appType"),
	    OPERATION("operation");

	    public String value;

	    MessageBackupParameters(String value) {
	        this.value = value;
	    }

	    public String getValue() {
	        return value;
	    }
}
