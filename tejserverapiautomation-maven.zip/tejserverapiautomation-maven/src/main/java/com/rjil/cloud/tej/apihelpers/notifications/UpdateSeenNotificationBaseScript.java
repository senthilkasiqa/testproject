/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.notifications;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NmsConstants;
import com.rjil.cloud.tej.apiconstants.NotificationConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 * 
 * Base class for Update Seen Notification API
 *
 */
public class UpdateSeenNotificationBaseScript extends BaseTestScript {

	protected static final String apiName = "UpdateSeenNotification";
	protected String updateSeenNotificationJSONBody;
//	protected Map<String, String> headerMap = null;
	
	public UpdateSeenNotificationBaseScript(){
		globalApiName=apiName;
	}
	
	/**
	 * 
	 * Create URL for Update Seen Notification Api
	 * 
	 * @return
	 */

	protected String getUpdateSeenNotificationUrl() {
		FrameworkLogger.logStep("getUpdateSeenNotificationUrl: Start");
		//String url= apiUrls.get("baseURL") + serverConfig.get("updateSeenNotificatioUrl");
		String url=getUpdateSeenNotificationUrl("updateSeenNotificatioUrl");
		FrameworkLogger.logStep("getUpdateSeenNotificationUrl: End");
		return url;

	}
	
	/**
	 * 
	 * Create URL for Update Seen Notification Api Negative test cases
	 * 
	 * @return
	 */

	protected String getUpdateSeenNotificationUrl(String apiUrl) {
		FrameworkLogger.logStep("getUpdateSeenNotificationUrl: Start");
		String url= apiUrls.get("baseURL") + serverConfig.get(apiUrl);
		FrameworkLogger.logStep("getUpdateSeenNotificationUrl: End");
		return url;

	}
	
	/**
	 * 
	 * Create Header for Update Seen Notification Api
	 */

/*	protected void createHeader() {
		FrameworkLogger.logStep("createHeader:-> Start");
		headerMap = new HashMap<>();
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");

		// Add X-API Header key if the value is set as YES in the configuration
		// file
		addXapiHeaderKey(headerMap);
		FrameworkLogger.logStep("createHeader:-> End");

	}
*/

	// Overload the method.
	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Remove from header for this API.
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * 
	 * Create JSON body for Update Seen Notification Api
	 * 
	 * @return
	 * @throws IOException
	 */
	protected String setUpdateSeenNotificationJsonBody() throws IOException {
		FrameworkLogger.logStep("setUpdateSeenNotificationJsonBody:-> Start");
		String path = System.getProperty("user.dir") + "/resources/notificationsTestData/updateSeenNotificationBody.js";
		File file = new File(path);
		updateSeenNotificationJSONBody = JsonPath.parse(file).jsonString();
		
		FrameworkLogger.logStep("setUpdateSeenNotificationJsonBody:-> End");
		return updateSeenNotificationJSONBody;
	}
	
	/**
	 * 
	 * Execute Update Seen Notiification api and fetch the response
	 * 
	 * @return
	 */
	
	protected ValidatableResponse getUpdateSeenNotificationResponse(){
		FrameworkLogger.logStep("getUpdateSeenNotificationResponse:-> Start");
/*		ValidatableResponse response = given().body(updateSeenNotificationJSONBody)
                .headers(headerMap)
                .log().all()
                .when()
                .put(getUpdateSeenNotificationUrl())
                .then();
        response.log().all();
        Utils.addRequestResponseToLogger();
*/        
	//	String strApiUrl=getUpdateSeenNotificationUrl();
		//Call method to trigger PUT API.
		//ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,updateSeenNotificationJSONBody);

		ValidatableResponse response=getUpdateSeenNotificationResponse("updateSeenNotificatioUrl");
        FrameworkLogger.logStep("getUpdateSeenNotificationResponse:-> End");
        return response;
	}
	
	/**
	 * 
	 * Execute Update Seen Notiification api and fetch the response for negative test
	 * 
	 * @return
	 */
	
	protected ValidatableResponse getUpdateSeenNotificationResponse(String apiUrl){
		FrameworkLogger.logStep("getUpdateSeenNotificationResponse:-> Start");
     
		String strApiUrl=getUpdateSeenNotificationUrl(apiUrl);
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,updateSeenNotificationJSONBody);

        FrameworkLogger.logStep("getUpdateSeenNotificationResponse:-> End");
        return response;
	}
}
