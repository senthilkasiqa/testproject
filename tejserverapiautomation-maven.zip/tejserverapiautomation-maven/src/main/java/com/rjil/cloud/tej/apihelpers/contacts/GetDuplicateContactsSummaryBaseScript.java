package com.rjil.cloud.tej.apihelpers.contacts;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import static com.jayway.restassured.RestAssured.given;
/**
 * @author Chandrashekhar Singh
 * 
 * Base script for Merge Summary(Get Duplicate Contacts Summary).
 * */
public class GetDuplicateContactsSummaryBaseScript extends BaseTestScript {
    protected static final String apiName="GetDuplicateContactsSummary";
    
    public GetDuplicateContactsSummaryBaseScript(){
  		globalApiName=apiName;
  	}
   
    protected String getDuplicateContactsSummaryURL() {
        return apiUrls.get("baseContactURL") + serverConfig.get("mergeSummaryURL");
    }
    /**
     * @return validatable response for Merge Summary
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     * @throws IOException 
     */
    protected ValidatableResponse triggerGetApiDuplicateContactsSummary() throws IOException {
        FrameworkLogger.logStep("triggerGetApiDuplicateContactsSummary -> Start");
       String strApiUrl= getDuplicateContactsSummaryURL();
       headerMap = createHeader(deviceOwnerInfo);
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
        FrameworkLogger.logStep("triggerGetApiDuplicateContactsSummary -> End");
        return response;
    }
    /**
     * @return validatable response for Merge Summary
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     * @throws IOException 
     */
    public static ValidatableResponse getDuplicateContactsSummaryApiResponseWithDefaultHeader() throws IOException {
        FrameworkLogger.logStep("getDuplicateContactsSummaryApiResponseWithDefaultHeader -> Start");
        GetDuplicateContactsSummaryBaseScript apiObj=new GetDuplicateContactsSummaryBaseScript();
        apiObj.createHeader();
    	ValidatableResponse response = apiObj.triggerGetApiDuplicateContactsSummary();
    	
        FrameworkLogger.logStep("getDuplicateContactsSummaryApiResponseWithDefaultHeader -> End");
        return response;
    }
    /**
     * 
     * @author Chandrashekhar Singh
     * <p>
     * Method to search the record with first name in Duplicate Contacts Summary response.
     */
        public static int searchRecordInDuplicateContactsSummaryResponse(ValidatableResponse response, String firstName){
        FrameworkLogger.logStep("searchRecordInDuplicateContactsSummaryResponse -> Start");
//        GetDuplicateContactsSummaryBaseScript apiObj=new GetDuplicateContactsSummaryBaseScript();
        int indexOfSearchedRecord=-1;
     //   String duplicateType="completeMatchContacts";
        String duplicateType="partialMatchContacts";
        
      //  ArrayList<String> compDupCountAr=response.extract().path("partialMatchContacts.duplicateCount");
        ArrayList<String> partialDupCountAr2=response.extract().path("partialMatchContacts.duplicateCount");
     //   FrameworkLogger.logStep("dupCountAr of completeMatch: "+compDupCountAr.size());
        FrameworkLogger.logStep("dupCountAr2 of PartialMatch: "+partialDupCountAr2.size());
        boolean foundRecord=false;
        
     /*   for(int i=0; i< compDupCountAr.size(); i++){
        	FrameworkLogger.logStep("CompleteMatch Comparing with: ");
        	
        	try{
        	FrameworkLogger.logStep(response.extract().path(duplicateType+"["+i+"].firstName").toString()+ "  -> "+firstName);
        	if(response.extract().path(duplicateType+"["+i+"].firstName").toString().equalsIgnoreCase(firstName)){
        		printContactInfoInDuplicateContactsSummaryResponse(duplicateType, response, i);
        		indexOfSearchedRecord=i;
                FrameworkLogger.logStep("Found in Complete match");
                foundRecord=true;
                break;
        	}
        	}catch(Exception e){
        		FrameworkLogger.logStep("Something wrong during comparing COMPLETE match records, Exception:->");
        		FrameworkLogger.logStep(e.toString());
        	}
        }
        //////////////////////
        if(!foundRecord)*/{
            for(int i=0; i< partialDupCountAr2.size(); i++){
            	FrameworkLogger.logStep("PartialMatch Comparing with: ");
            	try{
            		duplicateType="partialMatchContacts";
            	FrameworkLogger.logStep(response.extract().path(duplicateType+"["+i+"].firstName").toString()+ "  -> "+firstName);
            	if(response.extract().path(duplicateType+"["+i+"].firstName").toString().equalsIgnoreCase(firstName)){
            		printContactInfoInDuplicateContactsSummaryResponse(duplicateType, response, i);
            		indexOfSearchedRecord=i;
                    FrameworkLogger.logStep("Found in Partial match");
                    foundRecord=true;
                    break;
            	}
            	}catch(Exception e){
            		FrameworkLogger.logStep("Something wrong during comparing PARTIAL match records, Exception:->");
            		FrameworkLogger.logStep(e.toString());
            	}
            }
        }
        
        if(!foundRecord){
            FrameworkLogger.logStep("Record NOT Found in Duplicate Contacts summary");
            return indexOfSearchedRecord;
            
        }
        
        FrameworkLogger.logStep("searchRecordInDuplicateContactsSummaryResponse -> End with indexOfSearchedRecord="+indexOfSearchedRecord);
//      return foundRecord;
      return indexOfSearchedRecord;
  }
        /**
         * 
         * @author Chandrashekhar Singh
         * <p>
         * Method to search the record with first name in Duplicate Contacts Summary response.
         * @throws VerificationFailException 
         */
            public static int searchRecordInDuplicateContactsSummaryResponse(ValidatableResponse response, Map<String, String[]>dedupeSetInfo) throws VerificationFailException{
            FrameworkLogger.logStep("searchRecordInDuplicateContactsSummaryResponse -> Start");
//            GetDuplicateContactsSummaryBaseScript apiObj=new GetDuplicateContactsSummaryBaseScript();
            int indexOfSearchedRecord=-1;
            String duplicateType="partialMatchContacts";
            String strMainDuplicateContactId=null;
            
            Set<String> contactSetInputReceived=dedupeSetInfo.keySet();
            
            ArrayList<String> compDupCountAr=response.extract().path("completeMatchContacts.duplicateCount");
            ArrayList<String> partialDupCountAr2=response.extract().path("partialMatchContacts.duplicateCount");
            FrameworkLogger.logStep("dupCountAr of completeMatch: "+compDupCountAr.size());
            FrameworkLogger.logStep("dupCountAr2 of PartialMatch: "+partialDupCountAr2.size());
            boolean foundRecord=false;
            
            for(int i=0; i< compDupCountAr.size(); i++){
            	FrameworkLogger.logStep("CompleteMatch Comparing with: ");
            	
            	try{
            		strMainDuplicateContactId=response.extract().path(duplicateType+"["+i+"].contactId").toString();
                	FrameworkLogger.logStep("Comparing contactSetInputReceived :-> " + contactSetInputReceived + ", with strMainDuplicateContactId :-> "+ strMainDuplicateContactId);
            	if(contactSetInputReceived.contains(strMainDuplicateContactId)){
            		printContactInfoInDuplicateContactsSummaryResponse(duplicateType, response, i);
            		indexOfSearchedRecord=i;
                    FrameworkLogger.logStep("Found in Complete match");
                    foundRecord=true;
                    break;
            	}
            	}catch(Exception e){
            		FrameworkLogger.logStep("Something wrong during comparing COMPLETE match records, Exception:->");
            		FrameworkLogger.logStep(e.toString());
            	}
            }
            //////////////////////
            if(!foundRecord){
                for(int i=0; i< partialDupCountAr2.size(); i++){
                	FrameworkLogger.logStep("PartialMatch Comparing with: ");
                	try{
                		duplicateType="partialMatchContacts";
                		strMainDuplicateContactId=response.extract().path(duplicateType+"["+i+"].contactId").toString();
                    	FrameworkLogger.logStep("Comparing contactSetInputReceived :-> " + contactSetInputReceived + ", with strMainDuplicateContactId :-> "+ strMainDuplicateContactId);
                    	if(contactSetInputReceived.contains(strMainDuplicateContactId)){
//                    		FrameworkLogger.logStep(response.extract().path(duplicateType+"["+i+"].contactId").toString());
//                    	if(contactSetInput.contains(response.extract().path(duplicateType+"["+i+"].contactId").toString())){
                		printContactInfoInDuplicateContactsSummaryResponse(duplicateType, response, i);
                		indexOfSearchedRecord=i;
                        FrameworkLogger.logStep("Found in Partial match");
                        foundRecord=true;
                        break;
                	}
                	}catch(Exception e){
                		FrameworkLogger.logStep("Something wrong during comparing PARTIAL match records, Exception:->");
                		FrameworkLogger.logStep(e.toString());
                	}
                }
            }
            
            if(!foundRecord){
                FrameworkLogger.logStep("Record NOT Found in Duplicate Contacts summary");
                return indexOfSearchedRecord;
                
            }
            
            //Geting number of duplicate contacts.
            int intDuplicateCountReceived=contactSetInputReceived.size();
            String[] strName=dedupeSetInfo.get(strMainDuplicateContactId);
            
        	int intDuplicateCountActual=response.extract().path(duplicateType+"["+indexOfSearchedRecord+"].duplicateCount");
        	String actualFname=response.extract().path(duplicateType+"["+indexOfSearchedRecord+"].firstName").toString();
        	String actualLname=response.extract().path(duplicateType+"["+indexOfSearchedRecord+"].lastName").toString();
        	ArrayList<String> duplicateIdsActual=response.extract().path(duplicateType+"["+indexOfSearchedRecord+"].duplicateIds");
            
            FrameworkLogger.logStep("contactSetInputReceived :-> " + contactSetInputReceived.toString()); 
            FrameworkLogger.logStep("intDuplicateCountReceived :-> " + intDuplicateCountReceived + ", intDuplicateCountActual :-> " + intDuplicateCountActual); 
      //      Verify.verifyEquals(intDuplicateCountActual, intDuplicateCountReceived, "Verifying duplicate counts in dedupe response");
        //    Verify.verifyEquals(actualFname, strName[0], "Verifying First Name in dedupe response");
        //    Verify.verifyEquals(actualLname, strName[1], "Verifying Last Name in dedupe response");
        	Set<String> actualDuplicateSet = new HashSet<String>(duplicateIdsActual);
        	
//        	contactSetInputReceived.remove(strMainDuplicateContactId);
        	
        	//Coppying all the contactIds from the received set.
            Set<String> contactIdSetWithoutMasterId=new HashSet<String>();
            for(String contactId: contactSetInputReceived){
            	contactIdSetWithoutMasterId.add(contactId);
            }
            //Removing the master Id.
            contactIdSetWithoutMasterId.remove(strMainDuplicateContactId);
            
        	boolean compareReceivedSetHasActualSet=contactIdSetWithoutMasterId.containsAll(actualDuplicateSet);
           	boolean compareActualSetHasReceivedSet=actualDuplicateSet.containsAll(contactIdSetWithoutMasterId);
        //   	Verify.verifyEquals(compareReceivedSetHasActualSet && compareActualSetHasReceivedSet, true, "Verifying duplicate contactIds sets in dedupe response");
            FrameworkLogger.logStep("searchRecordInDuplicateContactsSummaryResponse -> End with indexOfSearchedRecord="+indexOfSearchedRecord);
          return indexOfSearchedRecord;
      }
        /**
         * 
         * @author Chandrashekhar Singh
         * <p>
         * Method to search the record with all first names present in array in Duplicate Contacts Summary response.
         */
            public static int searchRecordInDuplicateContactsSummaryResponse(ValidatableResponse response, String [] strNames){
            FrameworkLogger.logStep("searchRecordInDuplicateContactsSummaryResponse -> Start");
//            GetDuplicateContactsSummaryBaseScript apiObj=new GetDuplicateContactsSummaryBaseScript();
            int indexOfSearchedRecord=-1;
            for(String strOneName: strNames){
                indexOfSearchedRecord= searchRecordInDuplicateContactsSummaryResponse(response, strOneName);
            	if(indexOfSearchedRecord>=0){
            		break;
            	}
            }
            
            FrameworkLogger.logStep("searchRecordInDuplicateContactsSummaryResponse -> End with indexOfSearchedRecord="+indexOfSearchedRecord);
//          return foundRecord;
          return indexOfSearchedRecord;
      }
            private static void printContactInfoInDuplicateContactsSummaryResponse(String duplicateType, ValidatableResponse response, int index){
        FrameworkLogger.logStep("printContactInfoInDuplicateContactsSummaryResponse -> Start");
    	FrameworkLogger.logStep("firstName: " + response.extract().path(duplicateType+"["+index+"].firstName").toString());
		FrameworkLogger.logStep("lastName: " + response.extract().path(duplicateType+"["+index+"].lastName").toString());
		FrameworkLogger.logStep("duplicateCount: " + response.extract().path(duplicateType+"["+index+"].duplicateCount").toString());
		FrameworkLogger.logStep("guid: " + response.extract().path(duplicateType+"["+index+"].guid").toString());
		FrameworkLogger.logStep("contactId: " + response.extract().path(duplicateType+"["+index+"].contactId").toString());
		FrameworkLogger.logStep("duplicateIds: " + response.extract().path(duplicateType+"["+index+"].duplicateIds"));
        FrameworkLogger.logStep("printContactInfoInDuplicateContactsSummaryResponse -> End");
    }
    
    /**
     * 
     * @author Chandrashekhar Singh
     * <p>
     * Method get index of searched record with first name in Merge Summary response.
     */
    public static int getIndexOfSearchedRecordInDuplicateContactsSummaryResponse(ValidatableResponse response, String firstName){
        FrameworkLogger.logStep("getIndexOfSearchedRecordInDuplicateContactsSummaryResponse -> Start");
    	
        
        int index=searchRecordInDuplicateContactsSummaryResponse(response, firstName);
    	
        FrameworkLogger.logStep("getIndexOfSearchedRecordInDuplicateContactsSummaryResponse -> End");
    	return index;
    }
    public static ValidatableResponse getDuplicateContactsSummaryApiResponseAfterSleep(double intMinToSleep) throws InterruptedException, IOException {
        FrameworkLogger.logStep("getMergeSummaryAPIResponseAfterSleep:-> Start");
		FrameworkLogger.logStep("Calling Merge Summary.");
		
        ValidatableResponse responseMergeSummary = getDuplicateContactsSummaryApiResponseWithDefaultHeader();
		FrameworkLogger.logStep("Sleeping for duration - " + intMinToSleep + " MIN.");
		
		// Sleep for 1 min.
//		Thread.sleep(1000 * 60 * intMinToSleep);
		int intSeconds=(int)(intMinToSleep*60);
		waitForTime(intSeconds);
		
		FrameworkLogger.logStep("Calling Merge Summary- After sleep.");
		
		responseMergeSummary = getDuplicateContactsSummaryApiResponseWithDefaultHeader();
        FrameworkLogger.logStep("getMergeSummaryAPIResponseAfterSleep:-> End");
        
		return responseMergeSummary;
	}
	public static void verifyNoDuplicateInDuplicateContactsSummaryResponse(ValidatableResponse response) throws VerificationFailException {
		FrameworkLogger.logStep("verifyNoDuplicateInMergeSummaryResponse:-> End");
        
		//Set the expected error information.
		int strExpectedHttpResponseMergeSummary = ApiResponseCodes.RESPONSECODE200.getValue();
		String strExpectedResponseCodeMergeSummary = "TEJRF0208";
		String strExpectedMessageMergeSummary = "No duplicate found.";
		//      Get and verify the status code.
		int strActualHttpResponseMergeSummary = response.extract().statusCode();
		String strActualCodeMergeSummary=null;
		String strActualMessageMergeSummary=null;
		try{
		strActualCodeMergeSummary= response.extract().path("code");
		}catch(Exception e){
			strActualCodeMergeSummary="Not able to read 'code' from response.";
		}
		try{
			strActualMessageMergeSummary = response.extract().path("error");
		}catch(Exception e){
			strActualMessageMergeSummary="Not able to read 'error' from response.";
		}
		
		//      Validating the response.
		Verify.verifyEquals(strActualMessageMergeSummary, strExpectedMessageMergeSummary, "Verify Response Message.");
		Verify.verifyEquals(strActualCodeMergeSummary, strExpectedResponseCodeMergeSummary, "Verify Response code.");
		Verify.verifyEquals(strExpectedHttpResponseMergeSummary, strActualHttpResponseMergeSummary, "Verify HTTP Response code.");
        
		FrameworkLogger.logStep("verifyNoDuplicateInMergeSummaryResponse:-> End");
	}
	
	 protected ValidatableResponse triggerGetApiDuplicateContactsSummaryNegative( Map<String, String> headerMap) throws IOException {
	        FrameworkLogger.logStep("triggerGetApiDuplicateContactsSummary -> Start");
	       String strApiUrl= getDuplicateContactsSummaryURL();
			//Call method to trigger GET API.
			ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
	        FrameworkLogger.logStep("triggerGetApiDuplicateContactsSummary -> End");
	        return response;
	    }
}