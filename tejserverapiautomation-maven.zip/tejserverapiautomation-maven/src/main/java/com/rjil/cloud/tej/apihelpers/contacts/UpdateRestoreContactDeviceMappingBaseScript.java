package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.RestoreContactsConstants;
import com.rjil.cloud.tej.apiconstants.UpdateRestoreContactDeviceMappingConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;

/**
 * @author Chandrashekhar Singh
 * 
 *         Base script for UpdateRestoreContactDeviceMapping API.
 * */

public class UpdateRestoreContactDeviceMappingBaseScript extends BaseTestScript {
	protected static final String apiName = "UpdateRestoreContactDeviceMappingAPI";
	protected String jsonBody;
	

	public UpdateRestoreContactDeviceMappingBaseScript(){
  		globalApiName=apiName;
  	}
	/**
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         It creates the url for API
	 */
	protected String getUpdateRestoreContactDeviceMappingApiUrl() {
		return apiUrls.get("baseContactURL")
				+ serverConfig.get("updateRestoreContactDeviceMappingApiUrl");
	}

	/**
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         It loads the default JSON body.
	 */

	protected void loadJsonFile() {
		FrameworkLogger.logStep("loadJsonFile:-> Start");
		// load json file
		String filePath = "/resources/updateRestoreContactDeviceMappingTestData/updateRestoreContactDeviceMappingApiJsonBody.js";
		jsonBody = loadJsonFile(filePath);

		FrameworkLogger.logStep("loadJsonFile:-> End");
	}

    /**
     * @author Chandrashekhar Singh
     * <p>
     * It will set the value on provided json path
     * @throws ParseException 
     */
    protected void setUpdateRestoreContactDeviceMappingInfoInJsonFile(String strSnapshotId, String strDeviceIds) throws ParseException {
		FrameworkLogger.logStep("setUpdateRestoreContactDeviceMappingInfoInJsonFile:-> Start");

		setJsonBody(UpdateRestoreContactDeviceMappingConstants.getSnapshotIdJsonPath(), strSnapshotId);
		setJsonBody(UpdateRestoreContactDeviceMappingConstants.getDevicesIdFirstLocationJsonPath(), strDeviceIds);
		
		FrameworkLogger.logStep("setUpdateRestoreContactDeviceMappingInfoInJsonFile:-> End");
    }

	/**
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         It will set the value on provided json path
	 */
	private void setJsonBody(String jsonPath, String value) {
		FrameworkLogger.logStep("setJsonBody:-> Start");
		jsonBody = setJsonData(jsonPath, value, jsonBody);

		FrameworkLogger.logStep("setJsonBody:-> End");
	}


	/**
	 * @return validatable response for API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the API and return the Response
	 */
	protected ValidatableResponse triggerPutApiUpdateRestoreContactDeviceMapping() {
		FrameworkLogger
				.logStep("triggerPutApiUpdateRestoreContactDeviceMapping:-> Start");

		String strApiUrl=getUpdateRestoreContactDeviceMappingApiUrl();
		//Call method to trigger PUT API.
		ValidatableResponse response = triggerPutApi(strApiUrl,headerMap,jsonBody);
		
		FrameworkLogger
				.logStep("triggerPutApiUpdateRestoreContactDeviceMapping:-> End");

		return response;
	}
	

/**
 * @return validatable response for API
 * @author Chandrashekhar Singh
 *         <p>
 *         Call the API and return the Response
 * @throws ParseException 
 * @throws IOException 
 */
public static ValidatableResponse triggerUpdateRestoreContactDeviceMappingServiceMethod(String strSnapshotId, String strDeviceIds) throws ParseException, IOException {
	FrameworkLogger
			.logStep("triggerUpdateRestoreContactDeviceMappingServiceMethod:-> Start");

	String strDeviceId1=serverConfig.get("deviceKey");
	//Calling the method with deviceMap.
	ValidatableResponse response = triggerUpdateRestoreContactDeviceMappingServiceMethod(deviceContributorInfo, strSnapshotId, strDeviceIds);

/*		UpdateRestoreContactDeviceMappingBaseScript apiObj=new UpdateRestoreContactDeviceMappingBaseScript();
	
	apiObj.loadJsonFile();

	apiObj.setUpdateRestoreContactDeviceMappingInfoInJsonFile(strSnapshotId, strDeviceIds);

	apiObj.createHeader();
	
	ValidatableResponse response=apiObj.triggerPutApiUpdateRestoreContactDeviceMapping();

*/		FrameworkLogger
			.logStep("triggerUpdateRestoreContactDeviceMappingServiceMethod:-> End");

	return response;
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * @return validatable response for API
	 * @author Chandrashekhar Singh
	 *         <p>
	 *         Call the API and return the Response
	 * @throws ParseException 
	 * @throws IOException 
	 */
	public static ValidatableResponse triggerUpdateRestoreContactDeviceMappingServiceMethod(Map<String, String>deviceInfoMap, String strSnapshotId, String strDeviceIds) throws ParseException, IOException {
		FrameworkLogger
				.logStep("triggerUpdateRestoreContactDeviceMappingServiceMethod:-> Start");

		UpdateRestoreContactDeviceMappingBaseScript apiObj=new UpdateRestoreContactDeviceMappingBaseScript();
		
		apiObj.loadJsonFile();

		apiObj.setUpdateRestoreContactDeviceMappingInfoInJsonFile(strSnapshotId, strDeviceIds);

		apiObj.createHeader(deviceInfoMap);
		
		ValidatableResponse response=apiObj.triggerPutApiUpdateRestoreContactDeviceMapping();

		FrameworkLogger
				.logStep("triggerUpdateRestoreContactDeviceMappingServiceMethod:-> End");

		return response;
	}

	//Verify success status.
	public static void verifyUpdateRestoreContactDeviceMappingSuccessMessageServiceMethod(ValidatableResponse response, int intExpCode, String strExpStatus) throws VerificationFailException{
		FrameworkLogger.logStep("verifyUpdateRestoreContactDeviceMappingSuccessMessageServiceMethod:-> Start");
		
		//Read the actual information from Response
		int intActStatus = response.extract().statusCode();	//200

		String strActCode = response.extract().path("status");

		//Validating the Actual and Expected information
		Verify.verifyEquals(strActCode, strExpStatus,
				"Verifying the response code.");
		Verify.verifyEquals(intActStatus, intExpCode,
				"Validating the Expected and Actual 'HTTP Codes for Error'.");

		FrameworkLogger.logStep("verifyUpdateRestoreContactDeviceMappingSuccessMessageServiceMethod:-> End");
	}

	public int getLatestRecordIndexValue(ValidatableResponse restoreContactSummaryResponse) throws ParseException, VerificationFailException, java.text.ParseException, IOException
	{
		FrameworkLogger.logStep("getLatestRecordIndexValue:-> Start");
		int  sizeOfContactsArray =	restoreContactSummaryResponse.extract().jsonPath().getList("restoreSummary").size();
		int latestRecordIndex = sizeOfContactsArray-1;
	/*	System.out.println("sizeOfContactsArray="+sizeOfContactsArray);
		System.out.println("latestRecordIndex="+latestRecordIndex);
		String snapshotId = restoreContactSummaryResponse.extract().path("restoreSummary["+latestRecordIndex+"].snapshotid");
		System.out.println("snapshot id of latest record="+snapshotId);*/
		FrameworkLogger.logStep("getLatestRecordIndexValue:-> End");
		return latestRecordIndex;
		
	}
	
	public static boolean verifyContactIdPresentInResponse(ValidatableResponse response, String serGuid) throws IOException
	{
		FrameworkLogger.logStep("verifyContactIdPresentInResponse:-> Start");
	    boolean contactidFound = false;

		int  sizeOfContactsArray =	response.extract().jsonPath().getList("contacts").size();
		for(int i=0;i<sizeOfContactsArray;i++)
		{
			String contactid = response.extract().path("contacts["+i+"].contactid");
			FrameworkLogger.logStep(i+"-> contactid:->"+contactid+",comparing with serGuid: "+serGuid);
			if (contactid.equalsIgnoreCase(serGuid))
			{
				FrameworkLogger.logStep("FOUND");
				contactidFound=true;
				break;
			}
		}
		FrameworkLogger.logStep("searchSerGuidAndGetIndexValue:-> End");
		return contactidFound;
	}
}
