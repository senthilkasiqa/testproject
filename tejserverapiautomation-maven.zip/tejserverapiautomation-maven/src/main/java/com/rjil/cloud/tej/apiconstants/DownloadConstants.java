/**
 * 
 */
package com.rjil.cloud.tej.apiconstants;

/**
 * @author Prateek
 *
 */
public class DownloadConstants {
	
	public static String getObjects(int index){
        return "$.objects["+index+"]";
    }
}
