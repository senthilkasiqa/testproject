package com.rjil.cloud.mailchamp.common.helper;

public class DeleteUserAccountBaseClass extends MailChampBaseTestScript {
	
/*	protected Map<String, String> createHeaderMap() {
		System.out.println("create Header from DeleteUserAccountBaseClass");

		Map<String, String> headerMap = initializeHeaderMap(getValueFromEnvConfig("userEmail"));
		return headerMap;

	}
*/
	protected String getDeleteUserUrl() {
		String baseUrl = getValueFromEnvConfig("baseURL");
		String subUrl = getValueFromProjectConfig("deleteUserURL");	
		return baseUrl + subUrl;
		}
}
