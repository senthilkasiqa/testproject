package com.rjil.cloud.tej.apihelpers.nms;

import static com.jayway.restassured.RestAssured.given;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class GetTrashMetadataBaseScript extends BaseTestScript{
	/**
	 * @author Sanjeevanee.Kanase
	 *class for having methods - for creating headers, get url for calling get trash metadata url, and getting response for api
	 */

//		protected  Map<String, String> headerMap = null;
	protected static final String apiName = "GetTrashMetadata";
	
	public GetTrashMetadataBaseScript(){
		globalApiName=apiName;
	}
	// created a Hashmap to save all the headers.
/*	protected  void createHeader() {

		FrameworkLogger.logStep("createHeader:-> Start");
		headerMap=new HashMap<>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");

		//Add 'X-Api-Key' in header for the API.
		addXapiHeaderKey(headerMap);

		FrameworkLogger.logStep("createHeader:-> End");
	}
*/
	/**get a complete url for 'get Trash Metadata API'
	 * @return
	 */
	protected String getTrashMetatadataURL() {
		FrameworkLogger.logStep("getTrashMetatadataURL: Start");
		return getTrashMetatadataURL(serverConfig.get("getTrashMetadataURL"));
	//	return apiUrls.get("baseURL") + serverConfig.get("getTrashMetadataURL");
	}
	
	/**get a complete url for 'get Trash Metadata API'
	 * @return
	 */
	protected String getTrashMetatadataURL(String url) {
		FrameworkLogger.logStep("getTrashMetatadataURL: Start");
		return (apiUrls.get("baseURL") + url);
	}


	/**
	 * Method to get getTrashMetadata Response
	 * @return getTrashMetadata validatable response
	 */
	protected ValidatableResponse triggerGetApiGetTrashMetadata() throws IOException {

/*		ValidatableResponse response = given()
				.headers(headerMap)
				.log().all()
				.when()
				.get(getTrashMetatadataURL())
				.then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/		
		FrameworkLogger.logStep("triggerGetApiGetTrashMetadata: Start");
		
//		String strApiUrl=getTrashMetatadataURL();
		//Call method to trigger GET API.
		
		ValidatableResponse response = triggerGetApiGetTrashMetadata(serverConfig.get("getTrashMetadataURL"));
		
		FrameworkLogger.logStep("triggerGetApiGetTrashMetadata: End");
		return response;

	}
	
	/**
	 * Method to get getTrashMetadata Response
	 * @return getTrashMetadata validatable response
	 */
	protected ValidatableResponse triggerGetApiGetTrashMetadata(String url) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetTrashMetadata: Start");
/*		ValidatableResponse response = given()
				.headers(headerMap)
				.log().all()
				.when()
				.get(getTrashMetatadataURL())
				.then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/		
		
		String strApiUrl=getTrashMetatadataURL(url);
		//Call method to trigger GET API.
		
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
		FrameworkLogger.logStep("triggerGetApiGetTrashMetadata: End");
		return response;

	}

	/**
	 * method to check that objectKey of uploaded file (using file upload api) is present in the response of getMetadata api.
	 * @param response - response of getMetadata API
	 * @param strObjectKey - objectKey of uploaded file
	 * @return boolean value - true: if objectKey of uploaded file is found in response of getmetadata api else false
	 * @throws IOException
	 */
	public static Boolean isObjectKeyPresentInResponse(ValidatableResponse response, String strObjectKey) throws IOException
	{
		FrameworkLogger.logStep("isObjectKeyPresentInResponse: Start");
		boolean isObjectKeyMatching = false;

		int  sizeOfOjectArray =	response.extract().jsonPath().getList("objects").size();
		for(int i=0;i<sizeOfOjectArray;i++)
		{
			String objectKey = response.extract().path("objects["+i+"].objectKey");
			if (objectKey.equalsIgnoreCase(strObjectKey))
			{
				 isObjectKeyMatching=true;
			}
		}
		FrameworkLogger.logStep("isObjectKeyPresentInResponse: End");
		return isObjectKeyMatching;
	}
	
	public static Object getResponseValuePresentInResponse(ValidatableResponse response, String strObjectKey, Object parameterKey) throws IOException
	{
		FrameworkLogger.logStep("getResponseValuePresentInResponse: Start");
		boolean isObjectKeyMatching = false;
		Object parameterValue = null;
		int  sizeOfOjectArray =	response.extract().jsonPath().getList("objects").size();
		for(int i=0;i<sizeOfOjectArray;i++)
		{
			String objectKey = response.extract().path("objects["+i+"].objectKey");
			if (objectKey.equalsIgnoreCase(strObjectKey))
			{
				 isObjectKeyMatching=true;
				  parameterValue = response.extract().path("objects["+i+"]."+parameterKey);	
				  break;
			}
		
		}
		FrameworkLogger.logStep("getResponseValuePresentInResponse: End");
		return parameterValue;
	}
}
