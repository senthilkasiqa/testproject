package com.rjil.cloud.mailchamp.common.enums;

public enum HeaderParameters {
	CONTENTTYPE("Content-Type"),
	XDEVICEKEY("X-Device-Key"),
	AUTHORIZATION("Authorization"),
	ACCEPTLANGUAGE("Accept-Language"),
	//XCODE("xCode"),
	XCODE("X-Offline-Code"),
	XUSERID("X-User-Id"),
	XMCSACCESSTOKEN("Authorization"),
	XAPIKEY("X-Api-Key"),
	XSUBSCRIPTIONTYPE("Subscription-Type"),
	XSUBSCRIPTIONKEY("Subscription-Key"),
	XEMAILID("X-Email-Id");
	
	
	
	
	   public String value;

	   HeaderParameters(String value) {
	       this.value = value;

	   }

	   public String getValue() {
	       return value;
	   }
	
}
