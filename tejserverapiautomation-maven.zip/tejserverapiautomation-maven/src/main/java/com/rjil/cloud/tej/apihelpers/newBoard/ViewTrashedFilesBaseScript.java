/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.newBoard;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boards.DeleteBoardFileBaseScript;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author Prateek
 *
 */
public class ViewTrashedFilesBaseScript extends BaseTestScript{

	protected static final String apiName = "ViewTrashedFiles";

	protected ViewTrashedFilesBaseScript() {
		globalApiName = apiName;
	}
	
	protected Map<String, String> createHeader(String limit,String ifModifiedSince) {
		headerMap = initializeHeader();
	//	headerMap.put(HeaderParameters.XSHARDKEY.getValue(), shardKey);
	//	headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(), ifModifiedSince);
	//	headerMap.put(HeaderParameters.LIMIT.getValue(), limit);
		return headerMap;
	}

	protected String getViewTrashedFileUrl(String urlValue) {
		FrameworkLogger.logStep(" getCommentsUrl:-> Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get(urlValue);
		FrameworkLogger.logStep("getCommentsUrl: End");
		return url;
	}
	
	protected ValidatableResponse triggerGetApiViewTrashedFiles(String urlValue) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetComments:-> Start");
		String strApiUrl = getViewTrashedFileUrl(urlValue);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetComments:-> End");
		return response;
	}

	public static ValidatableResponse ViewTrashedFileServiceMethod(String urlValue) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("ViewTrashedFileServiceMethod: Start");
		
		ViewTrashedFilesBaseScript viewTrash = new ViewTrashedFilesBaseScript();
		viewTrash.createHeader();
		ValidatableResponse response = viewTrash.triggerGetApiViewTrashedFiles(urlValue);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("ViewTrashedFileServiceMethod: End");
		return response;
	}
	
	
	public static ValidatableResponse getDeleteBoardFileURLServiceMethod(Map<String, String> headerMap1,String urlValue) throws IOException, VerificationFailException {
		FrameworkLogger.logStep("getDeleteBoardFileURLServiceMethod: Start");
		ViewTrashedFilesBaseScript viewTrash = new ViewTrashedFilesBaseScript();
		viewTrash.createHeader(headerMap1);
		ValidatableResponse response = viewTrash.triggerGetApiViewTrashedFiles(urlValue);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("getDeleteBoardFileURLServiceMethod: End");
		return response;
	}
}
