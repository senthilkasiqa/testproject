/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boardcomments;

import java.io.IOException;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

/**
 * @author Prateek
 * 
 * Base class for delete comment api
 *
 */
public class DeleteCommentBaseScript extends BaseTestScript{
	
	protected static final String apiName = "DeleteComments";

	protected DeleteCommentBaseScript() {
		globalApiName = apiName;
	}
	
	protected Map<String, String> createHeader() {
		headerMap = initializeHeader();
	//	headerMap.put(HeaderParameters.XSHARDKEY.getValue(), shardKey);
		
		return headerMap;
	}
	
	protected String deleteCommentsUrl(String urlValue,String boardKey,String commentKey) {
		FrameworkLogger.logStep(" getCommentsUrl:-> Start");
		String url = apiUrls.get("boardUrl") + serverConfig.get(urlValue).replace("{boardKey}", boardKey);
		String deleteCommentUrl=url.replace("{commentKey}", commentKey);
		FrameworkLogger.logStep("getCommentsUrl: End");
		return deleteCommentUrl;
	}
	
	protected ValidatableResponse triggerDeleteApiDeleteComments(String boardKey,String commentKey) throws IOException {
		FrameworkLogger.logStep("triggerDeleteApiDeleteComments:-> Start");
		String strApiUrl = deleteCommentsUrl("deleteCommentUrl", boardKey,commentKey);
		ValidatableResponse response = triggerDeleteApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerDeleteApiDeleteComments:-> End");
		return response;
	}
	
	protected ValidatableResponse triggerDeleteApiDeleteComments(String boardKey,String commentKey,boolean value) throws IOException {
		FrameworkLogger.logStep("triggerDeleteApiDeleteComments:-> Start");
		String strApiUrl = deleteCommentsUrl("deleteCommentUrl", boardKey,commentKey);
		ValidatableResponse response = triggerDeleteApi(strApiUrl, headerMap,value);
		FrameworkLogger.logStep("triggerDeleteApiDeleteComments:-> End");
		return response;
	}
	
	protected ValidatableResponse triggerDeleteApiDeleteComments(String boardKey,String commentKey,Map<String,String> deviceInfo) throws IOException {
		FrameworkLogger.logStep("triggerDeleteApiDeleteComments:-> Start");
		String strApiUrl = deleteCommentsUrl("deleteCommentUrl", boardKey,commentKey);
		Map<String, String> headerMap= createHeader(deviceInfo);
		ValidatableResponse response = triggerDeleteApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerDeleteApiDeleteComments:-> End");
		return response;
	}
	
	
	public static void deleteCommentServiceMethod(String boardKey,String commentKey){
		FrameworkLogger.logStep("triggerDeleteApiDeleteComments:-> Start");
		DeleteCommentBaseScript deleteCommentBaseScript= new DeleteCommentBaseScript();
		String strApiUrl = deleteCommentBaseScript.deleteCommentsUrl("deleteCommentUrl", boardKey,commentKey);
		deleteCommentBaseScript.triggerDeleteApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerDeleteApiDeleteComments:-> End");
	}

	public static void deleteCommentServiceMethod(String boardKey,String commentKey, Map<String,String> deviceInfo ) throws IOException{
		FrameworkLogger.logStep("triggerDeleteApiDeleteComments:-> Start");
		DeleteCommentBaseScript deleteCommentBaseScript= new DeleteCommentBaseScript();
		deleteCommentBaseScript.triggerDeleteApiDeleteComments(boardKey, commentKey, deviceInfo);
		FrameworkLogger.logStep("triggerDeleteApiDeleteComments:-> End");
	}

	
}
