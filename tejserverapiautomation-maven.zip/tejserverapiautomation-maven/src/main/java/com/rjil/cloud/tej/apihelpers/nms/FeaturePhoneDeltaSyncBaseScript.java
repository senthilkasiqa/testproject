
package com.rjil.cloud.tej.apihelpers.nms;

import static com.jayway.restassured.RestAssured.given;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;

import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.NmsParameters;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Prateek
 * 
 *         Base class for delta sync api
 *
 */
public class FeaturePhoneDeltaSyncBaseScript extends BaseTestScript {

	protected static final String apiName = "DeltaSync";
	protected static final int MILLIS_IN_ONE_MINUTE = 10;
//	protected Map<String, String> headerMap = null;
	
	public FeaturePhoneDeltaSyncBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * Create Header Parameters to be passed for the API request
	 */

/*	protected void createHeader() {
		headerMap = new HashMap<>();
		headerMap.put("Content-Type", "application/json");
		headerMap.put(NmsParameters.XUSERID.getValue(), userId);
		headerMap.put(NmsParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(NmsParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(NmsParameters.ACCEPTLANGUAGE.getValue(), "en");
		headerMap.put(NmsParameters.IFMODIFIEDSINCE.getValue(),
				Utils.getTimePriorCurrentTime(MILLIS_IN_ONE_MINUTE).toString());

		// Add X-api header key
		addXapiHeaderKey(headerMap);

	}
*/

	// Overload the method.
	protected Map<String, String> createHeader(String ifModifiedSince) {
		FrameworkLogger.logStep("createHeader -> Start");

		headerMap = initializeHeader();

		// Add additional header parameters.
		headerMap.put(HeaderParameters.IFMODIFIEDSINCE.getValue(),
				ifModifiedSince	);

		FrameworkLogger.logStep("createHeader -> End");
		return headerMap;
	}

	/**
	 * get url for NMS Delta Sync
	 * 
	 * @return url String
	 */

	protected String featurePhoneDeltfeaturePhoneDeltaSyncUrlaSyncUrl() {
		FrameworkLogger.logStep("getDeltaSyncFeaturePhoneURL: Start");
		//String url = apiUrls.get("baseURL") + serverConfig.get("deltaSyncUrl");
		String url=featurePhoneDeltaSyncUrl("deltaSyncFeaturePhoneUrl");
		FrameworkLogger.logStep("featurePhoneDeltaSyncUrl: End");
		return url;
	}
	
	/**
	 * get url for NMS Delta Sync for negative scenarios
	 * 
	 * @return url String
	 */

	protected String featurePhoneDeltaSyncUrl(String url) {
		FrameworkLogger.logStep("featurePhoneDeltaSyncUrl: Start");
		String deltaSyncApiUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		FrameworkLogger.logStep("featurePhoneDeltaSyncUrl: End");
		return deltaSyncApiUrl;
	}
	
	/**
	 * get url for NMS Delta Sync for negative scenarios with limit parameter
	 * 
	 * @return url String
	 */

	protected String featurePhoneDeltaSyncUrl(String url,String limit) {
		FrameworkLogger.logStep("getDeltaSyncURL: Start");
		String deltaSyncApiUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		String deltaSyncApiUrl1=deltaSyncApiUrl.replace("{limit}", limit);
		FrameworkLogger.logStep("getDeltaSyncURL: End");
		return deltaSyncApiUrl1;
	}
	
	/**
	 * get url for NMS Delta Sync for negative scenarios with page parameter
	 * 
	 * @return url String
	 */

	protected String featurePhoneDeltaSyncWithPageInUrl(String url,String page) {
		FrameworkLogger.logStep("getDeltaSyncURL: Start");
		//String deltaSyncApiUrl = apiUrls.get("baseURL") + serverConfig.get(url);
		String deltaSyncApiUrl=featurePhoneDeltaSyncUrl(url).replace("{page}", page);
		FrameworkLogger.logStep("getDeltaSyncURL: End");
		return deltaSyncApiUrl;
	}

	/**
	 * Method to get NMS Delta Sync Response
	 *
	 * @return Login validatable response
	 */
	protected ValidatableResponse getFeaturePhoneDeltaSyncApiResponse() {

		FrameworkLogger.logStep("getDeltaSyncApiResponse: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().get(getDeltaSyncUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/

		//Call method to trigger GET API.
		//ValidatableResponse response = triggerGetApi(getDeltaSyncUrl(),headerMap);
		
		ValidatableResponse response=getFeaturePhoneDeltaSyncApiResponse("deltaSyncFeaturePhoneUrl");

		FrameworkLogger.logStep("getDeltaSyncApiResponse: End");
		return response;
	}
	

	/**
	 * Method to get NMS Delta Sync Response
	 *
	 * @return Login validatable response
	 */
	protected ValidatableResponse getFeaturePhoneDeltaSyncApiResponse(String apiUrl) {

		FrameworkLogger.logStep("getDeltaSyncApiResponse: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().get(getDeltaSyncUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/
		
		String url=featurePhoneDeltaSyncUrl(apiUrl);
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(url,headerMap);

		FrameworkLogger.logStep("getDeltaSyncApiResponse: End");
		return response;
	}
	
	/**
	 * Method to get NMS Delta Sync Response with limit in url
	 *
	 * @return Login validatable response
	 */
	protected ValidatableResponse getFeaturePhoneDeltaSyncApiResponse(String apiUrl, String limit) {

		FrameworkLogger.logStep("getDeltaSyncApiResponse: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().get(getDeltaSyncUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/
		
		String url=featurePhoneDeltaSyncUrl(apiUrl,limit);
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(url,headerMap);

		FrameworkLogger.logStep("getDeltaSyncApiResponse: End");
		return response;
	}
	

	/**
	 * Method to get NMS Delta Sync Response with limit in url
	 *
	 * @return Login validatable response
	 */
	protected ValidatableResponse getFeaturePhoneDeltaSyncApiResponseWithPageInUrl(String apiUrl, String page) {

		FrameworkLogger.logStep("getDeltaSyncApiResponse: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().get(getDeltaSyncUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/
		
		String url=featurePhoneDeltaSyncWithPageInUrl(apiUrl,page);
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(url,headerMap);

		FrameworkLogger.logStep("getDeltaSyncApiResponse: End");
		return response;
	}
	
	

	/**
	 * Method to get NMS Delta Sync Response
	 *
	 * @return Login validatable response
	 */
	public ValidatableResponse getFeaturePhoneDeltaSyncApiService() {

		FrameworkLogger.logStep("getDeltaSyncApiService: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().get(getDeltaSyncUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/
		createHeader();
		//Call method to trigger GET API.
		//ValidatableResponse response = triggerGetApi(getDeltaSyncUrl(),headerMap);
		
		ValidatableResponse response=getFeaturePhoneDeltaSyncApiResponse("featurePhoneDeltaSyncUrl");

		FrameworkLogger.logStep("getDeltaSyncApiService: End");
		return response;
	}
	
	
	protected ValidatableResponse getFeaturePhoneDeltaSyncApiResponseForPageLinks(String apiUrl) {

		FrameworkLogger.logStep("getDeltaSyncApiResponse: Start");
/*		ValidatableResponse response = given().headers(headerMap).log().all().when().get(getDeltaSyncUrl()).then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/
		
		String url = apiUrls.get("baseURL") + apiUrl;
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(url,headerMap);

		FrameworkLogger.logStep("getDeltaSyncApiResponse: End");
		return response;
	}
}
