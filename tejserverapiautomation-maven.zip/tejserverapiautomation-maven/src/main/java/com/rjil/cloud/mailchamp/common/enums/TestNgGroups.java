package com.rjil.cloud.mailchamp.common.enums;

public class TestNgGroups {
	
	   public final static String SANITY = "Sanity";
	   public final static String REGRESSION = "Regression";


}
