
package com.rjil.cloud.tej.apihelpers.nms;

import static com.jayway.restassured.RestAssured.given;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.NmsParameters;


public class FeaturePhoneNmsInitialSyncBaseScript extends BaseTestScript {
	protected static final String apiName="FeaturePhoneNmsInitialSync";
//	protected Map<String, String> headerMap = null;

	public FeaturePhoneNmsInitialSyncBaseScript(){
		globalApiName=apiName;
	}
/*	protected void createHeader() {

		FrameworkLogger.logStep("createHeader: Start");
		headerMap = new HashMap<>();
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");
		addXapiHeaderKey(headerMap);
		FrameworkLogger.logStep("createHeader: End");
	}
*/
	/**
	 * get url for NMS Initial Sync
	 * 
	 * @return
	 */
	protected String getInitialSyncUrlForFeaturePhone() {
		FrameworkLogger.logStep("getInitialSyncUrlForFeaturePhone: Start");
		String url = apiUrls.get("baseURL") + serverConfig.get("initialSyncUrlFeaturePhone");
		FrameworkLogger.logStep("getInitialSyncUrlForFeaturePhone: End");
		return url;
	}
	

	/**
	 * get url for NMS Initial Sync for negative scenarios
	 * 
	 * @return
	 */
	protected String getInitialSyncUrlForFeaturePhone(String apiUrl) {
		FrameworkLogger.logStep("getInitialSyncUrlForFeaturePhone: Start");
		String url = apiUrls.get("baseURL") + serverConfig.get(apiUrl);
		FrameworkLogger.logStep("getInitialSyncUrlForFeaturePhone: End");
		return url;
	}

	/**
	 * Method to get NMS Initial Sync Response
	 *
	 * @return Login validatable response
	 */
	protected ValidatableResponse triggerGetApiNmsInitialSyncForFeaturePhone() {
		FrameworkLogger.logStep("triggerGetApiNmsInitialSync: Start");
		String url=getInitialSyncUrlForFeaturePhone();
		ValidatableResponse response=triggerGetApi(url, headerMap);
		FrameworkLogger.logStep("triggerGetApiNmsInitialSync: End");
		return response;
	}
	

	/**
	 * Method to get NMS Initial Sync Response With Invalid Url
	 *
	 * @return Login validatable response
	 */
	protected ValidatableResponse triggerGetApiNmsInitialSyncForFeaturePhone(String apiUrl) {
		FrameworkLogger.logStep("triggerGetApiNmsInitialSync: Start");
		String url= apiUrls.get("baseURL") + apiUrl;
		FrameworkLogger.logStep("URL========"+url);
		ValidatableResponse response=triggerGetApi(url, headerMap);
		FrameworkLogger.logStep("triggerGetApiNmsInitialSync: End");
		return response;
	}
	
	protected String getIndexIfObjectKeyPresentInResponseForFeaturePhone(ValidatableResponse response, String strObjectKeyValue)
			throws IOException {
		FrameworkLogger.logStep("getIndexIfObjectKeyPresentInResponse:-> start; strObjectKeyValue:-> " + strObjectKeyValue);
		int isObjectKeyMatchingIndex = -1;
		String nextLink = null;
		while(isObjectKeyMatchingIndex==-1)
		{
			int sizeOfOjectArray = response.extract().jsonPath().getList("objects").size();
			FrameworkLogger.logStep("sizeOfOjectArray:-> " + sizeOfOjectArray);
			
		for (int i = 0; i < sizeOfOjectArray; i++) 
		{
			String actualObjectKeyValue = response.extract().path("objects[" + i + "].objectKey");
			
			FrameworkLogger.logStep("Comparing strObjectKeyValue:-> " + strObjectKeyValue
					+ " With actualObjectKeyValue:-> " + actualObjectKeyValue);

			if (actualObjectKeyValue.equalsIgnoreCase(strObjectKeyValue)) {
				isObjectKeyMatchingIndex = i;
				FrameworkLogger.logStep("ObjectKeyValue matched.");
				break;
			}
			}
		if(isObjectKeyMatchingIndex==-1)
		{
		nextLink = response.extract().path("nextLink");
		response =  triggerGetApiNmsInitialSyncForFeaturePhone(nextLink);
		}
		//return isObjectKeyMatchingIndex;
		}
		FrameworkLogger.logStep("getIndexIfObjectKeyPresentInResponse:-> end");
		FrameworkLogger.logStep("index of file uploaded="+isObjectKeyMatchingIndex);
		return isObjectKeyMatchingIndex+":"+nextLink;
		
	}
	
	public String getMatchingIndex(String objectIndexAndUrl)
	{
		String matchedObjectIndex = objectIndexAndUrl.split(":")[0];
		return matchedObjectIndex;
		
	}
	
	public String getMatchingUrl(String objectIndexAndUrl)
	{
		String matchedObjectUrl = objectIndexAndUrl.split(":")[1];
		return matchedObjectUrl;
		
	}
	
	public String getValueForParameter(String objectIndexAndUrl, String key)
	
	{
		String matchedIndex = getMatchingIndex(objectIndexAndUrl);
		String matchedUrl = getMatchingUrl(objectIndexAndUrl);
		ValidatableResponse response =  triggerGetApiNmsInitialSyncForFeaturePhone(matchedUrl);
		String value = response.extract().path("objects["+matchedIndex+"]"+"."+key);
		return value;
	}
}
