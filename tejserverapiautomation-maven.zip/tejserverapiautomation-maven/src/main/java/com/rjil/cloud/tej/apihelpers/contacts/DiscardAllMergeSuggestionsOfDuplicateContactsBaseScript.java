package com.rjil.cloud.tej.apihelpers.contacts;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

import java.util.HashMap;
import java.util.Map;

import static com.jayway.restassured.RestAssured.given;
/**
 * @author Chandrashekhar Singh
 * 
 * Base script for Merge All Duplicate Contacts.
 * */

public class DiscardAllMergeSuggestionsOfDuplicateContactsBaseScript extends BaseTestScript {
    protected static final String apiName="DiscardAllMergeSuggestionsOfDuplicateContacts";
    public DiscardAllMergeSuggestionsOfDuplicateContactsBaseScript(){
		globalApiName=apiName;
	}
   
    /**
     * @author Chandrashekhar Singh
     * <p>
     * It creates the url for API
     */
    protected String getDiscardAllMergeSuggestionsOfDuplicateContactsUrl() {
        return apiUrls.get("baseContactURL") + serverConfig.get("discardAllDuplicateContactsURL");
    }


    /**
     * @return validatable response for Merge Summary
     * @author Chandrashekhar Singh
     * <p>
     * Call the API and return the Response
     */
    protected ValidatableResponse triggerDeleteApiDiscardAllMergeSuggestionsOfDuplicateContacts() {
		FrameworkLogger.logStep("deleteDiscardAllMergeSuggestionsOfDuplicateContacts:-> Start");
		String strApiUrl=getDiscardAllMergeSuggestionsOfDuplicateContactsUrl();
		
		//Call method to trigger DELETE API.
    	ValidatableResponse response=triggerDeleteApi(strApiUrl, headerMap);

        FrameworkLogger.logStep("deleteDiscardAllMergeSuggestionsOfDuplicateContacts:-> End");

        return response;
    }

    /**
     * 
     * @author Chandrashekhar Singh
     * <p>
     * Method to verify the success message in Discard All response.
     * @throws VerificationFailException 
     */
    public static void verifySuccessForDiscardAllAPIResponse(ValidatableResponse response) throws VerificationFailException{

        FrameworkLogger.logStep("verifySuccessForDiscardAllAPIResponse:-> Start");

    	//Set the expected error information.
		String strExpectedResponseStatus = "SUCCESS";
		String strExpectedResponseCode = "TEJAG0201";
		int strExpectedHttpResponse = ApiResponseCodes.RESPONSECODE200.getValue();
		String strExpectedMessage = "Discard done successfully.";

		//      Get and verify the status code.
		int strActualHttpResponse = response.extract().statusCode();
		String strActualMessage = response.extract().path("message");
		String strActualResponseStatus = response.extract().path("status");
		String strActualCode = response.extract().path("code");
		
		//      Validating the response.
		Verify.verifyEquals(strActualHttpResponse,strExpectedHttpResponse, "Verify Success HTTP Response code for DiscardAll.");
		Verify.verifyEquals(strActualResponseStatus,strExpectedResponseStatus, "Verify Success Response Status for DiscardAll.");
		Verify.verifyEquals(strActualMessage,strExpectedMessage, "Verify Success Response message for DiscardAll.");
		Verify.verifyEquals(strActualCode,strExpectedResponseCode, "Verify Success Response code for DiscardAll.");

        FrameworkLogger.logStep("verifySuccessForDiscardAllAPIResponse:-> End");
    }

    /**
     * 
     * @author Chandrashekhar Singh
     * <p>
     * Method to verify the error message in Discard All response.
     * @throws VerificationFailException 
     */
    public static void verifyErrorForDiscardAllAPIResponse(ValidatableResponse response) throws VerificationFailException{

        FrameworkLogger.logStep("verifyErrorForDiscardAllAPIResponse:-> Start");

    	//Set the expected error information.
		String strExpectedResponseCode = "TEJAG0407";
		int strExpectedHttpResponse = ApiResponseCodes.RESPONSECODE400.getValue();
		String strExpectedMessage = "no merge suggestions available for discard";

		//      Get and verify the status code.
		int strActualHttpResponse = response.extract().statusCode();
		String strActualErrorMessage = null;
		String strActualErrorsMessage = null;
		String strActualCode = null;
		
		try{
		strActualErrorMessage = response.extract().path("error");
		}catch(Exception e){
			strActualErrorMessage = "Not able to read 'error' from response";
		}

		try{
			strActualErrorsMessage = response.extract().path("errors[0]");
		}catch(Exception e){
			strActualErrorsMessage = "Not able to read 'errors[0]' from response";
		}

		try{
			strActualCode = response.extract().path("code");
		}catch(Exception e){
			strActualCode = "Not able to read 'code' from response";
		}

		//      Validating the response.
		Verify.verifyEquals(strActualErrorMessage,strExpectedMessage, "Verify Error Response message for DiscardAll.");
		Verify.verifyEquals(strActualErrorsMessage,strExpectedMessage, "Verify Errors Response message for DiscardAll.");
		Verify.verifyEquals(strActualCode,strExpectedResponseCode, "Verify Error Response code for DiscardAll.");
		Verify.verifyEquals(strActualHttpResponse,strExpectedHttpResponse, "Verify Error HTTP Response code for DiscardAll.");

        FrameworkLogger.logStep("verifyErrorForDiscardAllAPIResponse:-> End");
    }
}
