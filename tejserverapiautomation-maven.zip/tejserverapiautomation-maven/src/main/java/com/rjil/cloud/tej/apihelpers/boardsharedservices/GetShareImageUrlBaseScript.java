/**
 * 
 */
package com.rjil.cloud.tej.apihelpers.boardsharedservices;

import java.io.File;
import java.io.IOException;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 * 
 * Base class for get share image url base script
 *
 */
public class GetShareImageUrlBaseScript extends BaseTestScript{
	
	protected String getShareImageUrlJsonBody;
	protected static final String apiName = "GetShareImageUrl";
	
	public GetShareImageUrlBaseScript(){
		globalApiName=apiName;
	}

	/**
	 * get a complete url for 'Get Share Image API'
	 * 
	 * @return
	 */

	protected String getShareImageUrl() {

		FrameworkLogger.logStep("getShareImageUrl:-> Start");
		String aplURL = apiUrls.get("URL") + serverConfig.get("getSharedImageUrl").replace("{shareKey}",
				repositoryMap.get(RepositoryParameterEnum.SHAREKEY.getValue()));
		
		String strXapiKeyValue=apiUrls.get("xApiKeyValue");
		String shardKey=repositoryMap.get(RepositoryParameterEnum.SHARDKEY.getValue());
		  FrameworkLogger.logStep("aplURL : - > "+ aplURL + "; strXapiKeyValue : - > "+ strXapiKeyValue + "; shardKey : - > " + shardKey);
		String getShareImageUrl = aplURL.replace("{shardKey}", repositoryMap.get(RepositoryParameterEnum.SHARDKEY.getValue())).replace("{apiKey}", apiUrls.get("xApiKeyValue"));
		FrameworkLogger.logStep("AccessPublicLinkUrl=========>" + getShareImageUrl);
		FrameworkLogger.logStep("getShareImageUrl : End");
		return getShareImageUrl;
	}
	

	/**
	 * get a complete url for 'create a public link API'
	 * 
	 * @return
	 */

	protected String getShareImageUrl(String shareKey,String shardKeyValue) {

		FrameworkLogger.logStep("getShareImageUrl:-> Start");
		String aplURL = apiUrls.get("URL") + serverConfig.get("getSharedImageUrl").replace("{shareKey}",
				shareKey);
		
		String strXapiKeyValue=apiUrls.get("xApiKeyValue");
		String shardKey=shardKeyValue;
		 FrameworkLogger.logStep("aplURL : - > "+ aplURL + "; strXapiKeyValue : - > "+ strXapiKeyValue + "; shardKey : - > " + shardKey);
		String getShareImageUrl = aplURL.replace("{shardKey}", shardKey).replace("{apiKey}", apiUrls.get("xApiKeyValue"));
		FrameworkLogger.logStep("AccessPublicLinkUrl=========>" + getShareImageUrl);
		FrameworkLogger.logStep("getShareImageUrl : End");
		return getShareImageUrl;
	}

	/*protected String getShareImageUrl(String urlKey) {
		FrameworkLogger.logStep("getShareImageUrl with parameter :-> Start");
		return apiUrls.get("baseURL") + serverConfig.get(urlKey);
	}
*/
	/**
	 * Method to get the response after triggering Get All Shared Image Url
	 * API
	 */
	protected ValidatableResponse triggerGetApiGetShareImageUrl() throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetAllSharedPublicLink:-> Start");
		String strApiUrl = getShareImageUrl();
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetAllSharedPublicLink:-> End");
		return response;
	}

	/**
	 * Method to get the response after triggering Get All Shared Image Url
	 * API
	 */
	protected ValidatableResponse triggerGetApiGetShareImageUrlForNegativetest(String shareKey,String shardKey) throws IOException {
		FrameworkLogger.logStep("triggerGetApiGetAllSharedPublicLink:-> Start");
		String strApiUrl = getShareImageUrl(shareKey, shardKey);
		ValidatableResponse response = triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiGetAllSharedPublicLink:-> End");
		return response;
	}
	
}
