package com.rjil.cloud.tej.enums;

/**
 * @author c.singh1
 * 
 * API Response Success Codes Enum
 *
 */

public enum ApiSuccessResponseCodes {

    SUCCESSCODE_TEJAB0201("TEJAB0201"),
    SUCCESSCODE_TEJAB0202("TEJAB0202"),
    SUCCESSCODE_TEJAB0203("TEJAB0203"),
    SUCCESSCODE_TEJAB0204("TEJAB0204"),
    SUCCESSCODE_TEJAB0205("TEJAB0205");

    public String value;

    ApiSuccessResponseCodes(String value) {
        this.value = value;

    }

    public String getValue()
    {
        return value;
    }
}

