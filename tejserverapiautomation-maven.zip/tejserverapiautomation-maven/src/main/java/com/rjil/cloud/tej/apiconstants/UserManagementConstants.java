package com.rjil.cloud.tej.apiconstants;

import java.util.UUID;

/**
 * Add Idam account Constants Class
 */

public class UserManagementConstants {

    public static String getidamUnique() {
        return "$.idamUnique";
    }

    public static String getemailId() {
        return "$.emailId";
    }

    public static String getfirstName() {
        return "$.firstName";
    }

    public static String getlastName() {
        return "$.lastName";
    }

    public static String getmobileNumber() {
        return "$.mobileNumber";
    }

    public static String getfeatureCode() {
        return "$.featureCode";
    }

    public static String getcountry() {
        return "$.country";
    }

    public static String getlanguage() {
        return "$.language";
    }

    public static String gettimeZone() {
        return "$.timeZone";
    }
    
    public static String getObjectKey(){
    	return "$.objectKey";
    }
    
    public static String getbackupPhotos(){
    	return "$.backupPhotos";
    }
    
    public static String getbackupVideos(){
    	return "$.backupVideos";
    }
    
    public static String getbackupAudios(){
    	return "$.backupAudios";
    }
    
    public static String getbackupDocuments(){
    	return "$.backupDocuments";
    }
    
    public static String getbackupContacts(){
    	return "$.backupContacts";
    }
    
    public static String getbackupMessages(){
    	return "$.backupMessages";
    }
    
    public static String getbackupCallLogs(){
    	return "$.backupCallLogs";
    }
    
    public static String getinternetMode(){
    	return "$.internetMode";
    }
    
    public static String getlastBackUpTime(){
    	return "$.lastBackUpTime";
    }

    public static String getRefreshToken(){
    	return "$.refreshToken";
    }
    
    public static String getAuthProviderToken(){
    	return "$.authProviderToken";

    }
    
    public static String getUsedSpace(){
    	return "$.usedSpace";
    }
    
    public static String getOperation(){
    	return "$.operation";
    }
    
    public static String getMimeType(){
    	return "$.mimeType";
    }
}
