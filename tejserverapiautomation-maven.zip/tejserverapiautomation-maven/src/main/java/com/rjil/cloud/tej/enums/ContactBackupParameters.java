package com.rjil.cloud.tej.enums;

/**
 * @author: Chandra
 * 
 * ContactBackup Parameter Enum
 */
public enum ContactBackupParameters {
    ACTTRANID("actTranId"),
    HASMORE("hasMore"),
    ISFIRSTTIME("isFirstTime"),
    TOTALRECORDS("totalRecords"),
    DGUID("dguid"),
    OPERATION("operation"),
    CONSRCTYPE("conSrcType"),
    CONSRCNAME("conSrcName");

    public String value;

    ContactBackupParameters(String value) {
        this.value = value;

    }

    public String getValue() {
        return value;
    }
}

