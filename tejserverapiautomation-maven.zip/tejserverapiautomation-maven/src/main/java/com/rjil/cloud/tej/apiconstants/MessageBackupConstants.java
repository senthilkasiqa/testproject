package com.rjil.cloud.tej.apiconstants;

public class MessageBackupConstants {

	    public static String getMessagesJsonPath() {
	        return "$.messages";
	    }

	    public static String getFirstMessageJsonPath() {
	        return "$.messages[0]";
	    }
	    
	    public static String getNMessagesJsonPath(int msgIndex) {
	    	System.out.println("Valu of index inside Contacts="+msgIndex);
	        return "$.messages["+msgIndex+"]";
	    }

	    public static String getFirstMessagedvcMsgIdJsonPath() {
	        return "$.messages[0].dvcMsgId";
	    }

	    public static String getFirstMessageTextJsonPath() {
	        return "$.messages[0].text";
	    }

	    public static String getFirstMessageNameJsonPath() {
	        return "$.messages[0].name";
	    }

	    public static String getFirstMessagePhoneNoJsonPath() {
	        return "$.messages[0].phoneNo";
	    }

	    public static String getFirstMessageConvIdJsonPath() {
	        return "$.messages[0].convId";
	    }

	    public static String getFirstMessageDateTimeJsonPath() {
	        return "$.messages[0].dateTime";
	    }
	    
	    public static String getFirstMessageMsgTypeJsonPath() {
	        return "$.messages[0].msgType";
	    }

	    public static String getFirstMessageAppTypeJsonPath() {
	        return "$.messages[0].appType";
	    }
	    
	    public static String getFirstMessageOperationJsonPath() {
	        return "$.messages[0].operation";
	    }
}
