package com.rjil.cloud.tej.apihelpers.nms;

import static com.jayway.restassured.RestAssured.given;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;


/**
 * @author Sanjeevanee.Kanase
 *class for having methods - for creating headers, get url for calling get search metadata url, and getting response for api
 */

public class GetSearchMetadataBaseScript extends BaseTestScript {

	protected static final String apiName = "GetSearchMetadata";
//		protected  Map<String, String> headerMap = null;
	
	public GetSearchMetadataBaseScript(){
		globalApiName=apiName;
	}

	// created a Hashmap to save all the headers.
/*	protected  void createHeader() {

		FrameworkLogger.logStep("createHeader:-> Start");
		headerMap=new HashMap<>();
		headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json");
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), serverConfig.get("deviceKey"));
		headerMap.put(HeaderParameters.AUTHORIZATION.getValue(), accessToken);
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "en");

		//Add 'X-Api-Key' in header for the API.
		addXapiHeaderKey(headerMap);

		FrameworkLogger.logStep("createHeader:-> End");
	}
*/
	/**get a complete url for 'get search Metadata API'
	 * @return
	 * @throws InterruptedException 
	 * @throws VerificationFailException 
	 * @throws IOException 
	 */
	protected String getSearchMetatadataURL(String urlKey, String urlValue) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getSearchMetatadataURL:-> Start");
		 String url =apiUrls.get("baseURL") + setUrlForSearch(urlKey, urlValue);
		 FrameworkLogger.logStep("getSearchMetatadataURL:-> End");
		 return url;
	}
	
	/**get a complete url for 'get search Metadata API'
	 * @return
	 * @throws InterruptedException 
	 * @throws VerificationFailException 
	 * @throws IOException 
	 */
	protected String getSearchMetatadataURL(String urlKey) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getSearchMetatadataURL:-> Start");
		String url =  apiUrls.get("baseURL") + serverConfig.get(urlKey);
		FrameworkLogger.logStep("getSearchMetatadataURL:-> End");
		return url;
	}
	
	/**
	 * Method to get getSearchMetadata Response
	 * @return getSearchMetadata validatable response
	 * @throws InterruptedException 
	 * @throws VerificationFailException 
	 */
	protected ValidatableResponse getSearchMetadataAPIResponse(String urlKey, String urlValue) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getSearchMetadataAPIResponse:-> Start");
/*		ValidatableResponse response = given()
				.headers(headerMap)
				.log().all()
				.when()
				.get(getSearchMetatadataURL())
				.then();
		response.log().all();
		Utils.addRequestResponseToLogger();
*/		
		String strApiUrl=getSearchMetatadataURL(urlKey, urlValue);
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);

		FrameworkLogger.logStep("getSearchMetadataAPIResponse:-> End");
		return response;

	}
	
	protected ValidatableResponse getSearchMetadataAPIResponse(String urlKey) throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getSearchMetadataAPIResponse:-> Start");	
		
		String strApiUrl=getSearchMetatadataURL(urlKey);
		//Call method to trigger GET API.
		ValidatableResponse response = triggerGetApi(strApiUrl,headerMap);
		
		FrameworkLogger.logStep("getSearchMetadataAPIResponse:-> End");
		return response;

	}
	
	/**
	 * method to check that objectKey of uploaded file (using file upload api) is present in the response of search Metadata api.
	 * @param response - response of get search Metadata API
	 * @param strObjectKey - objectKey of uploaded file
	 * @return boolean value - true: if objectKey of uploaded file is found in response of get search metadata api else false
	 * @throws IOException
	 */
	protected boolean isObjectKeyPresentInResponse(ValidatableResponse response, String strObjectKey) throws IOException
	{
		FrameworkLogger.logStep("isObjectKeyPresentInResponse:-> Start");
		boolean isObjectKeyMatching = false;

		int  sizeOfOjectArray =	response.extract().jsonPath().getList("objects").size();
		for(int i=0;i<sizeOfOjectArray;i++)
		{
			String objectKey = response.extract().path("objects["+i+"].objectKey");
			if (objectKey.equalsIgnoreCase(strObjectKey))
			{
				 isObjectKeyMatching=true;
				 break;
			}
		}
		FrameworkLogger.logStep("isObjectKeyPresentInResponse:-> End");
		return isObjectKeyMatching;
	}
	
	
	protected String searchObjectKeyAndFindItsAttributeValue(ValidatableResponse response, String strObjectKey, String attribute) throws IOException
	{
		FrameworkLogger.logStep("searchObjectKeyAbdFindItsAttributeValue:-> Start");
		int objectKeyIndex = 0;
		FrameworkLogger.logStep("object key to be searched in search method="+strObjectKey);

		List<String> objList = response.extract().jsonPath().get("objects.objectKey");
		for (String actualObjectKeyValue : objList) {
			FrameworkLogger.logStep("Comparing strObjectKeyValue:-> " + strObjectKey
					+ " With actualObjectKeyValue:-> " + actualObjectKeyValue);
			if (actualObjectKeyValue.equalsIgnoreCase(strObjectKey)) {
				objectKeyIndex = objList.indexOf(actualObjectKeyValue);
				break;
			}
		}

//        int  sizeOfOjectArray =	response.extract().jsonPath().getList("objects").size();
//		for(int i=0;i<sizeOfOjectArray;i++)
//		{
//			String objectKey = response.extract().path("objects["+i+"].objectKey");
//			if (objectKey.equalsIgnoreCase(strObjectKey))
//			{
//				objectKeyIndex=i;
//				break;
//			}
//			
//		}
		FrameworkLogger.logStep("searchObjectKeyAbdFindItsAttributeValue:-> End");
		String attributeValue = response.extract().path("objects["+objectKeyIndex+"]."+attribute);
		return attributeValue;
	}
	
	protected boolean searchObjectKeyAndFindItsBooleanAttributeValue(ValidatableResponse response, String strObjectKey, String attribute) throws IOException
	{
		FrameworkLogger.logStep("searchObjectKeyAbdFindItsAttributeValue:-> Start");
		int objectKeyIndex = 0;
        System.out.println("object key to be searched in search method="+strObjectKey);
		int  sizeOfOjectArray =	response.extract().jsonPath().getList("objects").size();
		for(int i=0;i<sizeOfOjectArray;i++)
		{
			String objectKey = response.extract().path("objects["+i+"].objectKey");
			if (objectKey.equalsIgnoreCase(strObjectKey))
			{
				objectKeyIndex=i;
				break;
			}
		}
		FrameworkLogger.logStep("searchObjectKeyAbdFindItsAttributeValue:-> End");
		 boolean attributeValue = response.extract().path("objects["+objectKeyIndex+"]."+attribute);
		 return attributeValue;
	}
	
	public HashMap getSearchMetadataFilters() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getSearchMetadataFilters:-> Start");
		String url = serverConfig.get("getSearchMetadataURL");
		String [] url_char =url.split("&");
		String First_String_char[] =url_char[0].split("search?");
		String folderKey = First_String_char[1].replace("?", "");
		String searchKey = url_char[1];
		String limit = url_char[2];
		String filterCode = url_char[3];
		HashMap urlParameters = new HashMap();
		urlParameters.put("folderKey", folderKey.split("=")[1]);
		urlParameters.put("searchKey", searchKey.split("=")[1]);
		urlParameters.put("limit", limit.split("=")[1]);
		urlParameters.put("filterCode", filterCode.split("=")[1]);
		FrameworkLogger.logStep("getSearchMetadataFilters:-> End");
		return urlParameters;
	}
	
	public String setUrlForSearch(String urlKey, String urlValue) throws IOException, VerificationFailException, InterruptedException
	{
		FrameworkLogger.logStep("setUrlForSearch:-> Start");
		HashMap urlParameters = getSearchMetadataFilters();
		String url = serverConfig.get("getSearchMetadataURL");
		String urlKey1 = (String) urlParameters.get(urlKey);
		String newUrl = url.replace(urlKey+"="+urlKey1, urlKey+"="+urlValue);
		FrameworkLogger.logStep("setUrlForSearch:-> End");
		return newUrl;
	}
}
