package com.rjil.cloud.tej.apihelpers.messages;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class SyncDevicewithCloudforMessagesBaseScript extends BaseTestScript{
	protected static final String apiName = "SyncDevicewithCloudforMessages";
	protected String jsonBody;
	
	public SyncDevicewithCloudforMessagesBaseScript(){
		globalApiName=apiName;
	}

	protected Map<String, String> createHeader() {
		FrameworkLogger.logStep("createHeader:-> Start");

		createHeader("10");
//		If-Modified-Since: 1461930118359
//		X-Chunk-Size : 100 

		FrameworkLogger.logStep("createHeader:-> End");
		return headerMap;
	}

	protected Map<String, String> createHeader(String strChunkSize) {
		FrameworkLogger.logStep("createHeader:-> Start");

    	headerMap=initializeHeader();

		// size is 100 byte
		headerMap.put(HeaderParameters.XCHUNKSIZE.getValue(), strChunkSize); // Chunk
		

		FrameworkLogger.logStep("createHeader:-> End");
		return headerMap;
	}

	
	/**
	 * @author Sanjeevanee Kanase
	 *         <p>
	 *         It creates the url for API
	 */
	protected String getSyncDevicewithCloudforMessagesApiUrl() {
		FrameworkLogger.logStep("getSyncDevicewithCloudforMessagesApiUrl:-> Start");
	
		String url= apiUrls.get("baseMessagesURL") + serverConfig.get("getSyncDEvicewithCloudforMessagesApiUrl");
		
		FrameworkLogger.logStep("getSyncDevicewithCloudforMessagesApiUrl:-> End");
		
		return url;
	}
	
	
	protected String getSyncDevicewithCloudforMessagesApiUrl(String deviceKey) {
		FrameworkLogger.logStep("getSyncDevicewithCloudforMessagesApiUrl:-> Start");
	
		String url= apiUrls.get("baseMessagesURL") + serverConfig.get("getSyncDEvicewithCloudforMessagesApiUrl")+"?deviceKeys="+deviceKey;
		
		FrameworkLogger.logStep("getSyncDevicewithCloudforMessagesApiUrl:-> End");
		
		return url;
	}
	
	protected String getSyncDevicewithCloudforMessagesApiUrlForNextUrl(String nextUrl) {
		FrameworkLogger.logStep("getSyncDevicewithCloudforMessagesApiUrl:-> Start");
	
		String url= apiUrls.get("baseMessagesURL")+nextUrl;
		FrameworkLogger.logStep("URL HIT IS ="+url);
		FrameworkLogger.logStep("getSyncDevicewithCloudforMessagesApiUrl:-> End");
		
		return url;
	}
	public ValidatableResponse triggerGetApiSyncDevicewithCloudforMessages() {
		FrameworkLogger.logStep("triggerGetApiSyncDevicewithCloudforMessages:-> Start");

		String strApiUrl=getSyncDevicewithCloudforMessagesApiUrl();

		ValidatableResponse response=triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiSyncDevicewithCloudforMessages:-> End");
		return response;
	}
	
	public ValidatableResponse triggerGetApiSyncDevicewithCloudforMessages(String deviceKey) {
		FrameworkLogger.logStep("triggerGetApiSyncDevicewithCloudforMessages:-> Start");

		String strApiUrl=getSyncDevicewithCloudforMessagesApiUrl(deviceKey);

		ValidatableResponse response=triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiSyncDevicewithCloudforMessages:-> End");
		return response;
	}
	
	public ValidatableResponse triggerGetApiSyncDevicewithCloudforMessagesWithNextUrl(String nextUrl) {
		FrameworkLogger.logStep("triggerGetApiSyncDevicewithCloudforMessages:-> Start");

		String strApiUrl=getSyncDevicewithCloudforMessagesApiUrlForNextUrl(nextUrl);
		
		ValidatableResponse response=triggerGetApi(strApiUrl, headerMap);
		FrameworkLogger.logStep("triggerGetApiSyncDevicewithCloudforMessages:-> End");
		return response;
	}
	
	  public static int getIndexIfMessagePresentInResponse(ValidatableResponse response, String dvcMsgId)
				throws IOException {
			FrameworkLogger
					.logStep("getIndexIfMessagePresentInResponse:-> start; dvcMsgIdValue:-> " + dvcMsgId);
			int isdvcMsgIdMatchingIndex = -1;
			List<String> objList = response.extract().jsonPath().get("messages.dvcMsgId");
	
			for (String actualdvcMsgIdValue : objList) {
				FrameworkLogger.logStep("Comparing strObjectKeyValue:-> " + dvcMsgId
						+ " With actualObjectKeyValue:-> " + actualdvcMsgIdValue);
				if (actualdvcMsgIdValue.equalsIgnoreCase(dvcMsgId)) {
					isdvcMsgIdMatchingIndex = objList.indexOf(actualdvcMsgIdValue);
					break;
				}
			}
			FrameworkLogger.logStep("index of backup message in response=" + isdvcMsgIdMatchingIndex);
			return isdvcMsgIdMatchingIndex;
		}
	  
}
