package com.rjil.cloud.tej.api.test.boards;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class CreateBoardNegativeTest extends CreateBoardBaseScript {


	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if ''boardName' is invalid.", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithInvalidBoardName() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithInvalidBoardName:-> Start");

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), "b&^%$jcjoar^&D* _", boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithInvalidBoardName:-> End");

	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if board name is more than 256 characters.", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithLengthyName() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithLengthyName:-> Start");

		String boardName ="qwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmploki0987$%^&&*()^%$#@^&*())^&%$bhkhhhhhhhhhhhhhhhhhhhhhhfffffffffffffffffffffffffffffffffffffffffffffffff";
		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithLengthyName:-> End");

	}

	//Verify the response if 'parentObjectKey' is missing from the body.
	//Verify the response if 'boardName' is missing from the body.

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if 'boardName' is missing from the body.", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithMissingBoardName() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithMissingBoardName:-> Start");

		//the field is not present.

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = JsonPath.parse(boardJsonBody).delete(NewBoardConstants.getBoardName()).jsonString();

		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Failure Status");

		//the value for field is not present.

		createHeader();
		boardJsonBody = setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), "", boardJsonBody);

		ValidatableResponse response1 = triggerPostApiCreateBoard();

		int status1 = response1.extract().statusCode();
		Verify.verifyEquals(status1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Failure Status");
		
		String code = response1.extract().path("code");
		String error = response.extract().path("error");
		Verify.verifyEquals(code, "BRSOM0007", "Verify Board Media Auth Status");
		Verify.verifyEquals(error, "Missing Parameter boardName.", "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithMissingBoardName:-> End");
	}


	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response for invalid XuserId", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithInvalidXuserId() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithInvalidXuserId:-> Start");

		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		headerMap.put(HeaderParameters.XUSERID.getValue(), BaseTestScript.getInvalidUserid());
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify Failure Status");

		FrameworkLogger.logStep("CreateBoardTestWithInvalidXuserId:-> End");

	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response for invalid XDeviceKey", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithInvalidXDeviceKey() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithInvalidXDeviceKey:-> Start");

		//the field is not present.

		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), BaseTestScript.getInvalidUserid());
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Failure Status");

		FrameworkLogger.logStep("CreateBoardTestWithInvalidXDeviceKey:-> End");

	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if XUserId is missing", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithMissingXUserId() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithMissingXUserId:-> Start");

		//the field is not present.
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Failure Status");

		//the value for field is not present.

		createHeader();
		headerMap.put(HeaderParameters.XUSERID.getValue(), "");
		boardJsonBody = setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response1 = triggerPostApiCreateBoard();

		int status1 = response1.extract().statusCode();
		Verify.verifyEquals(status1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Failure Status");

		FrameworkLogger.logStep("CreateBoardTestWithMissingXUserId:-> End");

	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if Xdevice key is missing", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithMissingXDeviceKey() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithMissingXDeviceKey:-> Start");

		//the field is not present.
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Failure Status");


		FrameworkLogger.logStep("CreateBoardTestWithMissingXDeviceKey:-> End");

	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response for invalid url", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithInvalidUrl() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithValidValues:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard("/boardss");

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE500.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithValidValues:-> End");

	}
	
	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if categoryKey is invalid", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithInvalidCategoryKey() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithInvalidCategoryKey:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getCategoryKey(), "ghdjj*$%#7 o09", boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithInvalidCategoryKey:-> End");

	}
	
	@Test(priority = 11, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if if categoryKey is null", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithNullCategoryKey() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithNullCategoryKey:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getCategoryKey(), "", boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithNullCategoryKey:-> End");

	}
	
	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if if categoryKey is missing", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithMissingCategoryKey() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithMissingCategoryKey:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		boardJsonBody = JsonPath.parse(boardJsonBody).delete(NewBoardConstants.getCategoryKey()).jsonString();
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithMissingCategoryKey:-> End");

	}

	@Test(priority = 13, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if categoryName is invalid", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithInvalidCategoryName() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithInvalidCategoryName:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getCategoryName(), "ghdjj*$%#7 o09", boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithInvalidCategoryName:-> End");

	}
	
	@Test(priority = 14, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if if categoryName is null", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithNullCategoryName() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithNullCategoryName:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getCategoryName(), "", boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithNullCategoryName:-> End");

	}
	
	@Test(priority = 15, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if if categoryName is missing", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithMissingCategoryName() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithMissingCategoryName:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		boardJsonBody = JsonPath.parse(boardJsonBody).delete(NewBoardConstants.getCategoryName()).jsonString();
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithMissingCategoryName:-> End");

	}

	@Test(priority = 16, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if description is invalid", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithInvalidDescription() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithInvalidDescription:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getBoardDescription(), "@#*(@#$Board", boardJsonBody);

		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithInvalidDescription:-> End");

	}
	
	@Test(priority = 17, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if if baord description is null", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithNullBoardDescription() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithNullCategoryName:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
//		boardJsonBody = setJsonData(NewBoardConstants.getBoardDescription(), "", boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithNullBoardDescription:-> End");

	}
	
	@Test(priority = 18, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if if board description is missing", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithMissingDescription() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithMissingDescription:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
//		boardJsonBody = JsonPath.parse(boardJsonBody).delete(NewBoardConstants.getBoardDescription()).jsonString();
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithMissingDescription:-> End");

	}
	
	
	@Test(priority = 20, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if baordName has spacial characters", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithBoardNameContainsSpecialCharacters() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithBoardNameContainsSpecialCharacters:-> Start");
		String boardName = "1@@@&%$$$$hjkh=-";

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithBoardNameContainsSpecialCharacters:-> End");

	}
	
	@Test(priority = 21, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if baordName has only alphabets", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithBoardNameContainsOnlyAlphabets() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithBoardNameContainsOnlyAlphabets:-> Start");
		String boardName = "MyBoard";

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithBoardNameContainsOnlyAlphabets:-> End");

	}

	@Test(priority = 22, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if baordName has alphanumeric characters", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithBoardNameContainsOnlyAlphaNumericCharacters() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithBoardNameContainsOnlyAlphaNumericCharacters:-> Start");
		String boardName = "11MyBoard22";

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithBoardNameContainsOnlyAlphaNumericCharacters:-> End");

	}

	@Test(priority = 23, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if baordName is same as board created", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithDupliacteBoardName() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithBoardNameContainsOnlyAlphaNumericCharacters:-> Start");
		String boardName =  "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		ValidatableResponse response2 = triggerPostApiCreateBoard();
		int status2 = response2.extract().statusCode();
		Verify.verifyEquals(status2, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithBoardNameContainsOnlyAlphaNumericCharacters:-> End");

	}
	
	@Test(priority = 24, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify thelength of boardName", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestToCheckBoardNameLength() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestToCheckBoardNameLength:-> Start");
		String boardName =  "Board___"+Utils.getUniqueId()+"qwertyuioixhfgxvchjjjjjnnnnnnnnnnnnnnnnnnnnnn";

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestToCheckBoardNameLength:-> End");

	}

	@Test(priority = 19, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if baordName has spaces", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	
	public void CreateBoardTestWithBoardNameContainsSpaces() throws IOException, VerificationFailException, InterruptedException {
	
		FrameworkLogger.logStep("CreateBoardTestWithBoardNameContainsSpaces:-> Start");
		String boardName = "                  ";
	
		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		
		ValidatableResponse response = triggerPostApiCreateBoard();
	
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
	
		FrameworkLogger.logStep("CreateBoardTestWithBoardNameContainsSpaces:-> End");
	
	}
	
	@Test(priority = 20, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":create board without Board name", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void CreateBoardTestWithoutBoardNameInRequest() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("CreateBoardTestWithoutBoardNameInRequest:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = deleteJsonData(boardJsonBody,NewBoardConstants.getCategoryName());
		boardJsonBody = deleteJsonData(boardJsonBody,NewBoardConstants.getCategoryKey());
		boardJsonBody = deleteJsonData(boardJsonBody,NewBoardConstants.getBoardDescription());
		boardJsonBody = deleteJsonData(boardJsonBody,NewBoardConstants.getBoardName());
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("CreateBoardTestWithoutBoardNameInRequest:-> End");

	}

	

}
