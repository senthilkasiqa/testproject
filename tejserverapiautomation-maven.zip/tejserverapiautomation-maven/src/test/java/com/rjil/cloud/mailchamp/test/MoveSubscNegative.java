package com.rjil.cloud.mailchamp.test;

import java.util.Map;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.mailchamp.common.helper.MoveSubScriptionBaseClass;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.enums.HeaderParameters;


public class MoveSubscNegative extends MoveSubScriptionBaseClass {

	public ValidatableResponse response;

	@Test(description = "TC_48 - To validate the move subscription API when User Id is missing, "
			+ "when moving Subscription from New to Inbox", groups = { TestNgGroups.REGRESSION })

	public void aMovSubScpUserIdMissingNewToInbox() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);

		int newcount = response.extract().path("newCount");
		if (newcount == 0) {
			System.out.println("There are no Messages in NEW, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String userId = "";
			String baseUrl = getBaseURL();
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XUSERID.getValue(), userId);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from New to Inbox is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_49 - To validate the move subscription API when Access Token is missing, "
			+ "when moving Subscription from New to Inbox", groups = { TestNgGroups.REGRESSION })
	public void bMovSubScpAccessTokenMissingNewToInbox() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);


		int newcount = response.extract().path("newCount");
		if (newcount == 0) {
			System.out.println("There are no Messages in NEW, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String authToken = "";
			String baseUrl = getBaseURL();
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from New to Inbox is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_50 -To validate the move subscription API when User Id is missing, "
			+ "when moving Subscription from New to GroupIt", groups = { TestNgGroups.REGRESSION })
	public void cMovSubScpUserIdMissingNewToGroupIt() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);

		int newcount = response.extract().path("newCount");
		if (newcount == 0) {
			System.out.println("There are no Messages in NEW, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String userId = "";
			String baseUrl = getBaseURL();
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XUSERID.getValue(), userId);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from New to GroupIt is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_51 -To validate the move subscription API when ACCESS TOKEN is missing, "
			+ "when moving Subscription from New to GroupIt", groups = { TestNgGroups.REGRESSION })
	public void dMovSubScpAccessTokenMissingNewToGroupIt() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int newcount = response.extract().path("newCount");
		if (newcount == 0) {
			System.out.println("There are no Messages in NEW, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String authToken = "";
			String baseUrl = getBaseURL();
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from New to GroupIt is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_52 - To validate the move subscription API when User Id is missing, "
			+ "when moving Subscription from New to Unsubscribe", groups = { TestNgGroups.REGRESSION })
	public void eMovSubScpUserIdMissingNewToUnsubscribe() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int newcount = response.extract().path("newCount");
		if (newcount == 0) {
			System.out.println("There are no Messages in NEW, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String userId = "";
			String baseUrl = getBaseURL();
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XUSERID.getValue(), userId);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from New to Unsubscribe is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_53 - To validate the move subscription API when ACCESS TOKEN is missing, "
			+ "when moving Subscription from New to Unsubscribe", groups = { TestNgGroups.REGRESSION })
	public void fMovSubScpAccessTokenMissingNewToUnsubscribe() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int newcount = response.extract().path("newCount");
		if (newcount == 0) {
			System.out.println("There are no Messages in NEW, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String authToken = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from New to Unsubscribe is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_54 -  To validate the move subscription API when User Id is missing,"
			+ " when moving Subscription from GroupIt to Inbox", groups = { TestNgGroups.REGRESSION })

	public void gMovSubScpUserIdMissingGroupItToInbox() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int GroupItCount = response.extract().path("groupItCount");
		if (GroupItCount == 0) {
			System.out.println("There are no Messages in GroupIt, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String userId = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XUSERID.getValue(), userId);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from GroupIt to Inbox is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_55 -  To validate the move subscription API when ACCESS TOKEN is missing,"
			+ " when moving Subscription from GroupIt to Inbox", groups = { TestNgGroups.REGRESSION })

	public void hMovSubScpAccessTokenMissingGroupItToInbox() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int GroupItCount = response.extract().path("groupItCount");
		if (GroupItCount == 0) {
			System.out.println("There are no Messages in GroupIt, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String authToken = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from GroupIt to Inbox is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_56 - To validate the move subscription API when User Id is missing, "
			+ "when moving Subscription from GroupIt to New", groups = { TestNgGroups.REGRESSION })

	public void iMovSubScpUserIdMissingGroupItToNew() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int GroupItCount = response.extract().path("groupItCount");
		if (GroupItCount == 0) {
			System.out.println("There are no Messages in GroupIt, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String userId = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XUSERID.getValue(), userId);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from GroupIt to New is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_57 - To validate the move subscription API when ACCESS TOKEN is missing, "
			+ "when moving Subscription from GroupIt to New", groups = { TestNgGroups.REGRESSION })

	public void jMovSubScpAccessTokenMissingGroupItToNew() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int GroupItCount = response.extract().path("groupItCount");
		if (GroupItCount == 0) {
			System.out.println("There are no Messages in GroupIt, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String authToken = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from GroupIt to New is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_58 - To validate the move subscription API when User Id is missing, "
			+ "when moving Subscription from GroupIt to Unsubscribe", groups = { TestNgGroups.REGRESSION })

	public void kMovSubScpUserIdMissingGroupItToUnsubscribe() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int GroupItCount = response.extract().path("groupItCount");
		if (GroupItCount == 0) {
			System.out.println("There are no Messages in GroupIt, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String userId = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XUSERID.getValue(), userId);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from GroupIt to Unsubscribe is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_59 - To validate the move subscription API when Access Token is missing, "
			+ "when moving Subscription from GroupIt to Unsubscribe", groups = { TestNgGroups.REGRESSION })

	public void lMovSubScpAccessTokenMissingGroupItToUnsubscribe() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int GroupItCount = response.extract().path("groupItCount");
		if (GroupItCount == 0) {
			System.out.println("There are no Messages in GroupIt, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String authToken = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from GroupIt to Unsubscribe is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_60 - To validate the move subscription API when User Id is missing, "
			+ "when moving Subscription from Inbox to GroupIt", groups = { TestNgGroups.REGRESSION })

	public void mMovSubScpUserIdMissingInboxToGroupIt() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int inboxCount = response.extract().path("inboxCount");
		if (inboxCount == 0) {
			System.out.println("There are no Messages in Inbox, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String userId = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XUSERID.getValue(), userId);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from Inbox to GroupIt is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_61 - To validate the move subscription API when ACCESS TOKEN is missing, "
			+ "when moving Subscription from Inbox to GroupIt", groups = { TestNgGroups.REGRESSION })

	public void nMovSubScpAccessTokenMissingInboxToGroupIt() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int inboxCount = response.extract().path("inboxCount");
		if (inboxCount == 0) {
			System.out.println("There are no Messages in Inbox, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String authToken = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from Inbox to GroupIt is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_62 - To validate the move subscription API when User Id is missing, "
			+ "when moving Subscription from Inbox to New", groups = { TestNgGroups.REGRESSION })

	public void oMovSubScpUserIdMissingInboxToNew() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int inboxCount = response.extract().path("inboxCount");
		if (inboxCount == 0) {
			System.out.println("There are no Messages in Inbox, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String userId = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XUSERID.getValue(), userId);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from Inbox to New is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_63 - To validate the move subscription API when ACCESS TOKEN is missing, "
			+ "when moving Subscription from Inbox to New", groups = { TestNgGroups.REGRESSION })

	public void pMovSubScpAccessTokenMissingInboxToNew() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		 
		int inboxCount = response.extract().path("inboxCount");
		if (inboxCount == 0) {
			System.out.println("There are no Messages in Inbox, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String authToken = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from Inbox to New is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_64 - To validate the move subscription API when User Id is missing, "
			+ "when moving Subscription from Inbox to Unsubscribe", groups = { TestNgGroups.REGRESSION })

	public void qMovSubScpUserIdMissingInboxToUnsubscribe() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int inboxCount = response.extract().path("inboxCount");
		if (inboxCount == 0) {
			System.out.println("There are no Messages in Inbox, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String userId = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XUSERID.getValue(), userId);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from Inbox to Unsubscribe is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_65 - To validate the move subscription API when ACCESS TOKEN is missing, "
			+ "when moving Subscription from Inbox to Unsubscribe", groups = { TestNgGroups.REGRESSION })

	public void rMovSubScpAccessTokenMissingInboxToUnsubscribe() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int inboxCount = response.extract().path("inboxCount");
		if (inboxCount == 0) {
			System.out.println("There are no Messages in Inbox, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String authToken = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from Inbox to Unsubscribe is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_66 - To validate the move subscription API when User Id is missing, "
			+ "when moving Subscription from Unsubscribe to GroupIt", groups = { TestNgGroups.REGRESSION })

	public void sMovSubScpUserIdMissingUnsubscribeToGroupIt() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int unsubscribeCount = response.extract().path("unsubscribeCount");
		if (unsubscribeCount == 0) {
			System.out.println("There are no Messages in Unsubscribe, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String userId = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XUSERID.getValue(), userId);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from Unsubscribe to GroupIt is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_67 - To validate the move subscription API when ACCESS TOKEN is missing, "
			+ "when moving Subscription from Unsubscribe to GroupIt", groups = { TestNgGroups.REGRESSION })

	public void tMovSubScpAccessTokenMissingUnsubscribeToGroupIt() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int unsubscribeCount = response.extract().path("unsubscribeCount");
		if (unsubscribeCount == 0) {
			System.out.println("There are no Messages in Unsubscribe, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String authToken = "";
			String baseUrl = getBaseURL();
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from Unsubscribe to GroupIt is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_68 - To validate the move subscription API when User Id is missing, "
			+ "when moving Subscription from Unsubscribe to New", groups = { TestNgGroups.REGRESSION })
	public void uMovSubScpUserIdMissingUnsubscribeToNew() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int unsubscribeCount = response.extract().path("unsubscribeCount");
		if (unsubscribeCount == 0) {
			System.out.println("There are no Messages in Unsubscribe, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String userId = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XUSERID.getValue(), userId);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from Unsubscribe to New is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_69 - To validate the move subscription API when ACCESS TOKEN is missing, "
			+ "when moving Subscription from Unsubscribe to New", groups = { TestNgGroups.REGRESSION })
	public void vMovSubScpAccessTokenMissingUnsubscribeToNew() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int unsubscribeCount = response.extract().path("unsubscribeCount");
		if (unsubscribeCount == 0) {
			System.out.println("There are no Messages in Unsubscribe, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String authToken = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from Unsubscribe to New is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_70 - To validate the move subscription API when User Id is missing, "
			+ "when moving Subscription from Unsubscribe to inbox", groups = { TestNgGroups.REGRESSION })

	public void wMovSubScpUserIdMissingUnsubscribeToInbox() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int unsubscribeCount = response.extract().path("unsubscribeCount");
		if (unsubscribeCount == 0) {
			System.out.println("There are no Messages in Unsubscribe, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String userId = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XUSERID.getValue(), userId);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from Unsubscribe to Inbox is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_71 - To validate the move subscription API when ACCESS TOKEN is missing, "
			+ "when moving Subscription from Unsubscribe to inbox", groups = { TestNgGroups.REGRESSION })

	public void xMovSubScpAccessTokenMissingUnsubscribeToInbox() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int unsubscribeCount = response.extract().path("unsubscribeCount");
		if (unsubscribeCount == 0) {
			System.out.println("There are no Messages in Unsubscribe, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
			System.out.println("Message From to be moved is: " + subscriptionKey);

			String authToken = "";
			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authToken);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Move SubScr from Unsubscribe to Inbox is:" + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_72 - To validate the move subscription API when subscriptio key is missing,", groups = {
			 TestNgGroups.REGRESSION })
	public void yMovSubScpMissingSenderNewToGroupIt() {
		String baseUrl = getBaseURL();	
		Map<String, String> headerMapLocal = createHeaderMap();
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), "");
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerPutApi(baseUrl, headerMapLocal ); 
		int movSubScpStatus = response.extract().statusCode();
		System.out.println("Status Code for Move SubScr from New to GroupIt is:" + movSubScpStatus);
		Assert.assertEquals(movSubScpStatus, 400);
	}

	@Test(description = "TC_73 - To validate the move subscription API "
			+ "when Subscription-Key is INVALID.", groups = { TestNgGroups.REGRESSION })

	public void zMovSubScpNegMsgFromMissing() {
		String baseUrl = getBaseURL();	
		Map<String, String> headerMapLocal = createHeaderMap();
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), "abcd");
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerPutApi(baseUrl, headerMapLocal ); 
		
		int movSubScpStatus = response.extract().statusCode();
		System.out.println("Status Code for message from missing is: " + movSubScpStatus);
		Assert.assertEquals(movSubScpStatus, 400);
	}

	@Test(description = "TC_74 - To validate the move subscription API " + "when subscription type is empty", groups = {
			TestNgGroups.REGRESSION })

	public void z0MovSubScpMissingSubscriptionType() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int newCount = response.extract().path("newCount");
		if (newCount == 0) {
			System.out.println("There are no Messages in NEW, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionkey = response.extract().path("emailMetadataList[0].subscription-key");
			System.out.println("MessageFrom to be moved is: " + subscriptionkey);

			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionkey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Subscription type missing is: " + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_75 - To validate the move subscription API " + "when subscription type is Invalid", groups = {
			TestNgGroups.REGRESSION })
	public void z1MovSubScpInvalidSubscriptionType() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int newCount = response.extract().path("newCount");
		if (newCount == 0) {
			System.out.println("There are no Messages in NEW, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionkey = response.extract().path("emailMetadataList[0].subscription-key");
			System.out.println("MessageFrom to be moved is: " + subscriptionkey);

			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionkey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "abcd");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println("Status Code for Subscription type missing is: " + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_76 - To validate the move subscription API for valid details,"
			+ " when moving Subscription from Inbox to New (Inbox to move should not work)", groups = {
					TestNgGroups.REGRESSION })
	public void z2MovSubScpInboxtoNew() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int inboxCount = response.extract().path("inboxCount");
		if (inboxCount == 0) {
			System.out.println("There are no Messages in Inbox, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionkey = response.extract().path("emailMetadataList[0].subscription-key");
			System.out.println("MessageFrom to be moved is: " + subscriptionkey);

			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionkey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println(
					"User is not allowed to move message from Inbox to New, we are getting: " + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_77 - To validate the move subscription API for valid details, "
			+ "when moving Subscription from GroupIt to New (Inbox to New should not work)", groups = {
					TestNgGroups.REGRESSION })
	public void z3MovSubScpGroupItToNew() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int GroupItCount = response.extract().path("groupItCount");
		if (GroupItCount == 0) {
			System.out.println("There are no Messages in GroupIt, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionkey = response.extract().path("emailMetadataList[0].subscription-key");
			System.out.println("MessageFrom to be moved is: " + subscriptionkey);

			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionkey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println(
					"User is not allowed to move message from Inbox to New, we are getting: " + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}

	@Test(description = "TC_78 - To validate the move subscription API for valid details, "
			+ "when moving Subscription from Unsubscribe to New (Unsubscribe to New should not work)", groups = {
					TestNgGroups.REGRESSION })
	public void z4MovSubScpUnsubscribeTONew() {
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap); 
		
		int unsubscribeCount = response.extract().path("unsubscribeCount");
		if (unsubscribeCount == 0) {
			System.out.println("There are no Messages in Unsubscribe, hence stopping further execution of Script");
			return;
		} else {
			String subscriptionkey = response.extract().path("emailMetadataList[0].subscription-key");
			System.out.println("MessageFrom to be moved is: " + subscriptionkey);

			String baseUrl = getBaseURL();	
			Map<String, String> headerMapLocal = createHeaderMap();
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionkey);
			headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
			response = triggerPutApi(baseUrl, headerMapLocal ); 
			
			int movSubScpStatus = response.extract().statusCode();
			System.out.println(
					"User is not allowed to move message from Inbox to New, we are getting: " + movSubScpStatus);
			Assert.assertEquals(movSubScpStatus, 400);
		}
	}
}