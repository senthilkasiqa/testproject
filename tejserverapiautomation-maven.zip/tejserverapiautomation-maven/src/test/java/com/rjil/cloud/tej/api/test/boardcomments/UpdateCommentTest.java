package com.rjil.cloud.tej.api.test.boardcomments;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.boardcomments.DeleteCommentBaseScript;
import com.rjil.cloud.tej.apihelpers.boardcomments.GetCommentsBaseScript;
import com.rjil.cloud.tej.apihelpers.boardcomments.PostCommentBaseScript;
import com.rjil.cloud.tej.apihelpers.boardcomments.UpdateCommentBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.RemoveBoardMembersBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class UpdateCommentTest extends UpdateCommentBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comment api for a ownwer who created the board.", groups = {
					TestNgGroups.DEPLOYMENTSANITY})
	public void updateCommentTestWithOwnerUpdatingHisCommentOnHisBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithOwnerUpdatingHisCommentOnHisBoard:-> Start");

		Thread.sleep(10000);
		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.
		String newComment = "Awesome memories :* :* ";
		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment(boardKey, commentKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Update Comment Status");
		FrameworkLogger.logStep("updateCommentTestWithOwnerUpdatingHisCommentOnHisBoard:-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comment api for a ownwer who created the board.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS,TestNgGroups.QASANITY })
	public void updateCommentTestWithOwnerUpdatingHisCommentOnHisBoardTest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithOwnerUpdatingHisCommentOnHisBoard:-> Start");
		Thread.sleep(10000);
		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.
		String newComment = "Awesome memories :* :* ";
		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment(boardKey, commentKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		ValidatableResponse getResponse = GetCommentsBaseScript.getCommentsService(boardKey);

		String boardKeyFromGetComment = getResponse.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromGetComment, boardKey, "Verify Success Status");

		int commentCount = getResponse.extract().path("total");
		Verify.verifyEquals(commentCount, 1, "Verify Success Status");

		String commentFromResponse = getResponse.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse, newComment, "Verify Success Status");

		String firstNameFromResponse = getResponse.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse, firstName, "Verify Success Status");

		String commentStatus = getResponse.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus, "A", "Verify Success Status");

		String canUpdate = getResponse.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate, "Y", "Verify Success Status");

		String canDelete = getResponse.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete, "Y", "Verify Success Status");
		FrameworkLogger.logStep("updateCommentTestWithOwnerUpdatingHisCommentOnHisBoard:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comment api for a contributor updating hiw oe=wn comment on his own board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void updateCommentTestWithContributorUpdatingHisCommentOnHisBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithContributorUpdatingHisCommentOnHisBoard-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: other user accepts the invitation and become contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: Contributor creates his own board.
		String boardNameContributor = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(deviceContributorInfo, boardNameContributor);
		String boardKeyContributor = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Contributor commenting on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(deviceContributorInfo,
				comment, boardKeyContributor);
		String commentKey = postResponse.extract().path("comments[0].commentKey");
		String ifModifiedSince = System.currentTimeMillis() + "";
		Thread.sleep(10000);

		// Step 6: Contributor updating his own comment on his own board
		String newComment = "Awesome memories :* :* ";
		createHeader(deviceContributorInfo);
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse responseUpdate = triggerPutApiUpdateComment(boardKeyContributor, commentKey,
				deviceContributorInfo);
		int statusCode = responseUpdate.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		ValidatableResponse getResponse = GetCommentsBaseScript.getCommentsService(boardKeyContributor,
				deviceContributorInfo, ifModifiedSince);

		String boardKeyFromGetComment = getResponse.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromGetComment, boardKeyContributor, "Verify Success Status");

		int commentCount = getResponse.extract().path("total");
		Verify.verifyEquals(commentCount, 1, "Verify Success Status");

		String commentFromResponse = getResponse.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse, newComment, "Verify Success Status");

		String firstNameFromResponse = getResponse.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse, firstNameOfContributor, "Verify Success Status");

		String commentStatus = getResponse.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus, "A", "Verify Success Status");

		String canUpdate = getResponse.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate, "Y", "Verify Success Status");

		String canDelete = getResponse.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete, "Y", "Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithContributorUpdatingHisCommentOnHisBoard:-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comment api for a contributor updating hiw comment on owner's board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void updateCommentTestWithContributorUpdatingHisCommentOnOwnersBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithContributorUpdatingHisCommentOnOwnersBoard-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner invites another user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: other user accepts the invitation and become contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 5: Contributor commenting on owner's board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(deviceContributorInfo,
				comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 6: Contributor updating his own comment on owner's board
		String ifModifiedSince = System.currentTimeMillis() + "";
		Thread.sleep(10000);
		String newComment = "Awesome memories :* :* ";
		createHeader(deviceContributorInfo);
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse responseUpdate = triggerPutApiUpdateComment(boardKey, commentKey, deviceContributorInfo);
		int statusCode = responseUpdate.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		ValidatableResponse getResponse = GetCommentsBaseScript.getCommentsService(boardKey, deviceContributorInfo,
				ifModifiedSince);

		String boardKeyFromGetComment = getResponse.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromGetComment, boardKey, "Verify Success Status");

		int commentCount = getResponse.extract().path("total");
		Verify.verifyEquals(commentCount, 1, "Verify Success Status");

		String commentFromResponse = getResponse.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse, newComment, "Verify Success Status");

		String firstNameFromResponse = getResponse.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse, firstNameOfContributor, "Verify Success Status");

		String commentStatus = getResponse.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus, "A", "Verify Success Status");

		String canUpdate = getResponse.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate, "Y", "Verify Success Status");

		String canDelete = getResponse.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete, "Y", "Verify Success Status");

		// Owner validating comments on baord
		ValidatableResponse getResponseOwner = GetCommentsBaseScript.getCommentsService(boardKey, ifModifiedSince);
		String canUpdateO = getResponseOwner.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdateO, "N", "Verify Success Status");

		String canDeleteO = getResponseOwner.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDeleteO, "Y", "Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithContributorUpdatingHisCommentOnOwnersBoard:-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comment api for a member who leaves the board.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithContributorWhoLeftTHeBoardUpdatingHisCommentOnOwnersBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger
				.logStep("updateCommentTestWithContributorWhoLeftTHeBoardUpdatingHisCommentOnOwnersBoard-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner invites another user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: other user accepts the invitation and become contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: Contributor commenting on owner's board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(deviceContributorInfo,
				comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 5: Contributor left the board
		LeaveBoardBaseScript.leaveBoardService(boardKey, deviceContributorInfo);

		// Step 6: Contributor updating his own comment on owner's board
		String newComment = "Awesome memories :* :* ";
		createHeader(deviceContributorInfo);
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse responseUpdate = triggerPutApiUpdateComment(boardKey, commentKey, deviceContributorInfo);
		int statusCode = responseUpdate.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = responseUpdate.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Success Status");

		String error = responseUpdate.extract().path("error");
		Verify.verifyEquals(error, "Board User Relation Missing.", "Verify Success Status");
		FrameworkLogger
				.logStep("updateCommentTestWithContributorWhoLeftTHeBoardUpdatingHisCommentOnOwnersBoard:-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comments api for a owner who leaves own board.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithOwnerWhoLeftTHeBoardUpdatingHisCommentOnHisBoard()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("updateCommentTestWithOwnerWhoLeftTHeBoardUpdatingHisCommentOnHisBoard-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: owner commenting on own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: owner left the board
		LeaveBoardBaseScript.leaveBoardService(boardKey);

		// Step 4: owner updating his own comment on own board
		String newComment = "Awesome memories :* :* ";
		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse responseUpdate = triggerPutApiUpdateComment(boardKey, commentKey);
		int statusCode = responseUpdate.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = responseUpdate.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Success Status");

		String error = responseUpdate.extract().path("error");
		Verify.verifyEquals(error, "Board User Relation Missing.", "Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithOwnerWhoLeftTHeBoardUpdatingHisCommentOnHisBoard:-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName
			+ "://Verify update comments api for a member who is removed by owner.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithContributorWhoIsRemovedFromTheBoardUpdatingHisCommentOnOwnersBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(
				"updateCommentTestWithContributorWhoIsRemovedFromTheBoardUpdatingHisCommentOnOwnersBoard-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner invites another user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: other user accepts the invitation and become contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 5: Contributor commenting on owner's board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(deviceContributorInfo,
				comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 6: Now owner is removing Contributor
		RemoveBoardMembersBaseScript.removeBoardMemberService(boardKey, deviceContributorInfo.get("userId"));

		// Step 7: Contributor updating his own comment on owner's board
		String newComment = "Awesome memories :* :* ";
		createHeader(deviceContributorInfo);
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse responseUpdate = triggerPutApiUpdateComment(boardKey, commentKey, deviceContributorInfo);
		int statusCode = responseUpdate.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = responseUpdate.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Success Status");

		String error = responseUpdate.extract().path("error");
		Verify.verifyEquals(error, "Board User Relation Missing.", "Verify Success Status");

		FrameworkLogger.logStep(
				"updateCommentTestWithContributorWhoIsRemovedFromTheBoardUpdatingHisCommentOnOwnersBoard:-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Owner updating contributor comment.", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void updateCommentTestWithOwnerUpdatingContributorsCommentOnOwnersBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithOwnerUpdatingContributorsCommentOnOwnersBoard-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner invites another user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: other user accepts the invitation and become contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 5: Contributor commenting on owner's board.

		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(deviceContributorInfo,
				comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 6: owner updatingcontributor's comment on owner's board

		String newComment = "Awesome memories :* :* ";
		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse responseUpdate = triggerPutApiUpdateComment(boardKey, commentKey);
		int statusCode = responseUpdate.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = responseUpdate.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0156.getValue(), "Verify Success Status");

		String error = responseUpdate.extract().path("error");
		Verify.verifyEquals(error, "Members can update only their own comments.", "Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithOwnerUpdatingContributorsCommentOnOwnersBoard:-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Contributor updating owner comment", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void updateCommentTestWithContributorUpdatingOwnersCommentOnOwnersBoard()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("updateCommentTestWithContributorUpdatingOwnersCommentOnOwnersBoard-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner invites another user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: other user accepts the invitation and become contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: Owner commenting on owner's board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 6: contributor updating owner's comment on owner's board
		String newComment = "Awesome memories :* :* ";
		createHeader(deviceContributorInfo);
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse responseUpdate = triggerPutApiUpdateComment(boardKey, commentKey, deviceContributorInfo);
		int statusCode = responseUpdate.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = responseUpdate.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0156.getValue(), "Verify Success Status");
		String error = responseUpdate.extract().path("error");
		Verify.verifyEquals(error, "Members can update only their own comments.", "Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithContributorUpdatingOwnersCommentOnOwnersBoard:-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comment api for Owner updating deleted comment.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithOwnerUpdatingHisDeletedCommentOnHisBoard()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("updateCommentTestWithOwnerUpdatingHisDeletedCommentOnHisBoard:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Owner deleting his comment
		DeleteCommentBaseScript.deleteCommentServiceMethod(boardKey, commentKey);

		// Step 4: Now owner updating his own deleted comment on his board.
		String newComment = "Awesome memories :* :* ";
		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment(boardKey, commentKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0153.getValue(), "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Board and Comment Key mapping not exist.", "Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithOwnerUpdatingHisDeletedCommentOnHisBoard:-> End");
	}

	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comment api for Contributor updating deleted comment", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithContributorUpdatingHisDeletedCommentOnOwnersBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithContributorUpdatingHisDeletedCommentOnOwnersBoard-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: other user accepts the invitation and become contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 5: Contributor commenting on owner's board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(deviceContributorInfo,
				comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 6: Contributor deleting his own comment
		DeleteCommentBaseScript.deleteCommentServiceMethod(boardKey, commentKey, deviceContributorInfo);

		// Step 7: Contributor updating his own comment on owner's board

		String newComment = "Awesome memories :* :* ";
		createHeader(deviceContributorInfo);
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse responseUpdate = triggerPutApiUpdateComment(boardKey, commentKey, deviceContributorInfo);
		int statusCode = responseUpdate.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = responseUpdate.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0153.getValue(), "Verify Success Status");

		String error = responseUpdate.extract().path("error");
		Verify.verifyEquals(error, "Board and Comment Key mapping not exist.", "Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithContributorUpdatingHisDeletedCommentOnOwnersBoard:-> End");
	}
}
