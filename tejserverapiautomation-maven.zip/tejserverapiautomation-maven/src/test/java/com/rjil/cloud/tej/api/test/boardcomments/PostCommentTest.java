package com.rjil.cloud.tej.api.test.boardcomments;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.boardcomments.PostCommentBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.DeclineBoardRequestBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.RemoveBoardMembersBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.BoardsDeltaSyncBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class PostCommentTest extends PostCommentBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify owner is able to post comment on board .", groups = { TestNgGroups.DEPLOYMENTSANITY})
	public void postCommentTestWithOwnerPostingCommentOnHisBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithOwnerPostingCommentOnHisBoard:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String comment = "Nice travel memories";
		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Post Comment Status");
		FrameworkLogger.logStep("postCommentTestWithOwnerPostingCommentOnHisBoard:-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify owner is able to post comment on board .", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS,TestNgGroups.QASANITY })
	public void postCommentTestWithOwnerPostingCommentOnHisBoardTest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithOwnerPostingCommentOnHisBoard:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String comment = "Nice travel memories";
		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKeyFromPostComment = response.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromPostComment, boardKey, "Verify Success Status");

		int commentCount = response.extract().path("total");
		Verify.verifyEquals(commentCount, 1, "Verify Success Status");

		String commentFromResponse = response.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse, comment, "Verify Success Status");

		String firstNameFromResponse = response.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse, firstName, "Verify Success Status");

		String commentStatus = response.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus, "A", "Verify Success Status");

		String canUpdate = response.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate, "Y", "Verify Success Status");

		String canDelete = response.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete, "Y", "Verify Success Status");
		response.body(JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/postCommentTest-Schema.json"));
		FrameworkLogger.logStep("postCommentTestWithOwnerPostingCommentOnHisBoard:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify contributor is able to post comment on owner board.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithContributorPostingCommentOnOwnersBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithContributorPostingCommentOnOwnersBoard:-> Start");
		// Step 1: Owner Creates a board

		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: owner invites other user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 4: other user accepts the invitation and become contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 5: Contributor commenting on owner's board.
		String comment = "Nice pics guys";
		createHeader(deviceContributorInfo);
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKeyFromPostComment = response.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromPostComment, boardKey, "Verify Success Status");

		int commentCount = response.extract().path("total");
		Verify.verifyEquals(commentCount, 1, "Verify Success Status");

		String commentFromResponse = response.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse, comment, "Verify Success Status");

		String firstNameFromResponse = response.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse, firstNameOfContributor, "Verify Success Status");

		String commentStatus = response.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus, "A", "Verify Success Status");

		String canUpdate = response.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate, "Y", "Verify Success Status");

		String canDelete = response.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete, "Y", "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithContributorPostingCommentOnOwnersBoard:-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify if owner leaves board then contributor should be able to post comment on board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void postCommentTestWithOwnerLeavingBoardAndContributorPostCommentOnBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithOwnerLeavingBoardAndContributorPostCommentOnBoard:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: owner invites other user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: other user accepts the invitation and become contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: Owner leaving the board.
		LeaveBoardBaseScript.leaveBoardService(boardKey);

		// Step 5: Contributor commenting on owner's board.
		String comment = "Nice travel memories";
		createHeader(deviceContributorInfo);
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKeyFromPostComment = response.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromPostComment, boardKey, "Verify Success Status");

		int commentCount = response.extract().path("total");
		Verify.verifyEquals(commentCount, 1, "Verify Success Status");

		String commentFromResponse = response.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse, comment, "Verify Success Status");

		String firstNameFromResponse = response.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse, firstNameOfContributor, "Verify Success Status");

		String commentStatus = response.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus, "A", "Verify Success Status");

		String canUpdate = response.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate, "Y", "Verify Success Status");

		String canDelete = response.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete, "Y", "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithOwnerLeavingBoardAndContributorPostCommentOnBoard:-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify if owner leaves board then owner should not be able to post comment on board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void postCommentTestWithOwnerLeavingBoardAndOwnerPostCommentOnBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithOwnerLeavingBoardAndOwnerPostCommentOnBoard:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: owner invites other user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: other user accepts the invitation and become contributor

		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: Owner leaving the board.
		LeaveBoardBaseScript.leaveBoardService(boardKey);

		// Step 5: Owner commenting on owner's board.
		String comment = "Nice travel memories";
		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Board User Relation Missing.", "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithOwnerLeavingBoardAndOwnerPostCommentOnBoard:-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify if contributor leaves board then contributor should not be able to post comment on owners board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void postCommentTestWithContributorLeavingBoardAndContributorPostCommentOnBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithContributorLeavingBoardAndContributorPostCommentOnBoard:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: owner invites other user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: other user accepts the invitation and become contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: Contributor leaving the board.
		LeaveBoardBaseScript.leaveBoardService(boardKey, deviceContributorInfo);

		// Step 5: Contributor commenting on owner's board.
		String comment = "Nice travel memories";
		createHeader(deviceContributorInfo);
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Board User Relation Missing.", "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithContributorLeavingBoardAndContributorPostCommentOnBoard:-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify if owner removes board members then board members should not be able to post comment on board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void postCommentTestWithOwnerRemovingContributorAndContributorPostingComment()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithOwnerRemovingContributorAndContributorPostingComment:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: owner invites other user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: other user accepts the invitation and become contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: Owner removing Contributor.
		RemoveBoardMembersBaseScript.removeBoardMemberService(boardKey, deviceContributorInfo.get("userId"));

		// Step 5: Contributor commenting on owner's board.
		String comment = "Nice travel memories";
		createHeader(deviceContributorInfo);
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Board User Relation Missing.", "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithOwnerRemovingContributorAndContributorPostingComment:-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify if a member decline board request then that member should not to be able to post a comment on board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void postCommentTestWithUserDecliningBoardRequestPostingComment()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithUserDecliningBoardRequestPostingComment:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: owner invites other user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: other user declines the invitation
		ValidatableResponse responseDecline = DeclineBoardRequestBaseScript.declineInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeDecline = responseDecline.extract().statusCode();
		Verify.verifyEquals(statusCodeDecline, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: user who is not the part of baord is commenting on owner's
		// board.
		String comment = "Nice travel memories";
		createHeader(deviceContributorInfo);
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Board User Relation Missing.", "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithUserDecliningBoardRequestPostingComment:-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify owner is able to post comment on board .", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithOwnerPostingCommentOnHisBoardAndVerifyInBoardDeltaSyncResponse()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger
				.logStep("postCommentTestWithOwnerPostingCommentOnHisBoardAndVerifyInBoardDeltaSyncResponse:-> Start");

		String ifModifiedSince = System.currentTimeMillis() + "";
		Thread.sleep(10000);

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String comment = "Nice travel memories";
		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKeyFromPostComment = response.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromPostComment, boardKey, "Verify Success Status");

		int commentCount = response.extract().path("total");
		Verify.verifyEquals(commentCount, 1, "Verify Success Status");

		String commentFromResponse = response.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse, comment, "Verify Success Status");

		String firstNameFromResponse = response.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse, firstName, "Verify Success Status");

		String commentStatus = response.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus, "A", "Verify Success Status");

		String canUpdate = response.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate, "Y", "Verify Success Status");

		String canDelete = response.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete, "Y", "Verify Success Status");

		ValidatableResponse responseDeltaSync = BoardsDeltaSyncBaseScript.getBoardsDeltaSyncService(ifModifiedSince);

		String boardNameFromDeltaSync = responseDeltaSync.extract().path("boards[0].boardName");
		String boardStatusFromDeltaSync = responseDeltaSync.extract().path("boards[0].status");
		int boardFilesCountFromDeltaSync = responseDeltaSync.extract().path("boards[0].filesCount");
		int commentsCountFromDeltaSync = responseDeltaSync.extract().path("boards[0].commentsCount");
		String boardKeyFromDeltaSync = responseDeltaSync.extract().path("boards[0].boardKey");

		Verify.verifyEquals(boardNameFromDeltaSync, boardName, "Verify Success Status");
		Verify.verifyEquals(boardStatusFromDeltaSync, "A", "Verify Success Status");
		Verify.verifyEquals(boardFilesCountFromDeltaSync, 0, "Verify Success Status");
		Verify.verifyEquals(commentsCountFromDeltaSync, 1, "Verify Success Status");
		Verify.verifyEquals(boardKeyFromDeltaSync, boardKey, "Verify Success Status");
		FrameworkLogger
				.logStep("postCommentTestWithOwnerPostingCommentOnHisBoardAndVerifyInBoardDeltaSyncResponse:-> End");
	}

	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Owner posting more than 1 comment on same board .", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithOwnerPostingTwoCommentOnHisBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithOwnerPostingCommentOnHisBoard:-> Start");
		String ifModifiedSince = System.currentTimeMillis() + "";
		Thread.sleep(10000);

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String comment = "Nice travel memories";
		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKeyFromPostComment = response.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromPostComment, boardKey, "Verify Success Status");

		int commentCount = response.extract().path("total");
		Verify.verifyEquals(commentCount, 1, "Verify Success Status");

		String commentFromResponse = response.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse, comment, "Verify Success Status");

		String firstNameFromResponse = response.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse, firstName, "Verify Success Status");

		String commentStatus = response.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus, "A", "Verify Success Status");

		String canUpdate = response.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate, "Y", "Verify Success Status");

		String canDelete = response.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete, "Y", "Verify Success Status");

		// Owner commenting on same board again with different comment
		String comment2 = "awesome pics shared";
		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment2, postCommentJsonBody);
		ValidatableResponse response2 = triggerPostApiPostComment(boardKey);
		int statusCode2 = response2.extract().statusCode();
		Verify.verifyEquals(statusCode2, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKeyFromPostComment1 = response2.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromPostComment1, boardKey, "Verify Success Status");

		int commentCount1 = response2.extract().path("total");
		Verify.verifyEquals(commentCount1, 2, "Verify Success Status");

		String commentFromResponse1 = response2.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse1, comment2, "Verify Success Status");

		String firstNameFromResponse1 = response2.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse1, firstName, "Verify Success Status");

		String commentStatus1 = response2.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus1, "A", "Verify Success Status");

		String canUpdate1 = response2.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate1, "Y", "Verify Success Status");

		String canDelete1 = response2.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete1, "Y", "Verify Success Status");

		ValidatableResponse responseDeltaSync = BoardsDeltaSyncBaseScript.getBoardsDeltaSyncService(ifModifiedSince);

		String boardNameFromDeltaSync = responseDeltaSync.extract().path("boards[0].boardName");
		String boardStatusFromDeltaSync = responseDeltaSync.extract().path("boards[0].status");
		int boardFilesCountFromDeltaSync = responseDeltaSync.extract().path("boards[0].filesCount");
		int commentsCountFromDeltaSync = responseDeltaSync.extract().path("boards[0].commentsCount");
		String boardKeyFromDeltaSync = responseDeltaSync.extract().path("boards[0].boardKey");

		Verify.verifyEquals(boardNameFromDeltaSync, boardName, "Verify Success Status");
		Verify.verifyEquals(boardStatusFromDeltaSync, "A", "Verify Success Status");
		Verify.verifyEquals(boardFilesCountFromDeltaSync, 0, "Verify Success Status");
		Verify.verifyEquals(commentsCountFromDeltaSync, 2, "Verify Success Status");
		Verify.verifyEquals(boardKeyFromDeltaSync, boardKey, "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithOwnerPostingCommentOnHisBoard:-> End");
	}

	@Test(priority = 11, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Owner posting same comment on same board again .", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithOwnerPostingSameCommentAgainOnHisBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithOwnerPostingSameCommentAgainOnHisBoard:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String comment = "Nice travel memories";
		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		String boardKeyFromPostComment = response.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromPostComment, boardKey, "Verify Success Status");

		int commentCount = response.extract().path("total");
		Verify.verifyEquals(commentCount, 1, "Verify Success Status");

		String commentFromResponse = response.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse, comment, "Verify Success Status");

		String firstNameFromResponse = response.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse, firstName, "Verify Success Status");

		String commentStatus = response.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus, "A", "Verify Success Status");

		String canUpdate = response.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate, "Y", "Verify Success Status");

		String canDelete = response.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete, "Y", "Verify Success Status");

		// Owner commenting on same board again with different comment
		String comment2 = comment;
		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment2, postCommentJsonBody);
		ValidatableResponse response2 = triggerPostApiPostComment(boardKey);
		int statusCode2 = response2.extract().statusCode();
		Verify.verifyEquals(statusCode2, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKeyFromPostComment1 = response2.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromPostComment1, boardKey, "Verify Success Status");

		int commentCount1 = response2.extract().path("total");
		Verify.verifyEquals(commentCount1, 2, "Verify Success Status");

		String commentFromResponse1 = response2.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse1, comment2, "Verify Success Status");

		String firstNameFromResponse1 = response2.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse1, firstName, "Verify Success Status");

		String commentStatus1 = response2.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus1, "A", "Verify Success Status");

		String canUpdate1 = response2.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate1, "Y", "Verify Success Status");

		String canDelete1 = response2.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete1, "Y", "Verify Success Status");

		FrameworkLogger.logStep("postCommentTestWithOwnerPostingSameCommentAgainOnHisBoard:-> End");
	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Contributor posting more than 1 comment on same board.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithContributorPostingTwoCommentsOnBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithContributorPostingCommentOnOwnersBoard:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: owner invites other user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 4: other user accepts the invitation and become contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 5: Contributor commenting on owner's board.
		String comment = "Nice travel memories";
		createHeader(deviceContributorInfo);
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKeyFromPostComment = response.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromPostComment, boardKey, "Verify Success Status");

		int commentCount = response.extract().path("total");
		Verify.verifyEquals(commentCount, 1, "Verify Success Status");

		String commentFromResponse = response.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse, comment, "Verify Success Status");

		String firstNameFromResponse = response.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse, firstNameOfContributor, "Verify Success Status");

		String commentStatus = response.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus, "A", "Verify Success Status");

		String canUpdate = response.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate, "Y", "Verify Success Status");

		String canDelete = response.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete, "Y", "Verify Success Status");

		String comment2 = "Good job";
		createHeader(deviceContributorInfo);
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment2, postCommentJsonBody);
		ValidatableResponse response2 = triggerPostApiPostComment(boardKey, deviceContributorInfo);
		int statusCode2 = response2.extract().statusCode();
		Verify.verifyEquals(statusCode2, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKeyFromPostComment1 = response2.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromPostComment1, boardKey, "Verify Success Status");

		int commentCount1 = response2.extract().path("total");
		Verify.verifyEquals(commentCount1, 2, "Verify Success Status");

		String commentFromResponse1 = response2.extract().path("comments[0].comment");
		Verify.verifyEquals(commentFromResponse1, comment2, "Verify Success Status");

		String firstNameFromResponse1 = response2.extract().path("comments[0].firstName");
		Verify.verifyEquals(firstNameFromResponse1, firstNameOfContributor, "Verify Success Status");

		String commentStatus1 = response2.extract().path("comments[0].status");
		Verify.verifyEquals(commentStatus1, "A", "Verify Success Status");

		String canUpdate1 = response2.extract().path("comments[0].canUpdate");
		Verify.verifyEquals(canUpdate1, "Y", "Verify Success Status");

		String canDelete1 = response2.extract().path("comments[0].canDelete");
		Verify.verifyEquals(canDelete1, "Y", "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithContributorPostingCommentOnOwnersBoard:-> End");
	}

	@Test(enabled = false, priority = 13, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify owner is able to post comment on board for 1000 times .", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithOwnerPostingCommentOnHisBoardFor1kTimes()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithOwnerPostingCommentOnHisBoardFor1kTimes:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		for (int i = 0; i < 1001; i++) {
			String comment = "Nice travel memories";
			createHeader();
			setPostCommentJsonBody();
			postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment + i, postCommentJsonBody);
			ValidatableResponse response = triggerPostApiPostComment(boardKey);
			int statusCode = response.extract().statusCode();
			Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		}
		FrameworkLogger.logStep("postCommentTestWithOwnerPostingCommentOnHisBoardFor1kTimes:-> End");
	}
}