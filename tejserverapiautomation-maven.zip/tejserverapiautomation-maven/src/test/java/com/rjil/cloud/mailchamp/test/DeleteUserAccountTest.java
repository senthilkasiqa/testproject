package com.rjil.cloud.mailchamp.test;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.mailchamp.common.helper.DeleteUserAccountBaseClass;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.enums.HeaderParameters;



public class DeleteUserAccountTest extends DeleteUserAccountBaseClass {
	
	public ValidatableResponse response;
	

	@Test 
	(description = "TC_89 - To validate Delete user API in case of all valid details, should get 200 OK",
	groups = {TestNgGroups.REGRESSION})
	public void eDeleteValidUserTest(){
		Map<String, String> headerMap=createHeaderMap();
//		response = triggerDeleteApi(getDeleteUserUrl() , getValueFromEnvConfig("userEmail"));
		response = triggerPutApi(getDeleteUserUrl() , headerMap);
		int intDeleteStatus = response.extract().statusCode();	//200
		System.out.println("Status Code for Valid user: " +intDeleteStatus);
		Assert.assertEquals(intDeleteStatus, 200);
		}
	
	 
	@Test 
	(description = "TC_90 - To validate Delete user API, when User Id is missing",
			groups = {TestNgGroups.REGRESSION})	
		public void aDeleteUserMissingUserId(){
		String userId = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),userId );
		response = triggerPutApi(getDeleteUserUrl() , headerMap);
		int intDeleteStatus = response.extract().statusCode();	//400
		System.out.println("Status Code for Missing UserId: " +intDeleteStatus);
		Assert.assertEquals(intDeleteStatus, 400);
		}
	
	@Test 
	(description = "TC_91 - To validate Delete user API, when ACCESS TOKEN is MISSING",
			groups = {TestNgGroups.REGRESSION})
		public void bDeleteUserMissingAccessToken(){
		String authCode = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),authCode );
		response = triggerPutApi(getDeleteUserUrl() , headerMap);
		int intDeleteStatus = response.extract().statusCode();	//400
		System.out.println("Status Code for Missing ACCESS TOKEN: " +intDeleteStatus);
		Assert.assertEquals(intDeleteStatus, 400);
		}
	
	
	@Test 
	(description = "TC_92 - To validate Delete user API, when User ID is INVALID",
			groups = {TestNgGroups.REGRESSION})	
		public void cDeleteUserInvalidUserId(){
		String userId = "abc123";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),userId );
		response = triggerPutApi(getDeleteUserUrl() , headerMap);
		int intDeleteStatus = response.extract().statusCode();	//400
		System.out.println("Status Code for INVALID UserId: " +intDeleteStatus);
		Assert.assertEquals(intDeleteStatus, 400);
		}
	
	@Test 
	(description = "TC_93 - To validate Delete user API, when ACCESS TOKEN is MISSING",
	groups = {TestNgGroups.REGRESSION})	
		public void dDeleteUserInvalidAccessToken(){
		String authCode = "abcd1234";
		Map<String, String> headerMap=createHeaderMap();	
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),authCode );
		response = triggerPutApi(getDeleteUserUrl() , headerMap);
		int intDeleteStatus = response.extract().statusCode();	//400
		System.out.println("Status Code for Invalid ACCESS TOKEN: " +intDeleteStatus);
		Assert.assertEquals(intDeleteStatus, 401);
		}
}
