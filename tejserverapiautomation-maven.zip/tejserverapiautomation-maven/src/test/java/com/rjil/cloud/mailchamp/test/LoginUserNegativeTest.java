package com.rjil.cloud.mailchamp.test;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.mailchamp.common.helper.LoginUserBaseClass;
import com.rjil.cloud.tej.common.TestNgGroups;

public class LoginUserNegativeTest extends LoginUserBaseClass{
		public ValidatableResponse response;
		
		@Test (description = "To verify the Login AP, when the X-Code is invalid or expired",
				groups = {TestNgGroups.REGRESSION})
		public void invaliToken(){
			String invalidXCode = "cc048030-4122-11e7-97a9-7d3d3869b009";
			response = triggerPostApi(getLoginUserUrl(), createHeaderMap(invalidXCode));
			int intActStatus = response.extract().statusCode();	
			System.out.println("Status Code for invalid XCode is: " +intActStatus);
			Assert.assertEquals(intActStatus, 400);
			}
		
		@Test (description = "TC_03 - To verify the Login API,  when the token is missing.",
				groups = {TestNgGroups.REGRESSION})
			public void missingToken(){
			String noXCode = "";
			response = triggerPostApi(getLoginUserUrl(), createHeaderMap(noXCode) );
			int intActStatus = response.extract().statusCode();	
			System.out.println("Status Code for Missing XCode is: " +intActStatus);
			Assert.assertEquals(intActStatus, 400);
	}

}
