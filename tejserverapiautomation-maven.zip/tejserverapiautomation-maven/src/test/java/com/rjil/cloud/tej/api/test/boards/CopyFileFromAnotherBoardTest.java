package com.rjil.cloud.tej.api.test.boards;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.RemoveBoardMembersBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.BoardsDeltaSyncBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CopyFileFromAnotherBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardHyperlinkBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.IndividualBoardDeltaSyncBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.RepositoryFileUploadToBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.fileupload.UploadBaseScript;
import com.rjil.cloud.tej.apihelpers.newBoard.BoardsFeedBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class CopyFileFromAnotherBoardTest extends CopyFileFromAnotherBoardBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the success code if user copies an image file from his one board to another.", groups = {
					TestNgGroups.DEPLOYMENTSANITY })

	public void copyFileFromAnotherBoardTestWithOwnerCopyingImageFileFromOneOfHisBoardToAnother()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingImageFileFromOneOfHisBoardToAnother:-> Start");

		// Step 1: Upload a file in the Root folder of the owner

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName);
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		// Step 2: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: Owner uploads a valid file from its root folder to his own
		// board.

		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod("A", objectKey, boardKey1);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 4: Now Owner creates another board.

		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Now Owner copying a file from board1 to board2
		createHeader();
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);
		Verify.verifyEquals(response.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Copy File From Another Board Status");
		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingImageFileFromOneOfHisBoardToAnother:-> End");

	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the success code if user copies an image file from his one board to another.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS, TestNgGroups.QASANITY })
	public void copyFileFromAnotherBoardTestWithOwnerCopyingImageFileFromOneOfHisBoardToAnotherTest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingImageFileFromOneOfHisBoardToAnother:-> Start");

		// Step 1: Upload a file in the Root folder of the owner
		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName);
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		// Step 2: Owner Creates a board
		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: Owner uploads a valid file from its root folder to his own
		// board.
		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod("A", objectKey, boardKey1);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 4: Now Owner creates another board.

		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Now Owner copying a file from board1 to board2
		createHeader();
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		String boardKeyFromResponse = response.extract().path("objects[0].boardKey");
		// List<String> objectKeyFromResponse =
		// response.extract().path("objectKey");
		String objectNameFromResponse = response.extract().path("objects[0].objectName");
		String objectTypeFromResponse = response.extract().path("objects[0].objectType");
		String mimeTypeFromResponse = response.extract().path("objects[0].mimeType");
		String mimeSubTypeFromResponse = response.extract().path("objects[0].mimeSubType");
		String statusFromResponse = response.extract().path("objects[0].status");

		String sourceFolderFromRepositoryUpload = response.extract().path("objects[0].sourceFolder");
		String originalDeviceKeyFromRepositoryUpload = response.extract().path("objects[0].originalDeviceKey");

		Verify.verifyEquals(sourceFolderFromRepositoryUpload,"1234", "Verify object type");
		Verify.verifyEquals(originalDeviceKeyFromRepositoryUpload, serverConfig.get("deviceKey"), "Verify object type");
		Verify.verifyEquals(boardKeyFromResponse, boardKey2, "verify boardKeyFromResponse of created board");
		// Verify.verifyEquals(objectKeyFromResponse.get(0), newObjectKey,
		// "verify objectKeyFromResponse of created board");
		Verify.verifyEquals(objectNameFromResponse, fileName, "verify objectNameFromResponse of created board");
		Verify.verifyEquals(objectTypeFromResponse, "BB", "verify objectTypeFromResponse of created board");
		Verify.verifyEquals(mimeTypeFromResponse, "image", "verify mimeTypeFromResponse of created board");
		Verify.verifyEquals(mimeSubTypeFromResponse, "jpeg", "verify mimeSubTypeFromResponse of created board");
		Verify.verifyEquals(statusFromResponse, "A", "verify statusFromResponse of created board");

		String ObjectKeyFromSecondBoard = response.extract().path("objects[0].objectKey");

		System.out.println("boardKey2======" + boardKey2);
		System.out.println("ObjectKeyFromSecondBoard======" + ObjectKeyFromSecondBoard);

		ValidatableResponse feedResponse = BoardsFeedBaseScript.getGetBoardsFeedService();
		int index = BoardsFeedBaseScript.getBoardIndexFromResponse(feedResponse, boardKey2);

		String boardCoverPicObjectKeyFromResponse = feedResponse.extract()
				.path("boards[" + index + "].boardCoverPicObjectKey");
		Verify.verifyEquals(boardCoverPicObjectKeyFromResponse, ObjectKeyFromSecondBoard, "Verify board Name");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/copyFileFromAnotherBoardTest-Schema.json"));

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingImageFileFromOneOfHisBoardToAnother:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the success code if user copies an audio file from his one board to another.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithOwnerCopyingAudioFileFromOneOfHisBoardToAnother()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingAudioFileFromOneOfHisBoardToAnother:-> Start");

		// Step 1: Upload a file in the Root folder of the owner

		String fileName = "Sample.mp3";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName);
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		// Step 2: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: Owner uploads a valid file from its root folder to his own
		// board.

		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod("A", objectKey, boardKey1);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");
		// Step 4: Now Owner creates another board.

		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Now Owner copying a file from board1 to board2
		createHeader();
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		String boardKeyFromResponse = response.extract().path("objects[0].boardKey");
		// List<String> objectKeyFromResponse =
		// response.extract().path("objectKey");
		String objectNameFromResponse = response.extract().path("objects[0].objectName");
		String objectTypeFromResponse = response.extract().path("objects[0].objectType");
		String mimeTypeFromResponse = response.extract().path("objects[0].mimeType");
		String mimeSubTypeFromResponse = response.extract().path("objects[0].mimeSubType");
		String statusFromResponse = response.extract().path("objects[0].status");

		Verify.verifyEquals(boardKeyFromResponse, boardKey2, "verify boardKeyFromResponse of created board");
		// Verify.verifyEquals(objectKeyFromResponse.get(0), newObjectKey,
		// "verify objectKeyFromResponse of created board");
		Verify.verifyEquals(objectNameFromResponse, fileName, "verify objectNameFromResponse of created board");
		Verify.verifyEquals(objectTypeFromResponse, "BB", "verify objectTypeFromResponse of created board");
		Verify.verifyEquals(mimeTypeFromResponse, "audio", "verify mimeTypeFromResponse of created board");
		Verify.verifyEquals(mimeSubTypeFromResponse, "mpeg", "verify mimeSubTypeFromResponse of created board");
		Verify.verifyEquals(statusFromResponse, "A", "verify statusFromResponse of created board");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/copyFileFromAnotherBoardTest-Schema.json"));

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingAudioFileFromOneOfHisBoardToAnother:-> End");

	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the success code if user copies an video file from his one board to another.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithOwnerCopyingVideoFileFromOneOfHisBoardToAnother()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingVideoFileFromOneOfHisBoardToAnother:-> Start");

		// Step 1: Upload a file in the Root folder of the owner

		String fileName = "Sample.mp4";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName);
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		// Step 2: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: Owner uploads a valid file from its root folder to his own
		// board.

		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod("A", objectKey, boardKey1);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 4: Now Owner creates another board.

		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Now Owner copying a file from board1 to board2
		createHeader();
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);
		String boardKeyFromResponse = response.extract().path("objects[0].boardKey");
		// List<String> objectKeyFromResponse =
		// response.extract().path("objectKey");
		String objectNameFromResponse = response.extract().path("objects[0].objectName");
		String objectTypeFromResponse = response.extract().path("objects[0].objectType");
		String mimeTypeFromResponse = response.extract().path("objects[0].mimeType");
		String mimeSubTypeFromResponse = response.extract().path("objects[0].mimeSubType");
		String statusFromResponse = response.extract().path("objects[0].status");

		Verify.verifyEquals(boardKeyFromResponse, boardKey2, "verify boardKeyFromResponse of created board");
		// Verify.verifyEquals(objectKeyFromResponse.get(0), newObjectKey,
		// "verify objectKeyFromResponse of created board");
		Verify.verifyEquals(objectNameFromResponse, fileName, "verify objectNameFromResponse of created board");
		Verify.verifyEquals(objectTypeFromResponse, "BB", "verify objectTypeFromResponse of created board");
		Verify.verifyEquals(mimeTypeFromResponse, "video", "verify mimeTypeFromResponse of created board");
		Verify.verifyEquals(mimeSubTypeFromResponse, "mp4", "verify mimeSubTypeFromResponse of created board");
		Verify.verifyEquals(statusFromResponse, "A", "verify statusFromResponse of created board");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/copyFileFromAnotherBoardTest-Schema.json"));

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingVideoFileFromOneOfHisBoardToAnother:-> End");

	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the success code if user copies an document file from his one board to another.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithOwnerCopyingDocFileFromOneOfHisBoardToAnother()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingDocFileFromOneOfHisBoardToAnother:-> Start");

		// Step 1: Upload a file in the Root folder of the owner

		String fileName = "Sample.pdf";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName);
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		// Step 2: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: Owner uploads a valid file from its root folder to his own
		// board.

		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod("A", objectKey, boardKey1);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 4: Now Owner creates another board.

		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Now Owner copying a file from board1 to board2
		createHeader();
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		String boardKeyFromResponse = response.extract().path("objects[0].boardKey");
		// List<String> objectKeyFromResponse =
		// response.extract().path("objectKey");
		String objectNameFromResponse = response.extract().path("objects[0].objectName");
		String objectTypeFromResponse = response.extract().path("objects[0].objectType");
		String mimeTypeFromResponse = response.extract().path("objects[0].mimeType");
		String mimeSubTypeFromResponse = response.extract().path("objects[0].mimeSubType");
		String statusFromResponse = response.extract().path("objects[0].status");

		Verify.verifyEquals(boardKeyFromResponse, boardKey2, "verify boardKeyFromResponse of created board");
		// Verify.verifyEquals(objectKeyFromResponse.get(0), newObjectKey,
		// "verify objectKeyFromResponse of created board");
		Verify.verifyEquals(objectNameFromResponse, fileName, "verify objectNameFromResponse of created board");
		Verify.verifyEquals(objectTypeFromResponse, "BB", "verify objectTypeFromResponse of created board");
		Verify.verifyEquals(mimeTypeFromResponse, "application", "verify mimeTypeFromResponse of created board");
		Verify.verifyEquals(mimeSubTypeFromResponse, "pdf", "verify mimeSubTypeFromResponse of created board");
		Verify.verifyEquals(statusFromResponse, "A", "verify statusFromResponse of created board");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/copyFileFromAnotherBoardTest-Schema.json"));

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingDocFileFromOneOfHisBoardToAnother:-> End");

	}

	// Commenting as Hyperlink is not Present in board
	// @Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
	// + ":Verify the success code if user copies an hyperlink from his one
	// board to another.", groups = {
	// TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void copyFileFromAnotherBoardTestWithOwnerCopyingHyperlinkFromOneOfHisBoardToAnother()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingHyperlinkFromOneOfHisBoardToAnother:-> Start");

		String hyperlink = "http://tutorialspoint.com";
		// Step 1: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner creates a hyperlink in the board.
		CreateBoardHyperlinkBaseScript.createBoardHyperlinkServiceMethod(hyperlink, boardKey1);

		// Step 4: Now Owner creates another board.

		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Now Owner copying a hyperlink from board1 to board2
		createHeader();
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(),
				repositoryMap.get(RepositoryParameterEnum.HYPERLINKOBJECTKEY.getValue()),
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		String boardKeyFromResponse = response.extract().path("objects[0].boardKey");
		// List<String> objectKeyFromResponse =
		// response.extract().path("objectKey");
		String objectNameFromResponse = response.extract().path("objects[0].objectName");
		String objectTypeFromResponse = response.extract().path("objects[0].objectType");
		String mimeTypeFromResponse = response.extract().path("objects[0].mimeType");
		String mimeSubTypeFromResponse = response.extract().path("objects[0].mimeSubType");
		String statusFromResponse = response.extract().path("objects[0].status");

		Verify.verifyEquals(boardKeyFromResponse, boardKey2, "verify boardKeyFromResponse of created board");
		// Verify.verifyEquals(objectKeyFromResponse.get(0), newObjectKey,
		// "verify objectKeyFromResponse of created board");
		// Verify.verifyEquals(objectNameFromResponse, hyperlink, "verify
		// objectNameFromResponse of created board");
		Verify.verifyEquals(objectTypeFromResponse, "HL", "verify objectTypeFromResponse of created board");
		Verify.verifyEquals(mimeTypeFromResponse, "href", "verify mimeTypeFromResponse of created board");
		// Verify.verifyEquals(mimeSubTypeFromResponse, "jpeg", "verify
		// mimeSubTypeFromResponse of created board");
		Verify.verifyEquals(statusFromResponse, "A", "verify statusFromResponse of created board");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/copyFileFromAnotherBoardTest-Schema.json"));

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingHyperlinkFromOneOfHisBoardToAnother:-> End");

	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the success code if contributor copies one file from his own board to shared baord.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithContributorCopyingImageFileFromHisBoardToOwnersBoard()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep(
				"copyFileFromAnotherBoardTestWithContributorCopyingImageFileFromHisBoardToOwnersBoard:-> Start");

		// Step 1: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// ValidatableResponse responseSendInvite =
		// SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKey1,
		// deviceContributorInfo.get("firstName"),
		// deviceContributorInfo.get("lastName"),
		// deviceContributorInfo.get("emailId"), "C");
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey1, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: Other user accepts the invitation and becomes contributor of
		// the board.

		createHeader(deviceContributorInfo);
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: Contributor creates his own board
		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(deviceContributorInfo, boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step5: Contributor uploads a file to his root folder

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName,
				deviceContributorInfo);
		String objectKeyContributor = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		// Step 6: Contributor uplaods a file to his own baord.
		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod(deviceContributorInfo, "A", objectKeyContributor, boardKey2);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 7: Now Contributor copying a file from his own board to owner's
		// board.

		createHeader(deviceContributorInfo);
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey2,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey1);

		String boardKeyFromResponse = response.extract().path("objects[0].boardKey");
		// List<String> objectKeyFromResponse =
		// response.extract().path("objectKey");
		String objectNameFromResponse = response.extract().path("objects[0].objectName");
		String objectTypeFromResponse = response.extract().path("objects[0].objectType");
		String mimeTypeFromResponse = response.extract().path("objects[0].mimeType");
		String mimeSubTypeFromResponse = response.extract().path("objects[0].mimeSubType");
		String statusFromResponse = response.extract().path("objects[0].status");

		Verify.verifyEquals(boardKeyFromResponse, boardKey1, "verify boardKeyFromResponse of created board");
		// Verify.verifyEquals(objectKeyFromResponse.get(0), newObjectKey,
		// "verify objectKeyFromResponse of created board");
		// Verify.verifyEquals(objectNameFromResponse, fileName, "verify
		// objectNameFromResponse of created board");
		Verify.verifyEquals(objectTypeFromResponse, "BB", "verify objectTypeFromResponse of created board");
		Verify.verifyEquals(mimeTypeFromResponse, "image", "verify mimeTypeFromResponse of created board");
		Verify.verifyEquals(mimeSubTypeFromResponse, "jpeg", "verify mimeSubTypeFromResponse of created board");
		Verify.verifyEquals(statusFromResponse, "A", "verify statusFromResponse of created board");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/copyFileFromAnotherBoardTest-Schema.json"));

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithContributorCopyingImageFileFromHisBoardToOwnersBoard:-> End");

	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the success code if contributor copies one file from his own board to shared baord.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithContributorCopyingImageFileFromHisOneBoardToAnotherBoard()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep(
				"copyFileFromAnotherBoardTestWithContributorCopyingImageFileFromHisOneBoardToAnotherBoard:-> Start");

		// Step 1: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey1, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: Other user accepts the invitation and becomes contributor of
		// the board.

		createHeader(deviceContributorInfo);
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: Contributor creates his own board
		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(deviceContributorInfo, boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String boardName3 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(deviceContributorInfo, boardName3);
		String boardKey3 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step5: Contributor uploads a file to his root folder

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName,
				deviceContributorInfo);
		String objectKeyContributor = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		String imageTranscodeUrlFromUpload = uploadResponse.extract().path("imageTranscodeUrl");

		// Step 6: Contributor uplaods a file to his own baord.
		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod(deviceContributorInfo, "A", objectKeyContributor, boardKey2);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 7: Now Contributor copying a file from his own board to owner's
		// board.

		createHeader(deviceContributorInfo);
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey2,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey3);

		String boardKeyFromResponse = response.extract().path("objects[0].boardKey");
		// List<String> objectKeyFromResponse =
		// response.extract().path("objectKey");
		String objectNameFromResponse = response.extract().path("objects[0].objectName");
		String objectTypeFromResponse = response.extract().path("objects[0].objectType");
		String mimeTypeFromResponse = response.extract().path("objects[0].mimeType");
		String mimeSubTypeFromResponse = response.extract().path("objects[0].mimeSubType");
		String statusFromResponse = response.extract().path("objects[0].status");

		Verify.verifyEquals(boardKeyFromResponse, boardKey3, "verify boardKeyFromResponse of created board");
		// Verify.verifyEquals(objectKeyFromResponse.get(0), newObjectKey,
		// "verify objectKeyFromResponse of created board");
		// Verify.verifyEquals(objectNameFromResponse, fileName, "verify
		// objectNameFromResponse of created board");
		Verify.verifyEquals(mimeTypeFromResponse, "image", "verify mimeTypeFromResponse of created board");
		Verify.verifyEquals(mimeSubTypeFromResponse, "jpeg", "verify mimeSubTypeFromResponse of created board");
		Verify.verifyEquals(statusFromResponse, "A", "verify statusFromResponse of created board");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/copyFileFromAnotherBoardTest-Schema.json"));

		FrameworkLogger.logStep(
				"copyFileFromAnotherBoardTestWithContributorCopyingImageFileFromHisOneBoardToAnotherBoard:-> End");

	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the success code if  contributor copying one file from shared board to his own board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithContributorCopyingImageFileFromOwnersToHisOwnBoard()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithContributorCopyingImageFileFromOwnersToHisOwnBoard:-> Start");

		// Step 1: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String strDeviceId2 = serverConfig.get("deviceKey2");

		String email1 = apiUrls.get("Email1");
		FrameworkLogger.logStep("EMAIL:" + email1);
		String password1 = apiUrls.get("Password1");
		FrameworkLogger.logStep("PASSWORD:" + password1);

		// Step2: Owner uploads a file to his root folder

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName);
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		String imageTranscodeUrlFromUpload = uploadResponse.extract().path("imageTranscodeUrl");

		// Step 3: Owner uploads a file to his own board.
		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod("A", objectKey, boardKey1);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey1, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 4: Other user accepts the invitation and becomes contributor of
		// the board.

		createHeader(deviceContributorInfo);
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 5: Contributor creates his own board
		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(deviceContributorInfo, boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 7: Now Contributor copying a file from owner's board to his own
		// board

		createHeader(deviceContributorInfo);
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		String boardKeyFromResponse = response.extract().path("objects[0].boardKey");
		// List<String> objectKeyFromResponse =
		// response.extract().path("objectKey");
		String objectNameFromResponse = response.extract().path("objects[0].objectName");
		String objectTypeFromResponse = response.extract().path("objects[0].objectType");
		String mimeTypeFromResponse = response.extract().path("objects[0].mimeType");
		String mimeSubTypeFromResponse = response.extract().path("objects[0].mimeSubType");
		String statusFromResponse = response.extract().path("objects[0].status");

		Verify.verifyEquals(boardKeyFromResponse, boardKey2, "verify boardKeyFromResponse of created board");
		// Verify.verifyEquals(objectKeyFromResponse.get(0), newObjectKey,
		// "verify objectKeyFromResponse of created board");
		// Verify.verifyEquals(objectNameFromResponse, fileName, "verify
		// objectNameFromResponse of created board");
		Verify.verifyEquals(objectTypeFromResponse, "BB", "verify objectTypeFromResponse of created board");
		Verify.verifyEquals(mimeTypeFromResponse, "image", "verify mimeTypeFromResponse of created board");
		Verify.verifyEquals(mimeSubTypeFromResponse, "jpeg", "verify mimeSubTypeFromResponse of created board");
		Verify.verifyEquals(statusFromResponse, "A", "verify statusFromResponse of created board");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/copyFileFromAnotherBoardTest-Schema.json"));

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithContributorCopyingImageFileFromOwnersToHisOwnBoard:-> End");

	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify if owner left the board, he should not able to copy to that board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithOwnerLeavingBoardAndCopyingFileToBoard()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithContributorCopyingImageFileFromOwnersToHisOwnBoard:-> Start");

		// Step 1: Upload a file in the Root folder of the owner

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName);
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		// Step 2: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: Owner uploads a valid file from its root folder to his own
		// board.

		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod("A", objectKey, boardKey1);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 4: Now Owner creates another board.

		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Owner leaving the board.
		LeaveBoardBaseScript.leaveBoardService(boardKey1);

		// Step 6: Now Owner copying a file from board1 to board2

		createHeader();
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP Status");

		String errorCode = response.extract().path("unprocessed[0].errorCode");
		String errorMessage = response.extract().path("unprocessed[0].errorMessage");

		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BRSOM0111.getValue(), "Verify Error Code");
		Verify.verifyEquals(errorMessage, "Board and Object Key mapping does not exist.", "Verify Error Message");

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithContributorCopyingImageFileFromOwnersToHisOwnBoard:-> End");
	}

	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify if owner left the board, he should not able to copy from that board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithOwnerLeaving2ndBoardAndCopyingFileToBoard()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithOwnerLeaving2ndBoardAndCopyingFileToBoard:-> Start");

		// Step 1: Upload a file in the Root folder of the owner

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName);
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		// Step 2: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: Owner uploads a valid file from its root folder to his own
		// board.

		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod("A", objectKey, boardKey1);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 4: Now Owner creates another board.

		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Owner leaving the board.
		LeaveBoardBaseScript.leaveBoardService(boardKey2);

		// Step 6: Now Owner copying a file from board1 to board2

		createHeader();
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String errorCode = response.extract().path("code");
		String errorMessage = response.extract().path("error");

		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Error Code");
		Verify.verifyEquals(errorMessage, "Board User Relation Missing.", "Verify Error Message");

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithOwnerLeaving2ndBoardAndCopyingFileToBoard:-> End");
	}

	@Test(priority = 11, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify if contributor left the board, he should not able to copy to that board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithContributorLeftTheBoardAndCopyingFile()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithContributorLeftTheBoardAndCopyingFile:-> Start");

		// Step 1: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey1, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: Other user accepts the invitation and becomes contributor of
		// the board.

		createHeader(deviceContributorInfo);
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: Contributor creates his own board
		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(deviceContributorInfo, boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step5: Contributor uploads a file to his root folder

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName,
				deviceContributorInfo);
		String objectKeyContributor = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		String imageTranscodeUrlFromUpload = uploadResponse.extract().path("imageTranscodeUrl");

		// Step 6: Contributor uplaods a file to his own baord.
		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod(deviceContributorInfo, "A", objectKeyContributor, boardKey2);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 7: Contributor leaving the board.
		LeaveBoardBaseScript.leaveBoardService(boardKey1, deviceContributorInfo);

		// Step 8: Now Contributor copying a file from his own board to owner's
		// board.

		createHeader(deviceContributorInfo);
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey2,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey1);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
		String errorCode = response.extract().path("code");
		String errorMessage = response.extract().path("error");

		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Error Code");
		Verify.verifyEquals(errorMessage, "Board User Relation Missing.", "Verify Error Message");

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithContributorLeftTheBoardAndCopyingFile:-> End");

	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify  if contributor left the board, he should not able to copy from that board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithContributorLeftTheBoard2AndCopyingFile()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithContributorLeftTheBoard2AndCopyingFile:-> Start");

		// Step 1: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey1, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: Other user accepts the invitation and becomes contributor of
		// the board.

		createHeader(deviceContributorInfo);
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		// Step 4: Contributor creates his own board
		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(deviceContributorInfo, boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step5: Contributor uploads a file to his root folder

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName,
				deviceContributorInfo);
		String objectKeyContributor = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		String imageTranscodeUrlFromUpload = uploadResponse.extract().path("imageTranscodeUrl");

		// Step 6: Contributor uplaods a file to his own baord.
		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod(deviceContributorInfo, "A", objectKeyContributor, boardKey2);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 7: Contributor leaving the board.
		LeaveBoardBaseScript.leaveBoardService(boardKey2, deviceContributorInfo);

		// Step 8: Now Contributor copying a file from his own board to owner's
		// board.

		createHeader(deviceContributorInfo);
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey2,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey1);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String errorCode = response.extract().path("unprocessed[0].errorCode");
		String errorMessage = response.extract().path("unprocessed[0].errorMessage");

		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BRSOM0111.getValue(), "Verify Error Code");
		Verify.verifyEquals(errorMessage, "Board and Object Key mapping does not exist.", "Verify Error Message");

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithContributorLeftTheBoard2AndCopyingFile:-> End");

	}
	// check 201
	// issue
	// @Test(priority = 13, description = TestNgGroups.BOARDS + ":" + apiName
	// + ":Verify if file to be copied is already there in the board then, error
	// should get generated.", groups = {
	// TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithOwnerCopyingAlreadyCopiedFile()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingAlreadyCopiedFile:-> Start");

		// Step 1: Upload a file in the Root folder of the owner

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName);
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		// Step 2: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: Owner uploads a valid file from its root folder to his own
		// board.

		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod("A", objectKey, boardKey1);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 4: Now Owner creates another board.

		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Now Owner copying a file from board1 to board2
		createHeader();
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		// Step 6: Again copy same file to same board.
		ValidatableResponse response2 = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		int status2 = response2.extract().statusCode();
		Verify.verifyEquals(status2, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		String errorCode = response.extract().path("unprocessed[0].errorCode");
		String errorMessage = response.extract().path("unprocessed[0].errorMessage");

		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BRSOM0111.getValue(), "Verify Error Code");
		Verify.verifyEquals(errorMessage, "Board and Object Key mapping does not exist.", "Verify Error Message");

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingAlreadyCopiedFile:-> End");
	}

	@Test(priority = 14, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify that after copying the file to board, board should be there in delta sync.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithOwnerCopyingFileVerifyInDeltaSync()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingFileVerifyInDeltaSync:-> Start");
		String ifModifiedSince = System.currentTimeMillis() + "";

		Thread.sleep(10000);
		// Step 1: Upload a file in the Root folder of the owner

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName);
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		// Step 2: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: Owner uploads a valid file from its root folder to his own
		// board.

		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod("A", objectKey, boardKey1);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 4: Now Owner creates another board.

		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Now Owner copying a file from board1 to board2
		createHeader();
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		String boardKeyFromResponse = response.extract().path("objects[0].boardKey");
		// List<String> objectKeyFromResponse =
		// response.extract().path("objectKey");
		String objectNameFromResponse = response.extract().path("objects[0].objectName");
		String objectTypeFromResponse = response.extract().path("objects[0].objectType");
		String mimeTypeFromResponse = response.extract().path("objects[0].mimeType");
		String mimeSubTypeFromResponse = response.extract().path("objects[0].mimeSubType");
		String statusFromResponse = response.extract().path("objects[0].status");

		Verify.verifyEquals(boardKeyFromResponse, boardKey2, "verify boardKeyFromResponse of created board");
		// Verify.verifyEquals(objectKeyFromResponse.get(0), newObjectKey,
		// "verify objectKeyFromResponse of created board");
		Verify.verifyEquals(objectNameFromResponse, fileName, "verify objectNameFromResponse of created board");
		Verify.verifyEquals(objectTypeFromResponse, "BB", "verify objectTypeFromResponse of created board");
		Verify.verifyEquals(mimeTypeFromResponse, "image", "verify mimeTypeFromResponse of created board");
		Verify.verifyEquals(mimeSubTypeFromResponse, "jpeg", "verify mimeSubTypeFromResponse of created board");
		Verify.verifyEquals(statusFromResponse, "A", "verify statusFromResponse of created board");

		// Step 6: Verify the board in delta sync response.
		ValidatableResponse responseDeltaSync = BoardsDeltaSyncBaseScript.getBoardsDeltaSyncService(ifModifiedSince);
		String boardNameFromDeltaSync = responseDeltaSync.extract().path("boards[0].boardName");
		String boardStatusFromDeltaSync = responseDeltaSync.extract().path("boards[0].status");
		int boardFilesCountFromDeltaSync = responseDeltaSync.extract().path("boards[0].filesCount");
		int imageCountFromDeltaSync = responseDeltaSync.extract().path("boards[0].imageCount");
		String boardKeyFromDeltaSync = responseDeltaSync.extract().path("boards[0].boardKey");

		Verify.verifyEquals(boardNameFromDeltaSync, boardName2, "Verify Success Status");
		Verify.verifyEquals(boardStatusFromDeltaSync, "A", "Verify Success Status");
		Verify.verifyEquals(boardFilesCountFromDeltaSync, 1, "Verify Success Status");
		Verify.verifyEquals(imageCountFromDeltaSync, 1, "Verify Success Status");
		Verify.verifyEquals(boardKeyFromDeltaSync, boardKey2, "Verify Success Status");

		// String fileNameFromDeltaSync =
		// responseDeltaSync.extract().path("boards[0].recentFiles[0].objectName");
		// String fileMimeTypeFromDeltaSync =
		// responseDeltaSync.extract().path("boards[0].recentFiles[0].mimeType");
		// String boardKeyFromRecentDeltaSync =
		// responseDeltaSync.extract().path("boards[0].recentFiles[0].boardKey");

		// Verify.verifyEquals(fileNameFromDeltaSync,"Sample.jpg" , "Verify
		// Success Status");
		// Verify.verifyEquals(fileMimeTypeFromDeltaSync, "image" , "Verify
		// Success Status");
		// Verify.verifyEquals(boardKeyFromRecentDeltaSync, boardKey2, "Verify
		// Success Status");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/copyFileFromAnotherBoardTest-Schema.json"));

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingFileVerifyInDeltaSync:-> End");
	}

	@Test(priority = 15, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify that after copying the file to board, board should be there in individual delta sync.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithOwnerCopyingFileVerifyInIndividualDeltaSync()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingFileVerifyInIndividualDeltaSync:-> Start");
		String ifModifiedSince = System.currentTimeMillis() + "";
		// Step 1: Upload a file in the Root folder of the owner

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName);
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		// Step 2: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: Owner uploads a valid file from its root folder to his own
		// board.

		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod("A", objectKey, boardKey1);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 4: Now Owner creates another board.

		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Now Owner copying a file from board1 to board2
		createHeader();
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		String boardKeyFromResponse = response.extract().path("objects[0].boardKey");
		// List<String> objectKeyFromResponse =
		// response.extract().path("objectKey");
		String objectNameFromResponse = response.extract().path("objects[0].objectName");
		String objectTypeFromResponse = response.extract().path("objects[0].objectType");
		String mimeTypeFromResponse = response.extract().path("objects[0].mimeType");
		String mimeSubTypeFromResponse = response.extract().path("objects[0].mimeSubType");
		String statusFromResponse = response.extract().path("objects[0].status");

		Verify.verifyEquals(boardKeyFromResponse, boardKey2, "verify boardKeyFromResponse of created board");
		// Verify.verifyEquals(objectKeyFromResponse.get(0), newObjectKey,
		// "verify objectKeyFromResponse of created board");
		Verify.verifyEquals(objectNameFromResponse, fileName, "verify objectNameFromResponse of created board");
		Verify.verifyEquals(objectTypeFromResponse, "BB", "verify objectTypeFromResponse of created board");
		Verify.verifyEquals(mimeTypeFromResponse, "image", "verify mimeTypeFromResponse of created board");
		Verify.verifyEquals(mimeSubTypeFromResponse, "jpeg", "verify mimeSubTypeFromResponse of created board");
		Verify.verifyEquals(statusFromResponse, "A", "verify statusFromResponse of created board");

		ValidatableResponse responseDeltaSync = IndividualBoardDeltaSyncBaseScript
				.individualBoardDeltaSyncService(boardKey2, ifModifiedSince);
		String boardNameFromDeltaSync = responseDeltaSync.extract().path("board.boardName");
		String boardStatusFromDeltaSync = responseDeltaSync.extract().path("board.status");
		int boardFilesCountFromDeltaSync = responseDeltaSync.extract().path("board.filesCount");
		int imageCountFromDeltaSync = responseDeltaSync.extract().path("board.imageCount");
		String boardKeyFromDeltaSync = responseDeltaSync.extract().path("board.boardKey");

		Verify.verifyEquals(boardNameFromDeltaSync, boardName2, "Verify Success Status");
		Verify.verifyEquals(boardStatusFromDeltaSync, "A", "Verify Success Status");
		Verify.verifyEquals(boardFilesCountFromDeltaSync, 1, "Verify Success Status");
		Verify.verifyEquals(imageCountFromDeltaSync, 1, "Verify Success Status");
		Verify.verifyEquals(boardKeyFromDeltaSync, boardKey2, "Verify Success Status");

		// String fileNameFromDeltaSync =
		// responseDeltaSync.extract().path("board.recentFiles[0].objectName");
		// String fileMimeTypeFromDeltaSync =
		// responseDeltaSync.extract().path("board.recentFiles[0].mimeType");
		// String boardKeyFromRecentDeltaSync =
		// responseDeltaSync.extract().path("board.recentFiles[0].boardKey");

		// Verify.verifyEquals(fileNameFromDeltaSync,"Sample.jpg" , "Verify
		// Success Status");
		// Verify.verifyEquals(fileMimeTypeFromDeltaSync, "image" , "Verify
		// Success Status");
		// Verify.verifyEquals(boardKeyFromRecentDeltaSync, boardKey2, "Verify
		// Success Status");

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingFileVerifyInIndividualDeltaSync:-> End");
	}

	@Test(priority = 16, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify if owner removes the user from the board then that user should not able to copy to that board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithOwnerRemovesContributorAndCopyingFile()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithOwnerRemovesContributorAndCopyingFile:-> Start");

		// Step 1: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey1, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: Other user accepts the invitation and becomes contributor of
		// the board.

		createHeader(deviceContributorInfo);
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: Contributor creates his own board
		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(deviceContributorInfo, boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step5: Contributor uploads a file to his root folder

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName,
				deviceContributorInfo);
		String objectKeyContributor = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		String imageTranscodeUrlFromUpload = uploadResponse.extract().path("imageTranscodeUrl");

		// Step 6: Contributor uplaods a file to his own baord.
		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod(deviceContributorInfo, "A", objectKeyContributor, boardKey2);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 7: owner removing Contributor from board.

		RemoveBoardMembersBaseScript.removeBoardMemberService(boardKey1, deviceContributorInfo.get("userId"));

		// Step 8: Now Contributor copying a file from his own board to owner's
		// board.

		createHeader(deviceContributorInfo);
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey2,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey1);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String errorCode = response.extract().path("code");
		String errorMessage = response.extract().path("error");

		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Error Code");
		Verify.verifyEquals(errorMessage, "Board User Relation Missing.", "Verify Error Message");

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithOwnerRemovesContributorAndCopyingFile:-> End");

	}

	@Test(priority = 17, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify  if owner removes the user from the board then that user should not able to copy from that board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void copyFileFromAnotherBoardTestWithOwnerRemovesContributorAndCopyingFileToBoard2()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerRemovesContributorAndCopyingFileToBoard2:-> Start");

		// Step 1: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey1, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: Other user accepts the invitation and becomes contributor of
		// the board.

		createHeader(deviceContributorInfo);
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 4: Contributor creates his own board
		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(deviceContributorInfo, boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step5: Contributor uploads a file to his root folder

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName,
				deviceContributorInfo);
		String objectKeyContributor = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		String imageTranscodeUrlFromUpload = uploadResponse.extract().path("imageTranscodeUrl");

		// Step 6: Contributor uplaods a file to his own baord.
		ValidatableResponse responseRepoUpload = RepositoryFileUploadToBoardBaseScript
				.repositoryFileUploadToBoardServiceMethod(deviceContributorInfo, "A", objectKeyContributor, boardKey2);
		String newObjectKey = responseRepoUpload.extract().path("objects[0].objectKey");

		// Step 7: owner removing Contributor from board.

		RemoveBoardMembersBaseScript.removeBoardMemberService(boardKey1, deviceContributorInfo.get("userId"));

		// Step 8: Now Contributor copying a file from his own board to owner's
		// board.

		createHeader(deviceContributorInfo);
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		String errorCode = response.extract().path("unprocessed[0].errorCode");
		String errorMessage = response.extract().path("unprocessed[0].errorMessage");

		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BRSOM0111.getValue(), "Verify Error Code");
		Verify.verifyEquals(errorMessage, "Board and Object Key mapping does not exist.", "Verify Error Message");

		FrameworkLogger.logStep("copyFileFromAnotherBoardTestWithOwnerRemovesContributorAndCopyingFileToBoard2:-> End");

	}

	@Test(priority = 18, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the success code if user copies an image file from his one board to another using single file upload to board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void copyFileFromAnotherBoardTestWithOwnerCopyingImageFileFromOneOfHisBoardToAnotherUsingSingleFileUploadToBoard()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingImageFileFromOneOfHisBoardToAnother:-> Start");

		// Step 1: Upload a file in the Root folder of the owner

		String fileName = "Sample.jpg";
		ValidatableResponse uploadResponse = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName);
		String objectKey = repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());

		// Step 2: Owner Creates a board

		String boardName1 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 3: Owner uploads a valid file from its root folder to his own
		// board.

		// ValidatableResponse responseRepoUpload =
		// RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod("A",
		// objectKey, boardKey1);
		// String
		// newObjectKey=responseRepoUpload.extract().path("objects[0].objectKey");
		ValidatableResponse responseRepoUpload = UploadBaseScript.getUploadFileToBoardServiceMethod(fileName,
				boardKey1);
		String newObjectKey = responseRepoUpload.extract().path("objectKey");
		// Step 4: Now Owner creates another board.

		String boardName2 = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 5: Now Owner copying a file from board1 to board2
		createHeader();
		copyFileFromAnotherBoardJsonBody = setCopyFileFromAnotherBoardJsonBody();
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceBoardKey(), boardKey1,
				copyFileFromAnotherBoardJsonBody);
		copyFileFromAnotherBoardJsonBody = setJsonData(NewBoardConstants.getSourceObjectKey(), newObjectKey,
				copyFileFromAnotherBoardJsonBody);
		ValidatableResponse response = triggerPostApiCopyFileFromAnotherBoard(boardKey2);

		String boardKeyFromResponse = response.extract().path("objects[0].boardKey");
		// List<String> objectKeyFromResponse =
		// response.extract().path("objectKey");
		String objectNameFromResponse = response.extract().path("objects[0].objectName");
		String objectTypeFromResponse = response.extract().path("objects[0].objectType");
		String mimeTypeFromResponse = response.extract().path("objects[0].mimeType");
		String mimeSubTypeFromResponse = response.extract().path("objects[0].mimeSubType");
		String statusFromResponse = response.extract().path("objects[0].status");

		Verify.verifyEquals(boardKeyFromResponse, boardKey2, "verify boardKeyFromResponse of created board");
		// Verify.verifyEquals(objectKeyFromResponse.get(0), newObjectKey,
		// "verify objectKeyFromResponse of created board");
		// Verify.verifyEquals(objectNameFromResponse, fileName, "verify
		// objectNameFromResponse of created board");
		Verify.verifyEquals(objectTypeFromResponse, "BB", "verify objectTypeFromResponse of created board");
		Verify.verifyEquals(mimeTypeFromResponse, "image", "verify mimeTypeFromResponse of created board");
		Verify.verifyEquals(mimeSubTypeFromResponse, "jpeg", "verify mimeSubTypeFromResponse of created board");
		Verify.verifyEquals(statusFromResponse, "A", "verify statusFromResponse of created board");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/copyFileFromAnotherBoardTest-Schema.json"));
		FrameworkLogger
				.logStep("copyFileFromAnotherBoardTestWithOwnerCopyingImageFileFromOneOfHisBoardToAnother:-> End");
	}
}
