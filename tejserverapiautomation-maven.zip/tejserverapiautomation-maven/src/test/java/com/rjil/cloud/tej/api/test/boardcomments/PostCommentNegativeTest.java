package com.rjil.cloud.tej.api.test.boardcomments;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boardcomments.PostCommentBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class PostCommentNegativeTest extends PostCommentBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify post comment api if user id is missing in header.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithMissingUserId() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithMissingUserId:-> Start");
		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String comment = "Nice travel memories";
		createHeader();
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");
		String code = response.extract().path("code");
		Verify.verifyEquals(code, "TEJGA0400", "Verify Success Status");
		String error = response.extract().path("error");
		Verify.verifyEquals(error, "X-User-Id Not Sent in HTTP Header", "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithMissingUserId:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify post comment api if userId is invalid", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithInvalidUserId() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithInvalidUserId:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String comment = "Nice travel memories";
		createHeader();
		headerMap.put(HeaderParameters.XUSERID.getValue(), BaseTestScript.getInvalidUserid());
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify failure Status");
		String code = response.extract().path("code");
		Verify.verifyEquals(code, "TEJGA0401", "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Authorization Token Expired or wrong", "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithInvalidUserId:-> End");
	}

	// @Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
	// + ":Verify post comment api if xdeviceKey is missing in header.", groups
	// = {
	// TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void postCommentTestWithMissingXDeviceKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithMissingXDeviceKey:-> Start");
		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String comment = "Nice travel memories";
		createHeader();
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");
		String code = response.extract().path("code");
		Verify.verifyEquals(code, "TEJGA0400", "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "X-User-Id Not Sent in HTTP Header", "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithMissingXDeviceKey:-> End");
	}

	// issue
//	 @Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
//	 + ":Verify post comment api if xDeviceKey is invalid", groups = {
//	 TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void postCommentTestWithInvalidXDeviceKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithInvalidXDeviceKey:-> Start");
		// Step 1: Owner Creates a board

		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String comment = "Nice travel memories";
		createHeader();
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), BaseTestScript.getInvalidUserid());
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");
		FrameworkLogger.logStep("postCommentTestWithInvalidXDeviceKey:-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify post comment api if boardKey is invalid.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithInvalidBoardKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithInvalidBoardKey:-> Start");
		// Step 1: Owner Creates a board

		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String comment = "Nice travel memories";
		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment("invalid23Board");
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");
		String code = response.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Board User Relation Missing.", "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithInvalidBoardKey:-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify post comment api if boardKey is missing.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithMissingBoardKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithMissingBoardKey:-> Start");
		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);

		String comment = "Nice travel memories";
		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment("");
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");
		FrameworkLogger.logStep("postCommentTestWithMissingBoardKey:-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify post comment api if comment is invalid.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithInvalidComment()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithInvalidComment:-> Start");
		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), " ", postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Http code");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0151.getValue(), "Verify failure Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Comment is missing in the request.", "Verify Failure Message");
		FrameworkLogger.logStep("postCommentTestWithInvalidComment:-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify post comment api if comment is missing.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithMissingComment()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithMissingComment:-> Start");
		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = JsonPath.parse(postCommentJsonBody).delete(NewBoardConstants.getComment()).jsonString();
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0151.getValue(), "Verify failure Status");
		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Comment is missing in the request.", "Verify Failure Message");
		FrameworkLogger.logStep("postCommentTestWithMissingComment:-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify post comment api with more than 3600 characters.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void postCommentTestWithMoreThan3600Char()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithMoreThan3600Char:-> Start");
		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String comment = generateString(3600).toString();
		FrameworkLogger.logStep("Comment:-> End" + comment);
		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");
		String code = response.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0152.getValue(), "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Comment length must be less than 3600 characters", "Verify Success Status");
		FrameworkLogger.logStep("postCommentTestWithMoreThan3600Char:-> End");
	}
}
