package com.rjil.cloud.mailchamp.test;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.mailchamp.common.helper.SyncDataAndGetSubscriptionBaseClass;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.enums.HeaderParameters;


public class SyncDataAndGetSubscriptionNegative extends SyncDataAndGetSubscriptionBaseClass {

	public ValidatableResponse response;

	@Test(description = "TC_11 - To verify SyncDataAndGetSubscriptions API, for Invalid X-Mcs-Access-Token", 
			groups = {TestNgGroups.REGRESSION })
	public void aInvaliToken() {
		String syncAuthCode = "12345dfsdfgsdgdfgdsgdsg";
		Map<String, String> headerMap = createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), syncAuthCode);

		response = triggerGetApi(getSynsDataUrl(), headerMap);
		int intsyncStatus = response.extract().statusCode();
		System.out.println("Status Code for invalid AuthCode is: " + intsyncStatus);
		Assert.assertEquals(intsyncStatus, 401);
	}

	@Test(description = "TC_12 - To verify SyncDataAndGetSubscriptions API, for Invalid X-User-Id.", 
			groups = {TestNgGroups.REGRESSION })
	public void bInvalidUserId() {
		String invalidUserId = "abc123";
		Map<String, String> headerMap = createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(), invalidUserId);

		response = triggerGetApi(getSynsDataUrl(), headerMap);
		int intSyncStatus = response.extract().statusCode();
		System.out.println("Status Code for Invalid User ID is: " + intSyncStatus);
		Assert.assertEquals(intSyncStatus, 400);
	}

	@Test(description = "TC_13 - To verify SyncDataAndGetSubscriptions API, for MISSING X-Mcs-Access-Token", 
			groups = {TestNgGroups.REGRESSION })
	public void cMissingToken() {
		String noAuthCode = "";
		Map<String, String> headerMap = createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), noAuthCode);

		response = triggerGetApi(getSynsDataUrl(), headerMap);
		int intSyncStatus = response.extract().statusCode();
		System.out.println("Status Code for Missing AuthCode is: " + intSyncStatus);
		Assert.assertEquals(intSyncStatus, 400);
	}

	@Test(description = "TC_14 - To verify SyncDataAndGetSubscriptions API, for MISSING X-User-Id.", 
			groups = {TestNgGroups.REGRESSION })
	public void dMissingUserId() {
		String noUserId = "";
		Map<String, String> headerMap = createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(), noUserId);

		response = triggerGetApi(getSynsDataUrl(), headerMap);
		int intSyncStatus = response.extract().statusCode();
		System.out.println("Status Code for Missing UserID is: " + intSyncStatus);
		Assert.assertEquals(intSyncStatus, 400);
	}

}
