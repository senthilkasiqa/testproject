package com.rjil.cloud.tej.api.test.boards;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boards.BoardsDeltaSyncBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class BoardDeltaSyncNegativeTest extends BoardsDeltaSyncBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response if if-modified-since with value=0", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForIfModifiedSince0()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" BoardsDeltaSyncTestForIfModifiedSince0:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = "0";

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(ifModifiedSince);
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForIfModifiedSince0:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response if if-modified-since with value=Negative value", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForIfModifiedSinceNegative()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" BoardsDeltaSyncTestForIfModifiedSinceNegative:-> Start");

		// If-Modified-since header is set to currentTime.

		String ifModifiedSince = "-1";
		// Now create a new board

		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api

		createHeader(ifModifiedSince);
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get boards delta sync api returns response code as 400
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForIfModifiedSinceNegative:-> End");
	}

	// ISSUE
	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response if if-modified-since with value=future value", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForIfModifiedSinceFuturValue()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" BoardsDeltaSyncTestForIfModifiedSinceFuturValue:-> Start");

		// If-Modified-since header is set to currentTime.

		String ifModifiedSince = "4015208209000";

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(ifModifiedSince);
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get boards delta sync api returns response code as 400
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForIfModifiedSinceFuturValue:-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response if if-modified-since with value=null value", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForIfModifiedSinceNullValue()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("BoardsDeltaSyncTestForIfModifiedSinceNullValue:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = "";

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(ifModifiedSince);
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get boards delta sync api returns response code as 400
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForIfModifiedSinceNullValue:-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response if if-modified-since is missing", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })

	public void BoardsDeltaSyncTestForMissingIfModifiedSince()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("BoardsDeltaSyncTestForMissingIfModifiedSince:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = System.currentTimeMillis() + "";

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(ifModifiedSince);
		headerMap.remove(HeaderParameters.IFMODIFIEDSINCE.getValue());
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get boards delta sync api returns response code as 400
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		String code = response.extract().path("code");
		String error = response.extract().path("error");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0116.getValue(), "Verify failure Status");
		Verify.verifyEquals(error, "Missing/Invalid Value in If-Modified-Since.", "Verify failure Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForIfModifiedSinceNullValue:-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response if XuserId is missing", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForMissingXuserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("BoardsDeltaSyncTestForMissingXuserId:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = System.currentTimeMillis() + "";

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(ifModifiedSince);
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get boards delta sync api returns response code as 400
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		String code = response.extract().path("code");
		String error = response.extract().path("error");

		Verify.verifyEquals(code, "TEJGA0400", "Verify failure Status");
		Verify.verifyEquals(error, "X-User-Id Not Sent in HTTP Header", "Verify failure Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForMissingXuserId:-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response if Xdevicekey is missing", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForMissingXDeviceKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("BoardsDeltaSyncTestForMissingXDeviceKey:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = System.currentTimeMillis() + "";

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(ifModifiedSince);
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get boards delta sync api returns response code as 400
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForMissingXDeviceKey:-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response if XUserId is invalid ", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void BoardsDeltaSyncTestForInvalidXuserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("BoardsDeltaSyncTestForInvalidXuserId:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = System.currentTimeMillis() + "";

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(ifModifiedSince);
		headerMap.put(HeaderParameters.XUSERID.getValue(), BaseTestScript.getInvalidUserid());
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get boards delta sync api returns response code as 400
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify failure Status");
		String code = response.extract().path("code");
		String error = response.extract().path("error");

		Verify.verifyEquals(code, "TEJGA0401", "Verify failure Status");
		Verify.verifyEquals(error, "Authorization Token Expired or wrong", "Verify failure Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForInvalidXuserId:-> End");
	}

	// ISSUE
	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response if Xdevicekey is invalid", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForInvalidXDeviceKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("BoardsDeltaSyncTestForInvalidXDeviceKey:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = System.currentTimeMillis() + "";

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(ifModifiedSince);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), "abhabah");
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get boards delta sync api returns response code as 400
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForInvalidXDeviceKey:-> End");
	}

	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response for invalid url", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForInvalidUrl() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("BoardsDeltaSyncTestForInvalidUrl:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = System.currentTimeMillis() + "";

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(ifModifiedSince);
		ValidatableResponse response = triggerGetBoardsDeltaSync("boardsDeltaSyncInvalidUrl", "0", "20");

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get boards delta sync api returns response code as 400
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE500.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForInvalidUrl:-> End");
	}

	@Test(priority = 11, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response for invalid url", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForValidPageAndInvalidLimit()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("BoardsDeltaSyncTestForValidPageAndInvalidLimit:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = System.currentTimeMillis() + "";

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(ifModifiedSince);
		ValidatableResponse response = triggerGetBoardsDeltaSync("boardDeltaSyncUrlWithPageAndLimit", "0", "db");

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get boards delta sync api returns response code as 400
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		String code = response.extract().path("code");
		String error = response.extract().path("error");
		Verify.verifyEquals(code, "BRSOM0089", "Verify Board Media Auth Status");
		Verify.verifyEquals(error, "Missing/Invalid Value in Offset.", "Verify Success Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForValidPageAndInvalidLimit:-> End");
	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response for invalid url", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForInvalidPageAndValidLimit()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("BoardsDeltaSyncTestForInvalidPageAndValidLimit:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = System.currentTimeMillis() + "";

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(ifModifiedSince);
		ValidatableResponse response = triggerGetBoardsDeltaSync("boardDeltaSyncUrlWithPageAndLimit", "ss", "20");

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get boards delta sync api returns response code as 400
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		String code = response.extract().path("code");
		String error = response.extract().path("error");
		Verify.verifyEquals(code, "BRSOM0157", "Verify Board Media Auth Status");
		Verify.verifyEquals(error, "Missing/Invalid Value in Offset.", "Verify Success Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForInvalidPageAndValidLimit:-> End");
	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response for invalid url", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForInvalidPageAndInvalidLimit()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("BoardsDeltaSyncTestForInvalidPageAndInvalidLimit:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = System.currentTimeMillis() + "";

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(ifModifiedSince);
		ValidatableResponse response = triggerGetBoardsDeltaSync("boardDeltaSyncUrlWithPageAndLimit", "jbd", "@");

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get boards delta sync api returns response code as 400
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		String code = response.extract().path("code");
		String error = response.extract().path("error");
		Verify.verifyEquals(code, "BRSOM0089", "Verify Board Media Auth Status");
		Verify.verifyEquals(error, "Missing/Invalid Value in Offset.", "Verify Success Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForInvalidPageAndInvalidLimit:-> End");
	}
}
