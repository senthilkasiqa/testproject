package com.rjil.cloud.tej.api.test.boardinvites;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.boardinvites.DeclineBoardRequestBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class DeclineBoardRequestNegativeTest extends DeclineBoardRequestBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the resposne for invalid code in the url.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithInvalidInvitationCode()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithInvalidInvitationCode-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Get details of other user
		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest("po*&^kggvv", deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");
		String errorCodeFromResponse1 = response.extract().path("code");
		String errorMessageFromResponse1 = response.extract().path("error");
		Verify.verifyEquals(errorCodeFromResponse1, ErrorResponseCodes.ERRORCODE_BINVS0014.getValue(),
				"verify errorCode");
		Verify.verifyEquals(errorMessageFromResponse1, "Invalid invite code.", "verify errorMessage");
		FrameworkLogger.logStep("declineBoardRequestTestWithInvalidInvitationCode-> End");
	}

	@Test(enabled = false, priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the resposne for null code in the url.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithNullInvitationCode()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithNullInvitationCode-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKey, "Sanj", "K",
				contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = "";

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("declineBoardRequestTestWithNullInvitationCode-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the resposne for missing code in the url.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithMissingInvitationCode()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithMissingInvitationCode-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest("/invites//decline", invitationCode,
				deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");
		FrameworkLogger.logStep("declineBoardRequestTestWithMissingInvitationCode-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the resposne for invalid url.", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithInvalidUrl()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithInvalidUrl-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest("/invites/" + invitationCode + "/decline",
				invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE500.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("declineBoardRequestTestWithInvalidUrl-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the resposne for missing XuserId", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithMissingXuserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithMissingXuserId-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequestWithRemovedHeader(invitationCode,
				deviceContributorInfo, HeaderParameters.XUSERID.getValue());
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("declineBoardRequestTestWithMissingXuserId-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the resposne for missing XdeviceKey", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithMissingXdeviceKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithMissingXdeviceKey-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequestWithRemovedHeader(invitationCode,
				deviceContributorInfo, HeaderParameters.XUSERID.getValue());
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");
		String errorCodeFromResponse1 = response.extract().path("code");
		String errorMessageFromResponse1 = response.extract().path("error");

		Verify.verifyEquals(errorCodeFromResponse1, ErrorResponseCodes.ERRORCODE_TEJGA0400.getValue(),
				"verify errorCode");
		Verify.verifyEquals(errorMessageFromResponse1, "X-User-Id Not Sent in HTTP Header", "verify errorMessage");
		FrameworkLogger.logStep("declineBoardRequestTestWithMissingXdeviceKey-> End");
	}
}
