/**
 * 
 */
package com.rjil.cloud.tej.api.test.boards;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.Validatable;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.DeclineBoardRequestBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.RemoveBoardMembersBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.fileupload.ChunkFileUploadBaseScript;
import com.rjil.cloud.tej.apihelpers.fileupload.InitiateChunkUploadBaseScript;
import com.rjil.cloud.tej.apihelpers.nms.CreateFolderBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;
import com.rjil.cloud.tej.utility.CommonUtilityMethods;

/**
 * @author User
 *
 */
public class ChunkFileUploadForBoardTest extends ChunkFileUploadBaseScript{

	@Test(priority = 2, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk file upload on board by owner with valid data and verify status code", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD, TestNgGroups.QASANITY })

	public void testChunkUploadFileOnBoardWithValidDataAndVerifyStatusCode() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithValidDataAndVerifyStatusCode: Start");
		
		String chunkSizeValue="1024000";
		
		//String fileName="WIN_20161208_190534.MP4";
		String fileName="Mehram.mp4";
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		String boardKey=createBoardResponse.extract().path("boardKey");
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,false,false,false);
		
		String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
		ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
		chunk.uploadFileHelper(fileName,transactionId,chunkSizeValue,offsetValue);
		
		Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		/*String fileName1="WIN_20161208_190534.MP4";
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName1,boardKey,false,false,false);
		
		String transactionId1=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
		chunk.uploadFileHelper(fileName1,transactionId1,chunkSizeValue,offsetValue);
		
		Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		*/
		
	}
	
	
	@Test(priority = 3, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk file upload on board by contributor with valid data and verify status code", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardForContributor() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithValidDataAndVerifyStatusCode: Start");
		
		
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		String boardKey=createBoardResponse.extract().path("boardKey");
		//Send invite
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
		boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
			
		//Accept invite
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
												deviceContributorInfo);

		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,deviceContributorInfo,false,false,false);
		
		String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
		ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
		FrameworkLogger.logStep(deviceContributorInfo.toString());
		
		FrameworkLogger.logStep("AccessToken:"+deviceContributorInfo.get("authtoken"));
		
		chunk.uploadFileHelperForBoard(fileName,transactionId, chunkSizeValue,offsetValue,userIdOfContributor,deviceContributorInfo.get("authtoken"),deviceContributorInfo.get("deviceKey") );
		
		Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithValidDataAndVerifyStatusCode: End");
	}
	
	//Issue
	@Test(priority = 4, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk file upload on board by member who is not part of a board", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardForMemberWhoIsNotPartOfBoard() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardForMemberWhoIsNotPartOfBoard: Start");
		
		
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
        ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey=createBoardResponse.extract().path("boardKey");
		
		//Send invite
		//ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
		//boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		//String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
			
		//Accept invite
		//AcceptInvitationBaseScript.acceptInvitationService(invitationCode,deviceContributorInfo);

		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,deviceContributorInfo,false,false,false);
		
		//String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
		//ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
		//chunk.uploadFileHelperForBoard(fileName,transactionId, chunkSizeValue,offsetValue,userIdOfContributor,deviceContributorInfo.get("authtoken"),deviceContributorInfo.get("deviceKey") );
		
		//Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardForMemberWhoIsNotPartOfBoard: End");
	}
	
	//Issue
	@Test(priority = 5, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk file upload on board for owner who left board", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardForOwnerWhoLeftBoard() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardForOwnerWhoLeftBoard: Start");
		
		
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		//Send invite
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
		boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
			
		//Accept invite
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode,deviceContributorInfo);

		LeaveBoardBaseScript.leaveBoardService(boardKey);
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,false,false,false);
		
		//String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
		//ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
		//chunk.uploadFileHelper(fileName,transactionId,chunkSizeValue,offsetValue);
		
		//Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardForOwnerWhoLeftBoard: End");
	}
	
	//Issue
	@Test(priority = 6, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk file upload on board for contributor who left board", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardForContributorWhoLeftBoard() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardForContributorWhoLeftBoard: Start");
		
		
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		//Send invite
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
		boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
			
		//Accept invite
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode,deviceContributorInfo);

		LeaveBoardBaseScript.leaveBoardService(boardKey,deviceContributorInfo);
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,deviceContributorInfo,false,false,false);
		
	//	String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
	//	ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
	//	chunk.uploadFileHelperForBoard(fileName,transactionId, chunkSizeValue,offsetValue,userIdOfContributor,deviceContributorInfo.get("authtoken"),deviceContributorInfo.get("deviceKey") );
		
	//	Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardForContributorWhoLeftBoard: End");
	}

	//Issue
	@Test(priority = 7, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk file upload on board for contributor who is removed by owner", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardForContributorWhoIsRemovedByOwner() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardForContributorWhoIsRemovedByOwner: Start");
		
		
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		//Send invite
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
		boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
			
		//Accept invite
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode,deviceContributorInfo);

		RemoveBoardMembersBaseScript.removeBoardMemberService(boardKey, userIdOfContributor);
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,deviceContributorInfo,false,false,false);
		
	//	String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
	//	ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
	//	chunk.uploadFileHelperForBoard(fileName,transactionId, chunkSizeValue,offsetValue,userIdOfContributor,deviceContributorInfo.get("authtoken"),deviceContributorInfo.get("deviceKey") );
		
	//	Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardForContributorWhoIsRemovedByOwner: End");
	}

	//Issue
	@Test(priority = 8, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk file upload on board for member who decline board request", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardForMemberWhoDeclineBoardRequest() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardForContributorWhoLeftBoard: Start");
		
		
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		//Send invite
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
		boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
			
		//Decline invite
		DeclineBoardRequestBaseScript.declineInvitationService(invitationCode, deviceContributorInfo);
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,deviceContributorInfo,false,false,false);
		
	//	String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
	//	ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
	//	chunk.uploadFileHelperForBoard(fileName,transactionId, chunkSizeValue,offsetValue,userIdOfContributor,deviceContributorInfo.get("authtoken"),deviceContributorInfo.get("deviceKey") );
		
	//	Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardForContributorWhoLeftBoard: End");
	}
	
	@Test(priority = 9, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk file upload on board with isBoardCoverPic true in request", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardWithIsBoardCoverPicTrue() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithIsBoardCoverPicTrue: Start");
		
		
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		//baseScript.initiateUploadJSONBody= setJsonData(UploadConstants.getBoardCoverPic(), true, baseScript.initiateUploadJSONBody);
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,true,false,false);
		
		String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
		ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
		chunk.uploadFileHelper(fileName,transactionId,chunkSizeValue,offsetValue);
		
		Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithIsBoardCoverPicTrue: End");
	}
	
	@Test(priority = 10, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Update the existing board cover pic with new file", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardWithUpdateCoverPicOfBoardWithNewFile() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithUpdateCoverPicOfBoardWithNewFile: Start");
		
		
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		//baseScript.initiateUploadJSONBody= setJsonData(UploadConstants.getBoardCoverPic(), true, baseScript.initiateUploadJSONBody);
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,true,false,false);
		
		String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
		ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
		chunk.uploadFileHelper(fileName,transactionId,chunkSizeValue,offsetValue);
		
		Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		String fileName1="WIN_20161208_190534.MP4";
		
		
		CommonUtilityMethods.updateFile(fileName1);
		
		String boardName1 = "Board___"+Utils.getUniqueId();
		
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1=repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//InitiateChunkUploadBaseScript baseScript1= new InitiateChunkUploadBaseScript();
		
		//baseScript.initiateUploadJSONBody= setJsonData(UploadConstants.getBoardCoverPic(), true, baseScript.initiateUploadJSONBody);
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName1,boardKey1,true,false,false);
		
		String transactionId1=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
		//ChunkFileUploadBaseScript chunk1 = new ChunkFileUploadBaseScript();
		
		chunk.uploadFileHelper(fileName1,transactionId1,chunkSizeValue,offsetValue);
		
		Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithUpdateCoverPicOfBoardWithNewFile: End");
	}
	
	@Test(priority = 11, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk file upload on board on a board and make it as cover pic of board without boardKey", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardWithMakeUploadedFileAsBoardCoverPicWithNullBoardKey() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithMakeUploadedFileAsBoardCoverPicWithNullBoardKey: Start");
		
		
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		//baseScript.initiateUploadJSONBody= setJsonData(UploadConstants.getBoardCoverPic(), true, baseScript.initiateUploadJSONBody);
		
		ValidatableResponse response=baseScript.initiateChunkFileUploadServiceMethod(fileName,null,true,false,false);
		
		int status= response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
    	
    	
    	String code = response.extract().path("code");
    	String error = response.extract().path("error");
    	
    	Verify.verifyEquals(code,ErrorResponseCodes.ERRORCODE_TEJUF0421.getValue(), "Verify Success Status");
    	Verify.verifyEquals(error, "boardKey is mandatory when isBoardCoverPic is TRUE.", "Verify Success Status");
    	
		
		String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
	//	ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
	//	chunk.uploadFileHelper(fileName,transactionId,chunkSizeValue,offsetValue);
		
	//	Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithMakeUploadedFileAsBoardCoverPicWithNullBoardKey: End");
	}
	
	@Test(priority = 12, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk file upload on board with no baorKey and baordCoverPic is false.", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardWithNullBoardKeyAndBoardCoverPicFalse() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithMakeUploadedFileAsBoardCoverPicWithNullBoardKey: Start");
		
		
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		//baseScript.initiateUploadJSONBody= setJsonData(UploadConstants.getBoardCoverPic(), true, baseScript.initiateUploadJSONBody);
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName,null,false,false,false);
		
		
		String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
		ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
		chunk.uploadFileHelper(fileName,transactionId,chunkSizeValue,offsetValue);
		
	//	Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE200.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithMakeUploadedFileAsBoardCoverPicWithNullBoardKey: End");
	}
	
	@Test(priority = 13, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk file upload on board with valid boarKey and valid folderKey.", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardWithValidBoardKeyAndValidFolderKey() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithMakeUploadedFileAsBoardCoverPicWithNullBoardKey: Start");
		
		ValidatableResponse createFolderresponse = CreateFolderBaseScript.createFolderServiceMethod();
		String folderKey = createFolderresponse.extract().path("objectKey");
		
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
				//repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		//baseScript.initiateUploadJSONBody= setJsonData(UploadConstants.getBoardCoverPic(), true, baseScript.initiateUploadJSONBody);
		
		ValidatableResponse response=baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,true,false,false);
		
		int status= response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
    	
    	
    	String code = response.extract().path("code");
    	String error = response.extract().path("error");
    	
    	Verify.verifyEquals(code,ErrorResponseCodes.ERRORCODE_TEJUF0434.getValue(), "Verify Success Status");
    	Verify.verifyEquals(error, "boardKey must be valid UUID", "Verify Success Status");
    	
    	
		String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
	//	ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
	//	chunk.uploadFileHelper(fileName,transactionId,chunkSizeValue,offsetValue);
		
	//	Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithMakeUploadedFileAsBoardCoverPicWithNullBoardKey: End");
	}
	
	//Issue
	@Test(priority = 14, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk Upload file on a board with invalid boardKey and boardCoverPic is true.", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardWithInvalidBoardKeyAndBoardCoverPicTrue() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithMakeUploadedFileAsBoardCoverPicWithNullBoardKey: Start");
	
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		//baseScript.initiateUploadJSONBody= setJsonData(UploadConstants.getBoardCoverPic(), true, baseScript.initiateUploadJSONBody);
		
		ValidatableResponse response=baseScript.initiateChunkFileUploadServiceMethod(fileName,"sbddkjsabd",true,false,false);
		
		int status= response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
    	
    	
    	String code = response.extract().path("code");
    	String error = response.extract().path("error");
    	
    	Verify.verifyEquals(code,ErrorResponseCodes.ERRORCODE_TEJUF0434.getValue(), "Verify Success Status");
    	Verify.verifyEquals(error, "boardKey must be valid UUID", "Verify Success Status");
    	
		
		String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
	//	ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
	//	chunk.uploadFileHelper(fileName,transactionId,chunkSizeValue,offsetValue);
		
	//	Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithMakeUploadedFileAsBoardCoverPicWithNullBoardKey: End");
	}
	
	//@Test(priority = 15, description = TestNgGroups.UPLOAD + ":" + apiName
	//		+ "Chunk upload file on a board with valid boarKey and invalid baordCoverPic.", groups = {TestNgGroups.REGRESSION,
	//				TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardWithValidBoardKeyAndInvalidBoardCoverPic() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithValidBoardKeyAndInvalidBoardCoverPic: Start");
	
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		//baseScript.initiateUploadJSONBody= setJsonData(UploadConstants.getBoardCoverPic(), true, baseScript.initiateUploadJSONBody);
		
		ValidatableResponse response=baseScript.initiateChunkFileUploadServiceMethod(fileName,"sbddkjsabd",true,false,false);
		
		int status= response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
    	
    	
    	String code = response.extract().path("code");
    	String error = response.extract().path("error");
    	
    	Verify.verifyEquals(code,ErrorResponseCodes.ERRORCODE_TEJUF0420.getValue(), "Verify Success Status");
    	Verify.verifyEquals(error, "Only one of folderKey or boardKey is accepted in the same request.", "Verify Success Status");
    	
		
		String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
		
	//	ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
	//	chunk.uploadFileHelper(fileName,transactionId,chunkSizeValue,offsetValue);
		
	//	Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithValidBoardKeyAndInvalidBoardCoverPic: End");
	}
	
	@Test(priority = 16, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk file upload on board with valid boarKey and isProfilePic, isAutoUpload or isContactPhoto true", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardWithWithValidBoardKeyAndisProfilePicTrue() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithWithValidBoardKeyAndisProfilePicTrue: Start");
	
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		//baseScript.initiateUploadJSONBody= setJsonData(UploadConstants.getBoardCoverPic(), true, baseScript.initiateUploadJSONBody);
		
		ValidatableResponse response=baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,true,true,true);
		
		int status= response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
    	
    	
    	String code = response.extract().path("code");
    	String error = response.extract().path("error");
    	
    	Verify.verifyEquals(code,ErrorResponseCodes.ERRORCODE_TEJUF0409.getValue(), "Verify Success Status");
    	Verify.verifyEquals(error, "Only one of isProfilePic, isAutoUpload or isContactPhoto is accepted in the same request.", "Verify Success Status");
    	
		
	//	ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
	//	chunk.uploadFileHelper(fileName,transactionId,chunkSizeValue,offsetValue);
		
	//	Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithWithValidBoardKeyAndisProfilePicTrue: End");
	}
	

	@Test(priority = 17, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Chunk upload file on a board with valid boarKey and  isAutoUpload true", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardWithWithValidBoardKeyAndisAutoUploadTrue() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithWithValidBoardKeyAndisAutoUploadTrue: Start");
	
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		//baseScript.initiateUploadJSONBody= setJsonData(UploadConstants.getBoardCoverPic(), true, baseScript.initiateUploadJSONBody);
		
		ValidatableResponse response=baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,false,true,false);
		
		int status= response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
    	
    	
    	String code = response.extract().path("code");
    	String error = response.extract().path("error");
    	
    	Verify.verifyEquals(code,ErrorResponseCodes.ERRORCODE_TEJUF0412.getValue(), "Verify Success Status");
    	Verify.verifyEquals(error, "For isProfilePic, isAutoUpload or isContactPhoto, none of folderKey or boardKey is required.", "Verify Success Status");
    	
		
	//	ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
	//	chunk.uploadFileHelper(fileName,transactionId,chunkSizeValue,offsetValue);
		
	//	Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithWithValidBoardKeyAndisAutoUploadTrue: End");
	}
	
	//@Test(priority = 18, description = TestNgGroups.UPLOAD + ":" + apiName
	//		+ "Chunk file upload on a board with valid boarKey and isContactPhoto true", groups = {TestNgGroups.REGRESSION,
	//				TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardWithWithValidBoardKeyAndisContactPhotoTrue() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithWithValidBoardKeyAndisContactPhotoTrue: Start");
	
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		//baseScript.initiateUploadJSONBody= setJsonData(UploadConstants.getBoardCoverPic(), true, baseScript.initiateUploadJSONBody);
		
		ValidatableResponse response=baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,false,false,true);
		
		int status= response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
    	
    	
    	String code = response.extract().path("code");
    	String error = response.extract().path("error");
    	
    	Verify.verifyEquals(code,ErrorResponseCodes.ERRORCODE_TEJUF0412.getValue(), "Verify Success Status");
    	Verify.verifyEquals(error, "For isProfilePic, isAutoUpload or isContactPhoto, none of folderKey or boardKey is required.", "Verify Success Status");
    	
		
	//	ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
	//	chunk.uploadFileHelper(fileName,transactionId,chunkSizeValue,offsetValue);
		
	//	Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
		
		FrameworkLogger.logStep("testChunkUploadFileOnBoardWithWithValidBoardKeyAndisContactPhotoTrue: End");
	}
	
	@Test(priority = 19, description = TestNgGroups.UPLOAD + ":" + apiName
			+ "Contributor Uploading a single file on a board with valid boardKey abd boardCoverPic false", groups = {TestNgGroups.REGRESSION,
					TestNgGroups.UPLOAD })

	public void testChunkUploadFileOnBoardByContributorWithWithValidBoardKeyAndisBoardCoverPicFalse() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testChunkUploadFileOnBoardByContributorWithWithValidBoardKeyAndisBoardCoverPicFalse: Start");
	
		String chunkSizeValue="1024000";
		
		String fileName="WIN_20161208_190534.MP4";
		
		int offsetValue=0;
		
		CommonUtilityMethods.updateFile(fileName);
		
		String boardName = "Board___"+Utils.getUniqueId();
		
		 ValidatableResponse createBoardResponse = CreateBoardBaseScript.createBoardServiceMethod(boardName);
			String boardKey=createBoardResponse.extract().path("boardKey");
		
		//Step 4: Owner sends invite to other user.
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");


		//Step 5: Other user accepts the invitation and becomes contributor of the board.

		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		
		InitiateChunkUploadBaseScript baseScript= new InitiateChunkUploadBaseScript();
		
		//baseScript.initiateUploadJSONBody= setJsonData(UploadConstants.getBoardCoverPic(), true, baseScript.initiateUploadJSONBody);
		
		baseScript.initiateChunkFileUploadServiceMethod(fileName,boardKey,deviceContributorInfo,false,false,false);
		
		String transactionId=repositoryMap.get(RepositoryParameterEnum.TRANSACTIONID.getValue());
    	
		ChunkFileUploadBaseScript chunk = new ChunkFileUploadBaseScript();
		
		chunk.uploadFileHelperForBoard(fileName,transactionId, chunkSizeValue,offsetValue,userIdOfContributor,deviceContributorInfo.get("authtoken"),deviceContributorInfo.get("deviceKey") );
		
		Verify.verifyTrue(response1.getStatusLine().getStatusCode()==ApiResponseCodes.RESPONSECODE201.getValue());
				
		FrameworkLogger.logStep("testChunkUploadFileOnBoardByContributorWithWithValidBoardKeyAndisBoardCoverPicFalse: End");
		
	}
	
}
