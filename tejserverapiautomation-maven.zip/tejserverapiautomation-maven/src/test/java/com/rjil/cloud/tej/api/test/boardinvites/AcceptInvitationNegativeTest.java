package com.rjil.cloud.tej.api.test.boardinvites;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class AcceptInvitationNegativeTest extends AcceptInvitationBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne for invalid invitation code.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void acceptInvitationTestWithInvalidInvitationCode()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptInvitationTestWithInvalidInvitationCode-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//Send Invitation
		 SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");

		// Other user accepts the invitation and becomes contributor of board.
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService("ffffff",
				deviceContributorInfo);
		int statusCode = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("acceptInvitationTestWithInvalidInvitationCode-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS+ ":" + apiName+ "Verify the resposne for null invitation code.",
			groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS})
	public void acceptInvitationTestWithNullInvitationCode()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptInvitationTestWithNullInvitationCode-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		//Send Invitation
		SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");

		// Other user accepts the invitation and becomes contributor of board.
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(" ",
				deviceContributorInfo);
		int statusCode = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("acceptInvitationTestWithNullInvitationCode-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS+ ":" + apiName+ "Verify the resposne for missing invitation code.",
			groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS})
	public void acceptInvitationTestWithMissingInvitationCode()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptInvitationTestWithMissingInvitationCode-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		//Send Invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		//Other user accepts the invitation and becomes contributor of board.
		ValidatableResponse response = triggerPutApiAcceptInvitation("/invites/accept", invitationCode,
				deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE500.getValue(), "Verify failure Status");
		FrameworkLogger.logStep("acceptInvitationTestWithMissingInvitationCode-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS+ ":" + apiName+ "Verify the resposne for invalid url.",
			groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS})
	public void acceptInvitationTestWithInvalidUrl()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptInvitationTestWithInvalidUrl-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		//Other user accepts the invitation and becomes contributor of board.
		ValidatableResponse response = triggerPutApiAcceptInvitation("/invitess/" + invitationCode + "/accept",
				invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE500.getValue(), "Verify failure Status");
		FrameworkLogger.logStep("acceptInvitationTestWithInvalidUrl-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS+ ":" + apiName+ "Verify the resposne for invalid X-userId.",
			groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS})
	public void acceptInvitationTestWithInvalidXuserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptInvitationTestWithInvalidXuserId-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		//Send Invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Other user accepts the invitation and becomes contributor of board.
		createHeader(deviceContributorInfo);
		headerMap.put(HeaderParameters.XUSERID.getValue(), "%^&**FGGHH");
		ValidatableResponse response = triggerPutApiAcceptInvitation(invitationCode);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify failure Status");
		FrameworkLogger.logStep("acceptInvitationTestWithInvalidXuserId-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS+ ":" + apiName+ "Verify the resposne for invalid X-DeviceKey.",
			groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS})
	public void acceptInvitationTestWithInvalidXdeviceKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptInvitationTestWithInvalidXdeviceKey-> Start");	
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//Send Invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Other user accepts the invitation and becomes contributor of board.
		createHeader(deviceContributorInfo);
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), "jhdjk-9890-syg");
		ValidatableResponse response = triggerPutApiAcceptInvitation(invitationCode);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify failure Status");
		FrameworkLogger.logStep("acceptInvitationTestWithInvalidXdeviceKey-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne for missing XuserId", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void acceptInvitationTestWithMissingXuserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptInvitationTestWithInvalidInvitationCode-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		//Send Invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		//Other user accepts the invitation and becomes contributor of board.
		createHeader(deviceContributorInfo);
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		ValidatableResponse response = triggerPutApiAcceptInvitation(invitationCode);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");
		FrameworkLogger.logStep("acceptInvitationTestWithInvalidInvitationCode-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne for missing XdeviceKey", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void acceptInvitationTestWithMissingXDeviceKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptInvitationTestWithMissingXDeviceKey-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		//Send Invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Other user accepts the invitation and becomes contributor of board.
		createHeader(deviceContributorInfo);
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		ValidatableResponse response = triggerPutApiAcceptInvitation(invitationCode);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify failure Status");
		FrameworkLogger.logStep("acceptInvitationTestWithMissingXDeviceKey-> End");
	}
}
