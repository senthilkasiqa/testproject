package com.rjil.cloud.tej.api.test.boardinvites;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.DeclineBoardRequestBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class DeclineBoardRequestTest extends DeclineBoardRequestBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is declining the request which was a individual request.", groups = {
					TestNgGroups.DEPLOYMENTSANITY })
	public void declineBoardRequestTestWithDeclineIndividualRequest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineIndividualRequest-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Decline Invite Status");

		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineIndividualRequest-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is declining the request which was a individual request.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS,TestNgGroups.QASANITY })
	public void declineBoardRequestTestWithDeclineIndividualRequestTest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineIndividualRequest-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineIndividualRequest-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is declining the request which was a group request.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithDeclineGroupRequest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineGroupRequest-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send a group invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineGroupRequest-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is accepting an individual request and then decline the next individual request for same board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithAcceptIndividualRequestandDeclineNextRequestForSameBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger
				.logStep("declineBoardRequestTestWithAcceptIndividualRequestandDeclineNextRequestForSameBoard-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// accept the request
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		// send an invitation to user
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode1 = responseSendInvite1.extract().path("processed[0].inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode1, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		FrameworkLogger
				.logStep("declineBoardRequestTestWithAcceptIndividualRequestandDeclineNextRequestForSameBoard-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is accepting an group request and then decline the next group request for same board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithAcceptGroupRequestandDeclineNextGroupRequestForSameBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger
				.logStep("declineBoardRequestTestWithAcceptGroupRequestandDeclineNextGroupRequestForSameBoard-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send a group invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		responseSendInvite.extract().path("inviteCode");

		// send an invitation to user
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode1 = responseSendInvite1.extract().path("inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode1, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify failure Status");

		FrameworkLogger
				.logStep("declineBoardRequestTestWithAcceptGroupRequestandDeclineNextGroupRequestForSameBoard-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is accepting an individual request and then decline the same individual request for same board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithAcceptIndividualRequestandDeclineSameRequestForSameBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger
				.logStep("declineBoardRequestTestWithAcceptIndividualRequestandDeclineSameRequestForSameBoard-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// accept the request
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		FrameworkLogger
				.logStep("declineBoardRequestTestWithAcceptIndividualRequestandDeclineSameRequestForSameBoard-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is accepting an group request and then decline the same group request for same board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithAcceptGroupRequestandDeclineSameGroupRequestForSameBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger
				.logStep("declineBoardRequestTestWithAcceptGroupRequestandDeclineSameGroupRequestForSameBoard-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("inviteCode");

		// accept the request
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify failure Status");

		FrameworkLogger
				.logStep("declineBoardRequestTestWithAcceptGroupRequestandDeclineSameGroupRequestForSameBoard-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is accepting an individual request and then decline the next group request for same board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithAcceptIndividualRequestandDeclineNextGroupRequestForSameBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(
				"declineBoardRequestTestWithAcceptIndividualRequestandDeclineNextGroupRequestForSameBoard-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// accept the request
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		// again send a request to same user for same board
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode1 = responseSendInvite1.extract().path("inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode1, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep(
				"declineBoardRequestTestWithAcceptIndividualRequestandDeclineNextGroupRequestForSameBoard-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is accepting an group request and then decline the next individual request for same board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithAcceptGroupRequestandDeclineNextIndividualRequestForSameBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(
				"declineBoardRequestTestWithAcceptGroupRequestandDeclineNextIndividualRequestForSameBoard-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send a group invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("inviteCode");

		// accept the request
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		// again send a request to same user for same board

		// send an invitation to user
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode1 = responseSendInvite1.extract().path("processed[0].inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode1, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify failure Status");
		FrameworkLogger.logStep(
				"declineBoardRequestTestWithAcceptGroupRequestandDeclineNextIndividualRequestForSameBoard-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the resposne if user is declining again an already declined code.(individual ).", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithDeclineSameIndividualRequestAgain()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineSameIndividualRequestAgain-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify success Status");

		// decline the request again
		triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineSameIndividualRequestAgain-> End");
	}

	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the resposne if user is declining again an already declined code.(group).", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithDeclineSameGroupInvitationAgain()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineSameGroupInvitationAgain-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send a group invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify success Status");

		// decline same request again
		ValidatableResponse response1 = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode1 = response1.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineSameGroupInvitationAgain-> End");
	}

	@Test(priority = 11, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is declining an individual request and then accepting the next individual request for same board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithDeclineandThenAcceptNextIndividualRequest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineandThenAcceptNextIndividualRequest-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify success Status");

		// again send a request
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode1 = responseSendInvite1.extract().path("processed[0].inviteCode");

		// accept the request
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode1,
				deviceContributorInfo);
		int statusCode1 = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify success Status");

		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineandThenAcceptNextIndividualRequest-> End");
	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is declining an group request and then accepting the next group request for same board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithDeclineandThenAcceptNextGroupRequest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineandThenAcceptNextGroupRequest-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify success Status");

		// again send a request
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode1 = responseSendInvite1.extract().path("inviteCode");

		// accept the request
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode1,
				deviceContributorInfo);

		int statusCode1 = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify success Status");
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineandThenAcceptNextGroupRequest-> End");
	}

	@Test(priority = 13, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is declining an individual request and then accepting the next group request for same board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithDeclineIndivualandThenAcceptNextGroupRequest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineIndivualandThenAcceptNextGroupRequest-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify success Status");

		// again send a request
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode1 = responseSendInvite1.extract().path("inviteCode");

		// accept the request
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode1,
				deviceContributorInfo);
		int statusCode1 = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify success Status");
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineIndivualandThenAcceptNextGroupRequest-> End");
	}

	@Test(priority = 14, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user is declining an group request and then accepting the next individual request for same board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithDeclineGroupandThenAcceptNextIndividualRequest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineGroupandThenAcceptNextIndividualRequest-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify success Status");

		// again send a request
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode1 = responseSendInvite1.extract().path("processed[0].inviteCode");

		// accept the request
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode1,
				deviceContributorInfo);
		int statusCode1 = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify success Status");
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineGroupandThenAcceptNextIndividualRequest-> End");
	}

	@Test(priority = 15, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the resposne if owner declines the request .", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void declineBoardRequestTestWithOwnerDecliningBoardRequest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineIndividualRequest-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("inviteCode");

		// decline the request
		ValidatableResponse response = triggerPutApiDeclineBoardRequest(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("declineBoardRequestTestWithDeclineIndividualRequest-> End");
	}
}
