package com.rjil.cloud.mailchamp.test;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.enums.HeaderParameters;


public class CompleteOperationTest extends com.rjil.cloud.mailchamp.common.helper.CompleteOperationBaseClass {
	public ValidatableResponse response;



	@Test
	(description = "TC_79 - To verify the Complete Operation API works fine and give 200 OK for valid user",
			groups = {TestNgGroups.REGRESSION })

	public void aCompleteOperationValidUserSanity() {
		response = triggerPutApi(getCompleteOperationUrl(), createHeaderMap());
		int intCompleteOperationStatus = response.extract().statusCode(); // 200
		System.out.println("Status Code for Valid user: " + intCompleteOperationStatus);
		Assert.assertEquals(intCompleteOperationStatus, 200);
	}

	
	@Test
	(description = "TC_80 - To verify the Complete Operation API, when USER ID is MISSING", 
			groups = {TestNgGroups.REGRESSION })
		public void bCompleteOperationMissingUserId(){
		String userId = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),userId );
		response = triggerPutApi(getCompleteOperationUrl() , headerMap);
		int intcompleteOperationStatus = response.extract().statusCode();	//400
		System.out.println("Status Code for Missing UserId: " +intcompleteOperationStatus);
		Assert.assertEquals(intcompleteOperationStatus, 400);
		}
	
	
	@Test 
	(description = "TC_81 - To verify the Complete Operation API, when ACCESS TOKEN is MISSING",
	groups = {TestNgGroups.REGRESSION})	
		public void cCompleteOperationMissingAccessToken(){
		String authCode = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),authCode );
		response = triggerPutApi(getCompleteOperationUrl(), headerMap);
		int intcompleteOperationStatus = response.extract().statusCode();	//400
		System.out.println("Status Code for Missing ACCESS TOKEN: " +intcompleteOperationStatus);
		Assert.assertEquals(intcompleteOperationStatus, 400);
		}
	
	
	@Test
	(description = "TC_82 - To verify the Complete Operation API, when USER ID is INVALID", 
			groups = {TestNgGroups.REGRESSION })
		public void dCompleteOperationInvalidUserId(){
		String userId = "abc123";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),userId );
		response = triggerPutApi(getCompleteOperationUrl() , headerMap);
		int intcompleteOperationStatus = response.extract().statusCode();	//400
		System.out.println("Status Code for Invalid UserId: " +intcompleteOperationStatus);
		Assert.assertEquals(intcompleteOperationStatus, 400);
		}
	
	
	@Test 
	(description = "TC_83 - To verify the Complete Operation API, when ACCESS TOKEN is INVALID",
	groups = {TestNgGroups.REGRESSION})	
		public void eCompleteOperationInvalidAccessToken(){
		String authCode = "abcd1234";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),authCode );
		response = triggerPutApi(getCompleteOperationUrl(), headerMap);
		int intcompleteOperationStatus = response.extract().statusCode();	//400
		System.out.println("Status Code for Invalid ACCESS TOKEN: " +intcompleteOperationStatus);
		Assert.assertEquals(intcompleteOperationStatus, 401);
		}
}