package com.rjil.cloud.tej.api.test.boardcomments;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.boardcomments.PostCommentBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class MultipleCommentsTest extends PostCommentBaseScript{

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify owner is able to post comment on board .")
	public void postCommentTestWithOwnerPostingCommentOnHisBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("postCommentTestWithOwnerPostingCommentOnHisBoard:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Comment1";
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String comment = "Nice travel memories";
		createHeader();
		setPostCommentJsonBody();
		postCommentJsonBody = setJsonData(NewBoardConstants.getComment(), comment, postCommentJsonBody);
		for(int i=1; i<=250000;i++)
		{
		ValidatableResponse response = triggerPostApiPostComment(boardKey);
		
		int statusCode = response.extract().statusCode();
		
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Post Comment Status");
		
		}
		FrameworkLogger.logStep("postCommentTestWithOwnerPostingCommentOnHisBoard:-> End");
	}
}
