package com.rjil.cloud.tej.api.test.boards;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.RemoveBoardMembersBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.BoardsDeltaSyncBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.DeleteBoardFileBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.IndividualBoardDeltaSyncBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.RepositoryFileUploadToBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.RestoreTrashBoardFilesBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.UpdateBoardMetadataBaseScript;
import com.rjil.cloud.tej.apihelpers.fileupload.UploadBaseScript;

import com.rjil.cloud.tej.apihelpers.newBoard.ViewTrashedFilesBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class DeleteBoardFileTest extends DeleteBoardFileBaseScript{

	
	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Delete trashed files of same board.", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS,TestNgGroups.QASANITY  })

	public void deleteBoardFileTestWithOwnerDeletingFilesFromSameBoard() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testOwnerTryingToViewTrashedFile:-> Start");
		
		String statusForUploadedFile = "A";
		String operationName="FTR";
		String ifModifiedSince = System.currentTimeMillis()+"";
		Thread.sleep(10000);
		
		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
	    //Step 2: Owner uploads file1 to repo.
		
		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
	
     /*   //Step 3: Owner uploads file2 to repo.
		
		String fileName2="Rose.jpg";
		ValidatableResponse uploadResponse2 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName2);
		String objectKey2= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		*/
        //Step 4: Add file1 into board.
	
		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");
		
	/*	 //Step 5: Add file2 into board.
		
		ValidatableResponse boardFileUplaodResponse2 =RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey2, boardKey);
		String objectKeyOfUploadedFile2=boardFileUplaodResponse2.extract().path("objects[0].objectKey");
		*/
		 //Step 6: Trash both files.
	
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
	//	UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile2, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		
		String ifModifiedSince2 = System.currentTimeMillis()+"";
		createHeader();
	//	deleteBoardFileJsonBody =setDeleteBoardFileJsonBody();
	
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBodyForSingleFile();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);
	//	deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(1), boardKey, deleteBoardFileJsonBody);
	//	deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(1), objectKeyOfUploadedFile2, deleteBoardFileJsonBody);
		
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile();
		
		
		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKey1Response = responseDeleteBoardFiles.extract().path("objects[0].object.boardKey");
		String objectKey1Response = responseDeleteBoardFiles.extract().path("objects[0].object.objectKey");
//		String boardKey2Response = responseDeleteBoardFiles.extract().path("objects[1].object.boardKey");
//		String objectKey2Response = responseDeleteBoardFiles.extract().path("objects[1].object.objectKey");
		
		Verify.verifyEquals(boardKey1Response, boardKey, "Verify Success Status");
		Verify.verifyEquals(objectKey1Response, objectKeyOfUploadedFile1, "Verify Success Status");
//		Verify.verifyEquals(boardKey2Response, boardKey, "Verify Success Status");
//		Verify.verifyEquals(objectKey2Response, objectKeyOfUploadedFile2, "Verify Success Status");
		
		
		/*responseViewTrashedFiles.body(
				JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/viewTrashFIleTest-Schema.json"));
		
		*/
		
		//Step 7: Verify that status of file is marked as 'D' in individual delta sync.
	//	Thread.sleep(120000);
		//String ifModifiedSince2 = System.currentTimeMillis()+"";
		Thread.sleep(10000);
		
		
		ValidatableResponse individualDelta = IndividualBoardDeltaSyncBaseScript.individualBoardDeltaSyncService(boardKey, ifModifiedSince2);
	/*	String fileStatus1 = individualDelta.extract().path( "files[0].status");
	//	String fileStatus2 = individualDelta.extract().path( "files[1].status");
		
		Verify.verifyEquals(fileStatus1, "D", "Verify Success Status");
	//	Verify.verifyEquals(fileStatus2, "D", "Verify Success Status");
		
		 //Step 8: Deleted file should not be there in the trash.
		ValidatableResponse viewTrashFileResponse = ViewTrashedFilesBaseScript.ViewTrashedFileServiceMethod("viewTrashedFileUrl");*/
		
		FrameworkLogger.logStep("testOwnerTryingToViewTrashedFile:-> End");
	}
	
	
	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Delete trashed files of different boards.", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })

	public void deleteBoardFileTestWithOwnerDeletingFilesFromDifferentBoard() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithOwnerDeletingFilesFromDifferentBoard:-> Start");
		
		String ifModifiedSince = System.currentTimeMillis()+"";
		
		Thread.sleep(10000);
		String statusForUploadedFile = "A";
		String operationName="FTR";
		
		//Step 1: Owner Creates a board1
		String boardName1 = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName1);
		String boardKey1= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//Step 2: Owner Creates a board2
		String boardName2 = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName2);
		String boardKey2= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
	    //Step 2: Owner uploads file1 on repo
		
		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
	
        //Step 3: Owner uploads file2 on repo
		
		String fileName2="Rose.jpg";
		ValidatableResponse uploadResponse2 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName2);
		String objectKey2= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
		
        //Step 4: Add file1 into board1.
	
		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey1);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");
		
		 //Step 5: Add file2 into board2.
		
		ValidatableResponse boardFileUplaodResponse2 =RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey2, boardKey2);
		String objectKeyOfUploadedFile2=boardFileUplaodResponse2.extract().path("objects[0].objectKey");
		
		 //Step 6: Trash both files.
	
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey1, "updateBoardMetadataBodyForFileTrashOperation.js");
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile2, boardKey2, "updateBoardMetadataBodyForFileTrashOperation.js");
		
		
		createHeader();
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBody();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey1, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(1), boardKey2, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(1), objectKeyOfUploadedFile2, deleteBoardFileJsonBody);
		
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile();
		
		
		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKey1Response = responseDeleteBoardFiles.extract().path("objects[0].object.boardKey");
		String objectKey1Response = responseDeleteBoardFiles.extract().path("objects[0].object.objectKey");
		String boardKey2Response = responseDeleteBoardFiles.extract().path("objects[1].object.boardKey");
		String objectKey2Response = responseDeleteBoardFiles.extract().path("objects[1].object.objectKey");
		
		Verify.verifyEquals(boardKey1Response, boardKey1, "Verify Success Status");
		Verify.verifyEquals(objectKey1Response, objectKeyOfUploadedFile1, "Verify Success Status");
		Verify.verifyEquals(boardKey2Response, boardKey2, "Verify Success Status");
		Verify.verifyEquals(objectKey2Response, objectKeyOfUploadedFile2, "Verify Success Status");
	//	responseViewTrashedFiles.body(
	//			JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/viewTrashFIleTest-Schema.json"));
		
		ValidatableResponse individualDelta1 = IndividualBoardDeltaSyncBaseScript.individualBoardDeltaSyncService(boardKey1, ifModifiedSince);
		String fileStatus1 = individualDelta1.extract().path( "files[0].status");
		
		ValidatableResponse individualDelta2 = IndividualBoardDeltaSyncBaseScript.individualBoardDeltaSyncService(boardKey2, ifModifiedSince);
		String fileStatus2 = individualDelta2.extract().path( "files[0].status");
		
		Verify.verifyEquals(fileStatus1, "D", "Verify Success Status");
		Verify.verifyEquals(fileStatus2, "D", "Verify Success Status");
		
		BoardsDeltaSyncBaseScript.getBoardsDeltaSyncService(ifModifiedSince+"");
		
		FrameworkLogger.logStep("deleteBoardFileTestWithOwnerDeletingFilesFromDifferentBoard:-> End");
	}

	
	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Owner deleting trashed files of same board and some files trashed by contributor.", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })

	public void deleteBoardFileTestWithOwnerDeletingFilesTrashedByHimAsWellAsByContributor() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithOwnerDeletingFilesTrashedByHimAsWellAsByContributor:-> Start");
		
		String  ifModifiedSince = System.currentTimeMillis()+"";
		String statusForUploadedFile = "A";
		String operationName="FTR";
		
		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		
	    //Step 2: Owner uploads file1 in repo
		
		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
	    //Step 3: Owner adds file1 into board1.
		
		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");
		
		
		//Step 4: Owner sends invite to other user.
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");


		//Step 5: Other user accepts the invitation and becomes contributor of the board.

		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
        
		//Step 6: Contributor uploads file2 on repo.
		
		String fileName2="Rose.jpg";
		ValidatableResponse uploadResponse2 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName2, deviceContributorInfo);
		String objectKey2= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
	    //Step 7: Contributor uploads file2 into board.
		
		ValidatableResponse boardFileUplaodResponse2 =RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(deviceContributorInfo,statusForUploadedFile, objectKey2, boardKey);
		String objectKeyOfUploadedFile2=boardFileUplaodResponse2.extract().path("objects[0].objectKey");
		
		 //Step 8: Owner trashes his file.
	
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		
		//Step 9: Contributor trashes his file.
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(deviceContributorInfo, operationName,objectKeyOfUploadedFile2, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		
		
		createHeader();
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBody();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(1), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(1), objectKeyOfUploadedFile2, deleteBoardFileJsonBody);
		
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile();
		
		
		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKey1Response = responseDeleteBoardFiles.extract().path("objects[0].object.boardKey");
		String objectKey1Response = responseDeleteBoardFiles.extract().path("objects[0].object.objectKey");
		String boardKey2Response = responseDeleteBoardFiles.extract().path("objects[1].object.boardKey");
		String objectKey2Response = responseDeleteBoardFiles.extract().path("objects[1].object.objectKey");
		
		Verify.verifyEquals(boardKey1Response, boardKey, "Verify Success Status");
		Verify.verifyEquals(objectKey1Response, objectKeyOfUploadedFile1, "Verify Success Status");
		Verify.verifyEquals(boardKey2Response, boardKey, "Verify Success Status");
		Verify.verifyEquals(objectKey2Response, objectKeyOfUploadedFile2, "Verify Success Status");
	//	responseViewTrashedFiles.body(
	//			JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/viewTrashFIleTest-Schema.json"));
		
		ValidatableResponse individualDelta1 = IndividualBoardDeltaSyncBaseScript.individualBoardDeltaSyncService(boardKey, ifModifiedSince);
		String fileStatus1 = individualDelta1.extract().path( "files[0].status");
		String fileStatus2 = individualDelta1.extract().path( "files[1].status");
		
		Verify.verifyEquals(fileStatus1, "D", "Verify Success Status");
		Verify.verifyEquals(fileStatus2, "D", "Verify Success Status");
		
		ValidatableResponse individualDelta2 = IndividualBoardDeltaSyncBaseScript.individualBoardDeltaSyncService(deviceContributorInfo, boardKey, ifModifiedSince);
		String fileStatus11 = individualDelta2.extract().path( "files[0].status");
		String fileStatus22 = individualDelta2.extract().path( "files[1].status");
		
		Verify.verifyEquals(fileStatus11, "D", "Verify Success Status");
		Verify.verifyEquals(fileStatus22, "D", "Verify Success Status");
		
		FrameworkLogger.logStep("deleteBoardFileTestWithOwnerDeletingFilesTrashedByHimAsWellAsByContributor:-> End");
	}

	
	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Contributor deleting file trashed by owner.", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })

	public void deleteBoardFileTestWithContributorDeletingFilesTrashedByOwner() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("deleteBoardFileTestWithContributorDeletingFilesTrashedByOwner:-> Start");
		
		String ifModifiedSince = System.currentTimeMillis()+"";
		String statusForUploadedFile = "A";
		String operationName="FTR";
		
		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		
	    //Step 2: Owner uploads file1 in repo
		
		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
	    //Step 3: Owner adds file1 into board1.
		
		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");
		
		
		//Step 4: Owner sends invite to other user.
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");


		//Step 5: Other user accepts the invitation and becomes contributor of the board.

		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
        
		
		 //Step 6: Owner trashes his file.
	
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		
		
		//Step 7: Contributor deletes file trashed by owner.
		
		createHeader(deviceContributorInfo);
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBodyForSingleFile();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);
	
		
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile(deviceContributorInfo);
		
		
		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

	//	responseViewTrashedFiles.body(
	//			JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/viewTrashFIleTest-Schema.json"));
		
		

		String boardKey1Response = responseDeleteBoardFiles.extract().path("objects[0].object.boardKey");
		String objectKey1Response = responseDeleteBoardFiles.extract().path("objects[0].object.objectKey");
	
		
		Verify.verifyEquals(boardKey1Response, boardKey, "Verify Success Status");
		Verify.verifyEquals(objectKey1Response, objectKeyOfUploadedFile1, "Verify Success Status");
		
	//	responseViewTrashedFiles.body(
	//			JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/viewTrashFIleTest-Schema.json"));
		
		ValidatableResponse individualDelta1 = IndividualBoardDeltaSyncBaseScript.individualBoardDeltaSyncService(boardKey, ifModifiedSince);
		String fileStatus1 = individualDelta1.extract().path( "files[0].status");
		Verify.verifyEquals(fileStatus1, "D", "Verify Success Status");
		
		
		ValidatableResponse individualDelta2 = IndividualBoardDeltaSyncBaseScript.individualBoardDeltaSyncService(deviceContributorInfo, boardKey, ifModifiedSince);
		String fileStatus11 = individualDelta2.extract().path( "files[0].status");
		Verify.verifyEquals(fileStatus11, "D", "Verify Success Status");
		
		
		BoardsDeltaSyncBaseScript.getBoardsDeltaSyncService(ifModifiedSince+"");
		
		FrameworkLogger.logStep("deleteBoardFileTestWithContributorDeletingFilesTrashedByOwner:-> End");
	}
	
	
	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Delete file of board without trashing it.", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })

	public void deleteBoardFileTestWithDeleteFileWithoutTrashing() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithDeleteFileWithoutTrashing:-> Start");
		
		String statusForUploadedFile = "A";
		String operationName="FTR";
		String ifModifiedSince = System.currentTimeMillis()+"";
		Thread.sleep(10000);
		
		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
	    //Step 2: Owner uploads file1 to repo.
		
		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
        //Step 3: Add file1 into board.
	
		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");
		
		 //Step 4: Delete the file without adding into trash.
	
		createHeader();
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBodyForSingleFile();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);
		
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile();
		
		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		/*responseViewTrashedFiles.body(
				JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/viewTrashFIleTest-Schema.json"));
		
		*/
		
		String errorCode = responseDeleteBoardFiles.extract().path("unprocessed[0].errorCode");
		String errorMessage = responseDeleteBoardFiles.extract().path("unprocessed[0].errorMessage");
		
		Verify.verifyEquals(errorCode, "BRSOM0027", "Verify Success Status");
		Verify.verifyEquals(errorMessage, "Object Key is not valid.", "Verify Success Status");
		
		FrameworkLogger.logStep("deleteBoardFileTestWithDeleteFileWithoutTrashing:-> End");
	}
	
	
	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "file from repo added tob board. deleted and then added same file again.", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })

	public void deleteBoardFileTestWithAddFileAgainToBoardAfterDeleting() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithAddFileAgainToBoardAfterDeleting:-> Start");
		
		String statusForUploadedFile = "A";
		String operationName="FTR";
		String ifModifiedSince = System.currentTimeMillis()+"";
		Thread.sleep(10000);
		
		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
	    //Step 2: Owner uploads file1 to repo.
		
		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		

        //Step 3: Add file1 into board.
	
		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");
		
		
		 //Step 4: Trash file.
	
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		
		
		//Step 5: Delete file
		
		createHeader();
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBodyForSingleFile();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);
		
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile();
		
		
		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		
	    //Step 6: Again add same file from repo to board
		ValidatableResponse boardFileUplaodResponse2=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		int statusCode1 = boardFileUplaodResponse2.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		
		FrameworkLogger.logStep("deleteBoardFileTestWithAddFileAgainToBoardAfterDeleting:-> End");
	}


	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Contributor who left the board deletes the file", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })
	public void deleteBoardFileTestWithContributorWhoLeftBoard() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithContributorWhoLeftBoard:-> Start");
		String  ifModifiedSince = System.currentTimeMillis()+"";
		String statusForUploadedFile = "A";
		String operationName="FTR";
		
		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
			
	    //Step 2: Owner uploads file1 in repo
		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
	    //Step 3: Owner adds file1 into board1.
		
		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");
		
		
		//Step 4: Owner sends invite to other user.
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");


		//Step 5: Other user accepts the invitation and becomes contributor of the board.

		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
        
		//Step 6: Contributor uploads file2 on repo.
		
		String fileName2="Rose.jpg";
		ValidatableResponse uploadResponse2 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName2, deviceContributorInfo);
		String objectKey2= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
	    //Step 7: Contributor uploads file2 into board.
		
		ValidatableResponse boardFileUplaodResponse2 =RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(deviceContributorInfo,statusForUploadedFile, objectKey2, boardKey);
		String objectKeyOfUploadedFile2=boardFileUplaodResponse2.extract().path("objects[0].objectKey");
		
		 //Step 8: Owner trashes his file.
	
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		
		//Step 9: Contributor trashes his file.
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(deviceContributorInfo, operationName,objectKeyOfUploadedFile2, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		
		//Step 10: Contributor left the board.
		
		LeaveBoardBaseScript.leaveBoardService(boardKey, deviceContributorInfo);
		
		//Step 11: Contributor who left the board is deleting the file.
		
		createHeader(deviceContributorInfo);
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBody();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(1), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(1), objectKeyOfUploadedFile2, deleteBoardFileJsonBody);
		
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile(deviceContributorInfo);
		
		
		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String errorCode = responseDeleteBoardFiles.extract().path("code");
		String errorMessage = responseDeleteBoardFiles.extract().path("error");
//		String unprocessedObjectKey = responseDeleteBoardFiles.extract().path("unprocessed[0].object.objectKey");
		
		Verify.verifyEquals(errorCode, "BRSOM0110", "Verify Success Status");
		Verify.verifyEquals(errorMessage, "Board User Relation Missing.", "Verify Success Status");
//		Verify.verifyEquals(unprocessedObjectKey, objectKeyOfUploadedFile1, "Verify Success Status");
		
		FrameworkLogger.logStep("deleteBoardFileTestWithContributorWhoLeftBoard:-> End");
	}


	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "	Owner who left the board deletes the file", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })
	public void deleteBoardFileTestWithOwnerWhoLeftBoard() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithContributorWhoLeftBoard:-> Start");
		
		String  ifModifiedSince = System.currentTimeMillis()+"";
		String statusForUploadedFile = "A";
		String operationName="FTR";
		
		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		
	    //Step 2: Owner uploads file1 in repo
		
		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
	    //Step 3: Owner adds file1 into board1.
		
		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");
		
    	 //Step 4: Owner trashes his file.
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		

		//Step 10: Owner left the board.
		LeaveBoardBaseScript.leaveBoardService(boardKey);
		
		//Step 11: Owner who left the board is deleting the file.
		createHeader();
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBodyForSingleFile();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);

		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile();
		
		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
		
		String errorCode = responseDeleteBoardFiles.extract().path("code");
		String errorMessage = responseDeleteBoardFiles.extract().path("error");
//		String unprocessedObjectKey = responseDeleteBoardFiles.extract().path("unprocessed[0].object.objectKey");
		
		Verify.verifyEquals(errorCode, "BRSOM0110", "Verify Success Status");
		Verify.verifyEquals(errorMessage, "Board User Relation Missing.", "Verify Success Status");
//		Verify.verifyEquals(unprocessedObjectKey, objectKeyOfUploadedFile1, "Verify Success Status");
	
		
		FrameworkLogger.logStep("deleteBoardFileTestWithOwnerWhoLeftBoard:-> End");
	}
	
	
	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Contributor who is removed by owner deletes the file", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })
	public void deleteBoardFileTestWithContributorWhoRemovedFromBoardByOwnerBoard() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithContributorWhoRemovedFromBoardByOwnerBoard:-> Start");
		
		String  ifModifiedSince = System.currentTimeMillis()+"";
		String statusForUploadedFile = "A";
		String operationName="FTR";
		
		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
	    //Step 2: Owner uploads file1 in repo
		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
	    //Step 3: Owner adds file1 into board1.
		
		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");
		
		
		//Step 4: Owner sends invite to other user.
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");


		//Step 5: Other user accepts the invitation and becomes contributor of the board.

		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
        
		//Step 6: Contributor uploads file2 on repo.
		
		String fileName2="Rose.jpg";
		ValidatableResponse uploadResponse2 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName2, deviceContributorInfo);
		String objectKey2= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
	    //Step 7: Contributor uploads file2 into board.
		
		ValidatableResponse boardFileUplaodResponse2 =RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(deviceContributorInfo,statusForUploadedFile, objectKey2, boardKey);
		String objectKeyOfUploadedFile2=boardFileUplaodResponse2.extract().path("objects[0].objectKey");
		
		 //Step 8: Owner trashes his file.
	
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		
		//Step 9: Contributor trashes his file.
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(deviceContributorInfo, operationName,objectKeyOfUploadedFile2, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		
		//Step 10: Contributor removed by owner the board.
		RemoveBoardMembersBaseScript.removeBoardMemberService(boardKey, deviceContributorInfo.get("userId"));
		
		//Step 11: Contributor who is removed from the the board is deleting the file.
		createHeader(deviceContributorInfo);
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBody();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(1), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(1), objectKeyOfUploadedFile2, deleteBoardFileJsonBody);
		
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile(deviceContributorInfo);
		
		
		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		
		
		String errorCode = responseDeleteBoardFiles.extract().path("code");
		String errorMessage = responseDeleteBoardFiles.extract().path("error");
//		String unprocessedObjectKey = responseDeleteBoardFiles.extract().path("unprocessed[0].object.objectKey");
		
		Verify.verifyEquals(errorCode, "BRSOM0110", "Verify Success Status");
		Verify.verifyEquals(errorMessage, "Board User Relation Missing.", "Verify Success Status");
//		Verify.verifyEquals(unprocessedObjectKey, objectKeyOfUploadedFile1, "Verify Success Status");
				
		FrameworkLogger.logStep("deleteBoardFileTestWithContributorWhoRemovedFromBoardByOwnerBoard:-> End");
	}

	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "invalid boardKey", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })
	public void deleteBoardFileTestWithInvalidBoardKey() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithInvalidBoardKey:-> Start");

		String statusForUploadedFile = "A";
		String operationName="FTR";
		String ifModifiedSince = System.currentTimeMillis()+"";
		Thread.sleep(10000);

		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		//Step 2: Owner uploads file1 to repo.

		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());


		//Step 3: Add file1 into board.

		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");

		//Step 4: Trash file.
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		createHeader();
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBodyForSingleFile();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey+87976, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);
	
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile();

		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String errorCode = responseDeleteBoardFiles.extract().path("code");
		String errorMessage = responseDeleteBoardFiles.extract().path("error");
		Verify.verifyEquals(errorCode, "BRSOM0110", "Verify Success Status");
		Verify.verifyEquals(errorMessage, "Board User Relation Missing.", "Verify Success Status");
		
		FrameworkLogger.logStep("deleteBoardFileTestWithInvalidBoardKey:-> End");
	}

	
	@Test(priority = 11, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "invalid objectKey", groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS })

	public void deleteBoardFileTestWithInvalidObjectKey() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithInvalidObjectKey:-> Start");

		String statusForUploadedFile = "A";
		String operationName="FTR";
		String ifModifiedSince = System.currentTimeMillis()+"";
		Thread.sleep(10000);

		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		//Step 2: Owner uploads file1 to repo.

		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());


		//Step 3: Add file1 into board.

		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");

		//Step 4: Trash file.

		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
	

		createHeader();
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBodyForSingleFile();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1+8979, deleteBoardFileJsonBody);
	
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile();

		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String errorCode = responseDeleteBoardFiles.extract().path("unprocessed[0].errorCode");
		String errorMessage = responseDeleteBoardFiles.extract().path("unprocessed[0].errorMessage");
		String unprocessedObjectKey = responseDeleteBoardFiles.extract().path("unprocessed[0].object.objectKey");
		
		Verify.verifyEquals(errorCode, "BRSOM0111", "Verify Success Status");
		Verify.verifyEquals(errorMessage, "Board and Object Key mapping does not exist.", "Verify Success Status");
		Verify.verifyEquals(unprocessedObjectKey, objectKeyOfUploadedFile1+"8979", "Verify Success Status");
		
		FrameworkLogger.logStep("deleteBoardFileTestWithInvalidObjectKey:-> End");
	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "missing boardKey", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })

	public void deleteBoardFileTestWithMissingBoardKey() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithMissingBoardKey:-> Start");

		String statusForUploadedFile = "A";
		String operationName="FTR";
		String ifModifiedSince = System.currentTimeMillis()+"";
		Thread.sleep(10000);

		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		//Step 2: Owner uploads file1 to repo.

		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());


		//Step 3: Add file1 into board.

		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");

		//Step 4: Trash file.

		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
	

		createHeader();
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBodyForSingleFile();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), "", deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);
	
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile();

		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String errorCode = responseDeleteBoardFiles.extract().path("unprocessed[0].errorCode");
		String errorMessage = responseDeleteBoardFiles.extract().path("unprocessed[0].errorMessage");
		String unprocessedObjectKey = responseDeleteBoardFiles.extract().path("unprocessed[0].object.objectKey");
		
		Verify.verifyEquals(errorCode, "BRSOM0103", "Verify Success Status");
		Verify.verifyEquals(errorMessage, "Certain Mandatory Request Parameter(s) are Missing or Empty.", "Verify Success Status");
		Verify.verifyEquals(unprocessedObjectKey, objectKeyOfUploadedFile1, "Verify Success Status");
		
		
		FrameworkLogger.logStep("deleteBoardFileTestWithMissingBoardKey:-> End");
	}

	
	@Test(priority = 13, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "missing objectKey", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })

	public void deleteBoardFileTestWithMissingObjectKey() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithMissingObjectKey:-> Start");

		String statusForUploadedFile = "A";
		String operationName="FTR";
		String ifModifiedSince = System.currentTimeMillis()+"";
		Thread.sleep(10000);

		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		//Step 2: Owner uploads file1 to repo.

		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());


		//Step 3: Add file1 into board.

		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");

		//Step 4: Trash file.

		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
	

		createHeader();
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBodyForSingleFile();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), "", deleteBoardFileJsonBody);
	
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile();

		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String errorCode = responseDeleteBoardFiles.extract().path("unprocessed[0].errorCode");
		String errorMessage = responseDeleteBoardFiles.extract().path("unprocessed[0].errorMessage");
		String unprocessedObjectKey = responseDeleteBoardFiles.extract().path("unprocessed[0].object.objectKey");
		
		Verify.verifyEquals(errorCode, "BRSOM0103", "Verify Success Status");
		Verify.verifyEquals(errorMessage, "Certain Mandatory Request Parameter(s) are Missing or Empty.", "Verify Success Status");
		Verify.verifyEquals(unprocessedObjectKey, "", "Verify Success Status");
		
		
		FrameworkLogger.logStep("deleteBoardFileTestWithMissingObjectKey:-> End");
	}

	@Test(priority = 14, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "combination of valid and invalid test", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })

	public void deleteBoardFileTestWithValidAndInvalidRequests() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithValidAndInvalidRequests:-> Start");
		
		String statusForUploadedFile = "A";
		String operationName="FTR";
		String ifModifiedSince = System.currentTimeMillis()+"";
		Thread.sleep(10000);
		
		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
	    //Step 2: Owner uploads file1 to repo.
		
		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
	
        //Step 3: Owner uploads file2 to repo.
		
		String fileName2="Rose.jpg";
		ValidatableResponse uploadResponse2 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName2);
		String objectKey2= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());
		
        //Step 4: Add file1 into board.
	
		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");
		
		 //Step 5: Add file2 into board.
		
		ValidatableResponse boardFileUplaodResponse2 =RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey2, boardKey);
		String objectKeyOfUploadedFile2=boardFileUplaodResponse2.extract().path("objects[0].objectKey");
		
		 //Step 6: Trash both files.
	
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile2, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
		
		
		createHeader();
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBody();
	
		
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(1), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(1), objectKeyOfUploadedFile2+111, deleteBoardFileJsonBody);
		
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile();
		
		System.out.println("OBJECTKEY++++++++++++====="+objectKeyOfUploadedFile1);
		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKey1Response = responseDeleteBoardFiles.extract().path("objects[0].object.boardKey");
		String objectKey1Response = responseDeleteBoardFiles.extract().path("objects[0].object.objectKey");
		
		Verify.verifyEquals(boardKey1Response, boardKey, "Verify Success Status");
		Verify.verifyEquals(objectKey1Response, objectKeyOfUploadedFile1, "Verify Success Status");
	
		String errorCode = responseDeleteBoardFiles.extract().path("unprocessed[0].errorCode");
		String errorMessage = responseDeleteBoardFiles.extract().path("unprocessed[0].errorMessage");
		String unprocessedObjectKey = responseDeleteBoardFiles.extract().path("unprocessed[0].object.objectKey");
		
		Verify.verifyEquals(errorCode, "BRSOM0111", "Verify Success Status");
		Verify.verifyEquals(errorMessage, "Board and Object Key mapping does not exist.", "Verify Success Status");
		Verify.verifyEquals(unprocessedObjectKey, objectKeyOfUploadedFile2+"111", "Verify Success Status");

				
		//Step 7: Verify that status of file is marked as 'D' in individual delta sync.
		
		ValidatableResponse individualDelta = IndividualBoardDeltaSyncBaseScript.individualBoardDeltaSyncService(boardKey, ifModifiedSince);
		String fileStatus1 = individualDelta.extract().path( "files[1].status");
		
		Verify.verifyEquals(fileStatus1, "D", "Verify Success Status");
	
		
		 //Step 8: Deleted file should not be there in the trash.
		ValidatableResponse viewTrashFileResponse = ViewTrashedFilesBaseScript.ViewTrashedFileServiceMethod("viewTrashedFileUrl");
		
		

		FrameworkLogger.logStep("deleteBoardFileTestWithValidAndInvalidRequests:-> End");
	}
	
	
	@Test(priority = 15, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "missing boardKey", groups = {
					TestNgGroups.REGRESSION,TestNgGroups.BOARDS })

	public void deleteBoardFileTestWithRestoreDeletedFile() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" deleteBoardFileTestWithRestoreDeletedFile:-> Start");

		String statusForUploadedFile = "A";
		String operationName="FTR";
		String ifModifiedSince = System.currentTimeMillis()+"";
		Thread.sleep(10000);

		//Step 1: Owner Creates a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey= repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		//Step 2: Owner uploads file1 to repo.

		String fileName1="Sample.jpg";
		ValidatableResponse uploadResponse1 = UploadBaseScript.getResponseOfUploadFileServiceMethod(fileName1);
		String objectKey1= repositoryMap.get(RepositoryParameterEnum.OBJECTKEY.getValue());


		//Step 3: Add file1 into board.

		ValidatableResponse boardFileUplaodResponse1=RepositoryFileUploadToBoardBaseScript.repositoryFileUploadToBoardServiceMethod(statusForUploadedFile, objectKey1, boardKey);
		String objectKeyOfUploadedFile1=boardFileUplaodResponse1.extract().path("objects[0].objectKey");

		//Step 4: Trash file.

		UpdateBoardMetadataBaseScript.updateBoardMetaDataServiceMethod(operationName,objectKeyOfUploadedFile1, boardKey, "updateBoardMetadataBodyForFileTrashOperation.js");
	
       //Step 5: Delete file.
		createHeader();
		deleteBoardFileJsonBody =setDeleteBoardFileJsonBodyForSingleFile();
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getBoardKeyForDeleteFile(0), boardKey, deleteBoardFileJsonBody);
		deleteBoardFileJsonBody  = setJsonData(NewBoardConstants.getObjectForDeleteFile(0), objectKeyOfUploadedFile1, deleteBoardFileJsonBody);
	
		ValidatableResponse responseDeleteBoardFiles= triggerPostApiDeleteBoardFile();

		int statusCode = responseDeleteBoardFiles.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		
	    //Step 6: Restore trashed file.
		
		ValidatableResponse restoreBoardFilesResponse = RestoreTrashBoardFilesBaseScript.restoreTrashBoardFileServiceMetod(boardKey, objectKeyOfUploadedFile1);
		
		String errorCode = restoreBoardFilesResponse.extract().path("unprocessed[0].errorCode");
		String errorMessage = restoreBoardFilesResponse.extract().path("unprocessed[0].errorMessage");
		String unprocessedObjectKey = restoreBoardFilesResponse.extract().path("unprocessed[0].object.objectKey");
		
		Verify.verifyEquals(errorCode, "BRSOM0111", "Verify Success Status");
		Verify.verifyEquals(errorMessage, "Board and Object Key mapping does not exist.", "Verify Success Status");
		Verify.verifyEquals(unprocessedObjectKey, objectKeyOfUploadedFile1, "Verify Success Status");
		
		FrameworkLogger.logStep("deleteBoardFileTestWithRestoreDeletedFile:-> End");
	}
	
	
	
}




