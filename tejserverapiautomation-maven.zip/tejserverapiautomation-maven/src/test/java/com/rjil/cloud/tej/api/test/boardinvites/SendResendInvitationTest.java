package com.rjil.cloud.tej.api.test.boardinvites;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.DeclineBoardRequestBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class SendResendInvitationTest extends SendResendInvitationBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":send a board invite to valid user", groups = { TestNgGroups.DEPLOYMENTSANITY })
	public void sendResendInvitationTestWithInvitationToValidUser()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToValiUser:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		headerMap.put(HeaderParameters.ACCEPTLANGUAGE.getValue(), "@#");
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Send Invite Status");
		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToValiUser:-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":send a board invite to valid user", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS,
					TestNgGroups.QASANITY })
	public void sendResendInvitationTestWithInvitationToValidUserTest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToValiUser:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response
		String firstNameFromResponse = response.extract().path("processed[0].firstName");
		String lastNameFromResponse = response.extract().path("processed[0].lastName");
		String userContactFromResponse = response.extract().path("processed[0].userContact");
		String userTypeFromResponse = response.extract().path("processed[0].userType");
		String inviteTypeFromResponse = response.extract().path("processed[0].inviteType");
		String contactTypeFromResponse = response.extract().path("processed[0].contactType");
		String inviteMessageFromResponse = response.extract().path("processed[0].inviteMessage");
		String inviteCodeFromResponse = response.extract().path("processed[0].inviteCode");
		String inviteUrlFromResponse = response.extract().path("processed[0].inviteUrl");

		Verify.verifyEquals(firstNameFromResponse, "Steve", "verify firstName of invited member");
		Verify.verifyEquals(lastNameFromResponse, "Bond", "verify lastName of invited member");
		Verify.verifyEquals(userContactFromResponse, "qaautojdfour@gmail.com", "verify userContact of invited member");
		Verify.verifyEquals(userTypeFromResponse, "C", "verify userType of invited member");
		Verify.verifyEquals(inviteTypeFromResponse, "I", "verify inviteType of invitation");
		Verify.verifyEquals(contactTypeFromResponse, "E", "verify contactType of invitation");
		Verify.verifyEquals(inviteMessageFromResponse, "Invite Message", "verify inviteMessage of invitation");
		// Verify.verifyEquals(inviteUrlFromResponse,
		// apiUrls.get("baseURL")+"/boardinvites/invites/"+inviteCodeFromResponse,
		// "verify inviteUrl of invitation");
		boolean isInviteUrlNull = inviteUrlFromResponse.isEmpty();
		Verify.verifyEquals(isInviteUrlNull, false, "verify inviteMessage of invitation");
		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/sendResendInvitationTest-Schema.json"));

		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToValiUser:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":send a board invite to both the valid users", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithInvitationToBothValidUsers()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToBothValidUsers:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBodyForTwoUsers();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response
		String firstNameFromResponse = response.extract().path("processed[0].firstName");
		String lastNameFromResponse = response.extract().path("processed[0].lastName");
		String userContactFromResponse = response.extract().path("processed[0].userContact");
		String userTypeFromResponse = response.extract().path("processed[0].userType");
		String inviteTypeFromResponse = response.extract().path("processed[0].inviteType");
		String contactTypeFromResponse = response.extract().path("processed[0].contactType");
		String inviteMessageFromResponse = response.extract().path("processed[0].inviteMessage");
		String inviteCodeFromResponse = response.extract().path("processed[0].inviteCode");
		String inviteUrlFromResponse = response.extract().path("processed[0].inviteUrl");

		Verify.verifyEquals(firstNameFromResponse, "Ashish", "verify firstName of invited member");
		Verify.verifyEquals(lastNameFromResponse, "Laad", "verify lastName of invited member");
		Verify.verifyEquals(userContactFromResponse, "+91-7332248065", "verify userContact of invited member");
		Verify.verifyEquals(userTypeFromResponse, "C", "verify userType of invited member");
		Verify.verifyEquals(inviteTypeFromResponse, "I", "verify inviteType of invitation");
		Verify.verifyEquals(contactTypeFromResponse, "M", "verify contactType of invitation");
		Verify.verifyEquals(inviteMessageFromResponse, "Send invite to two users",
				"verify inviteMessage of invitation");
		// Verify.verifyEquals(inviteUrlFromResponse,
		// apiUrls.get("baseURL") + "/i?c=" + inviteCodeFromResponse,
		// "verify inviteUrl of invitation");

		String firstNameFromResponse1 = response.extract().path("processed[1].firstName");
		String lastNameFromResponse1 = response.extract().path("processed[1].lastName");
		String userContactFromResponse1 = response.extract().path("processed[1].userContact");
		String userTypeFromResponse1 = response.extract().path("processed[1].userType");
		String inviteTypeFromResponse1 = response.extract().path("processed[1].inviteType");
		String contactTypeFromResponse1 = response.extract().path("processed[1].contactType");
		String inviteMessageFromResponse1 = response.extract().path("processed[1].inviteMessage");
		String inviteCodeFromResponse1 = response.extract().path("processed[1].inviteCode");
		String inviteUrlFromResponse1 = response.extract().path("processed[1].inviteUrl");

		Verify.verifyEquals(firstNameFromResponse1, "Anuja", "verify firstName of invited member");
		Verify.verifyEquals(lastNameFromResponse1, "Kale", "verify lastName of invited member");
		Verify.verifyEquals(userContactFromResponse1, "Anuja.k@gmail.com", "verify userContact of invited member");
		Verify.verifyEquals(userTypeFromResponse1, "C", "verify userType of invited member");
		Verify.verifyEquals(inviteTypeFromResponse1, "I", "verify inviteType of invitation");
		Verify.verifyEquals(contactTypeFromResponse1, "E", "verify contactType of invitation");
		// Verify.verifyEquals(inviteMessageFromResponse1, "Send invite to two
		// users",
		// "verify inviteMessage of invitation");
		// Verify.verifyEquals(inviteUrlFromResponse1,
		// apiUrls.get("baseURL")+"/boardinvites/invites/"+inviteCodeFromResponse1,
		// "verify inviteUrl of invitation");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/sendResendInvitationTest-Schema.json"));

		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToBothValidUsers:-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":send a board invite to both the invalid users", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithInvitationToBothInvalidUsers()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToBothInvalidUsers:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBodyForTwoUsers();
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserContact(), "abcd",
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getSecondUserContact(), "qaautojdgmail.com",
				sendResendInvitationJsonBody);
		FrameworkLogger.logStep("BODY:" + sendResendInvitationJsonBody);
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/sendResendInvitationTest-Schema.json"));

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Failure Status");
		String errorCode = response.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0405.getValue(), "Verify Error Code");
		String errorMessage = response.extract().path("error");
		Verify.verifyEquals(errorMessage, "No valid contact in the request.", "Verify Error Message");

		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToBothInvalidUsers:-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":send a board invite to one valid and other invalid user", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithInvitationToOneValidAndOneInvalidUser()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToOneValidAndOneInvalidUser:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBodyForTwoUsers();
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getSecondUserContact(), "@gmail.com",
				sendResendInvitationJsonBody);
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Failure Status");

		// verify response
		String firstNameFromResponse = response.extract().path("processed[0].firstName");
		String lastNameFromResponse = response.extract().path("processed[0].lastName");
		String userContactFromResponse = response.extract().path("processed[0].userContact");
		String userTypeFromResponse = response.extract().path("processed[0].userType");
		String inviteTypeFromResponse = response.extract().path("processed[0].inviteType");
		String contactTypeFromResponse = response.extract().path("processed[0].contactType");
		String inviteMessageFromResponse = response.extract().path("processed[0].inviteMessage");
		String inviteCodeFromResponse = response.extract().path("processed[0].inviteCode");
		String inviteUrlFromResponse = response.extract().path("processed[0].inviteUrl");

		Verify.verifyEquals(firstNameFromResponse, "Ashish", "verify firstName of invited member");
		Verify.verifyEquals(lastNameFromResponse, "Laad", "verify lastName of invited member");
		Verify.verifyEquals(userContactFromResponse, "+91-7332248065", "verify userContact of invited member");
		Verify.verifyEquals(userTypeFromResponse, "C", "verify userType of invited member");
		Verify.verifyEquals(inviteTypeFromResponse, "I", "verify inviteType of invitation");
		Verify.verifyEquals(contactTypeFromResponse, "M", "verify contactType of invitation");
		Verify.verifyEquals(inviteMessageFromResponse, "Send invite to two users",
				"verify inviteMessage of invitation");
				// Verify.verifyEquals(inviteUrlFromResponse,
				// apiUrls.get("baseURL") + "/i?c=" +
				// inviteCodeFromResponse,"verify inviteUrl of invitation");

		// <http://sit-apis.tejdrive.com
		// /i?c=Z935082117071217> but
		// was:<http://sit-www.tejdrive.com/i?c=Z935082117071217>

		String firstNameFromResponse1 = response.extract().path("unprocessed[0].firstName");
		String lastNameFromResponse1 = response.extract().path("unprocessed[0].lastName");
		String userContactFromResponse1 = response.extract().path("unprocessed[0].userContact");
		String userTypeFromResponse1 = response.extract().path("unprocessed[0].userType");
		String errorCodeFromResponse1 = response.extract().path("unprocessed[0].errorCode");
		String errorMessageFromResponse1 = response.extract().path("unprocessed[0].errorMessage");

		Verify.verifyEquals(firstNameFromResponse1, "Anuja", "verify firstName of invited member");
		Verify.verifyEquals(lastNameFromResponse1, "Kale", "verify lastName of invited member");
		Verify.verifyEquals(userContactFromResponse1, "@gmail.com", "verify userContact of invited member");
		Verify.verifyEquals(userTypeFromResponse1, "C", "verify userType of invited member");
		Verify.verifyEquals(errorCodeFromResponse1, ErrorResponseCodes.ERRORCODE_BINVS0406.getValue(),
				"verify errorCode");
		Verify.verifyEquals(errorMessageFromResponse1, "Email or Phone Number in the request is wrong.",
				"verify errorMessage");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/sendResendInvitationTest-Schema.json"));

		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToOneValidAndOneInvalidUser:-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":send a board invite to one valid twice", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithInvitationToSameUserAgain()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToSameUserAgain:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBodyForTwoUsers();
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getSecondUserContact(), "+91-7332248065",
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getSecondUserType(), "C",
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getSecondFirstName(), "Ashish",
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getSecondLastName(), "Laad",
				sendResendInvitationJsonBody);
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Failure Status");

		// verify response
		String firstNameFromResponse = response.extract().path("processed[0].firstName");
		String lastNameFromResponse = response.extract().path("processed[0].lastName");
		String userContactFromResponse = response.extract().path("processed[0].userContact");
		String userTypeFromResponse = response.extract().path("processed[0].userType");
		String inviteTypeFromResponse = response.extract().path("processed[0].inviteType");
		String contactTypeFromResponse = response.extract().path("processed[0].contactType");
		String inviteMessageFromResponse = response.extract().path("processed[0].inviteMessage");

		Verify.verifyEquals(firstNameFromResponse, "Ashish", "verify firstName of invited member");
		Verify.verifyEquals(lastNameFromResponse, "Laad", "verify lastName of invited member");
		Verify.verifyEquals(userContactFromResponse, "+91-7332248065", "verify userContact of invited member");
		Verify.verifyEquals(userTypeFromResponse, "C", "verify userType of invited member");
		Verify.verifyEquals(inviteTypeFromResponse, "I", "verify inviteType of invitation");
		Verify.verifyEquals(contactTypeFromResponse, "M", "verify contactType of invitation");
		Verify.verifyEquals(inviteMessageFromResponse, "Send invite to two users",
				"verify inviteMessage of invitation");

		String firstNameFromResponse1 = response.extract().path("processed[1].firstName");
		String lastNameFromResponse1 = response.extract().path("processed[1].lastName");
		String userContactFromResponse1 = response.extract().path("processed[1].userContact");
		String userTypeFromResponse1 = response.extract().path("processed[1].userType");
		String inviteTypeFromResponse1 = response.extract().path("processed[1].inviteType");
		String contactTypeFromResponse1 = response.extract().path("processed[1].contactType");
		String inviteMessageFromResponse1 = response.extract().path("processed[1].inviteMessage");

		Verify.verifyEquals(firstNameFromResponse1, "Ashish", "verify firstName of invited member");
		Verify.verifyEquals(lastNameFromResponse1, "Laad", "verify lastName of invited member");
		Verify.verifyEquals(userContactFromResponse1, "+91-7332248065", "verify userContact of invited member");
		Verify.verifyEquals(userTypeFromResponse1, "C", "verify userType of invited member");
		Verify.verifyEquals(inviteTypeFromResponse1, "I", "verify inviteType of invitation");
		Verify.verifyEquals(contactTypeFromResponse1, "M", "verify contactType of invitation");
		Verify.verifyEquals(inviteMessageFromResponse1, "Send invite to two users",
				"verify inviteMessage of invitation");
		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/sendResendInvitationTest-Schema.json"));
		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToSameUserAgain:-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":send a board invite by owner to owner and other valid users", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithInvitationToOwnerAndValidUser()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToOwnerAndValidUser:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserType(), "C",
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstFirstName(), firstNameOfOwner,
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstLastName(), lastNameOfOwner,
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserContact(), contactInfoOfOwner,
				sendResendInvitationJsonBody);
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response
		String firstNameFromResponse = response.extract().path("processed[0].firstName");
		String userContactFromResponse = response.extract().path("processed[0].userContact");
		String userTypeFromResponse = response.extract().path("processed[0].userType");
		String inviteTypeFromResponse = response.extract().path("processed[0].inviteType");
		String contactTypeFromResponse = response.extract().path("processed[0].contactType");
		String inviteMessageFromResponse = response.extract().path("processed[0].inviteMessage");
		String inviteCodeFromResponse = response.extract().path("processed[0].inviteCode");
		String inviteUrlFromResponse = response.extract().path("processed[0].inviteUrl");

		Verify.verifyEquals(firstNameFromResponse, firstNameOfOwner, "verify firstName of invited member");
		Verify.verifyEquals(userContactFromResponse, contactInfoOfOwner, "verify userContact of invited member");
		Verify.verifyEquals(userTypeFromResponse, "C", "verify userType of invited member");
		Verify.verifyEquals(inviteTypeFromResponse, "I", "verify inviteType of invitation");
		Verify.verifyEquals(contactTypeFromResponse, "E", "verify contactType of invitation");
		Verify.verifyEquals(inviteMessageFromResponse, "Invite Message", "verify inviteMessage of invitation");
		// Verify.verifyEquals(inviteUrlFromResponse, apiUrls.get("baseURL") +
		// "/i?c=" + inviteCodeFromResponse,"verify inviteUrl of invitation");

		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/sendResendInvitationTest-Schema.json"));
		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationToOwnerAndValidUser:-> End");
	}

	// need to add owner's info
	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName + ":send a board invite to self", groups = {
			TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithInvitationByOwnerToOnlyOwner()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationByOwnerToOnlyOwner:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		lastNameOfOwner = lastNameOfOwner + "test";
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserType(), "C",
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstFirstName(), firstNameOfOwner,
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstLastName(), lastNameOfOwner,
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserContact(), contactInfoOfOwner,
				sendResendInvitationJsonBody);
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response
		String firstNameFromResponse = response.extract().path("processed[0].firstName");
		String lastNameFromResponse = response.extract().path("processed[0].lastName");
		String userContactFromResponse = response.extract().path("processed[0].userContact");
		String userTypeFromResponse = response.extract().path("processed[0].userType");
		String inviteTypeFromResponse = response.extract().path("processed[0].inviteType");
		String contactTypeFromResponse = response.extract().path("processed[0].contactType");
		String inviteMessageFromResponse = response.extract().path("processed[0].inviteMessage");
		String inviteCodeFromResponse = response.extract().path("processed[0].inviteCode");
		String inviteUrlFromResponse = response.extract().path("processed[0].inviteUrl");

		Verify.verifyEquals(firstNameFromResponse, firstNameOfOwner, "verify firstName of invited member");
		Verify.verifyEquals(lastNameFromResponse, lastNameOfOwner, "verify lastName of invited member");
		Verify.verifyEquals(userContactFromResponse, contactInfoOfOwner, "verify userContact of invited member");
		Verify.verifyEquals(userTypeFromResponse, "C", "verify userType of invited member");
		Verify.verifyEquals(inviteTypeFromResponse, "I", "verify inviteType of invitation");
		Verify.verifyEquals(contactTypeFromResponse, "E", "verify contactType of invitation");
		Verify.verifyEquals(inviteMessageFromResponse, "Invite Message", "verify inviteMessage of invitation");
		// Verify.verifyEquals(inviteUrlFromResponse,apiUrls.get("baseURL") +
		// "/i?c=" + inviteCodeFromResponse,"verify inviteUrl of invitation");
		response.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/sendResendInvitationTest-Schema.json"));

		FrameworkLogger.logStep("sendResendInvitationTestWithInvitationByOwnerToOnlyOwner:-> End");
	}

	@Test(priority = 11, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the resposne if invite is send to member to whom invite is already send but not accepted", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithInvitationToValidUserToWhomInvitationAlreadySentButNotAccepted()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep(
				"sendResendInvitationTestWithInvitationToValidUserToWhomInvitationAlreadySentButNotAccepted:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		ValidatableResponse response1 = triggerPostApiSendResendInvitation(boardKey);

		int status1 = response1.extract().statusCode();
		Verify.verifyEquals(status1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response1
		String inviteCodeFromResponse1 = response1.extract().path("processed[0].inviteCode");
		String inviteUrlFromResponse1 = response1.extract().path("processed[0].inviteUrl");
		// Verify.verifyEquals(inviteUrlFromResponse1,apiUrls.get("baseURL") +
		// "/i?c=" + inviteCodeFromResponse1,"verify inviteUrl of invitation");

		// resend invitation
		ValidatableResponse response2 = triggerPostApiSendResendInvitation(boardKey);

		int status2 = response2.extract().statusCode();
		Verify.verifyEquals(status2, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response2

		String inviteCodeFromResponse2 = response2.extract().path("processed[0].inviteCode");
		String inviteUrlFromResponse2 = response2.extract().path("processed[0].inviteUrl");
		// Verify.verifyEquals(inviteUrlFromResponse2, apiUrls.get("baseURL") +
		// "/i?c=" + inviteCodeFromResponse2,"verify inviteUrl of invitation");

		FrameworkLogger.logStep(
				"sendResendInvitationTestWithInvitationToValidUserToWhomInvitationAlreadySentButNotAccepted:-> End");

	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if valid request for group invite is made.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })

	public void sendResendInvitationTestWithValidGroupInvitation()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("sendResendInvitationTestWithValidGroupInvitation:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBodyForGroupInvitation();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response

		String inviteTypeFromResponse = response.extract().path("inviteType");
		String inviteCodeFromResponse = response.extract().path("inviteCode");
		String inviteUrlFromResponse = response.extract().path("inviteUrl");

		Verify.verifyEquals(inviteTypeFromResponse, "G", "verify inviteType of invitation");
		// Verify.verifyEquals(inviteUrlFromResponse,apiUrls.get("baseURL") +
		// "/i?c=" + inviteCodeFromResponse,"verify inviteUrl of invitation");

		FrameworkLogger.logStep("sendResendInvitationTestWithValidGroupInvitation:-> End");

	}

	@Test(priority = 13, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if valid request for group invite is made and its not accepted and again got request.(accepted).", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void sendResendInvitationTestWithValidGroupInvitationDeniedAndThenAccepted()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("sendResendInvitationTestWithValidGroupInvitationDeniedAndThenAccepted:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBodyForGroupInvitation();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response
		String inviteCodeFromResponse = response.extract().path("inviteCode");

		// Decline the board request
		DeclineBoardRequestBaseScript.declineInvitationService(inviteCodeFromResponse, deviceContributorInfo);

		// again accept the same request
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(inviteCodeFromResponse,
				deviceContributorInfo);

		int statusAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("sendResendInvitationTestWithValidGroupInvitationDeniedAndThenAccepted:-> End");

	}

	@Test(priority = 14, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if valid request for individual invite is made and its not accepted and again got request.(accepted).", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithValidIndividualInvitationDeniedAndThenAccepted()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithValidIndividualInvitationDeniedAndThenAccepted:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		int status = responseSendInvite.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response
		String inviteCodeFromResponse = responseSendInvite.extract().path("processed[0].inviteCode");

		// Decline the board request
		ValidatableResponse reponseDecline = DeclineBoardRequestBaseScript
				.declineInvitationService(inviteCodeFromResponse, deviceContributorInfo);
		int statusDecline = reponseDecline.extract().statusCode();
		Verify.verifyEquals(statusDecline, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// again accept the same request
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(inviteCodeFromResponse,
				deviceContributorInfo);
		int statusAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusAccept, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("sendResendInvitationTestWithValidIndividualInvitationDeniedAndThenAccepted:-> End");
	}

	@Test(priority = 15, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if valid request for group invite is made and its declined it and again got individual request.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithValidGroupInvitationDeniedAndThenAcceptedInvidualInvite()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(
				"sendResendInvitationTestWithValidGroupInvitationDeniedAndThenAcceptedInvidualInvite:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBodyForGroupInvitation();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response
		String inviteCodeFromResponse = response.extract().path("inviteCode");

		// Decline the group board request
		DeclineBoardRequestBaseScript.declineInvitationService(inviteCodeFromResponse, deviceContributorInfo);

		// make an individual request again
		createHeader();
		ValidatableResponse responseAgain = triggerPostApiSendResendInvitation(boardKey);
		int statusAgain = responseAgain.extract().statusCode();
		Verify.verifyEquals(statusAgain, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String inviteCodeResponse = response.extract().path("inviteCode");

		// again accept the same request
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(inviteCodeResponse,
				deviceContributorInfo);
		int statusAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger
				.logStep("sendResendInvitationTestWithValidGroupInvitationDeniedAndThenAcceptedInvidualInvite:-> End");
	}

	@Test(priority = 16, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the resposne if invite is send to already joined member.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithValidIndividualInvitationAcceptedAndSentInvitationAgain()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(
				"sendResendInvitationTestWithValidIndividualInvitationAcceptedAndSentInvitationAgain:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		int status = responseSendInvite.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response
		String inviteCodeFromResponse = responseSendInvite.extract().path("processed[0].inviteCode");

		// accept the same request
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(inviteCodeFromResponse,
				deviceContributorInfo);
		int statusAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// again send request to same contributor for same board.
		createHeader();
		ValidatableResponse responseAgain = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKey,
				firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		int statusAgain = responseAgain.extract().statusCode();
		Verify.verifyEquals(statusAgain, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		FrameworkLogger
				.logStep("sendResendInvitationTestWithValidIndividualInvitationAcceptedAndSentInvitationAgain:-> End");
	}

	@Test(priority = 17, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the resposne if user have already accepted the invitation through individual way, and getting invite through grp invite.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithValidIndividualInvitationAcceptedAndThenGotGroupInvite()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(
				"sendResendInvitationTestWithValidGroupInvitationDeniedAndThenAcceptedInvidualInvite:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		int status = responseSendInvite.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response
		String inviteTypeFromResponse = responseSendInvite.extract().path("processed[0].inviteType");
		String inviteCodeFromResponse = responseSendInvite.extract().path("processed[0].inviteCode");
		Verify.verifyEquals(inviteTypeFromResponse, "I", "verify inviteType of invitation");

		// accept the same request
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(inviteCodeFromResponse,
				deviceContributorInfo);
		int statusAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// again send the group request to same contributor for same board

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBodyForGroupInvitation();
		ValidatableResponse responseAgain = triggerPostApiSendResendInvitation(boardKey);
		int statusAgain = responseAgain.extract().statusCode();
		Verify.verifyEquals(statusAgain, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Failure Status");

		FrameworkLogger
				.logStep("sendResendInvitationTestWithValidGroupInvitationDeniedAndThenAcceptedInvidualInvite:-> End");
	}

	@Test(priority = 18, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the resposne if user have already accepted the invitation through group way, and getting invite through individual invite.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithValidGroupInvitationAcceptedAndThenGotIndividualInvite()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger
				.logStep("sendResendInvitationTestWithValidGroupInvitationAcceptedAndThenGotIndividualInvite:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend grp invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBodyForGroupInvitation();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response
		String inviteTypeFromResponse = response.extract().path("inviteType");
		String inviteCodeFromResponse = response.extract().path("inviteCode");
		Verify.verifyEquals(inviteTypeFromResponse, "G", "verify inviteType of invitation");

		// accept the same request
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(inviteCodeFromResponse,
				deviceContributorInfo);
		int statusAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// again send the individual request to same contributor for same board

		// call send / resend invitation apis
		createHeader();
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");

		int statusAgain = responseSendInvite.extract().statusCode();
		Verify.verifyEquals(statusAgain, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Failure Status");

		FrameworkLogger
				.logStep("sendResendInvitationTestWithValidGroupInvitationAcceptedAndThenGotIndividualInvite:-> End");
	}

	// Verify the resposne for boardkey by other user.(invalid)
	// Verify the resposne if contributor is inviting to owner to join existing
	// group
	@Test(priority = 19, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the resposne if Contibutor is inviting his owner to join exising board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithContibutorInvitingHisOwnerToJoinExistingGroup()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithContibutorInvitingHisOwnerToJoinExistingGroup:-> Start");

		// accept the same request - by contributor

		// create a board - by owner
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend grp invitation apis - by owner to contributor
		sendResendInvitationJsonBody = setSendResendInvitationJsonBodyForGroupInvitation();
		createHeader();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response
		String inviteTypeFromResponse = response.extract().path("inviteType");
		String inviteCodeFromResponse = response.extract().path("inviteCode");
		String inviteUrlFromResponse = response.extract().path("inviteUrl");

		Verify.verifyEquals(inviteTypeFromResponse, "G", "verify inviteType of invitation");
		// Verify.verifyEquals(inviteUrlFromResponse,
		// apiUrls.get("baseURL")+"/boardinvites/invites/"+inviteCodeFromResponse,
		// "verify inviteUrl of invitation");

		// accept the same request - by contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(inviteCodeFromResponse,
				deviceContributorInfo);
		int statusAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// again send the individual request from contributor to owner to join
		// same board
		setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserContact(), contactInfoOfOwner,
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserType(), "C",
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstFirstName(), firstNameOfOwner,
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstLastName(), lastNameOfOwner,
				sendResendInvitationJsonBody);

		ValidatableResponse responseSendInvite = triggerPostApiSendResendInvitation(boardKey, deviceOwnerInfo);
		int status2 = responseSendInvite.extract().statusCode();
		Verify.verifyEquals(status2, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// accept the same request - by Owner
		ValidatableResponse responseAccept2 = AcceptInvitationBaseScript.acceptInvitationService(inviteCodeFromResponse,
				deviceOwnerInfo);
		int statusAccept2 = responseAccept2.extract().statusCode();
		Verify.verifyEquals(statusAccept2, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Failed Status");
		String errorCodeAccept2 = responseAccept2.extract().path("code");
		Verify.verifyEquals(errorCodeAccept2, ErrorResponseCodes.ERRORCODE_BINVS0054.getValue(), "Verify Error Code");
		FrameworkLogger.logStep("sendResendInvitationTestWithContibutorInvitingHisOwnerToJoinExistingGroup:-> End");
	}

	// Verify the resposne if contributor is inviting to owner to join new group
	@Test(enabled = false, priority = 20, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the resposne if Contibutor is inviting his owner to join new board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithContibutorInvitingHisOwnerToJoinNewGroup()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithContibutorInvitingHisOwnerToJoinExistingGroup:-> Start");

		// create a board - by owner
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend grp invitation apis - by owner to contributor
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBodyForGroupInvitation();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify response
		String inviteCodeFromResponse = response.extract().path("inviteCode");

		// accept the same request - by contributor
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(inviteCodeFromResponse,
				deviceContributorInfo);
		int statusAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// contributor creates new board
		String boardNameContributor = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(deviceContributorInfo, boardName);
		String boardKeyContributor = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// again send the individual request from contributor to owner to join
		// same board
		setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserContact(), contactInfoOfOwner,
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserType(), "C",
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstFirstName(), firstNameOfOwner,
				sendResendInvitationJsonBody);
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstLastName(), lastNameOfOwner,
				sendResendInvitationJsonBody);
		ValidatableResponse responseAgain = triggerPostApiSendResendInvitation(boardKeyContributor, deviceOwnerInfo);

		int statusAgain = responseAgain.extract().statusCode();
		Verify.verifyEquals(statusAgain, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		String inviteCodeFromNewResponse = responseAgain.extract().path("processed[0].inviteCode");

		// accept the same request - by Owner
		ValidatableResponse responseAccept2 = AcceptInvitationBaseScript
				.acceptInvitationService(inviteCodeFromNewResponse, deviceOwnerInfo);
		int statusAccept2 = responseAccept2.extract().statusCode();
		Verify.verifyEquals(statusAccept2, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("sendResendInvitationTestWithContibutorInvitingHisOwnerToJoinExistingGroup:-> End");
	}
}
