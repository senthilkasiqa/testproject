package com.rjil.cloud.mailchamp.test;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.mailchamp.common.helper.GetSubScriptionListBaseClass;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.enums.HeaderParameters;


public class GetSubscNegative extends GetSubScriptionListBaseClass {

	public ValidatableResponse response;

	@Test(description = "TC_19 - To verify if user get list of all subscriptions for a user "
			+ "when USER ID is missing and Subscription Type is New", groups = {TestNgGroups.REGRESSION })

	public void aGetSubScpFromNewNoUserId() {
		String userId = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),userId );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"New");
		
//		String getSubScpNew = getSubscriptionUrlForNew();
		String baseUrl = getBaseURL();
		
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for missing USERID in New subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 400);
	}

	@Test(description = "TC_20 - To verify if user get list of all subscriptions for a user "
			+ "when ACCESS TOKEN is missing and Subscription Type is New", groups = {TestNgGroups.REGRESSION })

	public void bGetSubScpFromNewNoAccessToken() {
		String authToken = "";
		Map<String, String> headerMap=createHeaderMap();
		//headerMap.remove(HeaderParameters.XMACACCESSTOKEN);
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),authToken );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"New");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); 	// 400
		System.out.println("Status Code for missing ACCESS TOKEN in New subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 400);
	}

	
	@Test(description = "TC_21 - To verify if user get list of all subscriptions for a user"
			+ " when USER ID is missing and Subscription Type is Inbox", groups = { TestNgGroups.REGRESSION })

	public void cGetSubScpFromInboxNoUserId() {
		String userId = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),userId );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"Inbox");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for missing USERID in Inbox subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 400);
	}
	
	
	@Test(description = "TC_22 - To verify if user get list of all subscriptions for a user"
			+ " when ACCESS TOKEN is missing and Subscription Type is Inbox", groups = { TestNgGroups.REGRESSION })

	public void dGetSubScpFromInboxNoAcessToken() {
		String authToken = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),authToken );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"Inbox");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for missing ACCESS TOKEN in Inbox subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 400);
	}

	
	@Test
	(description = "TC_23 - To verify if user get list of all subscriptions for a user "
			+ "when USER ID is missing and Subscription Type is GroupIt", groups = { TestNgGroups.REGRESSION })
	public void eGetSubScpFromGroupItNoUserId() {
		String userId = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),userId );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"GroupIt");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for missing USERID in GroupIt subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 400);
	}
	
	@Test
	(description = "TC_24 - To verify if user get list of all subscriptions for a user "
			+ "when ACCESS TOKEN is missing and Subscription Type is GroupIt", groups = { TestNgGroups.REGRESSION })
	
	public void fGetSubScpFromGroupItNoAccessToken() {
		String authToken = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),authToken );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"GroupIt");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for missing AccessToken in GroupIt subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 400);
	}

	
	@Test
	(description = "TC_25 - To verify if user get list of all subscriptions for a user "
			+ "when USERID is missing and Subscription Type is Unsubscribe", groups = { TestNgGroups.REGRESSION })

	public void gGetSubScpFromUnsubscribeNoEmail() {
		String userId = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),userId );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"Unsubscribe");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 401
		System.out.println("Status Code for no USERID in Unsubscribe subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 400);
	}

	@Test
	(description = "TC_26 - To verify if user get list of all subscriptions for a user "
			+ "when ACCESS TOKEN is missing and Subscription Type is Unsubscribe", groups = { TestNgGroups.REGRESSION })

	public void hGetSubScpFromUnsubscribeNoAccessToken() {
		String authToken = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),authToken );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"Unsubscribe");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 401
		System.out.println("Status Code for no ACCESS TOKEN in Unsubscribe subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 400);
	}

	
	@Test
	(description = "TC_27 - To verify if user get list of all subscriptions for a user "
			+ "when USERID is INVALID and Subscription Type is New", groups = { TestNgGroups.REGRESSION })

	public void iGetSubScpFromNewInvalidUserId() {
		String userId = "abcd@1234.com";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),userId );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"New");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for missing USERID in New subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 400);
	}

	@Test
	(description = "TC_28 - To verify if user get list of all subscriptions for a user "
			+ "when ACCESS TOKEN is INVALID and Subscription Type is New", groups = {TestNgGroups.REGRESSION })

	public void jGetSubScpFromNewInvalidAccessToken() {
		String authToken = "abcd@1234.com";
		Map<String, String> headerMap=createHeaderMap();
		//headerMap.remove(HeaderParameters.XMACACCESSTOKEN);
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),authToken );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"New");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for Invalid ACCESS TOKEN in New subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 401);
	}

	
	@Test
	(description = "TC_29 - To verify if user get list of all subscriptions for a user "
			+ "when USER ID is INVALID and Subscription Type is Inbox", groups = { TestNgGroups.REGRESSION })
	public void kGetSubScpFromInboxInvaliUserId() {
		String userId = "abcd@1234.com";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),userId );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"Inbox");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for INVALID USERID in Inbox subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 400);
	}
	
	
	@Test
	(description = "TC_30 - To verify if user get list of all subscriptions for a user"
			+ " when ACCESS TOKEN is INVALID and Subscription Type is Inbox", groups = { TestNgGroups.REGRESSION })

	public void lGetSubScpFromInboxInvaliAcessToken() {
		String authToken = "abcd@1234.com";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),authToken );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"Inbox");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for INVALID ACCESS TOKEN in Inbox subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 401);
	}


	@Test
	(description = "TC_31 - To verify if user get list of all subscriptions for a user "
			+ "when email id is INVALID and Subscription Type is GroupIt", groups = { TestNgGroups.REGRESSION })
	public void mGetSubScpFromGroupItInvaliUserId() {
		String userId = "abcd@1234.com";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),userId );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"GroupIt");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for INVALID USERID in GroupIt subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 400);
	}
	
	@Test
	(description = "TC_32 - To verify if user get list of all subscriptions for a user "
			+ "when ACCESS TOKEN is INVALID and Subscription Type is GroupIt", groups = { TestNgGroups.REGRESSION })
	public void nGetSubScpFromGroupItInvaliAcessToken() {
		String authToken = "abcd@1234.com";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),authToken );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"GroupIt");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for INVALID ACCESS TOKEN in GroupIt subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 401);
	}

	@Test
	(description = "TC_33 - To verify if user get list of all subscriptions for a user "
			+ "when email id is INVALID and Subscription Type is Unsubscribe", groups = { TestNgGroups.REGRESSION })
	public void oGetSubScpFromUnsubscribeInvaliUserId() {
		String userId = "abcd@1234.com";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),userId );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"Unsubscribe");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for INVALID ACCESS TOKEN in GroupIt subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 400);
	}

	@Test
	(description = "TC_34 - To verify if user get list of all subscriptions for a user "
			+ "when Access Token is INVALID and Subscription Type is Unsubscribe", groups = { TestNgGroups.REGRESSION })
	public void pGetSubScpFromUnsubscribeInvaliAcessToken() {
		String authToken = "abcd@1234.com";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),authToken );
		headerMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"Unsubscribe");
		
		String baseUrl = getBaseURL();
		response = triggerGetApi(baseUrl, headerMap);
		int subListStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for INVALID ACCESS TOKEN in GroupIt subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 401);
	}	
	
	@Test
	(description = "TC_35 - To verify GET subscription API when process is unable to get data from backend "
			+ "and Subscription Type is NEW", groups = { TestNgGroups.REGRESSION })
	public void qSubScrSvrErrNew() {
		String baseUrl = getBaseURL();
		Map<String, String> localHeaderMap = createHeaderMap();
		localHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(baseUrl, localHeaderMap);
		
		int subListStatus = response.extract().statusCode(); // 500
		System.out.println("TO FAIL when SERVER WORKING: - Status Code when no response from Server for NEW subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 500);
	}

	@Test
	(description = "TC_36 - To verify GET subscription API when process is unable to get data from backend "
			+ "and Subscription Type is INBOX", groups = { TestNgGroups.REGRESSION })
	public void rSubScrSvrErrInbox() {
		String baseUrl = getBaseURL();
		Map<String, String> localHeaderMap = createHeaderMap();
		localHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerGetApi(baseUrl, localHeaderMap);
		int subListStatus = response.extract().statusCode(); // 500
		System.out.println("TO FAIL when SERVER WORKING: - Status Code when no response from Server for INBOX subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 500);
	}

	@Test
	(description = "TC_37 - To verify GET subscription API when process is unable to get data from backend "
			+ "and Subscription Type is GroupIt", groups = { TestNgGroups.REGRESSION })
	public void sSubScrSvrErrGroupIt() {
		String baseUrl = getBaseURL();
		Map<String, String> localHeaderMap = createHeaderMap();
		localHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerGetApi(baseUrl, localHeaderMap);
		int subListStatus = response.extract().statusCode(); // 500
		System.out
				.println("TO FAIL when SERVER WORKING: - Status Code when no response from Server for GroupIt subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 500);
	}

	@Test
	(description = "TC_38 - To verify GET subscription API when process is unable to get data from backend "
			+ "and Subscription Type is UnSubscribe", groups = { TestNgGroups.REGRESSION })

	public void tSubScrSvrErrUnSubscribe() {
		String baseUrl = getBaseURL();
		Map<String, String> localHeaderMap = createHeaderMap();
		localHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerGetApi(baseUrl, localHeaderMap);int subListStatus = response.extract().statusCode(); // 500
		System.out.println(
				"TO FAIL when SERVER WORKING: - Status Code when no response from Server for UnSubscribe subscription type is :" + subListStatus);
		Assert.assertEquals(subListStatus, 500);
	}
}