package com.rjil.cloud.mailchamp.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.mailchamp.common.helper.SyncDataAndGetSubscriptionBaseClass;


public class SyncDataAndGetSubscription extends SyncDataAndGetSubscriptionBaseClass{
	
	public ValidatableResponse response;

	@Test
	(description = "TC_10 - To verify SyncDataAndGetSubscriptions API, for all valid details.",
			groups = {"SANITY", "REGRESSION"})
		public void syncDataGetSubscriptionStatusCode() 	{
		response = triggerGetApi(getSynsDataUrl(),createHeaderMap());

		int intSyncStatus = response.extract().statusCode();	//200
		System.out.println("Status Code is :" +intSyncStatus);
		Assert.assertEquals(intSyncStatus, 200);
		}
}