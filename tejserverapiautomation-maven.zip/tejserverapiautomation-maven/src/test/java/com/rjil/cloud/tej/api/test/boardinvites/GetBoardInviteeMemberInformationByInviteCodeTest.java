package com.rjil.cloud.tej.api.test.boardinvites;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.ValidatableResponse;

import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.DeclineBoardRequestBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.GetBoardInviteeInformationByInviteCodeBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.fileupload.UploadBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 *
 *
 */
public class GetBoardInviteeMemberInformationByInviteCodeTest extends GetBoardInviteeInformationByInviteCodeBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the board and invitee information when invite code is genereted for users who are not yet part of boards.", groups = {
					TestNgGroups.DEPLOYMENTSANITY})
	public void verifyBoardAndInviteeInformationForUserWhichIsNotPartOfBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationForUserWhichIsNotPartOfBoard:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		String fileName = "Sample.jpg";
		UploadBaseScript.getUploadFileToBoardServiceMethod(fileName, boardKey);

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Get Board Invite member information
		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode, deviceContributorInfo);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(),
				"Verify Get Board Invitee Member By Invite Code status");
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationForUserWhichIsNotPartOfBoard:-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the board and invitee information when invite code is genereted for users who are not yet part of boards.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS,TestNgGroups.QASANITY })
	public void verifyBoardAndInviteeInformationForUserWhichIsNotPartOfBoardTest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationForUserWhichIsNotPartOfBoard:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		String fileName = "Sample.jpg";

		// Upload file in board
		UploadBaseScript.getUploadFileToBoardServiceMethod(fileName, boardKey);

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		
		//kalpesh
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		//kalpesh

		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode, deviceContributorInfo);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Http Code");
		String boardKeyFromResponse = responseGetBoardInviteeInfo.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardOwnerNameFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerUserId");
		Verify.verifyEquals(boardOwnerNameFromResponse, userIdOfOwner, "verify board owner user id of created board");

		String contributorUserId = responseGetBoardInviteeInfo.extract().path("boardMembers[0].userId");
		Verify.verifyEquals(contributorUserId, userIdOfContributor, "Verify user id of contributor");

		String contributorFirstName = responseGetBoardInviteeInfo.extract().path("boardMembers[0].firstName");
		Verify.verifyEquals(contributorFirstName, firstNameOfContributor, "Verify first name of contributor");

		String contributorType = responseGetBoardInviteeInfo.extract().path("boardMembers[0].memberType");
		Verify.verifyEquals(contributorType, "C", "Verify Member Type for contributor");

		String contributorProfilePic = responseGetBoardInviteeInfo.extract().path("boardMembers[0].profilePic");
		Verify.verifyEquals(contributorProfilePic,
				apiUrls.get("downloadPublicIp") + "/boards/members/" + userIdOfContributor + "/profilepic",
				"Verify Member Type for contributor");

		String contributorMemberStatus = responseGetBoardInviteeInfo.extract().path("boardMembers[0].memberStatus");
		Verify.verifyEquals(contributorMemberStatus, "P", "Verify contact info of contributor");

		responseGetBoardInviteeInfo.body(JsonSchemaValidator
				.matchesJsonSchemaInClasspath("newBoardTestData/getBoardAndInviteeInformationTest-Schema.json"));
		String ownerProfilePic = responseGetBoardInviteeInfo.extract().path("owner.ownerProfilePic");
		Verify.verifyEquals(ownerProfilePic,
				"http://sit-dl.tejdrive.com/boards/members/" + userIdOfOwner + "/profilepic",
				"Verify Member Type for contributor");

		String profilePicMember1 = responseGetBoardInviteeInfo.extract().path("boardMembers[0].profilePic ");
		Verify.verifyEquals(profilePicMember1,
				"http://sit-dl.tejdrive.com/boards/members/" + userIdOfContributor + "/profilepic",
				"Verify Member Type for contributor");

		FrameworkLogger.logStep("verifyBoardAndInviteeInformationForUserWhichIsNotPartOfBoard:-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the board and invitee info if invite code is generated for member who has left the board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationForMemberWhoIsYetToAccept()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationForMemberWhoLeftTheBoard:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode, deviceContributorInfo);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Http Code");
		String boardKeyFromResponse = responseGetBoardInviteeInfo.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardOwnerIdFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerUserId");
		Verify.verifyEquals(boardOwnerIdFromResponse, userIdOfOwner, "verify board owner user id of created board");
		String boardOwnerNameFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerFirstName");
		Verify.verifyEquals(boardOwnerNameFromResponse, firstNameOfOwner,
				"verify board owner user id of created board");
		String boardMemberIdFromResponse = responseGetBoardInviteeInfo.extract().path("boardMembers[0].userId");
		Verify.verifyEquals(boardMemberIdFromResponse, userIdOfContributor, "verify board member id");
		String boardMemberFirstNameFromResponse = responseGetBoardInviteeInfo.extract()
				.path("boardMembers[0].firstName");
		Verify.verifyEquals(boardMemberFirstNameFromResponse, firstNameOfContributor, "verify board member name");
		String boardMemberTypeFromResponse = responseGetBoardInviteeInfo.extract().path("boardMembers[0].memberType");
		Verify.verifyEquals(boardMemberTypeFromResponse, "C", "verify board member type");
		String boardMemberStatusFromResponse = responseGetBoardInviteeInfo.extract()
				.path("boardMembers[0].memberStatus");
		Verify.verifyEquals(boardMemberStatusFromResponse, "P", "verify member status");

		FrameworkLogger.logStep("verifyBoardAndInviteeInformationForMemberWhoLeftTheBoard:-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the board and invitee info if invite code is generated for member to whom, owner has already removed.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationForMemberWhoAcceptedInvite()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationForMemberWhoIsRemovedByOwner:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Accept invitation
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode, deviceContributorInfo);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Http Code");
		String boardKeyFromResponse = responseGetBoardInviteeInfo.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");
		String errorCodeFromResponse = responseGetBoardInviteeInfo.extract().path("errorCode");
		Verify.verifyEquals(errorCodeFromResponse, ErrorResponseCodes.ERRORCODE_BINVS0054.getValue(),
				"verify error code");
		String errorMessageFromResponse = responseGetBoardInviteeInfo.extract().path("errorMessage");
		Verify.verifyEquals(errorMessageFromResponse, "User is already a part of Board.", "verify error message");

		String boardOwnerIdFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerUserId");
		Verify.verifyEquals(boardOwnerIdFromResponse, userIdOfOwner, "verify board owner user id of created board");
		String boardOwnerNameFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerFirstName");
		Verify.verifyEquals(boardOwnerNameFromResponse, firstNameOfOwner,
				"verify board owner user id of created board");
		String boardMemberIdFromResponse = responseGetBoardInviteeInfo.extract().path("boardMembers[0].userId");
		Verify.verifyEquals(boardMemberIdFromResponse, userIdOfContributor, "verify board member id");
		String boardMemberFirstNameFromResponse = responseGetBoardInviteeInfo.extract()
				.path("boardMembers[0].firstName");
		Verify.verifyEquals(boardMemberFirstNameFromResponse, firstNameOfContributor, "verify board member name");
		String boardMemberTypeFromResponse = responseGetBoardInviteeInfo.extract().path("boardMembers[0].memberType");
		Verify.verifyEquals(boardMemberTypeFromResponse, "C", "verify board member type");
		String boardMemberStatusFromResponse = responseGetBoardInviteeInfo.extract()
				.path("boardMembers[0].memberStatus");
		Verify.verifyEquals(boardMemberStatusFromResponse, "A", "verify member status");

		FrameworkLogger.logStep("verifyBoardAndInviteeInformationForMemberWhoIsRemovedByOwner:-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the board and invitee info if invite code is generated by new owner to old owner", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationIfInviteCodeIsGeneratedByNewOwner()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfInviteCodeIsGeneratedByNewOwnerToOldOwner:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user1
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode1 = responseSendInvite1.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode1, deviceContributorInfo);

		// Owner leaves board
		createHeader();
		LeaveBoardBaseScript.leaveBoardService(boardKey);
		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode1, deviceContributorInfo);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Http Code");
		String boardKeyFromResponse = responseGetBoardInviteeInfo.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");
		String errorCodeFromResponse = responseGetBoardInviteeInfo.extract().path("errorCode");
		Verify.verifyEquals(errorCodeFromResponse, ErrorResponseCodes.ERRORCODE_BINVS0054.getValue(),
				"verify error code");
		String errorMessageFromResponse = responseGetBoardInviteeInfo.extract().path("errorMessage");
		Verify.verifyEquals(errorMessageFromResponse, "User is already a part of Board.", "verify error message");

		String boardOwnerIdFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerUserId");
		Verify.verifyEquals(boardOwnerIdFromResponse, userIdOfContributor,
				"verify board owner user id of created board");
		String boardOwnerNameFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerFirstName");
		Verify.verifyEquals(boardOwnerNameFromResponse, firstNameOfContributor,
				"verify board owner user id of created board");
		String boardMemberIdFromResponse = responseGetBoardInviteeInfo.extract().path("boardMembers[0].userId");
		Verify.verifyEquals(boardMemberIdFromResponse, userIdOfContributor, "verify board member id");
		String boardMemberFirstNameFromResponse = responseGetBoardInviteeInfo.extract()
				.path("boardMembers[0].firstName");
		Verify.verifyEquals(boardMemberFirstNameFromResponse, firstNameOfContributor, "verify board member name");
		String boardMemberTypeFromResponse = responseGetBoardInviteeInfo.extract().path("boardMembers[0].memberType");
		Verify.verifyEquals(boardMemberTypeFromResponse, "O", "verify board member type");
		String boardMemberStatusFromResponse = responseGetBoardInviteeInfo.extract()
				.path("boardMembers[0].memberStatus");
		Verify.verifyEquals(boardMemberStatusFromResponse, "A", "verify member status");
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfInviteCodeIsGeneratedByNewOwnerToOldOwner:-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the board and invitee info if group invite is made by owner ", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationIfGroupInviteCodeIsMadeByOwner()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfInviteCodeIsGeneratedByNewOwnerToOldOwner:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);
		String invitationCode = responseSendInvite.extract().path("inviteCode");
		createHeader();
		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Http Code");
		String boardKeyFromResponse = responseGetBoardInviteeInfo.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");
		String errorCodeFromResponse = responseGetBoardInviteeInfo.extract().path("errorCode");
		Verify.verifyEquals(errorCodeFromResponse, ErrorResponseCodes.ERRORCODE_BINVS0054.getValue(),
				"verify error code");
		String errorMessageFromResponse = responseGetBoardInviteeInfo.extract().path("errorMessage");
		Verify.verifyEquals(errorMessageFromResponse, "User is already a part of Board.", "verify error message");
		String boardOwnerIdFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerUserId");
		Verify.verifyEquals(boardOwnerIdFromResponse, userIdOfOwner, "verify board owner user id of created board");
		String boardOwnerNameFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerFirstName");
		Verify.verifyEquals(boardOwnerNameFromResponse, firstNameOfOwner,
				"verify board owner user id of created board");
		String boardMemberIdFromResponse = responseGetBoardInviteeInfo.extract().path("boardMembers[0].userId");
		Verify.verifyEquals(boardMemberIdFromResponse, userIdOfOwner, "verify board member id");
		String boardMemberFirstNameFromResponse = responseGetBoardInviteeInfo.extract()
				.path("boardMembers[0].firstName");
		Verify.verifyEquals(boardMemberFirstNameFromResponse, firstNameOfOwner, "verify board member name");
		String boardMemberTypeFromResponse = responseGetBoardInviteeInfo.extract().path("boardMembers[0].memberType");
		Verify.verifyEquals(boardMemberTypeFromResponse, "O", "verify board member type");
		String boardMemberStatusFromResponse = responseGetBoardInviteeInfo.extract()
				.path("boardMembers[0].memberStatus");
		Verify.verifyEquals(boardMemberStatusFromResponse, "A", "verify member status");

		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfInviteCodeIsGeneratedByNewOwnerToOldOwner:-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the error message for invalid inviteCode", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationIfInviteCodeIsInvalid()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfInviteCodeIsInvalid:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKey, firstNameOfContributor,
				lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = "sahvcsbc";
		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode, deviceContributorInfo);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Http Code");
		String errorCode = responseGetBoardInviteeInfo.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0014.getValue(), "Verify Error Code");
		String errorMessage = responseGetBoardInviteeInfo.extract().path("error");
		Verify.verifyEquals(errorMessage, "Invalid invite code.", "Verify Error Message");

		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfInviteCodeIsInvalid:-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the error message for null inviteCode ", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationIfInviteCodeIsNull()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfInviteCodeIsNull:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKey, firstNameOfContributor,
				lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = "";
		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode, deviceContributorInfo);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE404.getValue(), "Verify Http Code");
		String errorCode = responseGetBoardInviteeInfo.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_TEJRF0404.getValue(), "Verify Error Code");

		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfInviteCodeIsNull:-> End");
	}

	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the error message for missing inviteCode ", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationIfInviteCodeIsMissing()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfInviteCodeIsMissing:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKey, firstNameOfContributor,
				lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = "";
		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode, deviceContributorInfo);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE404.getValue(), "Verify Http Code");
		String errorCode = responseGetBoardInviteeInfo.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_TEJRF0404.getValue(), "Verify Error Code");

		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfInviteCodeIsMissing:-> End");
	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ " verify the error code if deviceKey is missing.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationIfDeviceKeyIsMissing()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfDeviceKeyIsMissing:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		createHeader();
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), "");
		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify Http Code");
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfDeviceKeyIsMissing:-> End");
	}

	@Test(priority = 13, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the error code if xuserId is invalid.", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationIfUserIdIsInvalid()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfUserIdIsInvalid:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		createHeader();
		headerMap.put(HeaderParameters.XUSERID.getValue(), "kjbcsbc");
		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify Http Code");
		String errorCode = responseGetBoardInviteeInfo.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_TEJGA0401.getValue(), "Verify Error Code");
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfUserIdIsInvalid:-> End");
	}

	@Test(priority = 14, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the error code if xuserId is missing.", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationIfUserIdIsMissing()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfUserIdIsMissing:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		createHeader();
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Http Code");
		String errorCode = responseGetBoardInviteeInfo.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_TEJGA0400.getValue(), "Verify Error Code");
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfUserIdIsMissing:-> End");
	}

	// @Test(priority = 15, description = TestNgGroups.BOARDS + ":" + apiName +
	// ":"
	// + "Verify the error code if unauthorized user is trying to access board
	// and invitee information.(non board member can see the info)", groups = {
	// TestNgGroups.REGRESSION,TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationIfUserIsUnauthorized()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfUserIsUnauthorized:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		deviceSecondContributorInfo.put(HeaderParameters.XUSERID.getValue(), "hjg7667");
		// view invite code by 3rd user
		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode, deviceSecondContributorInfo);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify Http Code");
		String errorCode = responseGetBoardInviteeInfo.extract().path("errorCode");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0015.getValue(), "Verify Error Code");
		String errorMessage = responseGetBoardInviteeInfo.extract().path("errorMessage");
		Verify.verifyEquals(errorMessage, "Invite code is already used.", "Verify Error Message");
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfUserIsUnauthorized:-> End");
	}

	@Test(priority = 16, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the board and invitee info if invite code is generated for member who has left the board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationByTheOwner()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationForTheBoard:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		LeaveBoardBaseScript.leaveBoardService(boardKey, deviceContributorInfo);
		createHeader();
		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Http Code");
		String boardKeyFromResponse = responseGetBoardInviteeInfo.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");
		String errorCodeFromResponse = responseGetBoardInviteeInfo.extract().path("errorCode");
		Verify.verifyEquals(errorCodeFromResponse, ErrorResponseCodes.ERRORCODE_BINVS0054.getValue(),
				"verify error code");
		String errorMessageFromResponse = responseGetBoardInviteeInfo.extract().path("errorMessage");
		Verify.verifyEquals(errorMessageFromResponse, "User is already a part of Board.", "verify error message");
		String boardOwnerIdFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerUserId");
		Verify.verifyEquals(boardOwnerIdFromResponse, userIdOfOwner, "verify board owner user id of created board");
		String boardOwnerNameFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerFirstName");
		Verify.verifyEquals(boardOwnerNameFromResponse, firstNameOfOwner,
				"verify board owner user id of created board");
		String boardMemberIdFromResponse = responseGetBoardInviteeInfo.extract().path("boardMembers[0].userId");
		Verify.verifyEquals(boardMemberIdFromResponse, userIdOfOwner, "verify board member id");
		String boardMemberFirstNameFromResponse = responseGetBoardInviteeInfo.extract()
				.path("boardMembers[0].firstName");
		Verify.verifyEquals(boardMemberFirstNameFromResponse, firstNameOfOwner, "verify board member name");
		String boardMemberTypeFromResponse = responseGetBoardInviteeInfo.extract().path("boardMembers[0].memberType");
		Verify.verifyEquals(boardMemberTypeFromResponse, "O", "verify board member type");
		String boardMemberStatusFromResponse = responseGetBoardInviteeInfo.extract()
				.path("boardMembers[0].memberStatus");
		Verify.verifyEquals(boardMemberStatusFromResponse, "A", "verify member status");

		FrameworkLogger.logStep("verifyBoardAndInviteeInformationForTheBoard:-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the board and invitee info if invite code is generated for member to whom, owner has already removed.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationForMemberWhoDeclinedInvite()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationForMemberWhoIsRemovedByOwner:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Decline invitation
		DeclineBoardRequestBaseScript.declineInvitationService(invitationCode, deviceContributorInfo);

		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode, deviceContributorInfo);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Http Code");
		String errorCodeFromResponse = responseGetBoardInviteeInfo.extract().path("errorCode");
		Verify.verifyEquals(errorCodeFromResponse, ErrorResponseCodes.ERRORCODE_BINVS0012.getValue(),
				"verify error code");
		String errorMessage = responseGetBoardInviteeInfo.extract().path("errorMessage");
		Verify.verifyEquals(errorMessage, "Inactive invite code.", "Verify Error Message");
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationForMemberWhoIsRemovedByOwner:-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the board and invitee info if group invite is made by owner ", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyBoardAndInviteeInformationIfGroupInviteCodeIsMadeByMember()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfGroupInviteCodeIsMadeByMember:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);
		String invitationCode = responseSendInvite.extract().path("inviteCode");
		ValidatableResponse responseGetBoardInviteeInfo = triggerGetApiGetBoardInviteeMemberInformationByInviteCode(
				invitationCode, deviceContributorInfo);
		int httpCode = responseGetBoardInviteeInfo.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Http Code");
		String boardKeyFromResponse = responseGetBoardInviteeInfo.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");
		String boardOwnerIdFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerUserId");
		Verify.verifyEquals(boardOwnerIdFromResponse, userIdOfOwner, "verify board owner user id of created board");
		String boardOwnerNameFromResponse = responseGetBoardInviteeInfo.extract().path("owner.ownerFirstName");
		Verify.verifyEquals(boardOwnerNameFromResponse, firstNameOfOwner,
				"verify board owner user id of created board");
		String boardMemberIdFromResponse = responseGetBoardInviteeInfo.extract().path("boardMembers[0].userId");
		Verify.verifyEquals(boardMemberIdFromResponse, userIdOfContributor, "verify board member id");
		String boardMemberFirstNameFromResponse = responseGetBoardInviteeInfo.extract()
				.path("boardMembers[0].firstName");
		Verify.verifyEquals(boardMemberFirstNameFromResponse, firstNameOfContributor, "verify board member name");
		String boardMemberTypeFromResponse = responseGetBoardInviteeInfo.extract().path("boardMembers[0].memberType");
		Verify.verifyEquals(boardMemberTypeFromResponse, "C", "verify board member type");
		String boardMemberStatusFromResponse = responseGetBoardInviteeInfo.extract()
				.path("boardMembers[0].memberStatus");
		Verify.verifyEquals(boardMemberStatusFromResponse, "P", "verify member status");

		FrameworkLogger.logStep("verifyBoardAndInviteeInformationIfGroupInviteCodeIsMadeByMember:-> End");
	}

}
