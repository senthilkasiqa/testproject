/**
 * 
 */
package com.rjil.cloud.tej.api.test.boardinvites;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.DeclineBoardRequestBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.RemoveBoardMembersBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.BoardsDeltaSyncBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 * 
 *         Test class for Leave/Unjoin Board Api
 *
 */
public class LeaveBoardTest extends LeaveBoardBaseScript {
	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify that any valid member of board should be able to leave the board.", groups = {
					TestNgGroups.DEPLOYMENTSANITY })
	public void testLeaveBoardWithValidData() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testLeaveBoardWithValidData-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		ValidatableResponse leaveBoardResponse = triggerPutApiLeaveBoard(boardKey, deviceContributorInfo);
		int httpCode = leaveBoardResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Leave Board Status");
		FrameworkLogger.logStep("testLeaveBoardWithValidData-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify that any valid member of board should be able to leave the board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS, TestNgGroups.QASANITY })
	public void testLeaveBoardWithValidDataTest() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testLeaveBoardWithValidData-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		ValidatableResponse leaveBoardResponse = triggerPutApiLeaveBoard(boardKey, deviceContributorInfo);
		int httpCode = leaveBoardResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP Status Code");

		String ifModifiedSince = System.currentTimeMillis() + "";
		BoardsDeltaSyncBaseScript.getBoardsDeltaSyncService(ifModifiedSince);
		String ifModifiedSince1 = System.currentTimeMillis() + "";
		LeaveBoardBaseScript.leaveBoardService(boardKey);
		BoardsDeltaSyncBaseScript.getBoardsDeltaSyncService(ifModifiedSince1);
		FrameworkLogger.logStep("testLeaveBoardWithValidData-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify that owner of board should be able to leave the board.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyOwnerShouldBeAbleToLeaveBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testLeaveBoardWithValidData-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		ValidatableResponse leaveBoardResponse = triggerPutApiLeaveBoard(boardKey);
		int httpCode = leaveBoardResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP Status Code");
		FrameworkLogger.logStep("testLeaveBoardWithValidData-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the error response if user already left the board tries to leave it again.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyErrorIfOwnerTriesToLeaveBoardAgain()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyErrorIfOwnerTriesToLeaveBoardAgain-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		ValidatableResponse leaveBoardResponse = triggerPutApiLeaveBoard(boardKey);
		int httpCode = leaveBoardResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP Status Code");

		createHeader();
		ValidatableResponse leaveBoardResponse1 = triggerPutApiLeaveBoard(boardKey);
		int httpCode1 = leaveBoardResponse1.extract().statusCode();
		Verify.verifyEquals(httpCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP Status Code");
		String errorCode = leaveBoardResponse1.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0003.getValue(), "Verify Error Code");
		String errorMessage = leaveBoardResponse1.extract().path("error");
		Verify.verifyEquals(errorMessage, "User is not part of Board.", "Verify Error Message");
		FrameworkLogger.logStep("verifyErrorIfOwnerTriesToLeaveBoardAgain-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the response if user who is not a part of board tries to leave the board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyErrorIfUserTriesToLeaveBoardWhoIsNotAPartOfABoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyErrorIfUserTriesToLeaveBoardWhoIsNotAPartOfABoard-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKey, firstNameOfContributor,
				lastNameOfContributor, contactInfoOfContributor, "C");

		ValidatableResponse leaveBoardResponse = triggerPutApiLeaveBoard(boardKey, deviceContributorInfo);
		int httpCode1 = leaveBoardResponse.extract().statusCode();
		Verify.verifyEquals(httpCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP Status Code");
		String errorCode = leaveBoardResponse.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0003.getValue(), "Verify Error Code");
		String errorMessage = leaveBoardResponse.extract().path("error");
		Verify.verifyEquals(errorMessage, "User is not part of Board.", "Verify Error Message");
		FrameworkLogger.logStep("verifyErrorIfUserTriesToLeaveBoardWhoIsNotAPartOfABoard-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify that if owner has already removed the member then that member should not be able to leave the board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyMemberShouldNotBeAbleToLeaveBoardIfRemovedByOwner()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyMemberShouldNotBeAbleToLeaveBoardIfRemovedByOwner-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		RemoveBoardMembersBaseScript.removeBoardMemberService(boardKey, userIdOfContributor);
		ValidatableResponse leaveBoardResponse = triggerPutApiLeaveBoard(boardKey, deviceContributorInfo);
		int httpCode1 = leaveBoardResponse.extract().statusCode();
		Verify.verifyEquals(httpCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP Status Code");
		String errorCode = leaveBoardResponse.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0003.getValue(), "Verify Error Code");
		String errorMessage = leaveBoardResponse.extract().path("error");
		Verify.verifyEquals(errorMessage, "User is not part of Board.", "Verify Error Message");
		FrameworkLogger.logStep("verifyMemberShouldNotBeAbleToLeaveBoardIfRemovedByOwner-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify if user who have decline the request to join the board, he should not be able to leave the board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyMemberShouldNotBeAbleToLeaveBoardIfDeclinedBoardRequest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyMemberShouldNotBeAbleToLeaveBoardIfDeclinedBoardRequest-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Decline Invitation
		DeclineBoardRequestBaseScript.declineInvitationService(invitationCode, deviceContributorInfo);

		ValidatableResponse leaveBoardResponse = triggerPutApiLeaveBoard(boardKey, deviceContributorInfo);
		int httpCode1 = leaveBoardResponse.extract().statusCode();
		Verify.verifyEquals(httpCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP Status Code");
		String errorCode = leaveBoardResponse.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0003.getValue(), "Verify Error Code");
		String errorMessage = leaveBoardResponse.extract().path("error");
		Verify.verifyEquals(errorMessage, "User is not part of Board.", "Verify Error Message");
		FrameworkLogger.logStep("verifyMemberShouldNotBeAbleToLeaveBoardIfDeclinedBoardRequest-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the error code if boardKey in the url is invalid.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void testLeaveBoardIfBoardKeyInUrlIsInvalid()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testLeaveBoardIfBoardKeyInUrlIsInvalid-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		ValidatableResponse leaveBoardResponse = triggerPutApiLeaveBoard("avcasbc", deviceContributorInfo);
		int httpCode = leaveBoardResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP Status Code");
		FrameworkLogger.logStep("testLeaveBoardIfBoardKeyInUrlIsInvalid-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName
			+ " verify the error code if boardKey in the url is missing.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void testLeaveBoardIfBoardKeyInUrlIsMissing()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testLeaveBoardIfBoardKeyInUrlIsMissing-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		ValidatableResponse leaveBoardResponse = triggerPutApiLeaveBoard("", deviceContributorInfo);
		int httpCode = leaveBoardResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP Status Code");
		FrameworkLogger.logStep("testLeaveBoardIfBoardKeyInUrlIsMissing-> End");
	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the error code if deviceKey is missing.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void testLeaveBoardIfDeviceKeyIsMissing()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testLeaveBoardIfDeviceKeyIsMissing-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), "");
		ValidatableResponse leaveBoardResponse = triggerPutApiLeaveBoard(boardKey);
		int httpCode = leaveBoardResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify HTTP Status Code");
		FrameworkLogger.logStep("testLeaveBoardIfDeviceKeyIsMissing-> End");
	}

	@Test(priority = 13, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the error code if xuserId is missing.", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void testLeaveBoardIfUserIdIsMissing() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("testLeaveBoardIfUserIdIsMissing-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		headerMap.put(HeaderParameters.XUSERID.getValue(), "");
		ValidatableResponse leaveBoardResponse = triggerPutApiLeaveBoard(boardKey);
		int httpCode = leaveBoardResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP Status Code");
		FrameworkLogger.logStep("testLeaveBoardIfUserIdIsMissing-> End");
	}
}
