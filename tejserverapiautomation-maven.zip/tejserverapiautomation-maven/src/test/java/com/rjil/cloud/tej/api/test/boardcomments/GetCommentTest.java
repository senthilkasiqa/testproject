package com.rjil.cloud.tej.api.test.boardcomments;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.boardcomments.GetCommentsBaseScript;
import com.rjil.cloud.tej.apihelpers.boardcomments.PostCommentBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.DeclineBoardRequestBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.RemoveBoardMembersBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

import bsh.util.Util;

/**
 * @author Prateek
 * 
 *         Test class for Get comment api
 *
 */
public class GetCommentTest extends GetCommentsBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify get comments for board api with all valid data", groups = { TestNgGroups.DEPLOYMENTSANITY })
	public void getCommnetsWithValidData() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getCommnetsWithValidData:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		String ownerComment1 = "Baahubali - Awesome movie....";
		ValidatableResponse ownerCommentResponse1 = PostCommentBaseScript.postCommentServiceMethod(ownerComment1,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse1.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Post Comment Response");
		String limit = "5";
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(limit, ifModifiedSince);

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetComments(boardKey);
		//comments[0].profilePhotoPath
		String profilePhotoPath =  response.extract().path("comments[0].profilePhotoPath");
		// "profilePhotoPath": "http://sit-dl.tejdrive.com/boards/members/d604633fbc4c4370a878abe0b53a7520/profilepic",

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Get Comment status");
		FrameworkLogger.logStep("getCommnetsWithValidData:-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify get comments for board api with all valid data", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS, TestNgGroups.QASANITY })
	public void getCommnetsWithValidDataTest() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getCommnetsWithValidData:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		for (int i = 0; i < 10; i++) {
			String ownerComment1 = "Baahubali " + i + ":- Awesome movie....";
			ValidatableResponse ownerCommentResponse1 = PostCommentBaseScript.postCommentServiceMethod(ownerComment1,
					boardKey);
			Verify.verifyEquals(ownerCommentResponse1.extract().statusCode(),
					ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		}
		String limit = "5";
		createHeader(limit);

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetComments(boardKey);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Httpt Status");

		int totalCommentCount = response.extract().path("total");
		Verify.verifyEquals(totalCommentCount, 10, "Verify total comment count");
		response.body(JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/getCommentTest-Schema.json"));
		FrameworkLogger.logStep("getCommnetsWithValidData:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify get comments for board api without limit in header", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void getCommnetsWithoutLimit() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getCommnetsWithValidData:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Owner post comment on Board
		String ownerComment1 = "Relinace jio infocomm";
		ValidatableResponse ownerCommentResponse1 = PostCommentBaseScript.postCommentServiceMethod(ownerComment1,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse1.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Owner post comment on Board
		String ownerComment2 = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse2 = PostCommentBaseScript.postCommentServiceMethod(ownerComment2,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse2.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Owner post comment on Board
		String ownerComment3 = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse3 = PostCommentBaseScript.postCommentServiceMethod(ownerComment3,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse3.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Contributor post comment
		for (int i = 1; i <= 8; i++) {
			String contributorComment = "Baahubali 1:-" + System.currentTimeMillis();
			ValidatableResponse contributorCommentResponse = PostCommentBaseScript
					.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
			Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
					ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		}
		String limit = "5";
		createHeader(limit);
		headerMap.remove(HeaderParameters.LIMIT.getValue());

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetComments(boardKey);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Httpt Status");

		int totalCommentCount = response.extract().path("total");
		Verify.verifyEquals(totalCommentCount, 12, "Verify total comment count");
		response.body(JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/getCommentTest-Schema.json"));
		FrameworkLogger.logStep("getCommnetsWithValidData:-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify get comments for board api for a user who is contributor of the  board", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getCommnetsOfAUserWhoIsContributorOftheBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getCommnetsWithValidData:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String limit = "5";
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(limit, ifModifiedSince);

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetComments(boardKey, deviceContributorInfo);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Httpt Status");
		response.body(JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/getCommentTest-Schema.json"));
		FrameworkLogger.logStep("getCommnetsWithValidData:-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify get comments for board api for a user who is removed by the owner", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getCommnetsOfUserWhoIsRemovedByOwner()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getCommnetsOfUserWhoIsRemovedByOwner:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		RemoveBoardMembersBaseScript.removeBoardMemberService(boardKey, userIdOfContributor);
		String limit = "5";
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(limit, ifModifiedSince);
		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetComments(boardKey, deviceContributorInfo);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");
		FrameworkLogger.logStep("getCommnetsOfUserWhoIsRemovedByOwner:-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify get comments for board api for a user who declined board request", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getCommnetsOfUserWhoDeclineBoardRequest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getCommnetsOfUserWhoDeclineBoardRequest:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		ValidatableResponse response1 = DeclineBoardRequestBaseScript.declineInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");
		String limit = "5";
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(limit, ifModifiedSince);

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetComments(boardKey, deviceContributorInfo);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");
		FrameworkLogger.logStep("getCommnetsOfUserWhoDeclineBoardRequest:-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify get comments for board api for a user who leaves a board", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void getCommnetsOfUserWhoLeavesBoard() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getCommnetsOfUserWhoLeavesBoard:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// ValidatableResponse
		// response1=DeclineBoardRequestTest.declineInvitationService(invitationCode,
		// deviceContributorInfo);
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		LeaveBoardBaseScript.leaveBoardService(boardKey, deviceContributorInfo);
		String limit = "5";
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(limit, ifModifiedSince);

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetComments(boardKey, deviceContributorInfo);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");
		FrameworkLogger.logStep("getCommnetsOfUserWhoLeavesBoard:-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify get comments for board api with missing user id", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void getCommentsWithMissingUserId() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getCommentsWithMissingUserId:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String limit = "5";
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(limit, ifModifiedSince);
		headerMap.remove(HeaderParameters.XUSERID.getValue());

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetComments(boardKey);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");
		
		/*"code": "SCLN0050",
	    "error": "User Id is null/empty or invalid in the request"*/
		
		FrameworkLogger.logStep("getCommentsWithMissingUserId:-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify get comments for board api with invalid user id", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void getCommentsWithInvalidUserId() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getCommentsWithMissingUserId:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String limit = "5";
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(limit, ifModifiedSince);
		headerMap.put(HeaderParameters.XUSERID.getValue(), "kbcac");

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetComments(boardKey);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify Httpt Status");
		FrameworkLogger.logStep("getCommentsWithMissingUserId:-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify get comments for board api with missing board key", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void getCommentsWithMissingBoardKey() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getCommentsWithMissingBoardKey:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String limit = "5";
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(limit, ifModifiedSince);

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetComments("");

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");

		String errorCode = response.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Error Code");

		String errorMessage = response.extract().path("error");
		Verify.verifyEquals(errorMessage, "Board User Relation Missing.", "Verify Error Message");
		FrameworkLogger.logStep("getCommentsWithMissingBoardKey:-> End");
	}

	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify get comments for board api with invalid board key", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void getCommentsWithInvalidBoardKey() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getCommentsWithInvalidBoardKey:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String limit = "5";
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(limit, ifModifiedSince);

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetComments("KBX");

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");

		String errorCode = response.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Error Code");

		String errorMessage = response.extract().path("error");
		Verify.verifyEquals(errorMessage, "Board User Relation Missing.", "Verify Error Message");
		FrameworkLogger.logStep("getCommentsWithInvalidBoardKey:-> End");
	}
}
