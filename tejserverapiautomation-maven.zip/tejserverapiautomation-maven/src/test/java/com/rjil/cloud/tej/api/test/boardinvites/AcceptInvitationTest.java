package com.rjil.cloud.tej.api.test.boardinvites;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.fileupload.UploadBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class AcceptInvitationTest extends AcceptInvitationBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne if valid user accepts the invitation.(individual invites)", groups = {
					TestNgGroups.DEPLOYMENTSANITY})
	public void acceptIndividualInvitationTestWithValidInvitation()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptIndividualInvitationTestWithValidInvitation-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		String fileName = "Sample.jpg";
		UploadBaseScript.getUploadFileToBoardServiceMethod(fileName, boardKey);

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		FrameworkLogger.logStep("INVITECODE:" + invitationCode);

		FrameworkLogger.logStep("USERID OF SECOND USER " + deviceContributorInfo.get("userId"));
		ValidatableResponse response1 = acceptInvitationService(invitationCode, deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Accept Invite Status");
		FrameworkLogger.logStep("acceptIndividualInvitationTestWithValidInvitation-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne if valid user accepts the invitation.(individual invites)", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS,TestNgGroups.QASANITY })
	public void acceptIndividualInvitationTestWithValidInvitationTest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptIndividualInvitationTestWithValidInvitation-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		String fileName = "Sample.jpg";
		UploadBaseScript.getUploadFileToBoardServiceMethod(fileName, boardKey);

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		FrameworkLogger.logStep("INVITECODE:" + invitationCode);

		FrameworkLogger.logStep("USERID OF SECOND USER " + deviceContributorInfo.get("userId"));

		ValidatableResponse response1 = acceptInvitationService(invitationCode, deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKeyFromResponse = response1.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response1.extract().path("boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		String boardTypeFromResponse = response1.extract().path("boardType");
		Verify.verifyEquals(boardTypeFromResponse, "P", "verify board type of created board");

		String memberTypeFromResponse = response1.extract().path("boardMembers[0].memberType");
		Verify.verifyEquals(memberTypeFromResponse, "C", "verify member type of created board");

		String statusFromResponse = response1.extract().path("status");
		Verify.verifyEquals(statusFromResponse, "A", "verify status of created board");

		int userCountFromResponse = (int) response1.extract().path("usersCount");
		Verify.verifyEquals(userCountFromResponse, 2, "verify usersCount of created board");

		FrameworkLogger.logStep("acceptIndividualInvitationTestWithValidInvitation-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne if invalid user accepts the invitation.(invalid user tries to accept invitation code )", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void acceptIndividualInvitationTestWithInvitationAcceptedByInvalidUser()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptIndividualInvitationTestWithInvitationAcceptedByInvalidUser-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response = triggerPutApiAcceptInvitation(invitationCode);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("acceptIndividualInvitationTestWithInvitationAcceptedByInvalidUser-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne if valid user accepts the invitation.(Group invites)", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void acceptGroupInvitationTestWithValidInvitation()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptGroupInvitationTestWithValidInvitation-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send a group invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("inviteCode");
		ValidatableResponse response = triggerPutApiAcceptInvitation(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKeyFromResponse = response.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response.extract().path("boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		String boardTypeFromResponse = response.extract().path("boardType");
		Verify.verifyEquals(boardTypeFromResponse, "P", "verify board type of created board");

		String memberTypeFromResponse = response.extract().path("boardMembers[0].memberType");
		Verify.verifyEquals(memberTypeFromResponse, "C", "verify member type of created board");

		String statusFromResponse = response.extract().path("status");
		Verify.verifyEquals(statusFromResponse, "A", "verify status of created board");

		int userCountFromResponse = (int) response.extract().path("usersCount");
		Verify.verifyEquals(userCountFromResponse, 2, "verify usersCount of created board");

		int filesCountFromResponse = (int) response.extract().path("filesCount");
		Verify.verifyEquals(filesCountFromResponse, 0, "verify filesCount of created board");

		String createdByFromResponse = response.extract().path("createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");
		FrameworkLogger.logStep("acceptGroupInvitationTestWithValidInvitation-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne if already joined member ( through individual invite ) is trying to accept the invitation. (through individual invite)", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void acceptIndividualInvitationTestWithAlreadyJoinedMemberAcceptingIndividualInvite()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger
				.logStep("acceptIndividualInvitationTestWithAlreadyJoinedMemberAcceptingIndividualInvite-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// join the board
		ValidatableResponse response = triggerPutApiAcceptInvitation(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardNameFromResponse = response.extract().path("boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		int userCountFromResponse = (int) response.extract().path("usersCount");
		Verify.verifyEquals(userCountFromResponse, 2, "verify usersCount of created board");

		String createdByFromResponse = response.extract().path("createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		// now create new invite to same join board to same user
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode1 = responseSendInvite1.extract().path("processed[0].inviteCode");

		// now try to join same board again

		ValidatableResponse response1 = triggerPutApiAcceptInvitation(invitationCode1, deviceContributorInfo);
		int statusCode1 = response1.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("acceptIndividualInvitationTestWithAlreadyJoinedMemberAcceptingIndividualInvite-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne if already joined member ( through group invite ) is trying to accept the invitation. (through group invite)", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void acceptGroupInvitationTestWithAlreadyJoinedMemberAcceptingGroupInvite()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptGroupInvitationTestWithAlreadyJoinedMemberAcceptingGroupInvite-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send a group invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("inviteCode");

		// join the board
		ValidatableResponse response1 = triggerPutApiAcceptInvitation(invitationCode, deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardNameFromResponse = response1.extract().path("boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		int userCountFromResponse = (int) response1.extract().path("usersCount");
		Verify.verifyEquals(userCountFromResponse, 2, "verify usersCount of created board");

		String createdByFromResponse = response1.extract().path("createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		// now create new invite to same join board to same user
		// send a group invitation
		createHeader();
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode1 = responseSendInvite1.extract().path("inviteCode");

		// now try to join same board again
		ValidatableResponse response2 = triggerPutApiAcceptInvitation(invitationCode1, deviceContributorInfo);
		int statusCode1 = response2.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("acceptGroupInvitationTestWithAlreadyJoinedMemberAcceptingGroupInvite-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne if already joined member (individual invite) is trying to accept the invitation. (grp invite)", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void acceptInvitationTestWithAlreadyJoinedMemberthroughIndividualInviteAcceptingGroupInvite()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(
				"acceptInvitationTestWithAlreadyJoinedMemberthroughIndividualInviteAcceptingGroupInvite-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// join the board
		ValidatableResponse response = triggerPutApiAcceptInvitation(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardNameFromResponse = response.extract().path("boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		int userCountFromResponse = (int) response.extract().path("usersCount");
		Verify.verifyEquals(userCountFromResponse, 2, "verify usersCount of created board");

		String createdByFromResponse = response.extract().path("createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		// now create new invite to same join board to same user
		// send a group invitation
		createHeader();
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode1 = responseSendInvite1.extract().path("inviteCode");

		// now try to join same board again
		ValidatableResponse response1 = triggerPutApiAcceptInvitation(invitationCode1, deviceContributorInfo);
		int statusCode1 = response1.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		FrameworkLogger.logStep(
				"acceptInvitationTestWithAlreadyJoinedMemberthroughIndividualInviteAcceptingGroupInvite-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne if already joined member (group invite) is trying to accept the invitation. (individual invite)", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void acceptInvitationTestWithAlreadyJoinedMemberthroughGroupInviteAcceptingIndividualInvite()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(
				"acceptInvitationTestWithAlreadyJoinedMemberthroughGroupInviteAcceptingIndividualInvite-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("inviteCode");

		// join the board
		ValidatableResponse response = triggerPutApiAcceptInvitation(invitationCode, deviceContributorInfo);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardNameFromResponse = response.extract().path("boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		int userCountFromResponse = (int) response.extract().path("usersCount");
		Verify.verifyEquals(userCountFromResponse, 2, "verify usersCount of created board");

		String createdByFromResponse = response.extract().path("createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		// now create new invite to same join board to same user
		// send a group invitation
		createHeader();
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode1 = responseSendInvite1.extract().path("processed[0].inviteCode");

		// now try to join same board again
		ValidatableResponse response1 = triggerPutApiAcceptInvitation(invitationCode1, deviceContributorInfo);
		int statusCode1 = response1.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		FrameworkLogger.logStep(
				"acceptInvitationTestWithAlreadyJoinedMemberthroughGroupInviteAcceptingIndividualInvite-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne if owner tries to accept the invitation through individual invite", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void acceptIndividualInvitationTestWithOwnerAcceptingInvitation()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptIndividualInvitationTestWithOwnerAcceptingInvitation-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendInvitationServiceMethod(boardKey, "Sanj", "K", contactInfoOfContributor, "C");

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		createHeader();
		ValidatableResponse response = triggerPutApiAcceptInvitation(invitationCode);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("acceptIndividualInvitationTestWithOwnerAcceptingInvitation-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName
			+ "Verify the resposne if owner tries to accept the invitation through group invite", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void acceptIndividualInvitationTestWithOwnerAcceptingGroupInvitation()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("acceptIndividualInvitationTestWithOwnerAcceptingGroupInvitation-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send a group invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);

		// get the invitation code
		String invitationCode = responseSendInvite.extract().path("inviteCode");
		createHeader();
		ValidatableResponse response = triggerPutApiAcceptInvitation(invitationCode);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("acceptIndividualInvitationTestWithOwnerAcceptingGroupInvitation-> End");
	}
}
