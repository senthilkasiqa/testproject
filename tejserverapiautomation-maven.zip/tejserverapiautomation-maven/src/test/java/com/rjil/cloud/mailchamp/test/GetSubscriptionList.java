package com.rjil.cloud.mailchamp.test;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.mailchamp.common.helper.GetSubScriptionListBaseClass;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.enums.HeaderParameters;



public class GetSubscriptionList extends GetSubScriptionListBaseClass {

	public ValidatableResponse response;

	
	@Test(description = "TC_15 - To verify if user get list of all subscriptions for a user for all valid parameter, "
			+ "when Subscription type is New, also check for the number of emails getting displayed as per count of New.", 
			groups = {TestNgGroups.REGRESSION })
	public void asubScpNewTest() {
//		String getSubScpNew = getSubscriptionUrlForNew();
//		response = triggerGetApi(getSubScpNew, createHeaderMap());
		
		String baseUrl = getBaseURL();
		Map<String, String> localHeaderMap = createHeaderMap();
		localHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(baseUrl, localHeaderMap); 
		
		int subListStatus = response.extract().statusCode(); // 200
		System.out.println("Status Code for New Subscriptions is:" + subListStatus);
		Assert.assertEquals(subListStatus, 200);

		int newcount = response.extract().path("newCount");
		int emailMetadataList = response.extract().jsonPath().getList("emailMetadataList").size();
		System.out.println("Email in NewCount is:" + newcount);
		System.out.println("Email in New emailmeta is:" + emailMetadataList);
		Assert.assertEquals(newcount, emailMetadataList);
	}

	@Test(description = "TC_16 - To verify if user get list of all subscriptions for a user for all valid parameter, "
			+ "when Subscription type is Inbox, also check for the number of emails getting displayed as per count of Inbox.", 
			groups = {TestNgGroups.REGRESSION })
	public void bsubScpInbox() {
		String baseUrl = getBaseURL();
		Map<String, String> localHeaderMap = createHeaderMap();
		localHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerGetApi(baseUrl, localHeaderMap); 

		int subListStatus = response.extract().statusCode(); // 200
		System.out.println("Status Code for Inbox Subscriptions is:" + subListStatus);
		Assert.assertEquals(subListStatus, 200);

		int inboxCount = response.extract().path("inboxCount");
		int emailMetadataList = response.extract().jsonPath().getList("emailMetadataList").size();
		System.out.println("Email in InboxCount is:" + inboxCount);
		System.out.println("Email in Inbox emailmeta is:" + emailMetadataList);
		Assert.assertEquals(inboxCount, emailMetadataList);
	}

	@Test(description = "TC_17 - To verify if user get list of all subscriptions for a user for all valid parameter, "
			+ "when Subscription type is GroupIt, also check for the number of emails getting displayed as per count of GroupItCount.", 
			groups = {TestNgGroups.REGRESSION })
	public void csubScpGroupIt() {
		String baseUrl = getBaseURL();
		Map<String, String> localHeaderMap = createHeaderMap();
		localHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerGetApi(baseUrl, localHeaderMap); 
		
		int subListStatus = response.extract().statusCode(); // 200
		System.out.println("Status Code for GroupIt Subscriptions is:" + subListStatus);
		Assert.assertEquals(subListStatus, 200);

		int groupItCount = response.extract().path("groupItCount");
		int emailMetadataList = response.extract().jsonPath().getList("emailMetadataList").size();
		System.out.println("Email in GroupIt Count is:" + groupItCount);
		System.out.println("Email in GroupIt emailmeta is:" + emailMetadataList);
		Assert.assertEquals(groupItCount, emailMetadataList);
	}

	@Test(description = "TC_18 - To verify if user get list of all subscriptions for a user for all valid parameter,  "
			+ "when Subscription type is Unsubscribe, also check for the number of emails getting displayed as per count of Unsubscribe.", 
			groups = { TestNgGroups.REGRESSION })
	public void dsubScpUnSubscribe() {
		String baseUrl = getBaseURL();
		Map<String, String> localHeaderMap = createHeaderMap();
		localHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerGetApi(baseUrl, localHeaderMap); 
		
		int subListStatus = response.extract().statusCode(); // 200
		System.out.println("Status Code for Unsubscribe Subscriptions is:" + subListStatus);
		Assert.assertEquals(subListStatus, 200);

		int unSubscCount = response.extract().path("unsubscribeCount");
		int emailMetadataList = response.extract().jsonPath().getList("emailMetadataList").size();
		System.out.println("Email in Unsubscribe Count is:" + unSubscCount);
		System.out.println("Email in Unsubscribe emailmeta is:" + emailMetadataList);
		Assert.assertEquals(unSubscCount, emailMetadataList);
	}
}