package com.rjil.cloud.tej.api.test.boards;

import java.io.IOException;
import java.util.Map;

import org.testng.annotations.Test;

import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class CreateBoardTest extends CreateBoardBaseScript{

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Create a valid board with all valid parameters", groups = {
					TestNgGroups.DEPLOYMENTSANITY})
	public void createBoardTestWithValidValues() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("createBoardTestWithValidValues:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		//headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json").;
		
		setCreateBoardJsonBody();
		//FrameworkLogger.logStep("BoardName:"+NewBoardConstants.getBoardName());
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		

		//FrameworkLogger.logStep("BODY:"+setCreateBoardJsonBody());
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Create Board Status");

		FrameworkLogger.logStep("createBoardTestWithValidValues:-> End");

	}

	
	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Create a valid board with all valid parameters", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS ,TestNgGroups.QASANITY })

	public void createBoardTestWithValidValuesTest() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("createBoardTestWithValidValues:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		//headerMap.put(HeaderParameters.CONTENTTYPE.getValue(), "application/json").;
		
		setCreateBoardJsonBody();
		//FrameworkLogger.logStep("BoardName:"+NewBoardConstants.getBoardName());
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		

		//FrameworkLogger.logStep("BODY:"+setCreateBoardJsonBody());
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		System.out.println();
		String boardKeyFromResponse = response.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response.extract().path("boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		String boardTypeFromResponse = response.extract().path("boardType");
		Verify.verifyEquals(boardTypeFromResponse,"P", "verify board type of created board");

		String memberTypeFromResponse = response.extract().path("userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromResponse,"O", "verify member type of created board");

		String statusFromResponse = response.extract().path("status");
		Verify.verifyEquals(statusFromResponse,"A", "verify status of created board");

		int userCountFromResponse = (int)response.extract().path("usersCount");
		Verify.verifyEquals(userCountFromResponse, 1, "verify usersCount of created board");

		int filesCountFromResponse = (int)response.extract().path("filesCount");
		Verify.verifyEquals(filesCountFromResponse, 0, "verify filesCount of created board");

		int hrefCountFromResponse = (int)response.extract().path("hrefCount");
		Verify.verifyEquals(hrefCountFromResponse, 0, "verify hrefCount of created board");

		int audioCountFromResponse = (int)response.extract().path("audioCount");
		Verify.verifyEquals(audioCountFromResponse, 0, "verify audioCount of created board");

		int videoCountFromResponse = (int)response.extract().path("videoCount");
		Verify.verifyEquals(videoCountFromResponse, 0, "verify videoCount of created board");

		int imageCountFromResponse = (int)response.extract().path("imageCount");
		Verify.verifyEquals(imageCountFromResponse, 0, "verify imageCount of created board");

		int filesSizeFromResponse = (int)response.extract().path("sizeInBytes");
		Verify.verifyEquals(filesSizeFromResponse, 0, "verify filesSize of created board");

		String createdByFromResponse = response.extract().path("createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");
		
		response.body(
				JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/createBoardTest-schema.json"));
		

		FrameworkLogger.logStep("createBoardTestWithValidValues:-> End");

	}


	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if board with same name is created again in same root", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void createBoardTestWithSameNameandSameUser() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("createBoardTestWithSameNameandSameUser:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response1 = triggerPostApiCreateBoard();

		int status = response1.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		ValidatableResponse response2 = triggerPostApiCreateBoard();

		int status2 = response2.extract().statusCode();
		Verify.verifyEquals(status2, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Failure Status");

		FrameworkLogger.logStep("createBoardTestWithSameNameandSameUser:-> End");

	}


	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if board with same name is created again in different root", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void createBoardTestWithSameNameandDifferentUser() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("createBoardTestWithSameNameandDifferentUser:-> Start");

		//LOGIN USING USER1 AND CREATE A BOARD
		
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response1 = triggerPostApiCreateBoard();
		int status1 = response1.extract().statusCode();
		Verify.verifyEquals(status1, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		String boardKeyFromResponse1 = response1.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse1, boardKey1, "verify boardKey of created board");

		String boardNameFromResponse1 = response1.extract().path("boardName");
		Verify.verifyEquals(boardNameFromResponse1, boardName, "verify board name of created board");

		String memberTypeFromResponse1 = response1.extract().path("userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromResponse1,"O", "verify member type of created board");

		String statusFromResponse1 = response1.extract().path("status");
		Verify.verifyEquals(statusFromResponse1,"A", "verify status of created board");

		String createdByFromResponse1 = response1.extract().path("createdBy");
		Verify.verifyEquals(createdByFromResponse1, userId, "verify createdBy of created board");

		//LOGIN USING USER2 AND CREATE SAME BOARD
		
		ValidatableResponse response2 = triggerPostApiCreateBoard(deviceContributorInfo);
		int status2 = response2.extract().statusCode();
		Verify.verifyEquals(status2, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKey2 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		String boardKeyFromResponse2 = response2.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse2, boardKey2, "verify boardKey of created board");

		String boardNameFromResponse2 = response2.extract().path("boardName");
		Verify.verifyEquals(boardNameFromResponse2, boardName, "verify board name of created board");

		String memberTypeFromResponse2 = response2.extract().path("userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromResponse2,"O", "verify member type of created board");

		String statusFromResponse2 = response2.extract().path("status");
		Verify.verifyEquals(statusFromResponse2,"A", "verify status of created board");

		String createdByFromResponse2 = response2.extract().path("createdBy");
		Verify.verifyEquals(createdByFromResponse2, deviceContributorInfo.get("userId"), "verify createdBy of created board");

		response2.body(
				JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/createBoardTest-schema.json"));
		
		FrameworkLogger.logStep("createBoardTestWithSameNameandDifferentUser:-> End");

	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if contributor can create board with same name as owner", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void createBoardTestWithContributorCreatingBoardWithSameNameAsOwnersBoard() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("createBoardTestWithContributorCreatingBoardWithSameNameAsOwnersBoard:-> Start");

		//Step 1: Create board as owner
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKeyFromResponse = response.extract().path("boardKey");

		//Step 2: invite another user to join the board
		//Get details of other user

		String strDeviceId1=serverConfig.get("deviceKey2");
		String email1=apiUrls.get("Email1");
		FrameworkLogger.logStep("EMAIL:"+email1);
		String password1= apiUrls.get("Password1");
		FrameworkLogger.logStep("PASSWORD:"+password1);
		//login using another user
		BaseTestScript base = new BaseTestScript();
		//String strDeviceId1=serverConfig.get("deviceKey2");
		Map<String, String> device1Info= multiUserLogin(strDeviceId1, email1, password1);
	//	String contactInfoOfContributor=device1Info.get("emailId");

		//String contactInfoOfContributor=device1Info.get("emailId");

		String contactInfoOfContributor=deviceContributorInfo.get("emailId");

		ValidatableResponse	responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKeyFromResponse,"Sanj","K",contactInfoOfContributor,"C");
		String invitationCode =responseSendInvite.extract().path("processed[0].inviteCode");


		String contributorParentObjectKey = null;
		//createHeader(deviceContributorInfo);
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,deviceContributorInfo);
		int statusCode = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response2 = triggerPostApiCreateBoard(deviceContributorInfo);

		int status2 = response2.extract().statusCode();
		Verify.verifyEquals(status2, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String statusFromResponse = response2.extract().path("status");
		Verify.verifyEquals(statusFromResponse,"A", "verify status of created board");

		int userCountFromResponse = (int)response2.extract().path("usersCount");
		Verify.verifyEquals(userCountFromResponse, 1, "verify usersCount of created board");
		
		response2.body(
				JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/createBoardTest-schema.json"));
		
		FrameworkLogger.logStep("createBoardTestWithContributorCreatingBoardWithSameNameAsOwnersBoard:-> End");

	}
	
	@Test(priority = 13, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Create board with master categoryKey categoryName pair", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void createBoardTestWithValidCategoryKeyCategoryName() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("createBoardTestWithValidCategoryKeyCategoryName:-> Start");
		String boardName = "Board_"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getCategoryKey(), "ed2dbc53-0256-11e7-a66b-1db1c683fdb4", boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getCategoryName(), "Travel", boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		String boardKeyFromResponse = response.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response.extract().path("boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		String boardTypeFromResponse = response.extract().path("boardType");
		Verify.verifyEquals(boardTypeFromResponse,"P", "verify board type of created board");

		String memberTypeFromResponse = response.extract().path("userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromResponse,"O", "verify member type of created board");

		String statusFromResponse = response.extract().path("status");
		Verify.verifyEquals(statusFromResponse,"A", "verify status of created board");

		int userCountFromResponse = (int)response.extract().path("usersCount");
		Verify.verifyEquals(userCountFromResponse, 1, "verify usersCount of created board");

		int filesCountFromResponse = (int)response.extract().path("filesCount");
		Verify.verifyEquals(filesCountFromResponse, 0, "verify filesCount of created board");

		int hrefCountFromResponse = (int)response.extract().path("hrefCount");
		Verify.verifyEquals(hrefCountFromResponse, 0, "verify hrefCount of created board");

		int audioCountFromResponse = (int)response.extract().path("audioCount");
		Verify.verifyEquals(audioCountFromResponse, 0, "verify audioCount of created board");

		int videoCountFromResponse = (int)response.extract().path("videoCount");
		Verify.verifyEquals(videoCountFromResponse, 0, "verify videoCount of created board");

		int imageCountFromResponse = (int)response.extract().path("imageCount");
		Verify.verifyEquals(imageCountFromResponse, 0, "verify imageCount of created board");

		int filesSizeFromResponse = (int)response.extract().path("sizeInBytes");
		Verify.verifyEquals(filesSizeFromResponse, 0, "verify filesSize of created board");

		String createdByFromResponse = response.extract().path("createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		response.body(
				JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/createBoardTest-schema.json"));
		
		FrameworkLogger.logStep("createBoardTestWithValidCategoryKeyCategoryName:-> End");

	}

	@Test(priority = 14, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":create board with no values for categoryKey and categoryName.", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void createBoardTestWithNoCategoryKeyCategoryName() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("createBoardTestWithNoCategoryKeyCategoryName:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getCategoryKey(), "", boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getCategoryName(), "", boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		String boardKeyFromResponse = response.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response.extract().path("boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		String boardTypeFromResponse = response.extract().path("boardType");
		Verify.verifyEquals(boardTypeFromResponse,"P", "verify board type of created board");

		String memberTypeFromResponse = response.extract().path("userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromResponse,"O", "verify member type of created board");

		String statusFromResponse = response.extract().path("status");
		Verify.verifyEquals(statusFromResponse,"A", "verify status of created board");

		int userCountFromResponse = (int)response.extract().path("usersCount");
		Verify.verifyEquals(userCountFromResponse, 1, "verify usersCount of created board");

		int filesCountFromResponse = (int)response.extract().path("filesCount");
		Verify.verifyEquals(filesCountFromResponse, 0, "verify filesCount of created board");

		int hrefCountFromResponse = (int)response.extract().path("hrefCount");
		Verify.verifyEquals(hrefCountFromResponse, 0, "verify hrefCount of created board");

		int audioCountFromResponse = (int)response.extract().path("audioCount");
		Verify.verifyEquals(audioCountFromResponse, 0, "verify audioCount of created board");

		int videoCountFromResponse = (int)response.extract().path("videoCount");
		Verify.verifyEquals(videoCountFromResponse, 0, "verify videoCount of created board");

		int imageCountFromResponse = (int)response.extract().path("imageCount");
		Verify.verifyEquals(imageCountFromResponse, 0, "verify imageCount of created board");

		int filesSizeFromResponse = (int)response.extract().path("sizeInBytes");
		Verify.verifyEquals(filesSizeFromResponse, 0, "verify filesSize of created board");

		String createdByFromResponse = response.extract().path("createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		response.body(
				JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/createBoardTest-schema.json"));
		
		FrameworkLogger.logStep("createBoardTestWithNoCategoryKeyCategoryName:-> End");

	}
	
	@Test(priority = 15, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":create board with cutomized categoryKey categoryName pair it will not reflect in response", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void createBoardTestWithUserDefinedCategory() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("createBoardTestWithUserDefinedCategory:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getCategoryKey(), "fhajklmnjh", boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getCategoryName(), "BeautyParlourBoard", boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		String boardKeyFromResponse = response.extract().path("boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response.extract().path("boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		String boardTypeFromResponse = response.extract().path("boardType");
		Verify.verifyEquals(boardTypeFromResponse,"P", "verify board type of created board");

		String memberTypeFromResponse = response.extract().path("userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromResponse,"O", "verify member type of created board");

		String statusFromResponse = response.extract().path("status");
		Verify.verifyEquals(statusFromResponse,"A", "verify status of created board");

		int userCountFromResponse = (int)response.extract().path("usersCount");
		Verify.verifyEquals(userCountFromResponse, 1, "verify usersCount of created board");

		int filesCountFromResponse = (int)response.extract().path("filesCount");
		Verify.verifyEquals(filesCountFromResponse, 0, "verify filesCount of created board");

		int hrefCountFromResponse = (int)response.extract().path("hrefCount");
		Verify.verifyEquals(hrefCountFromResponse, 0, "verify hrefCount of created board");

		int audioCountFromResponse = (int)response.extract().path("audioCount");
		Verify.verifyEquals(audioCountFromResponse, 0, "verify audioCount of created board");

		int videoCountFromResponse = (int)response.extract().path("videoCount");
		Verify.verifyEquals(videoCountFromResponse, 0, "verify videoCount of created board");

		int imageCountFromResponse = (int)response.extract().path("imageCount");
		Verify.verifyEquals(imageCountFromResponse, 0, "verify imageCount of created board");

		int filesSizeFromResponse = (int)response.extract().path("sizeInBytes");
		Verify.verifyEquals(filesSizeFromResponse, 0, "verify filesSize of created board");

		String createdByFromResponse = response.extract().path("createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		response.body(
				JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/createBoardTest-schema.json"));
		
		FrameworkLogger.logStep("createBoardTestWithUserDefinedCategory:-> End");

	}

	//ISSUE
	@Test(priority = 16, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":create board with cutomizes categoryName same as master categoryKey", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void createBoardTestWithUserDefinedCategorySameAsMaster() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("recateBoardTestWithUserDefinedCategory:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = setJsonData(NewBoardConstants.getCategoryKey(), "fhajklmnjhjk987543", boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		boardJsonBody = setJsonData(NewBoardConstants.getCategoryName(), "Travel", boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Http Status");

		FrameworkLogger.logStep("createBoardTestWithUserDefinedCategory:-> End");

	}
	
	@Test(priority = 17, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":create board with only Board name in request", groups = {TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void createBoardTestWithOnlyBoardNameInRequest() throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("createBoardTestWithOnlyBoardNameInRequest:-> Start");
		String boardName = "Board___"+Utils.getUniqueId();

		createHeader();
		setCreateBoardJsonBody();
		boardJsonBody = deleteJsonData(boardJsonBody,NewBoardConstants.getCategoryName());
		boardJsonBody = deleteJsonData(boardJsonBody,NewBoardConstants.getCategoryKey());
		boardJsonBody = deleteJsonData(boardJsonBody,NewBoardConstants.getBoardDescription());
		boardJsonBody = setJsonData(NewBoardConstants.getBoardName(), boardName, boardJsonBody);
		ValidatableResponse response = triggerPostApiCreateBoard();

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		response.body(
				JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/createBoardTest-schema.json"));
		
		FrameworkLogger.logStep("createBoardTestWithOnlyBoardNameInRequest:-> End");

	}

}
