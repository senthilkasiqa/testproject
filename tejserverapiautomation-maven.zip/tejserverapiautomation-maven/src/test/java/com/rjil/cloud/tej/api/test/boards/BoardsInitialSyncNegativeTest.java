package com.rjil.cloud.tej.api.test.boards;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boards.BoardsFeedBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class BoardsInitialSyncNegativeTest extends BoardsFeedBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response for invalid X-userId", groups = {  TestNgGroups.REGRESSION,TestNgGroups.BOARDS})
	public void boardsFeedTestWithInvalidXuserId() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithInvalidXuserId:-> Start");
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();
		headerMap.put(HeaderParameters.XUSERID.getValue(), BaseTestScript.getInvalidUserid());
		
		//call boards feed api
		ValidatableResponse response = triggerGetgetBoardsFeed();

		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify Success Status");
				
		FrameworkLogger.logStep("boardsFeedTestWithInvalidXuserId:-> End");
	}
	
	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response for missing X-userId", groups = {  TestNgGroups.REGRESSION,})

	public void boardsFeedTestWithMissingXuserId() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithMissingXuserId:-> Start");
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		//remove the xuserId
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		
		//call boards feed api
		ValidatableResponse response = triggerGetgetBoardsFeed();

		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();
		
		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Http Status");
		
				
		FrameworkLogger.logStep("boardsFeedTestWithMissingXuserId:-> End");
	}
	
	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response for invalid url", groups = {  TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithInvalidUrl() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithInvalidUrl:-> Start");
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		//call boards feed api
		ValidatableResponse response = triggerGetgetBoardsFeed("boardFeedInvalidUrl","0","hgyu");

		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE500.getValue(), "Verify Success Status");
//expected: BRSOM0089				
//		"code":"BRSOM0118","error":"Missing/Invalid Value in Offset."
//"code":"BRSOM0119","error":"Missing/Invalid Value in PageSize."
		
		FrameworkLogger.logStep("boardsFeedTestWithInvalidUrl:-> End");
	}
	
	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response for invalid X-DeviceKey", groups = {  TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithInvalidXDeviceKey() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithInvalidXDeviceKey:-> Start");
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), "asfbkjasbf");
		
		//call boards feed api
		ValidatableResponse response = triggerGetgetBoardsFeed();

		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		

		FrameworkLogger.logStep("boardsFeedTestWithInvalidXDeviceKey:-> End");
	}
	
	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify the response for missing X-DeviceKey", groups = {  TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithMissingXDeviceKey() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithMissingXDeviceKey:-> Start");
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		//remove the xuserId
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		
		//call boards feed api
		ValidatableResponse response = triggerGetgetBoardsFeed();

		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("boardsFeedTestWithMissingXDeviceKey:-> End");
	}
	
	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify board feed api with valid page and invalid limit", groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithValidPageAndInvalidLimit() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithValidPageAndInvalidLimit:-> Start");
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		//call boards feed api
		ValidatableResponse response = triggerGetgetBoardsFeed("boardFeedInvalidUrl","0","avhdjd");

		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE500.getValue(), "Verify Success Status");
				
		FrameworkLogger.logStep("boardsFeedTestWithValidPageAndInvalidLimit:-> End");
	}
	
	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify board feed api with invalid page and valid limit", groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithInvalidPageAndValidLimit() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithInvalidPageAndValidLimit:-> Start");
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		//call boards feed api
		ValidatableResponse response = triggerGetgetBoardsFeed("boardFeedInvalidUrl","kjsbf","10");

		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE500.getValue(), "Verify Success Status");
				
		FrameworkLogger.logStep("boardsFeedTestWithInvalidPageAndValidLimit:-> End");
	}
	
	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify board feed api with invalid page and valid limit", groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithInvalidPageAndInvalidLimit() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithInvalidPageAndInvalidLimit:-> Start");
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		//call boards feed api
		ValidatableResponse response = triggerGetgetBoardsFeed("boardFeedInvalidUrl","kjsbf","skkjfb");

		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE500.getValue(), "Verify Success Status");
				
		FrameworkLogger.logStep("boardsFeedTestWithInvalidPageAndInvalidLimit:-> End");
	}
	
}
