package com.rjil.cloud.mailchamp.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.mailchamp.common.helper.ValidateUserBaseClass;

public class ValidateUserTest extends ValidateUserBaseClass{
	
public ValidatableResponse response;
	
	@Test
	(description = "TC_04 - To verify VALIDATE USER API, for all valid details.",
			groups = {"SANITY", "REGRESSION"})
		public void valiadateUserStatusCode() 	{
		response = triggerGetApi(getValidateUserUrl(),createHeaderMap());

		int intvalidateStatus = response.extract().statusCode();	//200
		System.out.println("Status Code is :" +intvalidateStatus);
		Assert.assertEquals(intvalidateStatus, 204);
}
}