package com.rjil.cloud.tej.api.test.boards;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.BoardsDeltaSyncBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardHyperlinkBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class BoardsDeltaSyncTest extends BoardsDeltaSyncBaseScript {

	private String boardKey = null;
	private String boardName = null;

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that all newly created boards after 'if modified since' value, should be there in the response. (only one should be there)", groups = {
					TestNgGroups.DEPLOYMENTSANITY })
	public void BoardsDeltaSyncTestForNewlyCreatedBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" BoardsDeltaSyncTestForNewlyCreatedBoard:-> Start");

		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(ifModifiedSince);
		ValidatableResponse responseDeltaSync = triggerGetBoardsDeltaSync();
		Long lastSyncDate = responseDeltaSync.extract().path("lastSyncDate");
		
		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(Long.toString(lastSyncDate));
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Board Delta Sync Status");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForNewlyCreatedBoard:-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that all newly created boards after 'if modified since' value, should be there in the response. (only one should be there)", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS, TestNgGroups.QASANITY })
	public void BoardsDeltaSyncTestForNewlyCreatedBoardTest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" BoardsDeltaSyncTestForNewlyCreatedBoard:-> Start");

		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(ifModifiedSince);
		ValidatableResponse responseDeltaSync = triggerGetBoardsDeltaSync();

		Long lastSyncDate = responseDeltaSync.extract().path("lastSyncDate");
		// If-Modified-since header is set to currentTime.

		// String ifModifiedSince = System.currentTimeMillis()+"";

		// createHeader(ifModifiedSince);
		// Thread.sleep(10000);
		// Thread.sleep(3000);
		// Now create a new board

		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(Long.toString(lastSyncDate));
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKeyFromResponse = response.extract().path("boards[0].boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response.extract().path("boards[0].boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		String boardTypeFromResponse = response.extract().path("boards[0].boardType");
		Verify.verifyEquals(boardTypeFromResponse, "P", "verify board type of created board");

		String memberTypeFromResponse = response.extract().path("boards[0].userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromResponse, "O", "verify member type of created board");

		String statusFromResponse = response.extract().path("boards[0].status");
		Verify.verifyEquals(statusFromResponse, "A", "verify status of created board");

		int userCountFromResponse = (int) response.extract().path("boards[0].usersCount");
		Verify.verifyEquals(userCountFromResponse, 1, "verify usersCount of created board");

		int filesCountFromResponse = (int) response.extract().path("boards[0].filesCount");
		Verify.verifyEquals(filesCountFromResponse, 0, "verify filesCount of created board");

		int hrefCountFromResponse = (int) response.extract().path("boards[0].hrefCount");
		Verify.verifyEquals(hrefCountFromResponse, 0, "verify hrefCount of created board");

		int audioCountFromResponse = (int) response.extract().path("boards[0].audioCount");
		Verify.verifyEquals(audioCountFromResponse, 0, "verify audioCount of created board");

		int videoCountFromResponse = (int) response.extract().path("boards[0].videoCount");
		Verify.verifyEquals(videoCountFromResponse, 0, "verify videoCount of created board");

		int imageCountFromResponse = (int) response.extract().path("boards[0].imageCount");
		Verify.verifyEquals(imageCountFromResponse, 0, "verify imageCount of created board");

		int filesSizeFromResponse = (int) response.extract().path("boards[0].sizeInBytes");
		Verify.verifyEquals(filesSizeFromResponse, 0, "verify filesSize of created board");

		String createdByFromResponse = response.extract().path("boards[0].createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		// Verify that there is only one board in the response
		int boardsSize = response.extract().jsonPath().getList("boards").size();
		Verify.verifyEquals(boardsSize, 1, "verify No. of boards in the response");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForNewlyCreatedBoard:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that board created and then hyperlink created in it, that board and hyperlink should be there in the response. ", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForNewlyCreatedBoardWithHyperlink()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" BoardsDeltaSyncTestForNewlyCreatedBoardWithHyperlink:-> Start");
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(ifModifiedSince);
		ValidatableResponse responseDeltaSync = triggerGetBoardsDeltaSync();

		Long lastSyncDate = responseDeltaSync.extract().path("lastSyncDate");
		System.out.println("LastSyncDate=" + lastSyncDate);

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// create a hyperlink in above created board.
		String hyperlink = "https://techcrunch.com";
		CreateBoardHyperlinkBaseScript.createBoardHyperlinkServiceMethod(hyperlink, boardKey);

		// get the response from boards delta sync api
		createHeader(Long.toString(lastSyncDate));
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKeyFromResponse = response.extract().path("boards[0].boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response.extract().path("boards[0].boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		String boardTypeFromResponse = response.extract().path("boards[0].boardType");
		Verify.verifyEquals(boardTypeFromResponse, "P", "verify board type of created board");

		String memberTypeFromResponse = response.extract().path("boards[0].userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromResponse, "O", "verify member type of created board");

		String statusFromResponse = response.extract().path("boards[0].status");
		Verify.verifyEquals(statusFromResponse, "A", "verify status of created board");

		int userCountFromResponse = (int) response.extract().path("boards[0].usersCount");
		Verify.verifyEquals(userCountFromResponse, 1, "verify usersCount of created board");

		int filesCountFromResponse = (int) response.extract().path("boards[0].filesCount");
		Verify.verifyEquals(filesCountFromResponse, 1, "verify filesCount of created board");

		int hrefCountFromResponse = (int) response.extract().path("boards[0].hrefCount");
		Verify.verifyEquals(hrefCountFromResponse, 1, "verify hrefCount of created board");

		int audioCountFromResponse = (int) response.extract().path("boards[0].audioCount");
		Verify.verifyEquals(audioCountFromResponse, 0, "verify audioCount of created board");

		int videoCountFromResponse = (int) response.extract().path("boards[0].videoCount");
		Verify.verifyEquals(videoCountFromResponse, 0, "verify videoCount of created board");

		int imageCountFromResponse = (int) response.extract().path("boards[0].imageCount");
		Verify.verifyEquals(imageCountFromResponse, 0, "verify imageCount of created board");

		int filesSizeFromResponse = (int) response.extract().path("boards[0].sizeInBytes");
		Verify.verifyEquals(filesSizeFromResponse, 0, "verify filesSize of created board");

		String createdByFromResponse = response.extract().path("boards[0].createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		// Verify that there is only one board in the response

		int boardsSize = response.extract().jsonPath().getList("boards").size();
		Verify.verifyEquals(boardsSize, 1, "verify No. of boards in the response");

		String ifModifiedSince1 = System.currentTimeMillis() + "";
		FrameworkLogger.logStep("TIME:" + ifModifiedSince1);

		FrameworkLogger.logStep("BoardsDeltaSyncTestForNewlyCreatedBoardWithHyperlink:-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that board created should be there in the response, if it was there earlier and hyperlink is added into it after 1 st delta sync", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForExistingBoardWithNewHyperlink()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" BoardsDeltaSyncTestForExistingBoardWithNewHyperlink:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(ifModifiedSince);
		ValidatableResponse responseDeltaSync = triggerGetBoardsDeltaSync();
		Long lastSyncDate = responseDeltaSync.extract().path("lastSyncDate");

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		Thread.sleep(5000);
		createHeader(Long.toString(lastSyncDate));

		ValidatableResponse response1 = triggerGetBoardsDeltaSync();
		int statusCode1 = response1.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKeyFromResponse = response1.extract().path("boards[0].boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response1.extract().path("boards[0].boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		int hrefCountFromResponse = (int) response1.extract().path("boards[0].hrefCount");
		Verify.verifyEquals(hrefCountFromResponse, 0, "verify hrefCount of created board");

		// Verify that there is only one board in the response

		int boardsSize = response1.extract().jsonPath().getList("boards").size();
		Verify.verifyEquals(boardsSize, 1, "verify No. of boards in the response");

		createHeader(Long.toString(lastSyncDate));

		// Now create a hyperlink in above created board.
		String hyperlink = "https://techcrunch.com";
		ValidatableResponse hrefResponse = CreateBoardHyperlinkBaseScript.createBoardHyperlinkServiceMethod(hyperlink,
				boardKey);
		String hrefKey = hrefResponse.extract().path("objectKey");
		String hrefName = hrefResponse.extract().path("objectName");
		String hrefUrl = hrefResponse.extract().path("url");

		// get the response from boards delta sync api
		Thread.sleep(5000);
		createHeader(Long.toString(lastSyncDate));
		ValidatableResponse response2 = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode2 = response2.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode2, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKeyFromResponse2 = response2.extract().path("boards[0].boardKey");
		Verify.verifyEquals(boardKeyFromResponse2, boardKey, "verify boardKey of created board");

		String boardNameFromResponse2 = response2.extract().path("boards[0].boardName");
		Verify.verifyEquals(boardNameFromResponse2, boardName, "verify board name of created board");

		int hrefCountFromResponse2 = (int) response2.extract().path("boards[0].hrefCount");
		Verify.verifyEquals(hrefCountFromResponse2, 1, "verify hrefCount of created board");

		// Verify that there is only one board in the response
		int boardsSize2 = response2.extract().jsonPath().getList("boards").size();
		Verify.verifyEquals(boardsSize2, 1, "verify No. of boards in the response");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForExistingBoardWithNewHyperlink:-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that board created should not be there in the response, if it was there earlier and nothing is updated in the board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForAlreadySyncedBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" BoardsDeltaSyncTestForAlreadySyncedBoard:-> Start");

		// If-Modified-since header is set to currentTime.

		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(ifModifiedSince);
		ValidatableResponse responseDeltaSync = triggerGetBoardsDeltaSync();

		Long lastSyncDate = responseDeltaSync.extract().path("lastSyncDate");

		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		// BoardsDeltaSyncBaseScript.getBoardsDeltaSyncService(ifModifiedSince);
		Thread.sleep(5000);
		createHeader(Long.toString(lastSyncDate));
		ValidatableResponse response1 = triggerGetBoardsDeltaSync();
		int statusCode1 = response1.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKeyFromResponse = response1.extract().path("boards[0].boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response1.extract().path("boards[0].boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		int hrefCountFromResponse = (int) response1.extract().path("boards[0].hrefCount");
		Verify.verifyEquals(hrefCountFromResponse, 0, "verify hrefCount of created board");

		// Verify that there is only one board in the response

		int boardsSize = response1.extract().jsonPath().getList("boards").size();
		Verify.verifyEquals(boardsSize, 1, "verify No. of boards in the response");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince2 = System.currentTimeMillis() + "";
		Thread.sleep(5000);

		// get the response from boards delta sync api
		createHeader(ifModifiedSince2);
		ValidatableResponse response2 = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode2 = response2.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode2, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Verify that there should not be any board in the response
		Verify.verifyEquals(response2.toString().contains("boards"), false, "verify No. of boards in the response");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForAlreadySyncedBoard:-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that all boards joined by new contributor after 'if modified since' value, should be there in the response.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForBoardsJoinedByContributor()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" BoardsDeltaSyncTestForBoardsJoinedByContributor:-> Start");

		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(ifModifiedSince);
		ValidatableResponse responseDeltaSync = triggerGetBoardsDeltaSync();
		Long lastSyncDate = responseDeltaSync.extract().path("lastSyncDate");

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		Thread.sleep(5000);
		createHeader(Long.toString(lastSyncDate));
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKeyFromResponse = response.extract().path("boards[0].boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response.extract().path("boards[0].boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		String boardTypeFromResponse = response.extract().path("boards[0].boardType");
		Verify.verifyEquals(boardTypeFromResponse, "P", "verify board type of created board");

		String memberTypeFromResponse = response.extract().path("boards[0].userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromResponse, "O", "verify member type of created board");

		String statusFromResponse = response.extract().path("boards[0].status");
		Verify.verifyEquals(statusFromResponse, "A", "verify status of created board");

		int userCountFromResponse = (int) response.extract().path("boards[0].usersCount");
		Verify.verifyEquals(userCountFromResponse, 1, "verify usersCount of created board");

		int filesCountFromResponse = (int) response.extract().path("boards[0].filesCount");
		Verify.verifyEquals(filesCountFromResponse, 0, "verify filesCount of created board");

		int hrefCountFromResponse = (int) response.extract().path("boards[0].hrefCount");
		Verify.verifyEquals(hrefCountFromResponse, 0, "verify hrefCount of created board");

		int audioCountFromResponse = (int) response.extract().path("boards[0].audioCount");
		Verify.verifyEquals(audioCountFromResponse, 0, "verify audioCount of created board");

		int videoCountFromResponse = (int) response.extract().path("boards[0].videoCount");
		Verify.verifyEquals(videoCountFromResponse, 0, "verify videoCount of created board");

		int imageCountFromResponse = (int) response.extract().path("boards[0].imageCount");
		Verify.verifyEquals(imageCountFromResponse, 0, "verify imageCount of created board");

		int filesSizeFromResponse = (int) response.extract().path("boards[0].sizeInBytes");
		Verify.verifyEquals(filesSizeFromResponse, 0, "verify filesSize of created board");

		String createdByFromResponse = response.extract().path("boards[0].createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		// Verify that there is only one board in the response

		int boardsSize = response.extract().jsonPath().getList("boards").size();
		Verify.verifyEquals(boardsSize, 1, "verify No. of boards in the response");

		String ifModifiedSinceAgain = System.currentTimeMillis() + "";
		createHeader(ifModifiedSinceAgain);

		// 4. login as other user and accept the board invite request

		String ifModifiedSince2 = System.currentTimeMillis() + "";
		Thread.sleep(5000);

		// ValidatableResponse
		// responseSendInvite=SendResendInvitationBaseScript.sendResendInvitationServiceMethod(deviceOwnerInfo,boardKey);
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: Other user accepts the invitation and becomes contributor of
		// the board.
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int status = responseAccept.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// 5. login as contributor and call delta sync api
		Thread.sleep(5000);
		ValidatableResponse responseAgain = BoardsDeltaSyncBaseScript.getBoardsDeltaSyncService(ifModifiedSince2,
				deviceContributorInfo);
		int statusCodeDeltaSync = responseAgain.extract().statusCode();
		Verify.verifyEquals(statusCodeDeltaSync, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// There should be a single board in this response
		String boardKeyFromContributorResponse = responseAgain.extract().path("boards[0].boardKey");
		Verify.verifyEquals(boardKeyFromContributorResponse, boardKey, "verify boardKey of created board");

		String boardNameFromContributorResponse = responseAgain.extract().path("boards[0].boardName");
		Verify.verifyEquals(boardNameFromContributorResponse, boardName, "verify board name of created board");

		String boardTypeFromContributorResponse = responseAgain.extract().path("boards[0].boardType");
		Verify.verifyEquals(boardTypeFromContributorResponse, "P", "verify board type of created board");

		String memberTypeFromContributorResponse = responseAgain.extract()
				.path("boards[0].userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromContributorResponse, "C", "verify member type of created board");

		String statusFromContributorResponse = responseAgain.extract().path("boards[0].status");
		Verify.verifyEquals(statusFromContributorResponse, "A", "verify status of created board");

		int userCountFromContributorResponse = (int) responseAgain.extract().path("boards[0].usersCount");
		Verify.verifyEquals(userCountFromContributorResponse, 2, "verify usersCount of created board");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForBoardsJoinedByContributor:-> End");
	}

	// Need to check
	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that all boards joined by new contributor after 'if modified since' value, should be there in the response.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForBoardsJoinedByContributorInOwnersResponse()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" BoardsDeltaSyncTestForBoardsJoinedByContributorInOwnersResponse:-> Start");

		// If-Modified-since header is set to currentTime.
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(ifModifiedSince);
		ValidatableResponse responseDeltaSync = triggerGetBoardsDeltaSync();

		Long lastSyncDate = responseDeltaSync.extract().path("lastSyncDate");

		// Now create a new board
		 String boardName = "Board___"+Utils.getUniqueId();
		 CreateBoardBaseScript.createBoardServiceMethod(boardName); 
		 String boardKey=repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		 

		// get the response from boards delta sync api
		Thread.sleep(20000);
		createHeader(Long.toString(lastSyncDate));
		ValidatableResponse response = triggerGetBoardsDeltaSync();

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKeyFromResponse = response.extract().path("boards[0].boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response.extract().path("boards[0].boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		String boardTypeFromResponse = response.extract().path("boards[0].boardType");
		Verify.verifyEquals(boardTypeFromResponse, "P", "verify board type of created board");

		String memberTypeFromResponse = response.extract().path("boards[0].userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromResponse, "O", "verify member type of created board");

		String statusFromResponse = response.extract().path("boards[0].status");
		Verify.verifyEquals(statusFromResponse, "A", "verify status of created board");

		int userCountFromResponse = (int) response.extract().path("boards[0].usersCount");
		Verify.verifyEquals(userCountFromResponse, 1, "verify usersCount of created board");

		int filesCountFromResponse = (int) response.extract().path("boards[0].filesCount");
		Verify.verifyEquals(filesCountFromResponse, 0, "verify filesCount of created board");

		int hrefCountFromResponse = (int) response.extract().path("boards[0].hrefCount");
		Verify.verifyEquals(hrefCountFromResponse, 0, "verify hrefCount of created board");

		int audioCountFromResponse = (int) response.extract().path("boards[0].audioCount");
		Verify.verifyEquals(audioCountFromResponse, 0, "verify audioCount of created board");

		int videoCountFromResponse = (int) response.extract().path("boards[0].videoCount");
		Verify.verifyEquals(videoCountFromResponse, 0, "verify videoCount of created board");

		int imageCountFromResponse = (int) response.extract().path("boards[0].imageCount");
		Verify.verifyEquals(imageCountFromResponse, 0, "verify imageCount of created board");

		int filesSizeFromResponse = (int) response.extract().path("boards[0].sizeInBytes");
		Verify.verifyEquals(filesSizeFromResponse, 0, "verify filesSize of created board");

		String createdByFromResponse = response.extract().path("boards[0].createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		// Verify that there is only one board in the response

		int boardsSize = response.extract().jsonPath().getList("boards").size();
		Verify.verifyEquals(boardsSize, 1, "verify No. of boards in the response");
		String ifModifiedSinceAgain = System.currentTimeMillis() + "";

		// Thread.sleep(10000);
		createHeader(ifModifiedSinceAgain);

		// 4. login as other user and accept the board invite request

		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Step 3: Other user accepts the invitation and becomes contributor of
		// the board.

		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// now as a Owner, call delta sync api

		createHeader();
		ValidatableResponse responseDelta = BoardsDeltaSyncBaseScript
				.getBoardsDeltaSyncService(Long.toString(lastSyncDate));
		int statusCodeDeltaSync = responseDelta.extract().statusCode();
		Verify.verifyEquals(statusCodeDeltaSync, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// There should be a single board in this response

		String boardKeyFromContributorResponse = responseDelta.extract().path("boards[0].boardKey");
		Verify.verifyEquals(boardKeyFromContributorResponse, boardKey, "verify boardKey of created board");

		String boardNameFromContributorResponse = responseDelta.extract().path("boards[0].boardName");
		Verify.verifyEquals(boardNameFromContributorResponse, boardName, "verify board name of created board");

		String boardTypeFromContributorResponse = responseDelta.extract().path("boards[0].boardType");
		Verify.verifyEquals(boardTypeFromContributorResponse, "P", "verify board type of created board");

		String memberTypeFromContributorResponse = responseDelta.extract()
				.path("boards[0].userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromContributorResponse, "O", "verify member type of created board");

		String statusFromContributorResponse = responseDelta.extract().path("boards[0].status");
		Verify.verifyEquals(statusFromContributorResponse, "A", "verify status of created board");

		int userCountFromContributorResponse = (int) responseDelta.extract().path("boards[0].usersCount");
		Verify.verifyEquals(userCountFromContributorResponse, 2, "verify usersCount of created board");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForBoardsJoinedByContributorInOwnersResponse:-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify board delta sync with valid page and limit", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForNewlyCreatedBoardWithValidPageAndLimit()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" BoardsDeltaSyncTestForNewlyCreatedBoardWithValidPageAndLimit:-> Start");

		String page = "1";
		String limit = "2";
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(ifModifiedSince);
		ValidatableResponse responseDeltaSync = triggerGetBoardsDeltaSync();
		Long lastSyncDate = responseDeltaSync.extract().path("lastSyncDate");
		
		// Now create a new board
		for (int i = 0; i <= 22; i++) {
			String boardName = "Board___" + Utils.getUniqueId();
			CreateBoardBaseScript.createBoardServiceMethod(boardName);
			boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		}
		
		// get the response from boards delta sync api
		createHeader(Long.toString(lastSyncDate));
		ValidatableResponse response = triggerGetBoardsDeltaSync("boardDeltaSyncUrlWithPageAndLimit", page, limit);

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

//		String boardKeyFromResponse = response.extract().path("boards[0].boardKey");
//		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

//		String boardNameFromResponse = response.extract().path("boards[0].boardName");
//		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		String boardTypeFromResponse = response.extract().path("boards[0].boardType");
		Verify.verifyEquals(boardTypeFromResponse, "P", "verify board type of created board");

		String memberTypeFromResponse = response.extract().path("boards[0].userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromResponse, "O", "verify member type of created board");

		String statusFromResponse = response.extract().path("boards[0].status");
		Verify.verifyEquals(statusFromResponse, "A", "verify status of created board");

		int userCountFromResponse = (int) response.extract().path("boards[0].usersCount");
		Verify.verifyEquals(userCountFromResponse, 1, "verify usersCount of created board");

		int filesCountFromResponse = (int) response.extract().path("boards[0].filesCount");
		Verify.verifyEquals(filesCountFromResponse, 0, "verify filesCount of created board");

		int hrefCountFromResponse = (int) response.extract().path("boards[0].hrefCount");
		Verify.verifyEquals(hrefCountFromResponse, 0, "verify hrefCount of created board");

		int audioCountFromResponse = (int) response.extract().path("boards[0].audioCount");
		Verify.verifyEquals(audioCountFromResponse, 0, "verify audioCount of created board");

		int videoCountFromResponse = (int) response.extract().path("boards[0].videoCount");
		Verify.verifyEquals(videoCountFromResponse, 0, "verify videoCount of created board");

		int imageCountFromResponse = (int) response.extract().path("boards[0].imageCount");
		Verify.verifyEquals(imageCountFromResponse, 0, "verify imageCount of created board");

		int filesSizeFromResponse = (int) response.extract().path("boards[0].sizeInBytes");
		Verify.verifyEquals(filesSizeFromResponse, 0, "verify filesSize of created board");

		String createdByFromResponse = response.extract().path("boards[0].createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		// Verify that there is only one board in the response

		int boardsSize = response.extract().jsonPath().getList("boards").size();
		Verify.verifyEquals(boardsSize, 2, "verify No. of boards in the response");

		FrameworkLogger.logStep("BoardsDeltaSyncTestForNewlyCreatedBoardWithValidPageAndLimit:-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify board delta sync with valid page and limit and verify previuos link in response", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void BoardsDeltaSyncTestForNewlyCreatedBoardWithValidPageAndLimitAndVerifyPreviousLinkInResponse()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(
				" BoardsDeltaSyncTestForNewlyCreatedBoardWithValidPageAndLimitAndVerifyPreviousLinkInResponse:-> Start");

		String page = "1";
		String limit = "2";
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(ifModifiedSince);
		ValidatableResponse responseDeltaSync = triggerGetBoardsDeltaSync();
		Long lastSyncDate = responseDeltaSync.extract().path("lastSyncDate");
		
		// Now create a new board
		for (int i = 0; i < 21; i++) {
			String boardName = "Board___" + Utils.getUniqueId();
			CreateBoardBaseScript.createBoardServiceMethod(boardName);
			boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		}

		// get the response from boards delta sync api
		createHeader(Long.toString(lastSyncDate));
		ValidatableResponse response = triggerGetBoardsDeltaSync("boardDeltaSyncUrlWithPageAndLimit", page, limit);

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// String boardKeyFromResponse =
		// response.extract().path("boards[0].boardKey");
		// Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey
		// of created board");

		/*
		 * String boardNameFromResponse =
		 * response.extract().path("boards[0].boardName");
		 * Verify.verifyEquals(boardNameFromResponse, boardName,
		 * "verify board name of created board");
		 * 
		 * String boardTypeFromResponse =
		 * response.extract().path("boards[0].boardType");
		 * Verify.verifyEquals(boardTypeFromResponse,"P",
		 * "verify board type of created board");
		 * 
		 * String memberTypeFromResponse =
		 * response.extract().path("boards[0].userBoardRelation.memberType");
		 * Verify.verifyEquals(memberTypeFromResponse,"O",
		 * "verify member type of created board");
		 * 
		 * String statusFromResponse =
		 * response.extract().path("boards[0].status");
		 * Verify.verifyEquals(statusFromResponse,"A",
		 * "verify status of created board");
		 * 
		 * int userCountFromResponse =
		 * (int)response.extract().path("boards[0].usersCount");
		 * Verify.verifyEquals(userCountFromResponse, 1,
		 * "verify usersCount of created board");
		 * 
		 * int filesCountFromResponse =
		 * (int)response.extract().path("boards[0].filesCount");
		 * Verify.verifyEquals(filesCountFromResponse, 0,
		 * "verify filesCount of created board");
		 * 
		 * int hrefCountFromResponse =
		 * (int)response.extract().path("boards[0].hrefCount");
		 * Verify.verifyEquals(hrefCountFromResponse, 0,
		 * "verify hrefCount of created board");
		 * 
		 * int audioCountFromResponse =
		 * (int)response.extract().path("boards[0].audioCount");
		 * Verify.verifyEquals(audioCountFromResponse, 0,
		 * "verify audioCount of created board");
		 * 
		 * int videoCountFromResponse =
		 * (int)response.extract().path("boards[0].videoCount");
		 * Verify.verifyEquals(videoCountFromResponse, 0,
		 * "verify videoCount of created board");
		 * 
		 * int imageCountFromResponse =
		 * (int)response.extract().path("boards[0].imageCount");
		 * Verify.verifyEquals(imageCountFromResponse, 0,
		 * "verify imageCount of created board");
		 * 
		 * int filesSizeFromResponse =
		 * (int)response.extract().path("boards[0].sizeInBytes");
		 * Verify.verifyEquals(filesSizeFromResponse, 0,
		 * "verify filesSize of created board");
		 * 
		 * String createdByFromResponse =
		 * response.extract().path("boards[0].createdBy");
		 * Verify.verifyEquals(createdByFromResponse, userId,
		 * "verify createdBy of created board");
		 */

		// Verify that there is only one board in the response

		int boardsSize = response.extract().jsonPath().getList("boards").size();
		Verify.verifyEquals(boardsSize, 2, "verify No. of boards in the response");

		String previousLink = response.extract().path("previousLink");
		Verify.verifyEquals(previousLink, "/boards/sync/delta?page=0&limit=2", "Verify Previous Link");

		FrameworkLogger.logStep(
				"BoardsDeltaSyncTestForNewlyCreatedBoardWithValidPageAndLimitAndVerifyPreviousLinkInResponse:-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify board delta sync with valid page and limit and verify size in response", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void BoardsDeltaSyncTestForNewlyCreatedBoardWithValidPageAndLimitAndVerifyArraySize()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger
				.logStep(" BoardsDeltaSyncTestForNewlyCreatedBoardWithValidPageAndLimitAndVerifyArraySize:-> Start");

		String page = "0";
		String limit = "23";
		String ifModifiedSince = System.currentTimeMillis() + "";
		createHeader(ifModifiedSince);
		ValidatableResponse responseDeltaSync = triggerGetBoardsDeltaSync();
		Long lastSyncDate = responseDeltaSync.extract().path("lastSyncDate");

		// Now create a new board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// get the response from boards delta sync api
		createHeader(Long.toString(lastSyncDate));
		ValidatableResponse response = triggerGetBoardsDeltaSync("boardDeltaSyncUrlWithPageAndLimit", page, limit);

		// get the api response code for boards delta sync api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		String boardKeyFromResponse = response.extract().path("boards[0].boardKey");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "verify boardKey of created board");

		String boardNameFromResponse = response.extract().path("boards[0].boardName");
		Verify.verifyEquals(boardNameFromResponse, boardName, "verify board name of created board");

		String boardTypeFromResponse = response.extract().path("boards[0].boardType");
		Verify.verifyEquals(boardTypeFromResponse, "P", "verify board type of created board");

		String memberTypeFromResponse = response.extract().path("boards[0].userBoardRelation.memberType");
		Verify.verifyEquals(memberTypeFromResponse, "O", "verify member type of created board");

		String statusFromResponse = response.extract().path("boards[0].status");
		Verify.verifyEquals(statusFromResponse, "A", "verify status of created board");

		int userCountFromResponse = (int) response.extract().path("boards[0].usersCount");
		Verify.verifyEquals(userCountFromResponse, 1, "verify usersCount of created board");

		int filesCountFromResponse = (int) response.extract().path("boards[0].filesCount");
		Verify.verifyEquals(filesCountFromResponse, 0, "verify filesCount of created board");

		int hrefCountFromResponse = (int) response.extract().path("boards[0].hrefCount");
		Verify.verifyEquals(hrefCountFromResponse, 0, "verify hrefCount of created board");

		int audioCountFromResponse = (int) response.extract().path("boards[0].audioCount");
		Verify.verifyEquals(audioCountFromResponse, 0, "verify audioCount of created board");

		int videoCountFromResponse = (int) response.extract().path("boards[0].videoCount");
		Verify.verifyEquals(videoCountFromResponse, 0, "verify videoCount of created board");

		int imageCountFromResponse = (int) response.extract().path("boards[0].imageCount");
		Verify.verifyEquals(imageCountFromResponse, 0, "verify imageCount of created board");

		int filesSizeFromResponse = (int) response.extract().path("boards[0].sizeInBytes");
		Verify.verifyEquals(filesSizeFromResponse, 0, "verify filesSize of created board");

		String createdByFromResponse = response.extract().path("boards[0].createdBy");
		Verify.verifyEquals(createdByFromResponse, userId, "verify createdBy of created board");

		// Verify that there is only one board in the response

		int boardsSize = response.extract().jsonPath().getList("boards").size();
		Verify.verifyEquals(boardsSize, 1, "verify No. of boards in the response");

		// Need to write logic for verify array size
		FrameworkLogger
				.logStep("BoardsDeltaSyncTestForNewlyCreatedBoardWithValidPageAndLimitAndVerifyArraySize:-> End");
	}
}
