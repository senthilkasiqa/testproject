package com.rjil.cloud.tej.api.test.boards;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;

import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.BoardsFeedBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardHyperlinkBaseScript;

import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class BoardsInitialSyncTest extends BoardsFeedBaseScript {
	
	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "create a new board and verify that board is reflecting in the response.", groups = { TestNgGroups.DEPLOYMENTSANITY})
	public void boardsFeedTestWithValidRequetToCheckBoardInResponse() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithValidRequetToCheckBoardInResponse:-> Start");
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		Thread.sleep(10000);
		// get the response from get metadata api
		ValidatableResponse response = triggerGetgetBoardsFeed();

		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Boards Feed Status");
		
		FrameworkLogger.logStep("boardsFeedTestWithValidRequetToCheckBoardInResponse:-> End");
	}
	
	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "create a new board and verify that board is reflecting in the response.", groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS,TestNgGroups.QASANITY})
	public void boardsFeedTestWithValidRequetToCheckBoardInResponseTest() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithValidRequetToCheckBoardInResponse:-> Start");
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		Thread.sleep(10000);
		// get the response from get metadata api
		ValidatableResponse response = triggerGetgetBoardsFeed("boardsFeedUrlWithPageAndLimit","0","100");

		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Boards Feed Status");
		int boardIndex = getBoardIndexFromResponse(response, boardKey);
		String boardNameKeyFromResponse = response.extract().path("boards["+boardIndex+"].boardName");
		Verify.verifyEquals(boardNameKeyFromResponse,boardName, "Verify board Name");
		FrameworkLogger.logStep("boardsFeedTestWithValidRequetToCheckBoardInResponse:-> End");
	}
	
	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that 'recentlyUpdatedFiles' has less than or equal to 6 values.", groups = {  TestNgGroups.REGRESSION,TestNgGroups.BOARDS})
	public void boardsFeedTestWithVerifyingCountForRecentlyUpdatedFiles() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithVerifyingCountForRecentlyUpdatedFiles:-> Start");
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		// get the response from get metadata api
		ValidatableResponse response = triggerGetgetBoardsFeed();

		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		
		/*int boardIndex = getBoardIndexFromResponse(response, boardKey);
		String boardNameFromResponse = response.extract().path("boards["+boardIndex+"].boardName");
		String boardStatusFromResponse = response.extract().path("boards["+boardIndex+"].status");
		String boardKeyFromResponse = response.extract().path("boards["+boardIndex+"].boardKey");
		String boardTypeFromResponse = response.extract().path("boards["+boardIndex+"].boardType");
		String boardUserIdFromResponse =response.extract().path( "boards["+boardIndex+"].recentUsers[0].userId");
		FrameworkLogger.logStep("UserId:"+boardUserIdFromResponse);
		String memberTypeFromResponse = response.extract().path("boards["+boardIndex+"].userBoardRelation.memberType");
		int boardUsersCountFromResponse = response.extract().path(("boards["+boardIndex+"].usersCount"));
		
		int boardIndex = getBoardIndexFromResponse(response, boardKey);
		String boardNameFromResponse = "boards["+boardIndex+"].boardName";
		String boardStatusFromResponse = "boards["+boardIndex+"].status";
		String boardKeyFromResponse = "boards["+boardIndex+"].boardKey";
		String boardTypeFromResponse = "boards["+boardIndex+"].boardType";
		String boardUserIdFromResponse = "boards["+boardIndex+"].userId";
		String memberTypeFromResponse = "boards["+boardIndex+"].memberType";
		int boardUsersCountFromResponse = Integer.parseInt(("boards["+boardIndex+"].usersCount"));
		
		Verify.verifyEquals(boardNameFromResponse, boardName , "Verify board Name");
		Verify.verifyEquals(boardStatusFromResponse, "A", "Verify board Status");
		Verify.verifyEquals(boardKeyFromResponse, boardKey, "Verify board Key");
		Verify.verifyEquals(boardTypeFromResponse, "P", "Verify board Type");
		Verify.verifyEquals(boardUserIdFromResponse, userId, "Verify board userId");
		Verify.verifyEquals(memberTypeFromResponse, "O", "Verify board memberType");
		Verify.verifyEquals(boardUsersCountFromResponse, 1, "Verify users count");*/
				
		//int sizeOfRecentlyUpdatedFiles = Integer.parseInt("boards["+boardIndex+"].recentlyUpdatedFiles.size");
		//boolean isSizeValid = ((sizeOfRecentlyUpdatedFiles<=6)&&(sizeOfRecentlyUpdatedFiles>0));
		//Verify.verifyEquals(isSizeValid, true, "Verify size of recently updated files size");
		
		FrameworkLogger.logStep("boardsFeedTestWithVerifyingCountForRecentlyUpdatedFiles:-> End");
	}
	
	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that memberType as 'C' if board is created by cotributor.", groups = {  TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithValidRequestToCheckMemberTypeC() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithValidRequestToCheckMemberTypeC:-> Start");
		
		
		//Step 1: Create a board - by owner
		
		//now create a new board with contributor as a board creator
		//create a board
		String boardNameContributor = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardNameContributor);
		//get the board key for created board
		String boardKeyContributor = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		FrameworkLogger.logStep("Contributor Board Key:"+boardKeyContributor);
		
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKeyContributor, firstNameOfOwner, lastNameOfOwner, contactInfoOfOwner, "C");
	   // ValidatableResponse	responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKeyFromResponse,"Sanj","K","sanjeevanee92kanase@gmail.com","C");
	    String invitationCode1 =responseSendInvite1.extract().path("processed[0].inviteCode");
		
	    ValidatableResponse responseAccept1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode1,deviceContributorInfo);
		int statusCodeAccept1 = responseAccept1.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

	
		//now call boards Feed API
		//createHeader(deviceContributorInfo);

		ValidatableResponse responseBoardsFeed = triggerGetgetBoardsFeed(deviceContributorInfo);
		String boardKeyFromBoardsFeedResponse = responseBoardsFeed.extract().path("boards[0].boardKey");
		FrameworkLogger.logStep("Contributor BoardFeed Key:"+boardKeyFromBoardsFeedResponse);
		// get the api response code for get metadata api
		int statusCodeBoardsFeed = responseBoardsFeed.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCodeBoardsFeed, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		
	    
		/*int boardIndex = getBoardIndexFromResponse(responseBoardsFeed, boardKeyContributor);
		FrameworkLogger.logStep("Index:"+boardIndex);
		String boardNameFromResponse = responseBoardsFeed.extract().path("boards["+boardIndex+"].boardName");
		String boardStatusFromResponse = responseBoardsFeed.extract().path("boards["+boardIndex+"].status");
		//String boardKeyFromResponse = response.extract().path("boards["+boardIndex+"].boardKey");
		String boardTypeFromResponse = responseBoardsFeed.extract().path("boards["+boardIndex+"].boardType");
		String boardUserIdFromResponse =responseBoardsFeed.extract().path( "boards["+boardIndex+"].recentUsers[0].userId");
		FrameworkLogger.logStep("UserId:"+boardUserIdFromResponse);
		String memberTypeFromResponse = responseBoardsFeed.extract().path("boards["+boardIndex+"].userBoardRelation.memberType");
		int boardUsersCountFromResponse = responseBoardsFeed.extract().path(("boards["+boardIndex+"].usersCount"));
		
		
		Verify.verifyEquals(boardNameFromResponse, boardNameContributor , "Verify board Name");
		Verify.verifyEquals(boardStatusFromResponse, "A", "Verify board Status");
		Verify.verifyEquals(boardTypeFromResponse, "P", "Verify board Type");
		Verify.verifyEquals(boardUserIdFromResponse, userIdOfContributor, "Verify board userId");
		Verify.verifyEquals(memberTypeFromResponse, "C", "Verify board memberType");
		Verify.verifyEquals(boardUsersCountFromResponse, 2, "Verify users count");
				*/
		FrameworkLogger.logStep("boardsFeedTestWithValidRequestToCheckMemberTypeC:-> End");
	}
	
	
	
	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that href count will increment on adding more href.", groups = {  TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithValidRequestToCheckHrefCount() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithValidRequestToCheckHrefCount:-> Start");
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		  String hyperlink = "https://techcrunch.com";
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now add a hyperlink to the board
		ValidatableResponse responseHyperlink = CreateBoardHyperlinkBaseScript.createBoardHyperlinkServiceMethod(hyperlink, boardKey);
	
		
		String hyperlinkKeyFromResponse = responseHyperlink.extract().path("objectKey");

		String boardKeyFromResponse = responseHyperlink.extract().path("boardKey");

		String objectNameFromResponse = responseHyperlink.extract().path("objectName");
	
		String objectTypeFromResponse = responseHyperlink.extract().path("objectType");

		String statusFromResponse = responseHyperlink.extract().path("status");

		String hrefFromResponse = responseHyperlink.extract().path("href");
		
		String hrefImageFromResponse = responseHyperlink.extract().path("hrefImage");
		
		String urlFromResponse = responseHyperlink.extract().path("url");
		
		//now call boards Feed API
		createHeader();

		// get the response from get metadata api
		ValidatableResponse response = triggerGetgetBoardsFeed();

		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		
		/*int boardIndex = getBoardIndexFromResponse(response, boardKey);
		String boardNameFromResponse = "boards["+boardIndex+"].boardName";
		String boardStatusFromResponse = "boards["+boardIndex+"].status";
		String boardTypeFromResponse = "boards["+boardIndex+"].boardType";
		String boardHrefCountFromResponse = "boards["+boardIndex+"].hrefCount";
		String memberTypeFromResponse = "boards["+boardIndex+"].memberType";
		int boardUsersCountFromResponse = Integer.parseInt(("boards["+boardIndex+"].usersCount"));*/
		
	/*	int boardIndex = getBoardIndexFromResponse(response, boardKey);
		String boardNameFromResponse = response.extract().path("boards["+boardIndex+"].boardName");
		String boardStatusFromResponse = response.extract().path("boards["+boardIndex+"].status");
		//String boardKeyFromResponse = response.extract().path("boards["+boardIndex+"].boardKey");
		String boardTypeFromResponse = response.extract().path("boards["+boardIndex+"].boardType");
		int boardHrefCountFromResponse = response.extract().path("boards["+boardIndex+"].hrefCount");
		String boardUserIdFromResponse =response.extract().path( "boards["+boardIndex+"].recentUsers[0].userId");
		FrameworkLogger.logStep("UserId:"+boardUserIdFromResponse);
		String memberTypeFromResponse = response.extract().path("boards["+boardIndex+"].userBoardRelation.memberType");
		int boardUsersCountFromResponse = response.extract().path(("boards["+boardIndex+"].usersCount"));
	//	String boardUsersCountFromResponse = response.extract().path("boards["+boardIndex+"].usersCount");
		
		Verify.verifyEquals(boardNameFromResponse, boardName , "Verify board Name");
		Verify.verifyEquals(boardStatusFromResponse, "A", "Verify board Status");
		Verify.verifyEquals(boardTypeFromResponse, "P", "Verify board Type");
		Verify.verifyEquals(boardHrefCountFromResponse, 1, "Verify board hrefCount");
		Verify.verifyEquals(memberTypeFromResponse, "O", "Verify board memberType");
		Verify.verifyEquals(boardUsersCountFromResponse, 1, "Verify users count");*/
		
		//String recentUpdateObjectName = "boards["+0+"].recentlyUpdatedFiles["+0+"].objectName";
		//String recentUpdateFileUrl = "boards["+0+"].recentlyUpdatedFiles["+0+"].fileURL";
		//String recentUpdateBoardKey = "boards["+0+"].recentlyUpdatedFiles["+0+"].boardKey";
		//String recentUpdateObjectKey = "boards["+0+"].recentlyUpdatedFiles["+0+"].objectKey";
		//String recentUpdateUrl = "boards["+0+"].recentlyUpdatedFiles["+0+"].url";
		
		//Verify.verifyEquals(recentUpdateObjectName, objectNameFromResponse , "Verify recently updated object name");
		//Verify.verifyEquals(recentUpdateFileUrl, hrefFromResponse , "Verify recently updated file url");
		//Verify.verifyEquals(recentUpdateBoardKey, boardKeyFromResponse , "Verify recently updated board key");
		//Verify.verifyEquals(recentUpdateObjectKey, hyperlinkKeyFromResponse , "Verify recently updated object key");
		//Verify.verifyEquals(recentUpdateUrl, urlFromResponse , "Verify recently updated url");
		
		FrameworkLogger.logStep("boardsFeedTestWithValidRequestToCheckHrefCount:-> End");
	}
	
	
	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify if user joins new board and then do sync", groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithValidRequetToCheckMemberCountBeforeAndAfterInvitationAcception() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithValidRequetToCheckMemberCountBeforeAndAfterInvitationAcception:-> Start");
		
		//Step 1: Create a board - by owner
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		// get the response from get metadata api
		ValidatableResponse response = triggerGetgetBoardsFeed();
		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
				
		//int boardIndex = getBoardIndexFromResponse(response, boardKey);
		//String boardNameFromResponse =response.extract().path("boards["+boardIndex+"].boardName");
		//int boardUsersCountFromResponse = response.extract().path(("boards["+boardIndex+"].usersCount"));
		//Verify.verifyEquals(boardUsersCountFromResponse, 1, "Verify users count");
		
		//Step 2: send an invitation to other user to join board
		
	    ValidatableResponse	responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKey,"Sanj","K","sanjeevanee92kanase@gmail.com","C");
	    String invitationCode =responseSendInvite.extract().path("processed[0].inviteCode");
	    
	    //Step 3: login as user 2 
	    
		
		//Step 4: accept the invitation
		createHeader(deviceContributorInfo);
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		//now call boards Feed API
		createHeader();
		ValidatableResponse responseBoardsFeed = triggerGetgetBoardsFeed();
		String boardKeyFromBoardsFeedResponse = responseBoardsFeed.extract().path("boards[0].boardKey");
		
		// get the api response code for get metadata api
		int statusCodeBoardsFeed = responseBoardsFeed.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCodeBoardsFeed, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		String boardKeyAgain = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
	   /* 
		int boardIndexAgain = getBoardIndexFromResponse(responseBoardsFeed, boardKeyAgain);
		String boardNameAgainFromResponse = responseBoardsFeed.extract().path("boards["+boardIndexAgain+"].boardName");
		String boardStatusFromResponse = responseBoardsFeed.extract().path("boards["+boardIndexAgain+"].status");
		String boardTypeFromResponse = responseBoardsFeed.extract().path("boards["+boardIndexAgain+"].boardType");
		//String boardUserIdFromResponse = response.extract().path("boards["+boardIndexAgain+"].userId");
		String memberTypeFromResponse = responseBoardsFeed.extract().path("boards["+boardIndexAgain+"].userBoardRelation.memberType");
		int boardUsersCountAgainFromResponse = responseBoardsFeed.extract().path("boards["+boardIndexAgain+"].usersCount");
		
		Verify.verifyEquals(boardNameAgainFromResponse, boardName , "Verify board Name");
		Verify.verifyEquals(boardStatusFromResponse, "A", "Verify board Status");
		Verify.verifyEquals(boardTypeFromResponse, "P", "Verify board Type");
		Verify.verifyEquals(memberTypeFromResponse, "O", "Verify board memberType");
		Verify.verifyEquals(boardUsersCountAgainFromResponse, 2, "Verify users count");*/
				
		FrameworkLogger.logStep("boardsFeedTestWithValidRequetToCheckMemberCountBeforeAndAfterInvitationAcception:-> End");
	}
	
	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify board feed api with page and limit in url", groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithPageAndLimitInUrl() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithPageAndLimitInUrl:-> Start");
		
		String page="0";
		String limit="20";
		//Step 1: Create a board - by owner
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		// get the response from get metadata api
		ValidatableResponse response = triggerGetgetBoardsFeed("boardsFeedUrlWithPageAndLimit",page,limit);
		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
				
		//int boardIndex = getBoardIndexFromResponse(response, boardKey);
		//String boardNameFromResponse =response.extract().path("boards["+boardIndex+"].boardName");
		//int boardUsersCountFromResponse = response.extract().path(("boards["+boardIndex+"].usersCount"));
		//Verify.verifyEquals(boardUsersCountFromResponse, 1, "Verify users count");
		
		//Step 2: send an invitation to other user to join board
		
	    ValidatableResponse	responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKey,"Sanj","K","sanjeevanee92kanase@gmail.com","C");
	    String invitationCode =responseSendInvite.extract().path("processed[0].inviteCode");
	    
	    //Step 3: login as user 2 
	    
		
		//Step 4: accept the invitation
		createHeader(deviceContributorInfo);
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		//now call boards Feed API
		createHeader();
		ValidatableResponse responseBoardsFeed = triggerGetgetBoardsFeed();
		String boardKeyFromBoardsFeedResponse = responseBoardsFeed.extract().path("boards[0].boardKey");
		
		// get the api response code for get metadata api
		int statusCodeBoardsFeed = responseBoardsFeed.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCodeBoardsFeed, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		//String boardKeyAgain = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
	  
				
		FrameworkLogger.logStep("boardsFeedTestWithPageAndLimitInUrl:-> End");
	}
	
	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify board feed api with page and limit in url and verify previous link in response", groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithPageAndLimitInUrlAndVerifyPreviousLink() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithPageAndLimitInUrlAndVerifyPreviousLink:-> Start");
		
		String page="1";
		String limit="2";
		//Step 1: Create a board - by owner
		
		//create a board
		for (int i=0;i<=20;i++){
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		}
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		// get the response from get metadata api
		ValidatableResponse response = triggerGetgetBoardsFeed("boardsFeedUrlWithPageAndLimit",page,limit);
		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
				
		//int boardIndex = getBoardIndexFromResponse(response, boardKey);
		//String boardNameFromResponse =response.extract().path("boards["+boardIndex+"].boardName");
		//int boardUsersCountFromResponse = response.extract().path(("boards["+boardIndex+"].usersCount"));
		//Verify.verifyEquals(boardUsersCountFromResponse, 1, "Verify users count");
		
		//Step 2: send an invitation to other user to join board
		
	    ValidatableResponse	responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKey,"Sanj","K","sanjeevanee92kanase@gmail.com","C");
	    String invitationCode =responseSendInvite.extract().path("processed[0].inviteCode");
	    
	    //Step 3: login as user 2 
	    
		
		//Step 4: accept the invitation
		createHeader(deviceContributorInfo);
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		//now call boards Feed API
		createHeader();
		ValidatableResponse responseBoardsFeed = triggerGetgetBoardsFeed();
		String boardKeyFromBoardsFeedResponse = responseBoardsFeed.extract().path("boards[0].boardKey");
		
		// get the api response code for get metadata api
		int statusCodeBoardsFeed = responseBoardsFeed.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCodeBoardsFeed, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		//String boardKeyAgain = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		String previousLink=responseBoardsFeed.extract().path("previousLink");
		//Verify.verifyEquals(previousLink, "","Verify previous link");
	  
				
		FrameworkLogger.logStep("boardsFeedTestWithPageAndLimitInUrlAndVerifyPreviousLink:-> End");
	}
	
	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify board feed api with page and limit in url and verify array size", groups = {TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithPageAndLimitInUrlAndVerifyArraySize() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithPageAndLimitInUrlAndVerifyArraySize:-> Start");
		
		String page="0";
		String limit="20";
		//Step 1: Create a board - by owner
		
		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		
		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		
		//now call boards Feed API
		createHeader();

		// get the response from get metadata api
		ValidatableResponse response = triggerGetgetBoardsFeed("boardsFeedUrlWithPageAndLimit",page,limit);
		// get the api response code for get metadata api
		int statusCode = response.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
				
		//int boardIndex = getBoardIndexFromResponse(response, boardKey);
		//String boardNameFromResponse =response.extract().path("boards["+boardIndex+"].boardName");
		//int boardUsersCountFromResponse = response.extract().path(("boards["+boardIndex+"].usersCount"));
		//Verify.verifyEquals(boardUsersCountFromResponse, 1, "Verify users count");
		
		//Step 2: send an invitation to other user to join board
		
	    ValidatableResponse	responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(boardKey,"Sanj","K","sanjeevanee92kanase@gmail.com","C");
	    String invitationCode =responseSendInvite.extract().path("processed[0].inviteCode");
	    
	    //Step 3: login as user 2 
	    
		
		//Step 4: accept the invitation
		createHeader(deviceContributorInfo);
		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,deviceContributorInfo);
		int statusCodeAccept = responseAccept.extract().statusCode();
		Verify.verifyEquals(statusCodeAccept, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		//now call boards Feed API
		createHeader();
		ValidatableResponse responseBoardsFeed = triggerGetgetBoardsFeed();
		String boardKeyFromBoardsFeedResponse = responseBoardsFeed.extract().path("boards[0].boardKey");
		
		// get the api response code for get metadata api
		int statusCodeBoardsFeed = responseBoardsFeed.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCodeBoardsFeed, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		//String boardKeyAgain = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());
		String previousLink=responseBoardsFeed.extract().path("previousLink");
		
		//Need to write logic for array size
				
		FrameworkLogger.logStep("boardsFeedTestWithPageAndLimitInUrlAndVerifyArraySize:-> End");
	}
	
	

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that board will not be there if all members unjoins", groups = { TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithAllMembersLeavingBoardC() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithAllMembersLeavingBoardC:-> Start");


		//Step 1: Create a board - by owner

		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);

		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");


		//Step 2: Other user accepts the invitation and becomes contributor of the board.

		ValidatableResponse responseAccept = AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);
		int status = responseAccept.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		
		//Step 3: now owner leaves board
		
		LeaveBoardBaseScript.leaveBoardService(boardKey);
		
		//Step 4: now contributor leaves the board
		
		LeaveBoardBaseScript.leaveBoardService(boardKey, deviceContributorInfo);
		
		//now call boards Feed API
		createHeader();
		ValidatableResponse responseBoardsFeed = triggerGetgetBoardsFeed();
		
		// get the api response code for get metadata api
		int statusCodeBoardsFeed = responseBoardsFeed.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCodeBoardsFeed, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
	int boardIndex=0;
		//Need to write logic for array size
		try
		{
		 boardIndex = getBoardIndexFromResponse(responseBoardsFeed, boardKey);
		System.out.println("boardIndex?****************====="+boardIndex);
		
		String boardCoverPicObjectKeyFromResponse = responseBoardsFeed.extract().path("boards["+boardIndex+"].boardCoverPicObjectKey");
		System.out.println("?****************====="+boardCoverPicObjectKeyFromResponse);
		}
		catch(Exception e)
		{
			System.out.println("Board Not Found");
			
		}
		
		Verify.verifyEquals(boardIndex,-1, "Verify Success Status");
		FrameworkLogger.logStep("boardsFeedTestWithAllMembersLeavingBoardC:-> End");
	}

			
	//

	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that board will not be there if all members unjoins", groups = { TestNgGroups.REGRESSION,TestNgGroups.BOARDS})

	public void boardsFeedTestWithBoardWithOnlyOwnerLeavingBoard() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("boardsFeedTestWithBoardWithOnlyOwnerLeavingBoard:-> Start");


		//Step 1: Create a board - by owner

		//create a board
		String boardName = "Board___"+Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);

		//get the board key for created board
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		
		//Step 3: now owner leaves board
		
		LeaveBoardBaseScript.leaveBoardService(boardKey);
		
		//now call boards Feed API
		createHeader();
		ValidatableResponse responseBoardsFeed = triggerGetgetBoardsFeed();
		
		// get the api response code for get metadata api
		int statusCodeBoardsFeed = responseBoardsFeed.extract().statusCode();

		// verify that get metadata api returns response code as 200
		Verify.verifyEquals(statusCodeBoardsFeed, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
	int boardIndex=0;
		
		try
		{
		 boardIndex = getBoardIndexFromResponse(responseBoardsFeed, boardKey);
		System.out.println("boardIndex?****************====="+boardIndex);
		
		String boardCoverPicObjectKeyFromResponse = responseBoardsFeed.extract().path("boards["+boardIndex+"].boardCoverPicObjectKey");
		System.out.println("?****************====="+boardCoverPicObjectKeyFromResponse);
		}
		catch(Exception e)
		{
			System.out.println("Board Not Found");
			
		}
		
		Verify.verifyEquals(boardIndex,-1, "Verify Success Status");
		FrameworkLogger.logStep("boardsFeedTestWithAllMembersLeavingBoardC:-> End");
	}
	//



}
