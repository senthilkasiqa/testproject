package com.rjil.cloud.tej.api.test.boardinvites;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class SendResendInvitationNegativeHeaderAndUrlTest extends SendResendInvitationBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if invalid XuserId is used", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithInvalidXuserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvalidXuserId:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		headerMap.put(HeaderParameters.XUSERID.getValue(), "%^&**FGGHH");
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify Failure Status");
		String errorCode = response.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_TEJGA0401.getValue(), "Verify Error Code");
		FrameworkLogger.logStep("sendResendInvitationTestWithInvalidXuserId:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if invalid XdeviceKey is used", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithInvalidXdeviceKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvalidXdeviceKey:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), "klm-kiojo");
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify Failure Status");
		/*
		 * \String errorCode = response.extract().path("code");
		 * Verify.verifyEquals(errorCode,
		 * ErrorResponseCodes.ERRORCODE_BINVS0023.getValue(),
		 * "Verify Error Code"); String errorMessage =
		 * response.extract().path("error"); Verify.verifyEquals(errorMessage,
		 * "Device Key is invalid or not found.", "Verify Error Message");
		 */
		FrameworkLogger.logStep("sendResendInvitationTestWithInvalidXdeviceKey:-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if XuserId is missing", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithMissingXuserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithMissingXuserId:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Failure Status");

		FrameworkLogger.logStep("sendResendInvitationTestWithMissingXuserId:-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if XdeviceKey is missing", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithMissingXdeviceKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithMissingXdeviceKey:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Failure Status");

		FrameworkLogger.logStep("sendResendInvitationTestWithMissingXdeviceKey:-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if url is invalid", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithInvalidUrl()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvalidUrl:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		ValidatableResponse response = triggerPostApiSendResendInvitation("/invite/board/" + boardKey, boardKey);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE500.getValue(), "Verify Failure Status");
		FrameworkLogger.logStep("sendResendInvitationTestWithInvalidUrl:-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if boardKey is null", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithNullBoardKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithNullBoardKey:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		ValidatableResponse response = triggerPostApiSendResendInvitation("");

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE404.getValue(), "Verify Failure Status");
		String errorCodeAccept2 = response.extract().path("code");
		Verify.verifyEquals(errorCodeAccept2, ErrorResponseCodes.ERRORCODE_TEJRF0404.getValue(), "Verify Error Code");
		FrameworkLogger.logStep("sendResendInvitationTestWithNullBoardKey:-> End");
	}
}
