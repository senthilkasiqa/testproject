/**
 * 
 */
package com.rjil.cloud.tej.api.test.boardinvites;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.DeclineBoardRequestBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.RemoveBoardMembersBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.BoardsDeltaSyncBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.BoardsFeedBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 * 
 *         Test class for Leave/Unjoin Board Api
 *
 */
public class LeaveBoardTestForaUser extends LeaveBoardBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify that any valid member of board should be able to leave the board.", groups = {
					TestNgGroups.QASANITY, TestNgGroups.BOARDS, TestNgGroups.REGRESSION })
	public void testLeaveBoardWithValidData() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("Leave all boards :-> Start");
		FrameworkLogger.logStep("Owner Leave all of his boards :-> Start");
		BoardsFeedBaseScript.getAllBoardKeysAndUnjoinBoard();
		FrameworkLogger.logStep("Owner Leave all of his boards :-> End");
	}

}
