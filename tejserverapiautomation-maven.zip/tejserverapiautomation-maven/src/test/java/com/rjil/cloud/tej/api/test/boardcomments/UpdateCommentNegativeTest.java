package com.rjil.cloud.tej.api.test.boardcomments;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.BaseTestScript;
import com.rjil.cloud.tej.apihelpers.boardcomments.PostCommentBaseScript;
import com.rjil.cloud.tej.apihelpers.boardcomments.UpdateCommentBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class UpdateCommentNegativeTest extends UpdateCommentBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comments api with comment lemgth more than 3600.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithCommentMoreThan3600()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithCommentMoreThan3600:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.
		PostCommentBaseScript post = new PostCommentBaseScript();
		String newComment = post.generateString(3600).toString();

		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment(boardKey, commentKey);
		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, "BRSOM0152", "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Comment length must be less than 3600 characters", "Verify Success Status");
		FrameworkLogger.logStep("updateCommentTestWithCommentMoreThan3600:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comments api with missing user id.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithMissingUserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithMissingUserId:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.
		String newComment = "Good one";

		createHeader();
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment(boardKey, commentKey);

		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, "TEJGA0400", "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "X-User-Id Not Sent in HTTP Header", "Verify Success Status");
		FrameworkLogger.logStep("updateCommentTestWithMissingUserId:-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comments api with invalid user id.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })

	public void updateCommentTestWithInvalidUserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithInvalidUserId:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.
		String newComment = "Good one";

		createHeader();
		headerMap.put(HeaderParameters.XUSERID.getValue(), BaseTestScript.getInvalidUserid());
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment(boardKey, commentKey);

		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, "TEJGA0401", "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Authorization Token Expired or wrong", "Verify Success Status");
		FrameworkLogger.logStep("updateCommentTestWithInvalidUserId:-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comments api with missing deviceKey.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithMissingXDeviceKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithMissingXDeviceKey:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.
		String newComment = "Good one";

		createHeader();
		headerMap.remove(HeaderParameters.XDEVICEKEY.getValue());
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment(boardKey, commentKey);

		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("updateCommentTestWithMissingXDeviceKey:-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comments api with invalid deviceKey.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithInvalidXDeviceKey()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("updateCommentTestWithInvalidXDeviceKey:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.
		String newComment = "Good one";

		createHeader();
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), BaseTestScript.getInvalidUserid());
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment(boardKey, commentKey);

		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("updateCommentTestWithInvalidXDeviceKey:-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comments api with invalid boardKey.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithInvalidBoardKeyKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithInvalidBoardKeyKey:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.
		String newComment = "Good one";

		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment("invalid23Board", commentKey);

		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Board User Relation Missing.", "Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithInvalidBoardKeyKey:-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comments api with missing boardKey.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithMissingBoardKeyKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithMissingBoardKeyKey:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.
		String newComment = "Good one";

		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment("", commentKey);

		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("updateCommentTestWithMissingBoardKeyKey:-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comments api with invalid commentKey.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithInvalidCommentKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("updateCommentTestWithInvalidCommentKey:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);

		// Step 3: Now owner updating his own comment on his board.
		String newComment = "Good one";

		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment(boardKey, "ghg67");

		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0154.getValue(), "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Comment key is missing or invalid.", "Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithInvalidCommentKey:-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comments api with missing commentKey.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithMissingCommentKey()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("updateCommentTestWithInvalidCommentKey:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.

		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.

		String newComment = "Good one";

		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment(boardKey, "");

		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE404.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, "TEJRF0404", "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error,
				"The requested resource could not be found but may be available again in the future.",
				"Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithInvalidCommentKey:-> End");

	}

	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comments api with invalid combination of boardKey and commentKey.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })

	public void updateCommentTestWithInvalidCombinationOfBoardKeyAndCommentKey()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("updateCommentTestWithInvalidCombinationOfBoardKeyAndCommentKey:-> Start");

		// Step 1: Owner Creates a board

		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.
		String newComment = "Good one";

		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), newComment, updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment("4253666hj", commentKey);

		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, ErrorResponseCodes.ERRORCODE_BRSOM0110.getValue(), "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Board User Relation Missing.", "Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithInvalidCombinationOfBoardKeyAndCommentKey:-> End");
	}

	@Test(priority = 11, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comment api  with invalid comment in pay load.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void updateCommentTestWithInvalidComment()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("updateCommentTestWithInvalidComment:-> Start");

		// Step 1: Owner Creates a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.
		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.

		String newComment = "Good one";

		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = setJsonData(NewBoardConstants.getComment(), "    ", updateCommentJsonBody);
		ValidatableResponse response = triggerPutApiUpdateComment(boardKey, commentKey);

		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String code = response.extract().path("code");
		Verify.verifyEquals(code, "BRSOM0151", "Verify Success Status");

		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Comment is missing in the request.", "Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithInvalidComment:-> End");

	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify update comment api  with missing comment in pay load.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })

	public void updateCommentTestWithMissingComment()
			throws IOException, VerificationFailException, InterruptedException {

		FrameworkLogger.logStep("updateCommentTestWithMissingComment:-> Start");

		// Step 1: Owner Creates a board

		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Step 2: Owner comments on his own board.

		String comment = "Nice travel memories";
		ValidatableResponse postResponse = PostCommentBaseScript.postCommentServiceMethod(comment, boardKey);
		String commentKey = postResponse.extract().path("comments[0].commentKey");

		// Step 3: Now owner updating his own comment on his board.
		createHeader();
		setUpdateCommentJsonBody();
		updateCommentJsonBody = JsonPath.parse(updateCommentJsonBody).delete(NewBoardConstants.getComment())
				.jsonString();
		ValidatableResponse response = triggerPutApiUpdateComment(boardKey, commentKey);

		int statusCode = response.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
		String code = response.extract().path("code");
		Verify.verifyEquals(code, "BRSOM0151", "Verify Success Status");
		String error = response.extract().path("error");
		Verify.verifyEquals(error, "Comment is missing in the request.", "Verify Success Status");

		FrameworkLogger.logStep("updateCommentTestWithMissingComment:-> End");
	}
}
