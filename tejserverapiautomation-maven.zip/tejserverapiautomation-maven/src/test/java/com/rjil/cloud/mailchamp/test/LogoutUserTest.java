package com.rjil.cloud.mailchamp.test;

import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.mailchamp.common.helper.LogoutUserBaseClass;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.enums.HeaderParameters;


public class LogoutUserTest extends LogoutUserBaseClass {

	public ValidatableResponse response;

	@Test(description = "TC_89 - To Verify Logout API for Valid details.", groups = { 
			TestNgGroups.REGRESSION })

	public void eLogoutValidUser() {
		response = triggerPutApi(getLogoutUserUrl(), createHeaderMap());
		int intLogoutStatus = response.extract().statusCode(); // 200
		System.out.println("Status Code for Valid user: " + intLogoutStatus);
		Assert.assertEquals(intLogoutStatus, 204);
	}

	@Test(description = "TC_90 - To Verify Logout API, when User ID is MISSING", groups = { TestNgGroups.REGRESSION })
	public void aLogoutUserMissingUserId() {
		String userId = "";
		Map<String, String> headerMap = createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		
		response = triggerPutApi(getLogoutUserUrl(), headerMap);
		int intLogoutStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for Missing UserId: " + intLogoutStatus);
		Assert.assertEquals(intLogoutStatus, 400);
	}

	@Test(description = "TC_91 - To Verify Logout API, when Access Token is MISSING", groups = { TestNgGroups.REGRESSION })
	public void bLogoutUserMissingAccessToken() {
		String authCode = "";
		Map<String, String> headerMap = createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authCode);
		response = triggerPutApi(getLogoutUserUrl(), headerMap);
		int intLogoutStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for Missing ACCESS TOKEN: " + intLogoutStatus);
		Assert.assertEquals(intLogoutStatus, 400);
	}

	@Test(description = "TC_92 - To Verify Logout API, when User ID is INVALID", groups = { TestNgGroups.REGRESSION })
	public void cLogoutUserInvalidUserId() {
		String userId = "abc123";
		Map<String, String> headerMap = createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(), userId);
		response = triggerPutApi(getLogoutUserUrl(), headerMap);
		int intLogoutStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for Invalid UserId: " + intLogoutStatus);
		Assert.assertEquals(intLogoutStatus, 400);
	}

	@Test(description = "TC_93 - To Verify Logout API, when Access Token is INVALID	", groups = {
			TestNgGroups.REGRESSION })
	public void dLogoutUserInvalidAccessToken() {
		String authCode = "abcd1234";
		Map<String, String> headerMap = createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(), authCode);
		response = triggerPutApi(getLogoutUserUrl(), headerMap);
		int intLogoutStatus = response.extract().statusCode(); // 400
		System.out.println("Status Code for Invalid ACCESS TOKEN: " + intLogoutStatus);
		Assert.assertEquals(intLogoutStatus, 401);
	}
}