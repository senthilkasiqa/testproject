package com.rjil.cloud.mailchamp.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.mailchamp.common.helper.LoginUserBaseClass;



public class LoginUserTest extends LoginUserBaseClass{
	public ValidatableResponse response;
	
	@Test
	(description = "TC_01 - To verify the Login API with valid Offline code Verify the status code of API.",
			groups = {"SANITY", "REGRESSION"})
		public void loginUserStatusCode() 	{
//		Map<String, String> header=createHeaderMap();
//		header.put(HeaderParameters.XCODE.getValue());
		response = triggerPostApi(getLoginUserUrl(),createHeaderMap());

		int intLoginStatus = response.extract().statusCode();	//200
		System.out.println("Status Code is :" +intLoginStatus);
		Assert.assertEquals(intLoginStatus, 200);
}
	
	// Following cases are not required
	/*
	@Test 
	(dependsOnMethods = {"statusCode"}, description = "TC_02 - Verify the FirstName of the logged in User, when user logs in to the system using their email credentials",
			groups = {"Sanity", "Regression"})
		public void firstName() 	{
		String usrFstName = response.extract().path("firstName");
		System.out.println("FirstName is :" +usrFstName);
		Assert.assertEquals(usrFstName, getValueFromEnvConfig("firstName"));
	}

	
	@Test 
	(dependsOnMethods = {"statusCode"}, description = "TC_03 - Verify the LastName of the logged in User, when user logs in to the system using their email credentials",
	groups = {"Sanity", "Regression"})
		public void lastName() 	{
		String usrLastName = response.extract().path("lastName");
		System.out.println("LastName is :" +usrLastName);
		Assert.assertEquals(usrLastName, getValueFromEnvConfig("lastName"));
	}
	
	
	@Test 
	(dependsOnMethods = {"statusCode"}, description = "TC_04 - Verify the Email ID of the logged in User, when user logs in to the system using their email credentials",
	groups = {"Sanity", "Regression"})
		public void email() 	{
		String usrEmailId = response.extract().path("emailId");
		System.out.println("email is :" +usrEmailId);
		Assert.assertEquals(usrEmailId, getValueFromEnvConfig("userEmail") );
	}
*/	
}