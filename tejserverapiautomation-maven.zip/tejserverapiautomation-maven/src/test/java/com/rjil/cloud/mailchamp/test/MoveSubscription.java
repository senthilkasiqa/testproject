package com.rjil.cloud.mailchamp.test;

import java.io.UnsupportedEncodingException;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.mailchamp.common.helper.MoveSubScriptionBaseClass;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.enums.HeaderParameters;



public class MoveSubscription extends MoveSubScriptionBaseClass{
	
	public ValidatableResponse response;
	
	//Commented cases are not in use
//	public String baseUrl = 
//			getValueFromEnvConfig("baseURL");

/*@Test 
	(description = "To validate the JSON response ",
	groups = {TestGroup.SANITY, TestGroup.REGRESSION})
	
	public void validateJSON(){
		//Validating Schema for GetSubscriptionList.
	     //  String strSchemaPath="cabTestData/cabResponseSchema.json";
		String strSchemaPath="getSubscriptionTestData/getSubscriptionListSchema.json";
	       
	       response.body(JsonSchemaValidator.matchesJsonSchemaInClasspath(strSchemaPath));
	}*/
	
	@Test 
	(description = "TC_39 - To validate the move subscription API for valid details, "
			+ "when moving Subscription from New to Inbox ",
			groups = {TestNgGroups.REGRESSION})

	public void aMovSubScpNewToInbox(){
		//Getting list of all Subscriptions from New and picking up the first record to be moved
		//Also checking count of items in Inbox, to compare it later
		
//		String getSubScpNew = getMoveSubscriptionUrlForNew();
//		response = triggerGetApi(getSubScpNew, createHeaderMap());

		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int subListStatus = response.extract().statusCode(); // 200
		System.out.println("Status Code for New Subscriptions is:" + subListStatus);
		
		int newcount = response.extract().path("newCount");
				if (newcount == 0)
		 {
				System.out.println("There are no Messages in NEW, hence stopping further execution of Script");
				return;
			}
		else {
			int inboxcount =response.extract().path("inboxCount");
		System.out.println("Inboxcount is: " +inboxcount);
		String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
		System.out.println("MessageFrom to be moved is: " +subscriptionKey);
		
		//Moving the first subscription from New to Inbox using Move subscription API
		String baseUrl = getBaseURL();
		Map<String, String> headerMapLocal = createHeaderMap();
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerPutApi(baseUrl, headerMapLocal ); 
		int movSubScpStatus = response.extract().statusCode();	//200
		System.out.println("Status Code for MoveSubScp fm New to Inbox is: " +movSubScpStatus);
		Assert.assertEquals(movSubScpStatus, 200);
		
		//Checking count of Inbox folder, this should increment by 1, as we have moved one subscription to Inbox
//		String getSubScpNewa = getMoveSubscriptionUrlForNew();
//		response = triggerGetApi(getSubScpNewa, createHeaderMap());

//		String subscriptionListUrla = getSubscriptionListBaseURL();
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int inboxCountnew = response.extract().path("inboxCount");
		int inboxcCountOld = inboxcount + 1;
		Assert.assertEquals(inboxCountnew, inboxcCountOld);
		System.out.println("Inbox Count: " + inboxcCountOld);
		System.out.println("Inbox CountNew: " +inboxCountnew);
	}
	}
	
	@Test 
	(description = "TC_40 To validate the move subscription API for valid details, "
			+ "when moving Subscription from New to GroupIt",
			groups = { TestNgGroups.REGRESSION})
	public void bMovSubScpNewToGroupIt(){
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int newcount = response.extract().path("newCount");
		if (newcount == 0) 
		{
			System.out.println("There are no Messages in NEW, hence stopping further execution of Script");
			return;
		}
	else {
		int groupItCount = response.extract().path("groupItCount");
		System.out.println("GroupItCount is: " +groupItCount);
		String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
		System.out.println("MessageFrom to be moved is: " +subscriptionKey);
		
		String baseUrl = getBaseURL();
		Map<String, String> headerMapLocal = createHeaderMap();
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerPutApi(baseUrl, headerMapLocal );
		int movSubScpStatus = response.extract().statusCode();	//200
		System.out.println("Status Code for MoveSubScp fm New to GroupIt is: " +movSubScpStatus);
		Assert.assertEquals(movSubScpStatus, 200);
		
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		int groupItCountnew = response.extract().path("groupItCount");
		int groupItCountold = groupItCount + 1;
		Assert.assertEquals(groupItCountnew, groupItCountold);
		System.out.println("GroupIt CountOld: " + groupItCountold);
		System.out.println("GroupIt CountNew: " +groupItCountnew);
	}
	}
	
	@Test 
	(description = "TC_41 To validate the move subscription API for valid details, "
			+ "when moving Subscription from New to Unsubscribe",
			groups = {TestNgGroups.REGRESSION})
	public void cMovSubScpNewToUnsubscribe(){
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "New");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int newcount = response.extract().path("newCount");
		if (newcount == 0) 
		{
			System.out.println("There are no Messages in NEW, hence stopping further execution of Script");
			return;
		}
	else {
		int unsubscribeCount = response.extract().path("unsubscribeCount");
		String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
		System.out.println("MessageFrom to be moved is: " +subscriptionKey);
		
		String baseUrl = getBaseURL();
		Map<String, String> headerMapLocal = createHeaderMap();
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerPutApi(baseUrl, headerMapLocal );
		int movSubScpStatus = response.extract().statusCode();	//200
		System.out.println("Status Code for MoveSubScp fm New to Unsubscribe is: " +movSubScpStatus);
		Assert.assertEquals(movSubScpStatus, 200);
		
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		int unsubscribeCountnew = response.extract().path("unsubscribeCount");
		int unsubscribeCountold = unsubscribeCount + 1;
		Assert.assertEquals(unsubscribeCountnew, unsubscribeCountold);
		System.out.println("Unsubscribe CountOld: " + unsubscribeCountold);
		System.out.println("Unsubscribe CountNew: " +unsubscribeCountnew);
		}
	}

	@Test
	(description = "TC_42 To validate the move subscription API for valid details, "
			+ "when moving Subscription from Inbox to GroupIt",
	groups = {TestNgGroups.REGRESSION})
	public void eMovSubScpInboxToGroupIt() throws UnsupportedEncodingException{
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int inboxCount = response.extract().path("inboxCount");
		if (inboxCount == 0) 
		{
			System.out.println("There are no Messages in INBOX, hence stopping further execution of Script");
			return;
		}
	else {
		int groupItCount = response.extract().path("groupItCount");
		String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
		System.out.println("MessageFrom to be moved is: " +subscriptionKey);
		
		String baseUrl = getBaseURL();
		Map<String, String> headerMapLocal = createHeaderMap();
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(),"GroupIt");
		response = triggerPutApi(baseUrl, headerMapLocal );
		int movSubScpStatus = response.extract().statusCode();	//200
		System.out.println("Status Code for MoveSubScp fm Inbox to GroupIt is: " +movSubScpStatus);
		Assert.assertEquals(movSubScpStatus, 200);
		
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		int groupItCountnew = response.extract().path("groupItCount");
		int groupItCountOld = groupItCount + 1;
		Assert.assertEquals(groupItCountnew, groupItCountOld);
		System.out.println("GroupIt Countold: " + groupItCountOld);
		System.out.println("Inbox CountNew: " +groupItCountnew);
	}
	}
	
	@Test
	(description = "TC_43 To validate the move subscription API for valid details,"
			+ " when moving Subscription from Inbox to Unsubscribe",
	groups = {TestNgGroups.REGRESSION})
	public void fMovSubScpInboxToUnsubscribe(){
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int inboxCount = response.extract().path("inboxCount");
		if (inboxCount == 0) 
		{
			System.out.println("There are no Messages in INBOX, hence stopping further execution of Script");
			return;
		}
	else {
		int unsubscribeCount = response.extract().path("unsubscribeCount");
		String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
		System.out.println("MessageFrom to be moved is: " +subscriptionKey);
		
		String baseUrl = getBaseURL();
		Map<String, String> headerMapLocal = createHeaderMap();
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerPutApi(baseUrl, headerMapLocal );
		int movSubScpStatus = response.extract().statusCode();	//200
		System.out.println("Status Code for MoveSubScp fm Inbox to Unsubscribe is: " +movSubScpStatus);
		Assert.assertEquals(movSubScpStatus, 200);
		
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		int unsubscribeCountnew = response.extract().path("unsubscribeCount");
		int unsubscribeCountold = unsubscribeCount + 1;
		Assert.assertEquals(unsubscribeCountnew	, unsubscribeCountold);
		System.out.println("UnsubscribeOld Count: " + unsubscribeCountold);
		System.out.println("UnsubscribeNew CountNew: " +unsubscribeCountnew);

	}
	}
	
	@Test
	(description = "TC_44 To validate the move subscription API for valid details, "
			+ "when moving Subscription from GroupIt to Inbox",
	groups = {TestNgGroups.REGRESSION})
	public void hMovSubScpGroupItToInbox(){
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int groupItCount = response.extract().path("groupItCount");
		if (groupItCount == 0) 
		{
			System.out.println("There are no Messages in GroupIt, hence stopping further execution of Script");
			return;
		}
	else {
		int inboxCount = response.extract().path("inboxCount");
		String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
		System.out.println("MessageFrom to be moved is: " +subscriptionKey);
		
		String baseUrl = getBaseURL();
		Map<String, String> headerMapLocal = createHeaderMap();
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerPutApi(baseUrl, headerMapLocal );
		int movSubScpStatus = response.extract().statusCode();	//200
		System.out.println("Status Code for MoveSubScp fm GroupIt to Inbox is: " +movSubScpStatus);
		Assert.assertEquals(movSubScpStatus, 200);
		
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		int inboxCountnew = response.extract().path("inboxCount");
		int inboxcCountOld = inboxCount + 1;
		Assert.assertEquals(inboxCountnew, inboxcCountOld);
		System.out.println("Inbox Count: " + inboxcCountOld);
		System.out.println("Inbox CountNew: " +inboxCountnew);
	}
	}
	
	@Test
	(description = "TC_45 To validate the move subscription API for valid details, "
			+ "when moving Subscription from GroupIt to Unsubscribe",
	groups = {TestNgGroups.REGRESSION})
	public void iMovSubScpGroupItToUnsubscribe(){
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int groupItCount = response.extract().path("groupItCount");
		if (groupItCount == 0) 
		{
			System.out.println("There are no Messages in GroupIt, hence stopping further execution of Script");
			return;
		}
	else {
		int unsubscribeCount = response.extract().path("unsubscribeCount");
		String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
		System.out.println("MessageFrom to be moved is: " +subscriptionKey);
		
		String baseUrl = getBaseURL();
		Map<String, String> headerMapLocal = createHeaderMap();
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerPutApi(baseUrl, headerMapLocal );
		int movSubScpStatus = response.extract().statusCode();	//200
		System.out.println("Status Code for MoveSubScp fm GroupIt to Unsubscribe is: " +movSubScpStatus);
		Assert.assertEquals(movSubScpStatus, 200);
		
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		int unsubscribeCountnew = response.extract().path("unsubscribeCount");
		int unsubscribeCountold = unsubscribeCount + 1;
		Assert.assertEquals(unsubscribeCountnew	, unsubscribeCountold);
		System.out.println("UnsubscribeOld Count: " + unsubscribeCountold);
		System.out.println("UnsubscribeNew CountNew: " +unsubscribeCountnew);
		}
		}

	
	@Test
	(description = "TC_46 - To validate the move subscription API for valid details,"
			+ " when moving Subscription from Unsubscribe to Inbox",
	groups = {TestNgGroups.REGRESSION})
	public void lMovSubScpUnsubscribeToInbox(){
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int unsubscribeCount = response.extract().path("unsubscribeCount");
		if (unsubscribeCount == 0) 
		{
			System.out.println("There are no Messages in UnSubscribe, hence stopping further execution of Script");
			return;
		}
	else {
		int inboxCount = response.extract().path("inboxCount");
		String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
		System.out.println("MessageFrom to be moved is: " +subscriptionKey);
		
		String baseUrl = getBaseURL();
		Map<String, String> headerMapLocal = createHeaderMap();
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Inbox");
		response = triggerPutApi(baseUrl, headerMapLocal ); 
		int movSubScpStatus = response.extract().statusCode();	//200
		System.out.println("Status Code for MoveSubScp fm Unsubscribe to Inbox is: " +movSubScpStatus);
		Assert.assertEquals(movSubScpStatus, 200);
		
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		int inboxCountnew = response.extract().path("inboxCount");
		int inboxcCountOld = inboxCount + 1;
		Assert.assertEquals(inboxCountnew, inboxcCountOld);
		System.out.println("Inbox Count: " + inboxcCountOld);
		System.out.println("Inbox CountNew: " +inboxCountnew);
	}
	}

	
	
	@Test
	(description = "TC_47 - To validate the move subscription API for valid details, "
			+ "when moving Subscription from Unsubscribe to GroupIt",
	groups = {TestNgGroups.REGRESSION})
	public void kMovSubScpUnsubscribetoGroupIt(){
		String subscriptionListUrl = getSubscriptionListBaseURL();
		Map<String, String> subscriptionHeaderMap = createHeaderMap();
		subscriptionHeaderMap.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "Unsubscribe");
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		
		int unsubscribeCount = response.extract().path("unsubscribeCount");
		if (unsubscribeCount == 0) 
		{
			System.out.println("There are no Messages in UnSubscribe, hence stopping further execution of Script");
			return;
		}
	else {
		int groupItCount = response.extract().path("groupItCount");
		String subscriptionKey = response.extract().path("emailMetadataList[0].subscriptionKey");
		System.out.println("MessageFrom to be moved is: " +subscriptionKey);
		
		String baseUrl = getBaseURL();
		Map<String, String> headerMapLocal = createHeaderMap();
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONKEY.getValue(), subscriptionKey);
		headerMapLocal.put(HeaderParameters.XSUBSCRIPTIONTYPE.getValue(), "GroupIt");
		response = triggerPutApi(baseUrl, headerMapLocal );
		int movSubScpStatus = response.extract().statusCode();	//200
		System.out.println("Status Code for MoveSubScp fm Unsubscribe to GroupIt is: " +movSubScpStatus);
		Assert.assertEquals(movSubScpStatus, 200);
		
		response = triggerGetApi(subscriptionListUrl, subscriptionHeaderMap);
		int groupItCountnew = response.extract().path("groupItCount");
		int groupItCountOld = groupItCount + 1;
		Assert.assertEquals(groupItCountnew, groupItCountOld);
		System.out.println("GroupIt Countold: " + groupItCountOld);
		System.out.println("Inbox CountNew: " +groupItCountnew);
	}
	}
}
