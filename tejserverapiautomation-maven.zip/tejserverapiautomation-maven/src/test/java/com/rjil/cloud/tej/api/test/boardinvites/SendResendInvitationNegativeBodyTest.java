package com.rjil.cloud.tej.api.test.boardinvites;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class SendResendInvitationNegativeBodyTest extends SendResendInvitationBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if invalid userContact is used", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithInvalidUserContact()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvalidUserContact:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserContact(), "928392",
				sendResendInvitationJsonBody);
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Failure Status");
		String errorCodeFromResponse1 = response.extract().path("code");
		String errorMessageFromResponse1 = response.extract().path("error");
		Verify.verifyEquals(errorCodeFromResponse1, ErrorResponseCodes.ERRORCODE_BINVS0405.getValue(),
				"verify errorCode");
		Verify.verifyEquals(errorMessageFromResponse1, "No valid contact in the request.", "verify errorMessage");

		FrameworkLogger.logStep("sendResendInvitationTestWithInvalidUserContact:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if invalid userType is used", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithInvalidUserType()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithInvalidUserType:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = setJsonData(NewBoardConstants.getFirstUserType(), "W",
				sendResendInvitationJsonBody);
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		// verify response
		String errorCodeFromResponse1 = response.extract().path("code");
		String errorMessageFromResponse1 = response.extract().path("error");

		Verify.verifyEquals(errorCodeFromResponse1, ErrorResponseCodes.ERRORCODE_BINVS0405.getValue(),
				"verify errorCode");
		Verify.verifyEquals(errorMessageFromResponse1, "No valid contact in the request.", "verify errorMessage");
		FrameworkLogger.logStep("sendResendInvitationTestWithInvalidUserType:-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if user contact is missing", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithMissingUserContact()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithMissingUserContact:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = JsonPath.parse(sendResendInvitationJsonBody)
				.delete(NewBoardConstants.getFirstUserContact()).jsonString();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Failure Status");

		// verify response
		String errorCodeFromResponse1 = response.extract().path("code");
		String errorMessageFromResponse1 = response.extract().path("error");
		Verify.verifyEquals(errorCodeFromResponse1, ErrorResponseCodes.ERRORCODE_BINVS0405.getValue(),
				"verify errorCode");
		Verify.verifyEquals(errorMessageFromResponse1, "No valid contact in the request.", "verify errorMessage");

		FrameworkLogger.logStep("sendResendInvitationTestWithMissingUserContact:-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if userType is missing", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithMissingUserType()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithMissingUserType:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = JsonPath.parse(sendResendInvitationJsonBody)
				.delete(NewBoardConstants.getFirstUserType()).jsonString();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);

		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		// verify response
		String errorCodeFromResponse1 = response.extract().path("code");
		String errorMessageFromResponse1 = response.extract().path("error");
		Verify.verifyEquals(errorCodeFromResponse1, ErrorResponseCodes.ERRORCODE_BINVS0405.getValue(),
				"verify errorCode");
		Verify.verifyEquals(errorMessageFromResponse1, "No valid contact in the request.", "verify errorMessage");
		FrameworkLogger.logStep("sendResendInvitationTestWithMissingUserType:-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if firstName is missing", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithMissingFirstName()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithMissingFirstName:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = JsonPath.parse(sendResendInvitationJsonBody)
				.delete(NewBoardConstants.getFirstFirstName()).jsonString();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("sendResendInvitationTestWithMissingFirstName:-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ ":Verify the response if lastname is missing", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void sendResendInvitationTestWithMissingLastName()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("sendResendInvitationTestWithMissingLastName:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// call send / resend invitation apis
		createHeader();
		sendResendInvitationJsonBody = setSendResendInvitationJsonBody();
		sendResendInvitationJsonBody = JsonPath.parse(sendResendInvitationJsonBody)
				.delete(NewBoardConstants.getFirstLastName()).jsonString();
		ValidatableResponse response = triggerPostApiSendResendInvitation(boardKey);
		int status = response.extract().statusCode();
		Verify.verifyEquals(status, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		FrameworkLogger.logStep("sendResendInvitationTestWithMissingLastName:-> End");
	}
}
