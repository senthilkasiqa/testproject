/**
 * 
 */
package com.rjil.cloud.tej.api.test.boardinvites;

import java.io.IOException;
import java.util.List;

import org.testng.annotations.Test;

import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.ValidatableResponse;

import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.DeclineBoardRequestBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.GetMembersOfBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.RemoveBoardMembersBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.fileupload.UploadBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

public class GetMembersOfBoardTest extends GetMembersOfBoardBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ " verify that a valid owner can get the list of active members of board.", groups = {
					TestNgGroups.DEPLOYMENTSANITY })
	public void getBoardMembersForValidOwner() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getBoardMembersForValidTest:-> Start");
		String fileName = "Sample.jpg";
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Upload file in board
		UploadBaseScript.getUploadFileToBoardServiceMethod(fileName, boardKey);

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Accept Invitation
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Accept Invite Status");
		createHeader();

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetBoardMembers(boardKey);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(),
				"Verify Get Board Members Status");
		FrameworkLogger.logStep("getBoardMembersForValidTest:-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ " verify that a valid owner can get the list of active members of board.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS, TestNgGroups.QASANITY })
	public void getBoardMembersForValidOwnerTest() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getBoardMembersForValidTest:-> Start");
		String fileName = "Sample.jpg";
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Upload file in board
		ValidatableResponse uploadToBoard = UploadBaseScript.getUploadFileToBoardServiceMethod(fileName, boardKey);

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		createHeader();

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerGetApiGetBoardMembers(boardKey);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// verify that
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		List<String> listOfUserIds = getListKeyValuesFromGetMembersOfBoardResponse(response, "userId");
		List<String> listOfUserNames = getListKeyValuesFromGetMembersOfBoardResponse(response, "firstName");
		List<String> listOfMemberType = getListKeyValuesFromGetMembersOfBoardResponse(response, "memberType");
		int indexOfContributor = 0;
		int indexOfOwner = 0;
		for (int i = 0; i < listOfUserIds.size(); i++) {
			if (listOfUserIds.get(i).equals(userIdOfContributor)) {
				indexOfContributor = i;
			}
			if (listOfUserIds.get(i).equals(userIdOfOwner)) {
				indexOfOwner = i;
			}
		}

		Verify.verifyEquals(listOfUserIds.get(indexOfOwner), userIdOfOwner, "Verify Owner id");
		Verify.verifyEquals(listOfUserNames.get(indexOfOwner), firstNameOfOwner, "Verify Owner name");
		Verify.verifyEquals(listOfMemberType.get(indexOfOwner), "O", "Verify Member Type for owner");
		Verify.verifyEquals(listOfUserIds.get(indexOfContributor), userIdOfContributor, "Verify Contributor id");
		Verify.verifyEquals(listOfUserNames.get(indexOfContributor), firstNameOfContributor, "Verify Contributor name");
		Verify.verifyEquals(listOfMemberType.get(indexOfContributor), "C", "Verify Member Type for contributor");

		response.body(
				JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/getMembersOfBoardTest-Schema.json"));
		String objectKeyFromUpload = uploadToBoard.extract().path("objectKey");

		String boardCoverPicObjectKey = response.extract().path("boardCoverPicObjectKey");
		Verify.verifyEquals(boardCoverPicObjectKey, objectKeyFromUpload, "Verify Member Type for contributor");

		String ownerProfilePic = response.extract().path("owner.ownerProfilePic");
		String profilePicMember1 = response.extract().path("boardMembers[0].profilePic ");
		String profilePicMember2 = response.extract().path("boardMembers[1].profilePic ");
		/*Verify.verifyEquals(ownerProfilePic,
				"http://sit-dl.tejdrive.com/boards/members/" + userIdOfOwner + "/profilepic",
				"Verify Member Type for contributor");

		
		Verify.verifyEquals(profilePicMember1,
				"http://sit-dl.tejdrive.com/boards/members/" + userIdOfContributor + "/profilepic",
				"Verify Member Type for contributor");

	
		Verify.verifyEquals(profilePicMember2,
				"http://sit-dl.tejdrive.com/boards/members/" + userIdOfOwner + "/profilepic",
				"Verify Member Type for contributor");*/
	//	ValidatableResponse responseDownload = triggerGetApi(ownerProfilePic,headerMap);
	//	ValidatableResponse responseDownload1 = triggerGetApi(profilePicMember1,headerMap);
		ValidatableResponse responseDownload2 = triggerGetApi(profilePicMember2,headerMap);
		FrameworkLogger.logStep("getBoardMembersForValidTest:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ " verify that a valid contributor can get the list of active members of board - including owner", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getBoardCategoriesForValidContributor()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getBoardCategoriesForValidContributor:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		FrameworkLogger.logStep("INVITECODE:" + invitationCode);
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// get the response from getboardmembers api
		ValidatableResponse response = triggerGetApiGetBoardMembers(boardKey, deviceContributorInfo);

		// get the api response code for getboardmembers api
		int statusCode1 = response.extract().statusCode();

		// verify that
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		List<String> listOfUserIds = getListKeyValuesFromGetMembersOfBoardResponse(response, "userId");
		List<String> listOfUserNames = getListKeyValuesFromGetMembersOfBoardResponse(response, "firstName");
		List<String> listOfMemberType = getListKeyValuesFromGetMembersOfBoardResponse(response, "memberType");
		int indexOfContributor = 0;
		int indexOfOwner = 0;
		for (int i = 0; i < listOfUserIds.size(); i++) {
			if (listOfUserIds.get(i).equals(userIdOfContributor)) {
				indexOfContributor = i;
			}
			if (listOfUserIds.get(i).equals(userIdOfOwner)) {
				indexOfOwner = i;
			}
		}
		Verify.verifyEquals(listOfUserIds.get(indexOfOwner), userIdOfOwner, "Verify Owner id");
		Verify.verifyEquals(listOfUserNames.get(indexOfOwner), firstNameOfOwner, "Verify Owner name");
		Verify.verifyEquals(listOfMemberType.get(indexOfOwner), "O", "Verify Member Type for owner");
		Verify.verifyEquals(listOfUserIds.get(indexOfContributor), userIdOfContributor, "Verify Contributor id");
		Verify.verifyEquals(listOfUserNames.get(indexOfContributor), firstNameOfContributor, "Verify Contributor name");
		Verify.verifyEquals(listOfMemberType.get(indexOfContributor), "C", "Verify Member Type for contributor");
		FrameworkLogger.logStep("getBoardCategoriesForValidContributor:-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify that if owner has left the board, he should not able to get the list of board members.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getBoardMembersIfOwnerLeftTheBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getBoardMembersIfOwnerLeftTheBoard:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 2: Now as a owner, leave the board
		LeaveBoardBaseScript.leaveBoardService(boardKey, deviceOwnerInfo);

		// get the response from get board members api
		createHeader();
		ValidatableResponse response = triggerGetApiGetBoardMembers(boardKey);

		// get the api response code for get board members api
		int httpCode = response.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String failureCode = response.extract().path("code");
		Verify.verifyEquals(failureCode, ErrorResponseCodes.ERRORCODE_BINVS0003.getValue(), "Verify failure Code");

		String errorMessage = response.extract().path("error");
		Verify.verifyEquals(errorMessage, "User is not part of Board.", "Verify error message");
		FrameworkLogger.logStep("getBoardMembersIfOwnerLeftTheBoard:-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify that if member has left the board, he should not able to get the list of board members.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getBoardMembersIfMemberLeftTheBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getBoardMembersIfMemberLeftTheBoard:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 2: Now as a owner, leave the board
		LeaveBoardBaseScript.leaveBoardService(boardKey, deviceContributorInfo);

		// get the response from get board members api
		ValidatableResponse response = triggerGetApiGetBoardMembers(boardKey, deviceContributorInfo);

		// get the api response code for get board members api
		int httpCode = response.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String failureCode = response.extract().path("code");
		Verify.verifyEquals(failureCode, ErrorResponseCodes.ERRORCODE_BINVS0003.getValue(), "Verify failure Code");

		String errorMessage = response.extract().path("error");
		Verify.verifyEquals(errorMessage, "User is not part of Board.", "Verify error message");
		FrameworkLogger.logStep("getBoardMembersIfMemberLeftTheBoard:-> End");
	}

	// Need to work on this case after creating script for Remove board member
	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ " verify that if owner has removed the member then that member should not able to get the list of board members.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getBoardMembersIfOwnerRemovedTheMember()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getBoardMembersIfOwnerRemovedTheMember:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 2: Now as a owner, leave the board
		RemoveBoardMembersBaseScript.removeBoardMemberService(boardKey, userIdOfContributor);
		createHeader();

		// get the response from get board members api
		ValidatableResponse response = triggerGetApiGetBoardMembers(boardKey);

		// get the api response code for get board members api
		int httpCode = response.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		List<String> listOfUserIds = getListKeyValuesFromGetMembersOfBoardResponse(response, "userId");
		List<String> listOfUserNames = getListKeyValuesFromGetMembersOfBoardResponse(response, "firstName");
		List<String> listOfMemberType = getListKeyValuesFromGetMembersOfBoardResponse(response, "memberType");

		Verify.verifyEquals(listOfUserIds.get(0), userIdOfOwner, "Verify Owner id");
		Verify.verifyEquals(listOfUserNames.get(0), firstNameOfOwner, "Verify Owner name");
		Verify.verifyEquals(listOfMemberType.get(0), "O", "Verify Member Type for owner");
		Verify.verifyEquals(listOfUserIds.size(), 1, "Verify Contributor id");
		FrameworkLogger.logStep("getBoardMembersIfOwnerRemovedTheMember:-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify that if owner has left the board then other members should not able to see the owner in the list of board members.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getBoardMembersNotVisibleToMemberIfOwnerLeftBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getBoardMembersIfOwnerRemovedTheMember:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		createHeader();
		LeaveBoardBaseScript.leaveBoardService(boardKey);

		ValidatableResponse getBoardMemberResponse = triggerGetApiGetBoardMembers(boardKey, deviceContributorInfo);
		int httpCode = getBoardMemberResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		List<String> listOfUserIds = getListKeyValuesFromGetMembersOfBoardResponse(getBoardMemberResponse, "userId");
		List<String> listOfUserNames = getListKeyValuesFromGetMembersOfBoardResponse(getBoardMemberResponse,
				"firstName");
		List<String> listOfMemberType = getListKeyValuesFromGetMembersOfBoardResponse(getBoardMemberResponse,
				"memberType");
		Verify.verifyEquals(listOfUserIds.get(0), userIdOfContributor, "Verify Owner id");
		Verify.verifyEquals(listOfUserNames.get(0), firstNameOfContributor, "Verify Owner name");
		Verify.verifyEquals(listOfMemberType.get(0), "O", "Verify contributor becomes owner");
		Verify.verifyEquals(listOfUserIds.size(), 1, "Verify Contributor id");
		FrameworkLogger.logStep("getBoardMembersIfOwnerRemovedTheMember:-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ " verify that if member has left the board then owner should not able to see that member in the list of baord members.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getBoardMembersNotVisibleToOwnerIfMemberLeftBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getBoardMembersNotVisibleToOwnerIfMemberLeftBoard:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Step 2: Now as a owner, leave the board
		LeaveBoardBaseScript.leaveBoardService(boardKey, deviceContributorInfo);
		createHeader();

		// get the response from get board members api
		ValidatableResponse getBoardMemberResponse = triggerGetApiGetBoardMembers(boardKey);

		// get the api response code for get board members api
		int httpCode = getBoardMemberResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		List<String> listOfUserIds = getListKeyValuesFromGetMembersOfBoardResponse(getBoardMemberResponse, "userId");
		List<String> listOfUserNames = getListKeyValuesFromGetMembersOfBoardResponse(getBoardMemberResponse,
				"firstName");
		List<String> listOfMemberType = getListKeyValuesFromGetMembersOfBoardResponse(getBoardMemberResponse,
				"memberType");
		Verify.verifyEquals(listOfUserIds.get(0), userIdOfOwner, "Verify contributor id");
		Verify.verifyEquals(listOfUserNames.get(0), firstNameOfOwner, "Verify contributor name");
		Verify.verifyEquals(listOfMemberType.get(0), "O", "Verify Member Type for contributor");
		Verify.verifyEquals(listOfUserIds.size(), 1, "Verify Contributor id");
		FrameworkLogger.logStep("getBoardMembersNotVisibleToOwnerIfMemberLeftBoard:-> End");
	}

	// Need to work on this case after creating script for Remove board member
	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify that if owner has removed the member from the board then owner should not able to see that member in the list of board members.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getBoardMembersNotVisibleToOwnerIfOwnerRemovedThatMember()
			throws IOException, VerificationFailException, InterruptedException {
		System.out.println(" getBoardMembersNotVisibleToOwnerIfOwnerRemovedThatMember:-> Start");
		FrameworkLogger.logStep(" getBoardMembersNotVisibleToOwnerIfOwnerRemovedThatMember:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfSecondContributor, lastNameOfSecondContributor, contactInfoOfSecondContributor,
				"C");
		String invitationCode1 = responseSendInvite1.extract().path("processed[0].inviteCode");

		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		ValidatableResponse response2 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode1,
				deviceSecondContributorInfo);
		createHeader();
		LeaveBoardBaseScript.leaveBoardService(boardKey);

		// get the response from get board members api
		ValidatableResponse getBoardMemberResponse = triggerGetApiGetBoardMembers(boardKey);

		int httpCode = getBoardMemberResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
		String failureCode = getBoardMemberResponse.extract().path("code");
		Verify.verifyEquals(failureCode, "BINVS0003", "Verify failure Code");
		// String errorMessage = getBoardMemberResponse.extract().path("error");
		// Verify.verifyEquals(errorMessage, "User is not part of Board.",
		// "Verify error message");
		FrameworkLogger.logStep("getBoardMembersNotVisibleToOwnerIfOwnerRemovedThatMember:-> End");
	}

	// Need to work on this case after creating script for Remove board member
	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ " verify that if owner has removed the member from the board then members should not able to see that member in the list of board members.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getBoardMembersNotVisibleToMemberIfOwnerRemovedThatMember()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" getBoardMembersNotVisibleToMemberIfOwnerRemovedThatMember:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript
				.sendResendGroupInvitationServiceMethod(boardKey);
		String invitationCode = responseSendInvite.extract().path("inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceSecondContributorInfo);
		ValidatableResponse response2 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);

		createHeader();
		RemoveBoardMembersBaseScript.removeBoardMemberService(boardKey, userIdOfContributor);

		ValidatableResponse getBoardMemberResponse = triggerGetApiGetBoardMembers(boardKey);

		// get the api response code for get board members api
		int httpCode = getBoardMemberResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("getBoardMembersNotVisibleToMemberIfOwnerRemovedThatMember:-> End");
	}

	@Test(priority = 11, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify that members who have declined the invitation should not get listed in the list of members.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getBoardMembersNotVisibleToMemberWhoDeclinedInvitation()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getBoardMembersNotVisibleToMemberWhoDeclinedInvitation:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		DeclineBoardRequestBaseScript.declineInvitationService(invitationCode, deviceContributorInfo);
		createHeader();

		// get the response from get board members api
		ValidatableResponse getBoardMemberResponse = triggerGetApiGetBoardMembers(boardKey, deviceContributorInfo);

		// get the api response code for get board members api
		int httpCode = getBoardMemberResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");

		String failureCode = getBoardMemberResponse.extract().path("code");
		Verify.verifyEquals(failureCode, ErrorResponseCodes.ERRORCODE_BINVS0003.getValue(), "Verify failure Code");

		String errorMessage = getBoardMemberResponse.extract().path("error");
		Verify.verifyEquals(errorMessage, "User is not part of Board.", "Verify error message");

		FrameworkLogger.logStep("getBoardMembersNotVisibleToMemberWhoDeclinedInvitation:-> End");
	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the error code if boardKey in the url is invalid.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void getBoardMembersIfBoardKeyIsInvalid()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getBoardMembersIfBoardKeyIsInvalid:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Send Invitation
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		FrameworkLogger.logStep("INVITECODE:" + invitationCode);

		// Accept Invitation
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		createHeader();

		// get the response from get board members api
		ValidatableResponse response = triggerGetApiGetBoardMembers("abc");

		// get the api response code for get board members api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify failure Status");

		FrameworkLogger.logStep("getBoardMembersIfBoardKeyIsInvalid:-> End");
	}

	@Test(priority = 15, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the error code if boardKey in the url is missing.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void getBoardMembersIfBoardKeyIsMissing()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getBoardMembersIfBoardKeyIsMissing:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Accept invite
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		createHeader();
		// get the response from get board members api
		ValidatableResponse response = triggerGetApiGetBoardMembers("");

		// get the api response code for get board api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE500.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("getBoardMembersIfBoardKeyIsMissing:-> End");
	}

	@Test(priority = 18, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "verify the error code if xuserId is missing.", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void getBoardMembersIfUserIdIsMissing() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("getBoardMembersIfUserIdIsMissing:-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		createHeader();
		headerMap.remove(HeaderParameters.XUSERID.getValue());
		// get the response from get board members api
		ValidatableResponse response = triggerGetApiGetBoardMembers(boardKey);

		// get the api response code for get board members api
		int statusCode1 = response.extract().statusCode();

		// verify that get board members api returns response code as 200
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Success Status");
		FrameworkLogger.logStep("getBoardMembersIfUserIdIsMissing:-> End");
	}
}
