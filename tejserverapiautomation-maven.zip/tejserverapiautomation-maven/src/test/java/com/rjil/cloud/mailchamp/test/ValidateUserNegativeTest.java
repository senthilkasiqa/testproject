package com.rjil.cloud.mailchamp.test;

import java.util.Map;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.mailchamp.common.helper.ValidateUserBaseClass;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.enums.HeaderParameters;

public class ValidateUserNegativeTest extends ValidateUserBaseClass{
	
	public ValidatableResponse response;
	
	@Test (description = "TC_05 - To verify VALIDATE USER API, for Invalid Access-Token",
			groups = {TestNgGroups.REGRESSION})
	public void ainvaliToken(){
		String invalidAuthCode = "cc056a90-4122-11e7-97a9-7d3d3869b009";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),invalidAuthCode );
		
		response = triggerGetApi(getValidateUserUrl(), headerMap);
		int intValidateStatus = response.extract().statusCode();	
		System.out.println("Status Code for invalid AuthCode is: " +intValidateStatus);
		Assert.assertEquals(intValidateStatus, 401);
		}
	
	@Test (description = "TC_06 - To verify VALIDATE USER API, for Invalid X-User-Id.",
			groups = {TestNgGroups.REGRESSION})
		public void bInvalidUSerId(){
		String invalidUserId = "abc123";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),invalidUserId );
		
		response = triggerGetApi(getValidateUserUrl(), headerMap);
		int intValidateStatus = response.extract().statusCode();
		System.out.println("Status Code for Invalid User ID is: " +intValidateStatus);
		Assert.assertEquals(intValidateStatus, 400);
		}

	@Test (description = "TC_07 - To verify VALIDATE USER API, for MISSING X-Mcs-Access-Token",
			groups = {TestNgGroups.REGRESSION})
	public void cinvaliToken(){
		String noAuthCode = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XMCSACCESSTOKEN.getValue(),noAuthCode );
		
		response = triggerGetApi(getValidateUserUrl(), headerMap);
		int intValidateStatus = response.extract().statusCode();	
		System.out.println("Status Code for invalid AuthCode is: " +intValidateStatus);
		Assert.assertEquals(intValidateStatus, 400);
		}
	
	@Test (description = "TC_08 - To verify VALIDATE USER API, for MISSING X-User-Id.",
			groups = {TestNgGroups.REGRESSION})
		public void dmissingToken(){
		String noUserId = "";
		Map<String, String> headerMap=createHeaderMap();
		headerMap.put(HeaderParameters.XUSERID.getValue(),noUserId );
		
		response = triggerGetApi(getValidateUserUrl(), headerMap);
		int intValidateStatus = response.extract().statusCode();
		System.out.println("Status Code for Missing XCode is: " +intValidateStatus);
		Assert.assertEquals(intValidateStatus, 400);
		}
	
/*	@AfterSuite
	(description = "TC_09 - To verify VALIDATE USER API, when Access Token expires after 30 minutes of inactivity.",
			groups = {"SANITY", "REGRESSION"})
		public void evaliadateUserStatusCode() throws InterruptedException 	{
		response = triggerGetApi(getValidateUserUrl(),createHeaderMap());
		Thread.sleep(190000);
		int intvalidateStatus = response.extract().statusCode();	
		System.out.println("Status Code is :" +intvalidateStatus);
		Assert.assertEquals(intvalidateStatus, 401);*/
}
