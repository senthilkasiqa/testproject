/**
 * 
 */
package com.rjil.cloud.tej.api.test.boardinvites;

import java.io.IOException;
import java.util.List;

import org.testng.annotations.Test;

import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apiconstants.NewBoardConstants;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.DeclineBoardRequestBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.GetMembersOfBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.RemoveBoardMembersBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 * 
 *         Test class for Remove board members api
 */
public class RemoveBoardMembersTest extends RemoveBoardMembersBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the success response if owner removes a valid list of members.", groups = {
					TestNgGroups.DEPLOYMENTSANITY })
	public void verifyRemoveBoardMembersIfOwnerRemovesValidBoardMembers()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfOwnerRemovesValidBoardMembers-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// accept invitation
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Accept Invite Status");
		createHeader();
		GetMembersOfBoardBaseScript.getGetBoardMemberService(boardKey);

		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfContributor,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey);
		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Remove Board Member status");
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfOwnerRemovesValidBoardMembers-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the success response if owner removes a valid list of members.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS, TestNgGroups.QASANITY })
	public void verifyRemoveBoardMembersIfOwnerRemovesValidBoardMembersTest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfOwnerRemovesValidBoardMembers-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// accept invitation
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		createHeader();
		GetMembersOfBoardBaseScript.getGetBoardMemberService(boardKey);
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfContributor,
				removeBoardMemberJsonBody);

		// Remove Board Member Api
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey);
		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP code");

		// get the response from get remove board api
		ValidatableResponse getBoardMemberResponse = GetMembersOfBoardBaseScript.getGetBoardMemberService(boardKey);
		List<String> listOfUserIds = GetMembersOfBoardBaseScript
				.getListKeyValuesFromGetMembersOfBoardResponse(getBoardMemberResponse, "userId");
		List<String> listOfUserNames = GetMembersOfBoardBaseScript
				.getListKeyValuesFromGetMembersOfBoardResponse(getBoardMemberResponse, "firstName");
		List<String> listOfMemberType = GetMembersOfBoardBaseScript
				.getListKeyValuesFromGetMembersOfBoardResponse(getBoardMemberResponse, "memberType");
		Verify.verifyEquals(listOfUserIds.size(), 1, "Verify Contributor id");
		Verify.verifyEquals(listOfUserIds.get(0), userIdOfOwner, "Verify Owner id");
		Verify.verifyEquals(listOfUserNames.get(0), firstNameOfOwner, "Verify Owner name");
		Verify.verifyEquals(listOfMemberType.get(0), "O", "Verify Member Type for owner");
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfOwnerRemovesValidBoardMembers-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the success response if member removes owner.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyRemoveBoardMembersIfMemberRemovesOwner()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfMemberRemovesOwner-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfOwner,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey, deviceOwnerInfo);

		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP code");
		String errorCode = removeBoardMembersResponse.extract().path("unprocessed[0].errorCode");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0061.getValue(), "Verify Error Code");
		String errorMessage = removeBoardMembersResponse.extract().path("unprocessed[0].errorMessage");
		Verify.verifyEquals(errorMessage, "User can’t remove himself/herself", "Verify Error message");
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfMemberRemovesOwner-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName
			+ " verify the success response if member removes other members.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyRemoveBoardMembersIfMemberRemovesMember()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfMemberRemovesMember-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfSecondContributor, lastNameOfSecondContributor, contactInfoOfSecondContributor,
				"C");
		String invitationCode1 = responseSendInvite1.extract().path("processed[0].inviteCode");

		// Accept invitation
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode1, deviceSecondContributorInfo);

		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfSecondContributor,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey,
				deviceContributorInfo);

		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP code");
		String errorCode = removeBoardMembersResponse.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0006.getValue(), "Verify Error Code");
		String errorMessage = removeBoardMembersResponse.extract().path("error");
		Verify.verifyEquals(errorMessage, "User is not an active board owner.", "Verify Error Message");

		FrameworkLogger.logStep("verifyRemoveBoardMembersIfMemberRemovesMember-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName
			+ " verify the error message when owner removes himself.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyRemoveBoardMembersIfOwnerRemovesSelf()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfMemberRemovesMember-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Accept Invitation
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfOwner,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey);

		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP code");
		String errorCode = removeBoardMembersResponse.extract().path("unprocessed[0].errorCode");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0061.getValue(), "Verify Error Code");
		String errorMessage = removeBoardMembersResponse.extract().path("unprocessed[0].errorMessage");
		Verify.verifyEquals(errorMessage, "User can’t remove himself/herself", "Verify Error Message");

		FrameworkLogger.logStep("verifyRemoveBoardMembersIfMemberRemovesMember-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the error message when owner tries to remove alredy removed member.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyRemoveBoardMembersIfOwnerRemovesAlreadyRemovedMember()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfOwnerRemovesAlreadyRemovedMember-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// Accept Invitation
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfContributor,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey);

		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP code");

		createHeader();
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfContributor,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse2 = triggerPutApiRemoveBoardMembers(boardKey);
		int httpCode2 = removeBoardMembersResponse2.extract().statusCode();
		Verify.verifyEquals(httpCode2, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP code");

		String errorCode2 = removeBoardMembersResponse2.extract().path("unprocessed[0].errorCode");
		Verify.verifyEquals(errorCode2, ErrorResponseCodes.ERRORCODE_BINVS0003.getValue(), "Verify Error Code");
		String errorMessage2 = removeBoardMembersResponse2.extract().path("unprocessed[0].errorMessage");
		Verify.verifyEquals(errorMessage2, "User is not part of Board.", "Verify Error Message");
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfOwnerRemovesAlreadyRemovedMember-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the error message when owner tried to remove member who have left the board already.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyRemoveBoardMemberIfOwnerTriesToRemoveMemberWhoLeftBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMemberIfOwnerTriesToRemoveMemberWhoLeftBoard-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// leave board
		LeaveBoardBaseScript.leaveBoardService(boardKey, deviceContributorInfo);
		createHeader();
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfContributor,
				removeBoardMemberJsonBody);

		ValidatableResponse removeBoardMembersResponse1 = triggerPutApiRemoveBoardMembers(boardKey);
		int httpCode1 = removeBoardMembersResponse1.extract().statusCode();
		Verify.verifyEquals(httpCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP code");
		String errorCode = removeBoardMembersResponse1.extract().path("unprocessed[0].errorCode");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0003.getValue(), "Verify Error Code");
		String errorMessage = removeBoardMembersResponse1.extract().path("unprocessed[0].errorMessage");
		Verify.verifyEquals(errorMessage, "User is not part of Board.", "Verify Error Message");
		FrameworkLogger.logStep("verifyRemoveBoardMemberIfOwnerTriesToRemoveMemberWhoLeftBoard-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the error message when owner tried to remove member who have declined the request.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyRemoveBoardMemberIfOwnerTriesToRemoveMemberWhoDeclineBoardInvite()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMemberIfOwnerTriesToRemoveMemberWhoLeftBoard-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// decline board invite
		DeclineBoardRequestBaseScript.declineInvitationService(invitationCode, deviceContributorInfo);

		// remove member
		createHeader();
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfContributor,
				removeBoardMemberJsonBody);

		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey);
		int httpCode1 = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP code");
		String errorCode = removeBoardMembersResponse.extract().path("unprocessed[0].errorCode");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0003.getValue(), "Verify Error Code");
		String errorMessage = removeBoardMembersResponse.extract().path("unprocessed[0].errorMessage");
		Verify.verifyEquals(errorMessage, "User is not part of Board.", "Verify Error Message");
		FrameworkLogger.logStep("verifyRemoveBoardMemberIfOwnerTriesToRemoveMemberWhoDeclineBoardInvite-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the success message, when owner left the board then the new owner should able to remove the members.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyRemoveBoardMemberWithNewOwnerRemovesMember()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithNewOwnerRemovesMember-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		ValidatableResponse responseSendInvite2 = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfSecondContributor, lastNameOfSecondContributor, contactInfoOfSecondContributor,
				"C");
		String invitationCode2 = responseSendInvite2.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode2, deviceSecondContributorInfo);
		createHeader();
		LeaveBoardBaseScript.leaveBoardService(boardKey);

		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfSecondContributor,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey,
				deviceContributorInfo);
		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP code");
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithNewOwnerRemovesMember-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the error response if user used in the requet is null", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyRemoveBoardMemberWithNullUserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithNullUserId-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), "", removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey);
		int httpCode1 = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP code");
		String errorCode = removeBoardMembersResponse.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0067.getValue(), "Verify Error Code");
		String errorMessage = removeBoardMembersResponse.extract().path("error");
		Verify.verifyEquals(errorMessage, "Invalid input.Remove member list cannot have null/empty user id.",
				"Verify Error Message");

		FrameworkLogger.logStep("verifyRemoveBoardMemberWithNullUserId-> End");
	}

	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the error response if user used in the requet is invalid", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyRemoveBoardMemberWithInvalidUserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithInvalidUserId-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), getInvalidUserid(),
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey);
		int httpCode1 = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP code");
		String errorCode = removeBoardMembersResponse.extract().path("unprocessed[0].errorCode");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0003.getValue(), "Verify Error Code");
		String errorMessage = removeBoardMembersResponse.extract().path("unprocessed[0].errorMessage");
		Verify.verifyEquals(errorMessage, "User is not part of Board.", "Verify Error Message");

		FrameworkLogger.logStep("verifyRemoveBoardMemberWithInvalidUserId-> End");
	}

	@Test(priority = 11, description = TestNgGroups.BOARDS + ":" + apiName
			+ " verify the error  response if user used in the requet is missing", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyRemoveBoardMemberWithMissingUserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithMissingUserId-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = deleteJsonData(removeBoardMemberJsonBody, NewBoardConstants.getMemberUserId(0));
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey);

		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP code");
		String errorCode = removeBoardMembersResponse.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BINVS0067.getValue(), "Verify Error Code");
		String errorMessage = removeBoardMembersResponse.extract().path("error");
		Verify.verifyEquals(errorMessage, "Invalid input.Remove member list cannot have null/empty user id.",
				"Verify Error Message");
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithMissingUserId-> End");
	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName
			+ " verify the error code if boardKey in the url is invalid.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyRemoveBoardMemberWithInvalidBoardKeyInUrl()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithMissingUserId-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfContributor,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers("vdjksvbdjsd");
		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP code");

		FrameworkLogger.logStep("verifyRemoveBoardMemberWithMissingUserId-> End");
	}

	@Test(priority = 14, description = TestNgGroups.BOARDS + ":" + apiName
			+ " verify the error code if boardKey in the url is missing.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyRemoveBoardMemberWithMissingBoardKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithMissingBoardKey-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfContributor,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers("");
		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP code");
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithMissingBoardKey-> End");
	}

	@Test(priority = 17, description = TestNgGroups.BOARDS + ":" + apiName
			+ " verify the error code if deviceKey is missing.", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void verifyRemoveBoardMemberWithDeviceKeyMissingInUrl()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithDeviceKeyMissingInUrl-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		headerMap.put(HeaderParameters.XDEVICEKEY.getValue(), "");
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfContributor,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey);

		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify HTTP code");
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithDeviceKeyMissingInUrl-> End");

	}

	@Test(priority = 18, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the error code if xuserId is missing.", groups = { TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyRemoveBoardMemberissingUserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithUserIdMissingInUrl-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode, deviceContributorInfo);

		createHeader();
		headerMap.put(HeaderParameters.XUSERID.getValue(), "");
		setRemoveBoardMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfContributor,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey);

		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify HTTP code");
		FrameworkLogger.logStep("verifyRemoveBoardMemberWithUserIdMissingInUrl-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the success response if owner removes a valid list of members.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyRemoveBoardMembersIfOwnerRemovesValidBoardMemberAndInvalidMember()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfOwnerRemovesValidBoardMembers-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// accept invitation
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		createHeader();
		GetMembersOfBoardBaseScript.getGetBoardMemberService(boardKey);

		setRemoveBoardTwoMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfContributor,
				removeBoardMemberJsonBody);
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(1), userIdOfSecondContributor,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey);

		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP code");
		String unprocessUserId = removeBoardMembersResponse.extract().path("unprocessed[0].userId");
		Verify.verifyEquals(unprocessUserId, userIdOfSecondContributor, "Verify unprocessed user id");
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfOwnerRemovesValidBoardMembers-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName
			+ "verify the success response if owner removes a valid list of members.", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void verifyRemoveBoardMembersIfOwnerRemovesValidTwoBoardMember()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep("verifyRemoveBoardMembersIfOwnerRemovesValidBoardMembers-> Start");

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");

		// accept invitation
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		ValidatableResponse responseSendInvite2 = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfSecondContributor, lastNameOfSecondContributor, contactInfoOfSecondContributor,
				"C");
		String invitationCode2 = responseSendInvite2.extract().path("processed[0].inviteCode");

		// accept invitation
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode2, deviceSecondContributorInfo);

		createHeader();
		GetMembersOfBoardBaseScript.getGetBoardMemberService(boardKey);

		setRemoveBoardTwoMembersJsonBody();
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(0), userIdOfContributor,
				removeBoardMemberJsonBody);
		removeBoardMemberJsonBody = setJsonData(NewBoardConstants.getMemberUserId(1), userIdOfSecondContributor,
				removeBoardMemberJsonBody);
		ValidatableResponse removeBoardMembersResponse = triggerPutApiRemoveBoardMembers(boardKey);
		int httpCode = removeBoardMembersResponse.extract().statusCode();
		Verify.verifyEquals(httpCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify HTTP code");

		FrameworkLogger.logStep("verifyRemoveBoardMembersIfOwnerRemovesValidBoardMembers-> End");
	}
}
