package com.rjil.cloud.tej.api.test.boardcomments;

import java.io.IOException;

import org.testng.annotations.Test;

import com.jayway.restassured.module.jsv.JsonSchemaValidator;
import com.jayway.restassured.response.ValidatableResponse;
import com.rjil.cloud.tej.apihelpers.boardcomments.DeleteCommentBaseScript;
import com.rjil.cloud.tej.apihelpers.boardcomments.GetCommentsBaseScript;
import com.rjil.cloud.tej.apihelpers.boardcomments.PostCommentBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.AcceptInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.LeaveBoardBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.RemoveBoardMembersBaseScript;
import com.rjil.cloud.tej.apihelpers.boardinvites.SendResendInvitationBaseScript;
import com.rjil.cloud.tej.apihelpers.boards.CreateBoardBaseScript;
import com.rjil.cloud.tej.common.TestNgGroups;
import com.rjil.cloud.tej.common.Utils;
import com.rjil.cloud.tej.common.VerificationFailException;
import com.rjil.cloud.tej.common.Verify;
import com.rjil.cloud.tej.common.logging.FrameworkLogger;
import com.rjil.cloud.tej.enums.ApiResponseCodes;
import com.rjil.cloud.tej.enums.ErrorResponseCodes;
import com.rjil.cloud.tej.enums.HeaderParameters;
import com.rjil.cloud.tej.enums.RepositoryParameterEnum;

/**
 * @author Prateek
 *
 */
public class DeleteCommentTest extends DeleteCommentBaseScript {

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api for a user who is the owner of the board and deleting his/her own comment", groups = {
					TestNgGroups.DEPLOYMENTSANITY })
	public void testDeleteCommnentsWithValidData() throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnentsWithValidData:-> Start");

		Thread.sleep(10000);
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Post Comment Response");
		String commentKeyOwner = ownerCommentResponse.extract().path("comments[0].commentKey");
		ValidatableResponse response = triggerDeleteApiDeleteComments(boardKey, commentKeyOwner);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(),
				"Verify Delete Comment API reponse");
		FrameworkLogger.logStep("testDeleteCommnentsWithValidData:-> End");
	}

	@Test(priority = 1, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api for a user who is the owner of the board and deleting his/her own comment", groups = {
					TestNgGroups.BOARDS, TestNgGroups.REGRESSION, TestNgGroups.QASANITY })
	public void testDeleteCommnentsWithValidDataTest()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnentsWithValidData:-> Start");
		String ifModifiedSince = System.currentTimeMillis() + "";
		Thread.sleep(10000);

		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");
		String commentKeyOwner = ownerCommentResponse.extract().path("comments[0].commentKey");

		ValidatableResponse response = triggerDeleteApiDeleteComments(boardKey, commentKeyOwner);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Httpt Status");
		// "status": "D",
		String status = response.extract().path("status");
		Verify.verifyEquals(status, "D", "Verify Comment Status");
		String responseBoardkey = response.extract().path("boardKey");
		Verify.verifyEquals(responseBoardkey, boardKey, "Verify Board Key");
		String responseCommentKey = response.extract().path("commentKey");
		Verify.verifyEquals(responseCommentKey, commentKeyOwner, "Verify Comment Key");

		GetCommentsBaseScript.getCommentsService(boardKey, ifModifiedSince);
		response.body(
				JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/deleteCommentTest-Schema.json"));
		FrameworkLogger.logStep("testDeleteCommnentsWithValidData:-> End");
	}

	@Test(priority = 2, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api for a user who is the owner of the board and deleting contributor comment", groups = {
					TestNgGroups.BOARDS, TestNgGroups.REGRESSION })
	public void testDeleteCommnetForOwnerDeletingContributorComment()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnetForOwnerDeletingContributorComment:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		String commentKeyContributor = contributorCommentResponse.extract().path("comments[0].commentKey");
		ValidatableResponse response = triggerDeleteApiDeleteComments(boardKey, commentKeyContributor);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Httpt Status");

		// "status": "D",
		String status = response.extract().path("status");
		Verify.verifyEquals(status, "D", "Verify Comment Status");
		FrameworkLogger.logStep("testDeleteCommnetsWithValidData:-> End");
	}

	@Test(priority = 3, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api for a user who is the contributor of the board and try to delete owner comment", groups = {
					TestNgGroups.BOARDS, TestNgGroups.REGRESSION })
	public void testDeleteCommnetForContributorDeletingOwnerComment()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnetForContributorDeletingOwnerComment:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");
		String commentKeyOwner = ownerCommentResponse.extract().path("comments[0].commentKey");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerDeleteApiDeleteComments(boardKey, commentKeyOwner, deviceContributorInfo);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Http Status");

		String errorCode = response.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BRSOM0155.getValue(), "Verify Error Code");

		String errorMessage = response.extract().path("error");
		Verify.verifyEquals(errorMessage, "Only board owner or member who has posted the comment can delete it.",
				"Verify Error Message");
		FrameworkLogger.logStep("testDeleteCommnetForContributorDeletingOwnerComment:-> End");
	}

	@Test(priority = 4, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api for a owner who leaves the board", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void testDeleteCommnetForOwnerWhoLeavesTheBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnetForOwnerWhoLeavesTheBoard:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");
		String commentKeyOwner = ownerCommentResponse.extract().path("comments[0].commentKey");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		// Leave Board
		LeaveBoardBaseScript.leaveBoardService(boardKey);

		// GetCommentsBaseScript.getCommentsService(boardKey,
		// 1,deviceContributorInfo);
		ValidatableResponse response = triggerDeleteApiDeleteComments(boardKey, commentKeyOwner);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");
		FrameworkLogger.logStep("testDeleteCommnetForOwnerWhoLeavesTheBoard:-> End");
	}

	@Test(priority = 5, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api for a contributor who leaves the board", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void testDeleteCommnetForContributorWhoLeavesTheBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnetForOwnerWhoLeavesTheBoard:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");
		String commentKeyOwner = ownerCommentResponse.extract().path("comments[0].commentKey");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		String commentKeyContributor = contributorCommentResponse.extract().path("comments[0].commentKey");

		LeaveBoardBaseScript.leaveBoardService(boardKey, deviceContributorInfo);
		ValidatableResponse response = triggerDeleteApiDeleteComments(boardKey, commentKeyContributor,
				deviceContributorInfo);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");
		FrameworkLogger.logStep("testDeleteCommnetForOwnerWhoLeavesTheBoard:-> End");
	}

	@Test(priority = 6, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api if owner removes board members", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void testDeleteCommnetForContributorWhoIsRemovedByOwner()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnetForContributorWhoIsRemovedByOwner:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		String commentKeyContributor = contributorCommentResponse.extract().path("comments[0].commentKey");

		// LeaveBoardBaseScript.leaveBoardService(boardKey);
		RemoveBoardMembersBaseScript.removeBoardMemberService(boardKey, userIdOfContributor);

		// GetCommentsBaseScript.getCommentsService(boardKey,
		// 1,deviceContributorInfo);
		ValidatableResponse response = triggerDeleteApiDeleteComments(boardKey, commentKeyContributor,
				deviceContributorInfo);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");
		FrameworkLogger.logStep("testDeleteCommnetForContributorWhoIsRemovedByOwner:-> End");
	}

	@Test(priority = 7, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api with missing board key", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void testDeleteCommnentsWithMissingBoardKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnentsWithValidData:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");
		String commentKeyOwner = ownerCommentResponse.extract().path("comments[0].commentKey");

		ValidatableResponse response = triggerDeleteApiDeleteComments("", commentKeyOwner, false);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE500.getValue(), "Verify Httpt Status");
		FrameworkLogger.logStep("testDeleteCommnentsWithValidData:-> End");
	}

	@Test(priority = 8, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api with invalid board key", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void testDeleteCommnentsWithInvalidBoardKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnentsWithInvalidBoardKey:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");
		String commentKeyOwner = ownerCommentResponse.extract().path("comments[0].commentKey");

		ValidatableResponse response = triggerDeleteApiDeleteComments("a", commentKeyOwner);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");
		FrameworkLogger.logStep("testDeleteCommnentsWithInvalidBoardKey:-> End");
	}

	@Test(priority = 9, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api with missing user id", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void testDeleteCommnentsWithMissingUserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnentsWithMissingUserId:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();

		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");
		String commentKeyOwner = ownerCommentResponse.extract().path("comments[0].commentKey");

		headerMap.remove(HeaderParameters.XUSERID.getValue());

		ValidatableResponse response = triggerDeleteApiDeleteComments(boardKey, commentKeyOwner);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");
		
	/*	 "code": "SCLN0050",
		    "error": "User Id is null/empty or invalid in the request"*/
		FrameworkLogger.logStep("testDeleteCommnentsWithMissingUserId:-> End");
	}

	@Test(priority = 10, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api with invalid user id", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void testDeleteCommnentsWithInvalidUserId()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnentsWithMissingUserId:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");
		String commentKeyOwner = ownerCommentResponse.extract().path("comments[0].commentKey");

		// get the response from getBoardMembers api
		createHeader();
		headerMap.put(HeaderParameters.XUSERID.getValue(), "aknsd");
		ValidatableResponse response = triggerDeleteApiDeleteComments(boardKey, commentKeyOwner);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE401.getValue(), "Verify Httpt Status");
		FrameworkLogger.logStep("testDeleteCommnentsWithMissingUserId:-> End");
		
		/*"code": "TEJGA0401",
	    "error": "Authorization Token Expired or wrong"*/
	}

	@Test(priority = 12, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api with invalid comment key", groups = { TestNgGroups.REGRESSION,
					TestNgGroups.BOARDS })
	public void testDeleteCommnentsWithInvalidCommentKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnentsWithInvalidCommentKey:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// get the response from getBoardMembers api
		ValidatableResponse response = triggerDeleteApiDeleteComments(boardKey, "bcsbc", false);

		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");

		String errorCode = response.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BRSOM0154.getValue(), "Verify Error Code");

		String errorMessage = response.extract().path("error");
		Verify.verifyEquals(errorMessage, "Comment key is missing or invalid.", "Verify Error Message");
		FrameworkLogger.logStep("testDeleteCommnentsWithInvalidCommentKey:-> End");
	}

	@Test(priority = 13, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api with wrong combination of comment key and board key", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void testDeleteCommnentsWithWrongCombinationOfCommentKeyAndBoardKey()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnentsWithWrongCombinationOfCommentKeyAndBoardKey:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode = responseSendInvite.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");
		String commentKeyOwner = ownerCommentResponse.extract().path("comments[0].commentKey");

		CreateBoardBaseScript.createBoardServiceMethod(deviceContributorInfo, boardName);
		String boardKey1 = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		ValidatableResponse response = triggerDeleteApiDeleteComments(boardKey1, commentKeyOwner, false);

		// get the api response code for getBoardMembers api
		int statusCode1 = response.extract().statusCode();
		Verify.verifyEquals(statusCode1, ApiResponseCodes.RESPONSECODE400.getValue(), "Verify Httpt Status");

		String errorCode = response.extract().path("code");
		Verify.verifyEquals(errorCode, ErrorResponseCodes.ERRORCODE_BRSOM0153.getValue(), "Verify Error Code");

		String errorMessage = response.extract().path("error");
		Verify.verifyEquals(errorMessage, "Board and Comment Key mapping not exist.", "Verify Error Message");
		FrameworkLogger.logStep("testDeleteCommnentsWithWrongCombinationOfCommentKeyAndBoardKey:-> End");
	}

	@Test(priority = 14, description = TestNgGroups.BOARDS + ":" + apiName + ":"
			+ "Verify delete comment api for a contributor who is the owner of the board ", groups = {
					TestNgGroups.REGRESSION, TestNgGroups.BOARDS })
	public void testDeleteCommnentsForContributorWhoIsTheOwnerOfBoard()
			throws IOException, VerificationFailException, InterruptedException {
		FrameworkLogger.logStep(" testDeleteCommnentsWithValidData:-> Start");
		// create a board
		String boardName = "Board___" + Utils.getUniqueId();
		CreateBoardBaseScript.createBoardServiceMethod(boardName);
		String boardKey = repositoryMap.get(RepositoryParameterEnum.BOARDKEY.getValue());

		// send an invitation to user
		ValidatableResponse responseSendInvite1 = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfContributor, lastNameOfContributor, contactInfoOfContributor, "C");
		String invitationCode1 = responseSendInvite1.extract().path("processed[0].inviteCode");
		ValidatableResponse response1 = AcceptInvitationBaseScript.acceptInvitationService(invitationCode1,
				deviceContributorInfo);
		int statusCode = response1.extract().statusCode();
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		ValidatableResponse responseSendInvite2 = SendResendInvitationBaseScript.sendResendInvitationServiceMethod(
				boardKey, firstNameOfSecondContributor, lastNameOfSecondContributor, contactInfoOfSecondContributor,
				"C");
		String invitationCode2 = responseSendInvite2.extract().path("processed[0].inviteCode");
		AcceptInvitationBaseScript.acceptInvitationService(invitationCode2, deviceSecondContributorInfo);
		Verify.verifyEquals(statusCode, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Success Status");

		// Owner post comment on Board
		String ownerComment = "Baahubali 1:- Awesome movie....";
		ValidatableResponse ownerCommentResponse = PostCommentBaseScript.postCommentServiceMethod(ownerComment,
				boardKey);
		Verify.verifyEquals(ownerCommentResponse.extract().statusCode(), ApiResponseCodes.RESPONSECODE201.getValue(),
				"Verify Success Status");

		// Contributor post comment
		String contributorComment = "Baahubali 2:- Awesome movie....";
		ValidatableResponse contributorCommentResponse = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment, boardKey);
		Verify.verifyEquals(contributorCommentResponse.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");
		String commentKeyFirstContributor = contributorCommentResponse.extract().path("comments[0].commentKey");

		// Contributor post comment
		String contributorComment1 = "Baahubali 2:- Awesome movie....:-)";
		ValidatableResponse contributorCommentResponse1 = PostCommentBaseScript
				.postCommentServiceMethod(deviceContributorInfo, contributorComment1, boardKey);
		Verify.verifyEquals(contributorCommentResponse1.extract().statusCode(),
				ApiResponseCodes.RESPONSECODE201.getValue(), "Verify Success Status");

		// Leave Board
		LeaveBoardBaseScript.leaveBoardService(boardKey);

		// GetCommentsBaseScript.getCommentsService(boardKey,0,deviceContributorInfo);
		ValidatableResponse response = triggerDeleteApiDeleteComments(boardKey, commentKeyFirstContributor,
				deviceContributorInfo);

		// get the api response code for getBoardMembers api
		int statusCodeDeleteApi = response.extract().statusCode();
		Verify.verifyEquals(statusCodeDeleteApi, ApiResponseCodes.RESPONSECODE200.getValue(), "Verify Httpt Status");
		// "status": "D",
		String status = response.extract().path("status");
		Verify.verifyEquals(status, "D", "Verify Comment Status");

		response.body(
				JsonSchemaValidator.matchesJsonSchemaInClasspath("newBoardTestData/deleteCommentTest-Schema.json"));
		FrameworkLogger.logStep("testDeleteCommnentsWithValidData:-> End");
	}
}
